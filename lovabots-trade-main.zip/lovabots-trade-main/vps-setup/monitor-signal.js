/**
 * Monitor VPS - Sinalização para Lovable Cloud
 * 
 * Este script envia sinais HTTP para a Lovable Cloud a cada 2 segundos.
 * A lógica de monitoramento foi movida para a edge function na Lovable Cloud
 * para contornar problemas de rede no VPS.
 */

require('dotenv').config({ path: '.env.monitor' });

// Configurações
const EDGE_FUNCTION_URL = process.env.EDGE_FUNCTION_URL || 'https://fznytwxyyoaqgslvfnll.supabase.co/functions/v1/monitor-execution';
const MONITOR_API_KEY = process.env.MONITOR_API_KEY;
const SIGNAL_INTERVAL = 2000; // 2 segundos

// Validação
if (!MONITOR_API_KEY) {
  console.error('❌ ERRO: MONITOR_API_KEY não configurada no .env.monitor');
  process.exit(1);
}

// Contadores de estatísticas
let totalSignals = 0;
let successfulSignals = 0;
let failedSignals = 0;
let lastStatus = null;

/**
 * Envia sinal para o monitor na Lovable Cloud
 */
async function sendMonitorSignal() {
  try {
    console.log(`📡 Enviando sinal #${totalSignals + 1} para monitor...`);
    
    const response = await fetch(EDGE_FUNCTION_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-monitor-key': MONITOR_API_KEY
      },
      body: JSON.stringify({
        timestamp: new Date().toISOString(),
        source: 'vps-monitor'
      })
    });

    totalSignals++;

    if (response.ok) {
      const data = await response.json();
      successfulSignals++;
      lastStatus = data.status;
      
      console.log(`✅ Sinal enviado com sucesso! Status: ${data.status}`);
      
      if (data.status === 'skipped') {
        console.log('⏸️ Monitor já está executando, aguardando conclusão...');
      } else if (data.status === 'throttled') {
        console.log('⏸️ Throttle ativo, reduzindo frequência...');
      } else if (data.status === 'processing') {
        console.log('🚀 Monitor iniciado na Lovable Cloud');
      }
    } else {
      failedSignals++;
      console.error(`❌ Erro ao enviar sinal: HTTP ${response.status}`);
      
      if (response.status === 401) {
        console.error('🔑 Chave de API inválida! Verifique MONITOR_API_KEY no .env.monitor');
      }
      
      try {
        const errorData = await response.json();
        console.error('Detalhes:', errorData);
      } catch (e) {
        // Ignorar erro de parse
      }
    }

    // Estatísticas a cada 30 sinais (1 minuto)
    if (totalSignals % 30 === 0) {
      printStatistics();
    }

  } catch (error) {
    failedSignals++;
    totalSignals++;
    console.error(`❌ Erro de rede ao enviar sinal:`, error.message);
  }
}

/**
 * Imprime estatísticas de execução
 */
function printStatistics() {
  const uptime = Math.floor(totalSignals * SIGNAL_INTERVAL / 1000 / 60); // minutos
  const successRate = ((successfulSignals / totalSignals) * 100).toFixed(1);
  
  console.log('\n📊 ═══════════════════════════════════════');
  console.log('📊 ESTATÍSTICAS DO MONITOR');
  console.log('📊 ═══════════════════════════════════════');
  console.log(`⏱️  Tempo ativo: ${uptime} minutos`);
  console.log(`📡 Total de sinais enviados: ${totalSignals}`);
  console.log(`✅ Sinais bem-sucedidos: ${successfulSignals}`);
  console.log(`❌ Sinais com falha: ${failedSignals}`);
  console.log(`📈 Taxa de sucesso: ${successRate}%`);
  console.log(`🎯 Último status: ${lastStatus || 'N/A'}`);
  console.log('📊 ═══════════════════════════════════════\n');
}

/**
 * Cleanup ao encerrar
 */
function handleShutdown() {
  console.log('\n🛑 Encerrando monitor VPS...');
  printStatistics();
  console.log('👋 Monitor VPS encerrado com sucesso!');
  process.exit(0);
}

// Handlers de sinal
process.on('SIGINT', handleShutdown);
process.on('SIGTERM', handleShutdown);
process.on('uncaughtException', (error) => {
  console.error('❌ Exceção não capturada:', error);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Promise rejeitada não tratada:', reason);
});

// Início do monitor
console.log('🚀 ═══════════════════════════════════════');
console.log('🚀 MONITOR VPS - SINALIZAÇÃO LOVABLE CLOUD');
console.log('🚀 ═══════════════════════════════════════');
console.log(`📡 Endpoint: ${EDGE_FUNCTION_URL}`);
console.log(`⏱️  Intervalo: ${SIGNAL_INTERVAL}ms (${SIGNAL_INTERVAL / 1000}s)`);
console.log(`🔑 Chave API: ${MONITOR_API_KEY.substring(0, 8)}...`);
console.log('🚀 ═══════════════════════════════════════\n');

// Executar imediatamente
sendMonitorSignal();

// Configurar intervalo
setInterval(sendMonitorSignal, SIGNAL_INTERVAL);

console.log('✅ Monitor VPS iniciado! Enviando sinais a cada 2 segundos...\n');
