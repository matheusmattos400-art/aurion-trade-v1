# 🔒 Configuração SSL/TLS para WebSocket

## 📌 Problema Identificado

A aplicação Lovable roda em **HTTPS** (seguro), mas o proxy WebSocket no VPS está configurado como **ws://** (inseguro).

Navegadores modernos **bloqueiam** conexões inseguras iniciadas de páginas HTTPS:

```
❌ Failed to construct WebSocket: An insecure WebSocket connection 
   may not be initiated from a page loaded over HTTPS.
```

## ✅ Soluções Disponíveis

### 🚀 Solução 1: Cloudflare Tunnel (RECOMENDADO)
**Tempo:** 5 minutos | **Custo:** Grátis | **Domínio:** Não necessário

📄 **Arquivo:** `QUICK_FIX_WSS.md`

**Vantagens:**
- ✅ Setup ultra-rápido
- ✅ SSL automático  
- ✅ Não precisa de domínio próprio
- ✅ Endpoint permanente e estável
- ✅ Ideal para desenvolvimento e produção

**Resumo dos passos:**
1. Instalar `cloudflared` no VPS
2. Criar tunnel com `cloudflared tunnel create`
3. Configurar rota WebSocket
4. Obter URL `wss://` automaticamente
5. Atualizar `.env` na Lovable

---

### 🔧 Solução 2: Nginx + Let's Encrypt
**Tempo:** 20 minutos | **Custo:** Grátis | **Domínio:** Necessário

📄 **Arquivo:** `WEBSOCKET_SSL_SETUP.md`

**Vantagens:**
- ✅ Controle total
- ✅ Domínio personalizado
- ✅ Certificado SSL renovável
- ✅ Ideal para produção com marca própria

**Resumo dos passos:**
1. Ter um domínio apontando para o VPS
2. Instalar Nginx e Certbot
3. Configurar Nginx como proxy reverso
4. Gerar certificado SSL com Let's Encrypt
5. Atualizar `.env` na Lovable

---

### 🧪 Solução 3: Ngrok
**Tempo:** 2 minutos | **Custo:** Grátis/Pago | **Domínio:** Não necessário

📄 **Arquivo:** `QUICK_FIX_WSS.md`

**Limitações:**
- ⚠️ URL muda toda vez que reinicia (versão grátis)
- ⚠️ Limite de conexões
- ✅ Apenas para testes rápidos

---

## 🎯 Qual Escolher?

| Cenário | Solução Recomendada |
|---------|---------------------|
| Teste rápido local | Ngrok |
| Desenvolvimento | Cloudflare Tunnel ⭐ |
| Produção sem domínio | Cloudflare Tunnel ⭐ |
| Produção com domínio | Nginx + Let's Encrypt |

---

## 📋 Checklist de Implementação

### Antes de começar:
- [ ] VPS está rodando os proxies (porta 3000 REST, 3001 WebSocket)
- [ ] Firewall liberado (portas 80, 443 para SSL; 3000, 3001 para dev)
- [ ] PM2 configurado e rodando

### Após configurar SSL:
- [ ] Endpoint `wss://` funcional
- [ ] Atualizar `.env` na Lovable com `VITE_PROXY_WS_URL=wss://seu-endpoint`
- [ ] Testar conexão no componente `WebSocketTest`
- [ ] Verificar logs: sem erros de "mixed content"
- [ ] Confirmar recebimento de dados do Binance

---

## 🧪 Como Testar

### 1. Console do Navegador
Abra o DevTools na Lovable e teste:

```javascript
const ws = new WebSocket('wss://SEU_ENDPOINT_AQUI');
ws.onopen = () => console.log('✅ Conectado com SSL!');
ws.onerror = (e) => console.error('❌ Erro:', e);
ws.onmessage = (m) => console.log('📩 Mensagem:', m.data);
```

Se conectar sem erros: **Sucesso!** ✅

### 2. Componente WebSocketTest
Na aplicação Lovable:
1. Acesse a página inicial
2. Role até o card "Teste WebSocket Binance"
3. Clique em "Conectar"
4. Verifique o status: deve mostrar "Conectado" 🟢

---

## 🛠️ Troubleshooting

### Erro: "WebSocket connection failed"
**Causa:** Endpoint incorreto ou proxy offline

**Solução:**
```bash
# No VPS, verificar se proxy está rodando
pm2 status
pm2 logs binance-proxy-websocket

# Testar endpoint
curl -i https://SEU_ENDPOINT
```

### Erro: "SSL certificate problem"
**Causa:** Certificado inválido ou expirado

**Solução Cloudflare:** Não se aplica (certificado automático)

**Solução Nginx:**
```bash
sudo certbot certificates  # Ver status
sudo certbot renew        # Renovar manualmente
```

### WebSocket conecta mas fecha imediatamente
**Causa:** ListenKey inválido ou proxy não alcança Binance

**Solução:**
```bash
# Verificar logs do proxy
pm2 logs binance-proxy-websocket --lines 100

# Verificar SOCKS5
systemctl status danted

# Testar conectividade
telnet fstream.binance.com 443
```

---

## 📞 Próximos Passos

1. **Escolha uma solução** (recomendamos Cloudflare Tunnel)
2. **Siga o guia** correspondente (QUICK_FIX_WSS.md ou WEBSOCKET_SSL_SETUP.md)
3. **Teste a conexão** no WebSocketTest
4. **Comece a receber** atualizações de PnL em tempo real! 🎉

---

## 📚 Arquivos de Referência

- 📄 `QUICK_FIX_WSS.md` - Solução rápida com Cloudflare Tunnel ou Ngrok
- 📄 `WEBSOCKET_SSL_SETUP.md` - Configuração completa Nginx + Let's Encrypt
- 📄 `WEBSOCKET_SETUP.md` - Configuração básica do proxy (sem SSL)
- 📄 `INSTALACAO.md` - Instalação inicial do VPS e proxies

---

## 🔐 Segurança

Independente da solução escolhida, certifique-se de:

- ✅ Usar `wss://` (WebSocket Seguro) na Lovable
- ✅ Manter credenciais SOCKS5 seguras
- ✅ Configurar firewall adequadamente
- ✅ Monitorar logs regularmente
- ✅ Manter certificados SSL atualizados (renovação automática)

---

**Dúvidas?** Consulte os arquivos de documentação detalhados! 📖
