const { Client } = require('pg');
const SocksProxyAgent = require('socks-proxy-agent');
const https = require('https');
const crypto = require('crypto');

// Configuração do banco de dados
const DB_CONNECTION_STRING = process.env.DATABASE_URL;

// Configuração SOCKS5
const SOCKS_HOST = process.env.SOCKS_HOST || 'localhost';
const SOCKS_PORT = process.env.SOCKS_PORT || 1080;
const SOCKS_USER = process.env.SOCKS_USER;
const SOCKS_PASS = process.env.SOCKS_PASS;

// Configuração Binance
const BINANCE_API_KEY = process.env.BINANCE_API_KEY;
const BINANCE_API_SECRET = process.env.BINANCE_API_SECRET;

// Intervalo de verificação (2 segundos para máxima velocidade)
const CHECK_INTERVAL = 2000;

console.log('🚀 Iniciando monitor de fechamento automático...');
console.log(`📊 Intervalo de verificação: ${CHECK_INTERVAL}ms`);

// Criar agente SOCKS5
const socksAgent = new SocksProxyAgent({
  host: SOCKS_HOST,
  port: SOCKS_PORT,
  userId: SOCKS_USER,
  password: SOCKS_PASS
});

// Função para criar assinatura Binance
function createSignature(queryString, secret) {
  return crypto
    .createHmac('sha256', secret)
    .update(queryString)
    .digest('hex');
}

// Função para fazer request na Binance via SOCKS5
async function binanceRequest(endpoint, params = {}) {
  const timestamp = Date.now();
  const queryParams = { ...params, timestamp };
  const queryString = Object.keys(queryParams)
    .map(key => `${key}=${queryParams[key]}`)
    .join('&');
  
  const signature = createSignature(queryString, BINANCE_API_SECRET);
  const fullQuery = `${queryString}&signature=${signature}`;
  
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'fapi.binance.com',
      path: `${endpoint}?${fullQuery}`,
      method: 'GET',
      agent: socksAgent,
      headers: {
        'X-MBX-APIKEY': BINANCE_API_KEY
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`Parse error: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.setTimeout(10000, () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
    req.end();
  });
}

// Função para cancelar todas as ordens abertas de um símbolo
async function cancelAllOrders(symbol) {
  const timestamp = Date.now();
  const params = { symbol, timestamp };

  const queryString = Object.keys(params)
    .map(key => `${key}=${params[key]}`)
    .join('&');
  
  const signature = createSignature(queryString, BINANCE_API_SECRET);
  const fullQuery = `${queryString}&signature=${signature}`;

  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'fapi.binance.com',
      path: `/fapi/v1/allOpenOrders?${fullQuery}`,
      method: 'DELETE',
      agent: socksAgent,
      headers: {
        'X-MBX-APIKEY': BINANCE_API_KEY
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          console.log(`🗑️  Ordens canceladas para ${symbol}:`, result.code ? result.msg : 'Sucesso');
          resolve(result);
        } catch (e) {
          reject(new Error(`Parse error: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.setTimeout(10000, () => {
      req.destroy();
      reject(new Error('Cancel orders timeout'));
    });
    req.end();
  });
}

// Função para fechar posição na Binance
async function closePosition(symbol, side) {
  const timestamp = Date.now();
  const params = {
    symbol,
    side: side === 'LONG' ? 'SELL' : 'BUY',
    type: 'MARKET',
    reduceOnly: 'true',
    timestamp
  };

  const queryString = Object.keys(params)
    .map(key => `${key}=${params[key]}`)
    .join('&');
  
  const signature = createSignature(queryString, BINANCE_API_SECRET);
  const fullQuery = `${queryString}&signature=${signature}`;

  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'fapi.binance.com',
      path: `/fapi/v1/order?${fullQuery}`,
      method: 'POST',
      agent: socksAgent,
      headers: {
        'X-MBX-APIKEY': BINANCE_API_KEY
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`Parse error: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.setTimeout(15000, () => {
      req.destroy();
      reject(new Error('Close position timeout'));
    });
    req.end();
  });
}

// Função para buscar posições ativas da Binance
async function getBinancePositions() {
  try {
    const positions = await binanceRequest('/fapi/v2/positionRisk');
    return positions.filter(p => parseFloat(p.positionAmt) !== 0);
  } catch (error) {
    console.error('❌ Erro ao buscar posições Binance:', error.message);
    return [];
  }
}

// Função para calcular PnL atual
function calculatePnL(position, currentPrice, entryPrice, investmentAmount, leverage) {
  if (!entryPrice || entryPrice === 0) return 0;
  
  const positionAmt = parseFloat(position.positionAmt);
  const side = positionAmt > 0 ? 'LONG' : 'SHORT';
  
  const priceDiff = side === 'LONG' 
    ? currentPrice - entryPrice 
    : entryPrice - currentPrice;
  
  const pnlPercent = (priceDiff / entryPrice) * 100 * leverage;
  return (investmentAmount * pnlPercent) / 100;
}

// Função principal de monitoramento
async function monitorOperations() {
  const client = new Client({ connectionString: DB_CONNECTION_STRING });
  
  try {
    await client.connect();
    
    // Buscar operações ativas com auto_close_enabled
    const result = await client.query(`
      SELECT * FROM active_operations 
      WHERE status = 'active' 
      AND auto_close_enabled = true
      AND profit_target IS NOT NULL
    `);

    if (result.rows.length === 0) {
      return;
    }

    console.log(`📋 Monitorando ${result.rows.length} operação(ões) ativa(s)`);

    // Buscar posições atuais da Binance
    const binancePositions = await getBinancePositions();
    
    for (const operation of result.rows) {
      try {
        const longPosition = binancePositions.find(p => p.symbol === operation.long_symbol);
        const shortPosition = binancePositions.find(p => p.symbol === operation.short_symbol);

        if (!longPosition || !shortPosition) {
          console.log(`⚠️  Posições não encontradas para operação ${operation.id}`);
          continue;
        }

        // Calcular PnL total
        const longPrice = parseFloat(longPosition.markPrice);
        const shortPrice = parseFloat(shortPosition.markPrice);
        
        const longPnL = calculatePnL(
          longPosition, 
          longPrice, 
          operation.entry_price_long, 
          operation.investment_amount / 2,
          operation.leverage_long
        );
        
        const shortPnL = calculatePnL(
          shortPosition, 
          shortPrice, 
          operation.entry_price_short, 
          operation.investment_amount / 2,
          operation.leverage_short
        );

        const totalPnL = longPnL + shortPnL;
        const profitPercent = (totalPnL / operation.investment_amount) * 100;

        console.log(`💰 Op ${operation.id.substring(0, 8)}: PnL $${totalPnL.toFixed(2)} (${profitPercent.toFixed(2)}%) | Meta: ${operation.profit_target}%`);

        // Verificar se atingiu a meta
        if (profitPercent >= operation.profit_target) {
          console.log(`🎯 META ATINGIDA! Fechando operação ${operation.id}`);
          
          // Primeiro, cancelar todas as ordens limite pendentes
          console.log(`🗑️  Cancelando ordens limite pendentes...`);
          await Promise.allSettled([
            cancelAllOrders(operation.long_symbol),
            cancelAllOrders(operation.short_symbol)
          ]);
          
          // Depois, fechar posições a mercado
          const closeResults = await Promise.allSettled([
            closePosition(operation.long_symbol, 'LONG'),
            closePosition(operation.short_symbol, 'SHORT')
          ]);

          const longClosed = closeResults[0].status === 'fulfilled';
          const shortClosed = closeResults[1].status === 'fulfilled';

          if (longClosed && shortClosed) {
            console.log(`✅ Posições fechadas com sucesso`);
            
            // Atualizar banco de dados
            await client.query(`
              UPDATE active_operations 
              SET status = 'closed', 
                  current_pnl = $1,
                  updated_at = NOW()
              WHERE id = $2
            `, [totalPnL, operation.id]);

            // Registrar no histórico
            const startedAt = new Date(operation.started_at);
            const duration = Math.floor((Date.now() - startedAt.getTime()) / 1000);

            await client.query(`
              INSERT INTO trade_history (
                user_id, long_symbol, short_symbol, 
                investment_amount, leverage, leverage_long, leverage_short,
                profit, started_at, duration_seconds, is_test
              ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            `, [
              operation.user_id,
              operation.long_symbol,
              operation.short_symbol,
              operation.investment_amount,
              operation.leverage,
              operation.leverage_long,
              operation.leverage_short,
              totalPnL,
              operation.started_at,
              duration,
              operation.is_test || false
            ]);

            console.log(`📊 Histórico registrado`);
          } else {
            console.error(`❌ Erro ao fechar posições:`, {
              long: closeResults[0],
              short: closeResults[1]
            });
          }
        }
      } catch (error) {
        console.error(`❌ Erro ao processar operação ${operation.id}:`, error.message);
      }
    }
  } catch (error) {
    console.error('❌ Erro no monitoramento:', error.message);
  } finally {
    await client.close();
  }
}

// Iniciar monitoramento contínuo
console.log('✅ Monitor iniciado com sucesso!\n');
setInterval(monitorOperations, CHECK_INTERVAL);

// Executar primeira verificação imediatamente
monitorOperations();

// Handlers de erro
process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error);
});

process.on('unhandledRejection', (error) => {
  console.error('❌ Unhandled Rejection:', error);
});
