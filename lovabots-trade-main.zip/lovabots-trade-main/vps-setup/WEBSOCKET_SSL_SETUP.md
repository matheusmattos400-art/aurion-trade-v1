# Configuração SSL/TLS para WebSocket Proxy

## Problema

A Lovable roda em HTTPS (seguro), mas o WebSocket estava configurado como `ws://` (inseguro). Navegadores modernos bloqueiam conexões inseguras iniciadas de páginas HTTPS com o erro:

```
Failed to construct WebSocket: An insecure WebSocket connection may not be initiated from a page loaded over HTTPS.
```

## Solução: Nginx como Proxy Reverso com SSL

Vamos configurar o Nginx para:
1. Receber conexões `wss://` (WebSocket Seguro) na porta 443
2. Fazer túnel para o proxy WebSocket local `ws://localhost:3001`
3. Usar certificado SSL gratuito do Let's Encrypt

---

## Passo 1: Instalar Nginx e Certbot

```bash
sudo apt update
sudo apt install nginx certbot python3-certbot-nginx -y
```

---

## Passo 2: Configurar Nginx para WebSocket

Crie o arquivo de configuração:

```bash
sudo nano /etc/nginx/sites-available/websocket-proxy
```

Cole a seguinte configuração (substitua `SEU_DOMINIO.com` pelo seu domínio):

```nginx
# Proxy WebSocket Seguro
server {
    listen 443 ssl http2;
    server_name SEU_DOMINIO.com;  # Substitua pelo seu domínio

    # Certificados SSL (serão gerados automaticamente pelo Certbot)
    ssl_certificate /etc/letsencrypt/live/SEU_DOMINIO.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/SEU_DOMINIO.com/privkey.pem;
    
    # Configurações SSL modernas
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # WebSocket Proxy
    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        
        # Headers necessários para WebSocket
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeouts para conexões longas
        proxy_read_timeout 86400;
        proxy_send_timeout 86400;
    }
}

# Redirecionar HTTP para HTTPS
server {
    listen 80;
    server_name SEU_DOMINIO.com;
    return 301 https://$server_name$request_uri;
}
```

Ative a configuração:

```bash
sudo ln -s /etc/nginx/sites-available/websocket-proxy /etc/nginx/sites-enabled/
sudo nginx -t  # Testar configuração
```

---

## Passo 3: Obter Certificado SSL com Let's Encrypt

```bash
sudo certbot --nginx -d SEU_DOMINIO.com
```

O Certbot irá:
1. Verificar seu domínio
2. Gerar certificado SSL gratuito
3. Configurar renovação automática

Siga as instruções interativas (forneça email, aceite os termos).

---

## Passo 4: Iniciar Nginx

```bash
sudo systemctl enable nginx
sudo systemctl start nginx
sudo systemctl status nginx
```

---

## Passo 5: Configurar Firewall

Abra as portas 80 (HTTP) e 443 (HTTPS):

```bash
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw reload
```

---

## Passo 6: Atualizar Variável de Ambiente na Lovable

No arquivo `.env` da Lovable, atualize para usar `wss://` (WebSocket Seguro):

```env
VITE_PROXY_WS_URL=wss://SEU_DOMINIO.com
```

**Importante:** 
- Use `wss://` (não `ws://`)
- Use seu domínio (não IP)
- Não inclua a porta `:3001` (Nginx escuta na porta 443 padrão)

---

## Passo 7: Testar Conexão

No navegador da Lovable, teste a conexão WebSocket. Deve conectar sem erros de segurança.

Logs do Nginx:
```bash
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

---

## Arquitetura Final

```
Lovable (HTTPS) 
    ↓ wss://SEU_DOMINIO.com
    ↓
Nginx (porta 443, SSL)
    ↓ ws://localhost:3001 (túnel interno)
    ↓
Proxy WebSocket (porta 3001)
    ↓ SOCKS5 → Binance
```

---

## Solução de Problemas

### Erro: "502 Bad Gateway"
- Verifique se o proxy WebSocket está rodando na porta 3001:
  ```bash
  pm2 list
  pm2 logs binance-proxy-websocket
  ```

### Erro: Certificado inválido
- Verifique se o certificado foi gerado:
  ```bash
  sudo certbot certificates
  ```
- Renove manualmente se necessário:
  ```bash
  sudo certbot renew
  ```

### Erro: Domínio não resolve
- Verifique os registros DNS do seu domínio
- Aguarde propagação (pode levar até 48h)
- Teste com `dig SEU_DOMINIO.com` ou `nslookup SEU_DOMINIO.com`

### WebSocket fecha imediatamente
- Verifique logs do proxy:
  ```bash
  pm2 logs binance-proxy-websocket --lines 100
  ```
- Verifique logs do Nginx:
  ```bash
  sudo tail -f /var/log/nginx/error.log
  ```

---

## Renovação Automática de Certificado

O Certbot configura renovação automática via cron/systemd. Para testar:

```bash
sudo certbot renew --dry-run
```

---

## Alternativa: Cloudflare Tunnel (sem domínio próprio)

Se você não tem domínio, pode usar Cloudflare Tunnel gratuitamente:

1. Instale cloudflared:
```bash
wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared-linux-amd64.deb
```

2. Configure tunnel:
```bash
cloudflared tunnel login
cloudflared tunnel create binance-ws
cloudflared tunnel route dns binance-ws SEU_SUBDOMINIO.trycloudflare.com
```

3. Crie config:
```yaml
# ~/.cloudflared/config.yml
tunnel: ID_DO_TUNNEL
credentials-file: /root/.cloudflared/ID_DO_TUNNEL.json

ingress:
  - hostname: SEU_SUBDOMINIO.trycloudflare.com
    service: ws://localhost:3001
  - service: http_status:404
```

4. Execute:
```bash
cloudflared tunnel run binance-ws
```

Isso criará um endpoint `wss://SEU_SUBDOMINIO.trycloudflare.com` seguro automaticamente.

---

## Segurança

- **Firewall:** Mantenha apenas portas 80, 443, 22 abertas
- **SSH:** Use autenticação por chave, desabilite senha
- **Certificado:** Renovação automática configurada pelo Certbot
- **Nginx:** Configurado com TLS 1.2/1.3 e ciphers modernos
