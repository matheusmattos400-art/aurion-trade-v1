# Monitor de Fechamento Automático - Setup VPS

Este sistema monitora operações ativas no banco de dados e fecha automaticamente as posições na Binance quando a meta de lucro é atingida, **mesmo com você offline**.

## 🚀 Características

- ✅ Monitoramento a cada 2 segundos (máxima velocidade)
- ✅ Funciona 24/7, mesmo com você offline
- ✅ Fecha posições automaticamente ao atingir a meta
- ✅ Registra histórico de trades automaticamente
- ✅ Usa o proxy SOCKS5 já configurado
- ✅ Logs detalhados para debug

## 📋 Pré-requisitos

- VPS com proxy SOCKS5 já configurado
- Node.js 18+ instalado
- PM2 instalado globalmente
- Credenciais Binance API
- Acesso ao banco de dados Supabase

## 🔧 Instalação

### 1. Instalar dependências adicionais

```bash
cd /opt/binance-proxy
npm install pg socks-proxy-agent
```

### 2. Configurar variáveis de ambiente

Copie o arquivo de exemplo e configure:

```bash
cp .env.monitor.example .env.monitor
nano .env.monitor
```

Configure as variáveis:

```bash
# Database Connection
DATABASE_URL=postgresql://postgres.fznytwxyyoaqgslvfnll:[SUA-SENHA]@aws-0-us-east-1.pooler.supabase.com:6543/postgres

# SOCKS5 Proxy (já configurado)
SOCKS_HOST=localhost
SOCKS_PORT=1080
SOCKS_USER=seu_usuario_socks
SOCKS_PASS=sua_senha_socks

# Binance API (use as mesmas credenciais do .env)
BINANCE_API_KEY=sua_chave_api
BINANCE_API_SECRET=seu_secret_api
```

### 3. Copiar arquivos para o VPS

```bash
# No seu computador local
scp vps-setup/auto-close-monitor.js root@seu-vps:/opt/binance-proxy/
scp vps-setup/.env.monitor.example root@seu-vps:/opt/binance-proxy/
```

### 4. Atualizar configuração PM2

```bash
# Copiar nova configuração PM2
scp vps-setup/ecosystem.config.js root@seu-vps:/opt/binance-proxy/

# No VPS, reiniciar PM2
ssh root@seu-vps
cd /opt/binance-proxy
pm2 delete all
pm2 start ecosystem.config.js
pm2 save
```

## 🎯 Como funciona

1. **Monitoramento contínuo**: O script verifica o banco de dados a cada 5 segundos
2. **Busca operações ativas**: Encontra operações com `status='active'` e `auto_close_enabled=true`
3. **Consulta Binance**: Busca posições atuais e preços de mercado via SOCKS5
4. **Calcula PnL**: Calcula o lucro/prejuízo em tempo real
5. **Verifica meta**: Compara PnL% com `profit_target`
6. **Fecha posições**: Quando meta atingida, fecha LONG e SHORT a mercado
7. **Registra histórico**: Salva no `trade_history` automaticamente

## 📊 Monitoramento

### Ver logs em tempo real

```bash
# Logs do monitor
pm2 logs auto-close-monitor

# Apenas erros
pm2 logs auto-close-monitor --err

# Últimas 100 linhas
pm2 logs auto-close-monitor --lines 100
```

### Verificar status

```bash
pm2 status
pm2 info auto-close-monitor
```

### Ver métricas

```bash
pm2 monit
```

## 🔍 Troubleshooting

### Monitor não inicia

```bash
# Verificar logs de erro
pm2 logs auto-close-monitor --err

# Verificar .env.monitor
cat /opt/binance-proxy/.env.monitor

# Testar conexão banco de dados
node -e "const {Client} = require('pg'); const c = new Client({connectionString: process.env.DATABASE_URL}); c.connect().then(() => console.log('✅ DB OK')).catch(e => console.error('❌', e));"
```

### Posições não fecham

```bash
# Verificar se operação tem auto_close_enabled
psql $DATABASE_URL -c "SELECT id, auto_close_enabled, profit_target FROM active_operations WHERE status='active';"

# Verificar logs detalhados
pm2 logs auto-close-monitor --lines 200
```

### Erro de conexão Binance

```bash
# Testar SOCKS5
curl --socks5 localhost:1080 --socks5-user seu_user:sua_senha https://fapi.binance.com/fapi/v1/ping

# Verificar credenciais Binance no .env.monitor
```

## 🎛️ Comandos úteis

```bash
# Reiniciar monitor
pm2 restart auto-close-monitor

# Parar monitor
pm2 stop auto-close-monitor

# Iniciar monitor
pm2 start auto-close-monitor

# Ver configuração
pm2 show auto-close-monitor

# Limpar logs
pm2 flush auto-close-monitor
```

## ⚙️ Configurações avançadas

### Alterar intervalo de verificação

Edite `auto-close-monitor.js`:

```javascript
// Verificar a cada 3 segundos (mais rápido)
const CHECK_INTERVAL = 3000;

// Verificar a cada 10 segundos (menos recursos)
const CHECK_INTERVAL = 10000;
```

### Adicionar notificações

Você pode adicionar notificações via Telegram, Discord, etc. quando a meta for atingida editando a função `monitorOperations()`.

## 🔒 Segurança

- ✅ Variáveis sensíveis em arquivo `.env.monitor` separado
- ✅ Conexão Binance via SOCKS5 (IP whitelist mantido)
- ✅ Conexão database via SSL automática
- ✅ Logs rotacionados automaticamente pelo PM2

## 📈 Performance

- **Latência média**: ~100-300ms por verificação
- **Uso de memória**: ~50-100MB
- **CPU**: <5% em idle, ~10-15% durante verificações
- **Intervalo**: 5 segundos (configurável)

## 💾 Backup logs

```bash
# Backup manual dos logs
tar -czf monitor-logs-$(date +%Y%m%d).tar.gz /var/log/auto-close-monitor-*.log

# Configurar backup automático diário (crontab)
0 0 * * * tar -czf /root/backups/monitor-logs-$(date +\%Y\%m\%d).tar.gz /var/log/auto-close-monitor-*.log
```

## 🆘 Suporte

Se encontrar problemas:

1. Verifique logs: `pm2 logs auto-close-monitor --lines 200`
2. Verifique status: `pm2 status`
3. Teste conexões: database e SOCKS5
4. Verifique credenciais no `.env.monitor`

## 🎯 Resultado Esperado

Com o monitor ativo, suas operações serão fechadas automaticamente quando atingirem a meta de lucro, **mesmo que você esteja offline**. Você verá nos logs:

```
📋 Monitorando 1 operação(ões) ativa(s)
💰 Op 12345678: PnL $45.23 (9.87%) | Meta: 10%
💰 Op 12345678: PnL $51.80 (10.36%) | Meta: 10%
🎯 META ATINGIDA! Fechando operação 12345678-...
✅ Posições fechadas com sucesso
📊 Histórico registrado
```
