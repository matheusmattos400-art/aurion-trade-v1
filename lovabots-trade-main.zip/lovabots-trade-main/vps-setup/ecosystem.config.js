module.exports = {
  apps: [
    {
      name: 'binance-proxy-http',
      script: 'proxy-server-socks5.js',
      cwd: '/opt/binance-proxy',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env_file: '.env',
      error_file: '/var/log/binance-proxy-http-error.log',
      out_file: '/var/log/binance-proxy-http-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      time: true
    },
    {
      name: 'binance-proxy-websocket',
      script: 'proxy-websocket.js',
      cwd: '/opt/binance-proxy',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env_file: '.env',
      error_file: '/var/log/binance-proxy-ws-error.log',
      out_file: '/var/log/binance-proxy-ws-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      time: true
    },
    {
      name: 'monitor-signal',
      script: 'monitor-signal.js',
      cwd: '/opt/binance-proxy',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '100M',
      env_file: '.env.monitor',
      error_file: '/var/log/monitor-signal-error.log',
      out_file: '/var/log/monitor-signal-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      time: true
    }
  ]
};
