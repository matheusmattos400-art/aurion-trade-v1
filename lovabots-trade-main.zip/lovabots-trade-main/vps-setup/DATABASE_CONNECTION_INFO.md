# 🔗 Informações de Conexão com o Banco de Dados

## 📋 Credenciais do Projeto Lovable Cloud

Baseado no seu projeto `fznytwxyyoaqgslvfnll`:

| Credencial | Valor | Descrição |
|------------|-------|-----------|
| **Host** | `aws-0-us-east-1.pooler.supabase.com` | Servidor do banco de dados |
| **Porta** | `6543` | Porta do connection pooler (recomendado) |
| **Porta Direta** | `5432` | Porta de conexão direta (alternativa) |
| **Database** | `postgres` | Nome do banco de dados |
| **Usuário** | `postgres.fznytwxyyoaqgslvfnll` | Usuário com acesso ao banco |
| **Project Ref** | `fznytwxyyoaqgslvfnll` | Referência do projeto |

## 🔐 Como Obter a Senha

### Opção 1: Via Lovable Cloud UI
1. Acesse **Settings** → **Database** no Lovable Cloud
2. Procure por **"Connection String"** ou **"PostgreSQL Connection String"**
3. Copie a string completa que aparecerá no formato:
   ```
   postgresql://postgres.fznytwxyyoaqgslvfnll:[SUA-SENHA]@aws-0-us-east-1.pooler.supabase.com:6543/postgres
   ```

### Opção 2: Reset da Senha (se necessário)
Se você não encontrar a senha:
1. Vá em **Settings** → **Database**
2. Procure por **"Reset Database Password"**
3. Copie a nova senha gerada

## 📝 Formato Final para .env.monitor

Após obter a senha, preencha o arquivo `vps-setup/.env.monitor` com:

```bash
# Database Connection (Supabase/Lovable Cloud)
DATABASE_URL=postgresql://postgres.fznytwxyyoaqgslvfnll:[COLE_SUA_SENHA_AQUI]@aws-0-us-east-1.pooler.supabase.com:6543/postgres

# SOCKS5 Proxy Configuration
SOCKS_HOST=localhost
SOCKS_PORT=1080
SOCKS_USER=your_socks_user
SOCKS_PASS=your_socks_password

# Binance API Credentials
BINANCE_API_KEY=your_binance_api_key
BINANCE_API_SECRET=your_binance_api_secret
```

## ✅ Teste de Conexão

Após configurar, teste a conexão no VPS (104.248.136.155):

```bash
# Instale o cliente PostgreSQL (se ainda não tiver)
sudo apt-get install -y postgresql-client

# Teste a conexão (substitua [SUA-SENHA])
psql "postgresql://postgres.fznytwxyyoaqgslvfnll:[SUA-SENHA]@aws-0-us-east-1.pooler.supabase.com:6543/postgres" -c "SELECT COUNT(*) FROM active_operations;"
```

Se retornar `213` (número de linhas que você viu), a conexão está funcionando! ✅

## 🚀 Próximos Passos

1. ✅ Obter a senha via Settings → Database
2. ✅ Preencher `.env.monitor` com DATABASE_URL completa
3. ✅ Adicionar suas credenciais SOCKS5 e Binance
4. ✅ Fazer upload do `.env.monitor` para o VPS em `/opt/binance-proxy/`
5. ✅ Iniciar o monitor com PM2: `pm2 restart auto-close-monitor`

## 🔒 Segurança

⚠️ **IMPORTANTE**:
- Nunca compartilhe a senha do banco publicamente
- O arquivo `.env.monitor` deve ter permissões restritas: `chmod 600 .env.monitor`
- O usuário `postgres.fznytwxyyoaqgslvfnll` tem acesso completo, mas o RLS (Row Level Security) ainda protege os dados por usuário
