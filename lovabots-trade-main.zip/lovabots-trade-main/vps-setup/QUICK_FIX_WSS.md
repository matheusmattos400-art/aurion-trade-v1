# Solução Rápida: WebSocket Seguro (wss://)

## Problema
A Lovable está em HTTPS mas tentando conectar a `ws://` (inseguro), causando o erro:
```
Failed to construct WebSocket: An insecure WebSocket connection may not be initiated from a page loaded over HTTPS.
```

## Solução Rápida 1: Cloudflare Tunnel (Recomendado - Sem domínio necessário)

### Vantagens
✅ Gratuito  
✅ SSL automático  
✅ Sem domínio próprio necessário  
✅ Setup em 5 minutos  

### Passos

1. **Instalar cloudflared no VPS:**
```bash
wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared-linux-amd64.deb
```

2. **Fazer login:**
```bash
cloudflared tunnel login
```
(Abrirá navegador - faça login na Cloudflare)

3. **Criar tunnel:**
```bash
cloudflared tunnel create binance-ws
```
(Anote o ID do tunnel que será mostrado)

4. **Criar arquivo de configuração:**
```bash
mkdir -p ~/.cloudflared
nano ~/.cloudflared/config.yml
```

Cole:
```yaml
tunnel: SEU_TUNNEL_ID_AQUI
credentials-file: /root/.cloudflared/SEU_TUNNEL_ID_AQUI.json

ingress:
  - hostname: binance-ws.SEUCONTA.trycloudflare.com
    service: ws://localhost:3001
  - service: http_status:404
```

5. **Criar rota DNS:**
```bash
cloudflared tunnel route dns binance-ws binance-ws.SEUCONTA.trycloudflare.com
```

6. **Executar tunnel:**
```bash
cloudflared tunnel run binance-ws
```

7. **Adicionar ao PM2 (para rodar automaticamente):**
```bash
nano ~/cloudflared-start.sh
```

Cole:
```bash
#!/bin/bash
cloudflared tunnel run binance-ws
```

```bash
chmod +x ~/cloudflared-start.sh
pm2 start ~/cloudflared-start.sh --name cloudflared-tunnel
pm2 save
```

8. **Atualizar .env na Lovable:**
```env
VITE_PROXY_WS_URL=wss://binance-ws.SEUCONTA.trycloudflare.com
```

✅ **Pronto!** Agora você tem WebSocket seguro sem precisar de domínio ou certificado SSL.

---

## Solução Rápida 2: Ngrok (Alternativa)

Se preferir ngrok:

1. **Instalar:**
```bash
wget https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-amd64.tgz
tar xvzf ngrok-v3-stable-linux-amd64.tgz
sudo mv ngrok /usr/local/bin/
```

2. **Fazer login:**
```bash
ngrok config add-authtoken SEU_TOKEN_AQUI
```
(Obtenha token em https://dashboard.ngrok.com/get-started/your-authtoken)

3. **Criar túnel WebSocket:**
```bash
ngrok http 3001 --scheme=https
```

4. **Copiar URL gerada** (ex: `wss://abc123.ngrok.io`)

5. **Atualizar .env na Lovable:**
```env
VITE_PROXY_WS_URL=wss://abc123.ngrok.io
```

**Limitações do ngrok gratuito:**
- URL muda toda vez que reinicia
- Limite de 40 conexões/minuto

---

## Solução Completa: Nginx + Let's Encrypt

Se você tem um domínio próprio, use esta solução para produção.

📄 Veja instruções completas em: **`WEBSOCKET_SSL_SETUP.md`**

### Resumo:
1. Instalar Nginx + Certbot
2. Configurar Nginx como proxy reverso
3. Gerar certificado SSL gratuito
4. Usar `wss://seu-dominio.com`

---

## Comparação das Soluções

| Solução | Custo | Complexidade | Estabilidade | Recomendado para |
|---------|-------|--------------|--------------|-----------------|
| **Cloudflare Tunnel** | Grátis | Baixa (5 min) | Alta | Desenvolvimento e Produção |
| **Ngrok** | Grátis/Pago | Muito Baixa (2 min) | Média | Apenas Desenvolvimento |
| **Nginx + Let's Encrypt** | Grátis | Média (20 min) | Muito Alta | Produção com domínio próprio |

---

## Verificar se está funcionando

Teste no console do navegador (Lovable):

```javascript
const ws = new WebSocket('wss://SEU_ENDPOINT_AQUI');
ws.onopen = () => console.log('✅ WebSocket conectado com SSL!');
ws.onerror = (e) => console.error('❌ Erro:', e);
```

Se conectar sem erros, está funcionando! 🎉
