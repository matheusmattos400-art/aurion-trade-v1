# 🚀 Monitor VPS - Sinalização para Lovable Cloud

## 📋 Visão Geral

Esta é a nova arquitetura do sistema de monitoramento, projetada para contornar problemas de rede no VPS com o banco de dados PostgreSQL.

### Arquitetura Atual

```
┌─────────────────┐         HTTP POST         ┌──────────────────────┐
│   Monitor VPS   │  ──────────────────────>  │   Lovable Cloud      │
│  (Sinalização)  │     a cada 2 segundos     │  (Edge Function)     │
│                 │                            │                      │
│  - Leve         │                            │  - Acesso ao DB      │
│  - Sem DB       │                            │  - API Binance       │
│  - Apenas HTTP  │                            │  - Lógica completa   │
└─────────────────┘                            └──────────────────────┘
```

### Por que mudamos?

O VPS apresentava falhas persistentes de rede (ENETUNREACH - IPv6) ao tentar conectar ao PostgreSQL. Como o IP do banco de dados é dinâmico, não podíamos configurar um IPv4 estático no VPS.

**Solução:** Mover toda a lógica de monitoramento para a Lovable Cloud, que tem conectividade estável, e usar o VPS apenas como um "sinalizador" leve via HTTP.

## 🛠️ Instalação

### 1. Configurar .env.monitor

```bash
cd /opt/binance-proxy
cp .env.monitor.example .env.monitor
nano .env.monitor
```

Configure as variáveis:

```bash
# URL da Edge Function na Lovable Cloud
EDGE_FUNCTION_URL=https://fznytwxyyoaqgslvfnll.supabase.co/functions/v1/monitor-execution

# Chave de API (mesmo valor configurado na Lovable Cloud)
MONITOR_API_KEY=sua_chave_secreta_aqui
```

**IMPORTANTE:** Use a mesma `MONITOR_API_KEY` configurada nos secrets da Lovable Cloud!

### 2. Atualizar PM2

```bash
# Parar o monitor antigo (se existir)
pm2 stop auto-close-monitor
pm2 delete auto-close-monitor

# Atualizar configuração do PM2
pm2 reload ecosystem.config.js

# Iniciar o novo monitor de sinalização
pm2 start ecosystem.config.js --only monitor-signal

# Salvar configuração
pm2 save
```

### 3. Verificar Status

```bash
# Ver status do monitor
pm2 status monitor-signal

# Ver logs em tempo real
pm2 logs monitor-signal

# Ver apenas últimas 50 linhas
pm2 logs monitor-signal --lines 50
```

## 📊 Como Funciona

### Fluxo de Execução

1. **VPS (a cada 2 segundos):**
   - Envia POST para `monitor-execution` edge function
   - Inclui chave de autenticação no header `x-monitor-key`
   - Aguarda resposta HTTP

2. **Lovable Cloud (edge function):**
   - Valida chave de API
   - Verifica se já há execução em andamento (controle de concorrência)
   - Responde imediatamente com status 202 (Accepted)
   - Executa lógica em background:
     - Busca operações ativas com `auto_close_enabled = true`
     - Para cada operação, consulta posições na Binance
     - Calcula PnL total
     - Se atingir o target, fecha posições e registra no histórico

### Controle de Concorrência

A edge function implementa dois mecanismos de segurança:

1. **Lock de execução:** Apenas uma instância da lógica roda por vez
2. **Throttle:** Mínimo de 2 segundos entre execuções

Isso previne:
- Múltiplas execuções simultâneas
- Sobrecarga do sistema
- Race conditions no fechamento de posições

### Respostas Possíveis

| Status | Resposta        | Significado                                    |
|--------|-----------------|------------------------------------------------|
| 202    | `processing`    | Monitor iniciado, lógica executando            |
| 200    | `skipped`       | Monitor já em execução, sinal ignorado         |
| 429    | `throttled`     | Muitos sinais, aguardando intervalo mínimo     |
| 401    | `Unauthorized`  | Chave de API inválida                          |
| 500    | Erro            | Falha na edge function                         |

## 📈 Monitoramento

### Logs do VPS

```bash
# Logs do monitor
pm2 logs monitor-signal

# Apenas erros
pm2 logs monitor-signal --err

# Últimas 100 linhas
pm2 logs monitor-signal --lines 100
```

### Logs da Lovable Cloud

Acesse os logs da edge function `monitor-execution` na Lovable Cloud para ver:
- Operações processadas
- PnL calculado
- Posições fechadas
- Erros de API Binance

### Estatísticas do Monitor

O monitor imprime estatísticas a cada minuto (30 sinais):

```
📊 ═══════════════════════════════════════
📊 ESTATÍSTICAS DO MONITOR
📊 ═══════════════════════════════════════
⏱️  Tempo ativo: 5 minutos
📡 Total de sinais enviados: 150
✅ Sinais bem-sucedidos: 148
❌ Sinais com falha: 2
📈 Taxa de sucesso: 98.7%
🎯 Último status: processing
📊 ═══════════════════════════════════════
```

## 🔧 Troubleshooting

### Monitor não inicia

```bash
# Verificar configuração
cat /opt/binance-proxy/.env.monitor

# Testar manualmente
cd /opt/binance-proxy
node monitor-signal.js

# Ver logs de erro
pm2 logs monitor-signal --err --lines 50
```

### Erro 401 (Unauthorized)

A chave de API está incorreta. Verifique:

1. Chave configurada no VPS (`.env.monitor`)
2. Chave configurada na Lovable Cloud (secret `MONITOR_API_KEY`)
3. Ambas devem ser **exatamente iguais**

### Erro 500 (Edge Function)

Problema na Lovable Cloud. Verifique:

1. Logs da edge function `monitor-execution`
2. Credenciais Binance configuradas
3. Conectividade com PostgreSQL

### Taxa de sucesso baixa

Se `Taxa de sucesso < 90%`:

1. Verifique conectividade VPS → Internet
2. Verifique se a URL da edge function está correta
3. Verifique logs para identificar padrão de erros

## 🔒 Segurança

### Autenticação

- Todo sinal requer header `x-monitor-key` com chave válida
- Sem chave válida = HTTP 401 (Unauthorized)
- Use chaves fortes e aleatórias (mínimo 32 caracteres)

### Recomendações

1. **Rotação de chaves:** Troque `MONITOR_API_KEY` periodicamente
2. **Firewall:** Configure firewall no VPS para permitir apenas saída HTTPS
3. **Logs:** Monitore logs para detectar tentativas de acesso não autorizado

## 📊 Performance

### Recursos do Monitor VPS

- **CPU:** ~0.1% (quase zero)
- **RAM:** ~50MB (muito leve)
- **Rede:** ~5KB/s (apenas sinais HTTP)

### Latência Esperada

- **VPS → Cloud:** ~50-200ms (depende da localização)
- **Execução total:** ~1-3s por operação
- **Taxa de sucesso:** >95%

## 🚀 Próximos Passos

1. **Notificações:** Adicionar webhook para notificar fechamentos
2. **Dashboard:** Criar dashboard para visualizar estatísticas
3. **Alertas:** Configurar alertas para taxa de sucesso baixa
4. **Métricas:** Coletar métricas de latência e performance

## 📞 Suporte

Em caso de problemas:

1. Verifique este guia primeiro
2. Consulte logs do monitor (`pm2 logs monitor-signal`)
3. Consulte logs da edge function na Lovable Cloud
4. Entre em contato com suporte técnico

---

**Data de criação:** 2025-01-26  
**Última atualização:** 2025-01-26  
**Versão:** 2.0 (Arquitetura de Sinalização)
