# 🚀 Guia de Instalação do Proxy HTTP→SOCKS5

## 📋 Pré-requisitos

- VPS com Ubuntu 20.04+ (seu Droplet DigitalOcean)
- Dante SOCKS5 já configurado na porta 8888
- Node.js 18+ instalado
- Acesso SSH ao VPS

## 📦 Passo 1: Criar Diretório e Copiar Arquivos

```bash
# Conectar ao VPS
ssh root@104.248.136.155

# Criar diretório
mkdir -p /opt/binance-proxy
cd /opt/binance-proxy
```

## 📄 Passo 2: Criar os Arquivos

### 2.1. Criar package.json

```bash
nano package.json
```

Cole o conteúdo do arquivo `package.json` e salve (Ctrl+X, Y, Enter).

### 2.2. Criar proxy-server-socks5.js

```bash
nano proxy-server-socks5.js
```

Cole o conteúdo do arquivo `proxy-server-socks5.js` e salve (Ctrl+X, Y, Enter).

### 2.3. Criar arquivo .env

```bash
nano .env
```

Cole o seguinte conteúdo:

```env
PORT=3000
SOCKS_HOST=127.0.0.1
SOCKS_PORT=8888
SOCKS_USER=lovable-proxy
SOCKS_PASSWORD=manu125523
```

Salve (Ctrl+X, Y, Enter).

## 📦 Passo 3: Instalar Dependências

```bash
npm install
```

## 🧪 Passo 4: Testar o Proxy

```bash
# Testar manualmente
npm start
```

Você deve ver:

```
============================================================
🚀 Proxy HTTP→SOCKS5 iniciado com sucesso!
============================================================
📍 Porta HTTP: 3000
🔒 SOCKS5: 127.0.0.1:8888
🎯 Destino: fapi.binance.com:443
============================================================
```

Pressione Ctrl+C para parar o teste.

## 🔄 Passo 5: Configurar PM2 para Rodar em Background

### 5.1. Instalar PM2

```bash
npm install -g pm2
```

### 5.2. Criar arquivo de configuração do PM2

```bash
nano ecosystem.config.js
```

Cole o conteúdo do arquivo `ecosystem.config.js` e salve.

### 5.3. Iniciar com PM2

```bash
# Iniciar o proxy
pm2 start ecosystem.config.js

# Configurar para iniciar no boot
pm2 startup
pm2 save

# Verificar status
pm2 status
```

## 📊 Passo 6: Verificar Logs

```bash
# Ver logs em tempo real
pm2 logs binance-proxy-socks5

# Ver últimas 50 linhas
pm2 logs binance-proxy-socks5 --lines 50

# Ver apenas erros
pm2 logs binance-proxy-socks5 --err
```

## 🔥 Passo 7: Configurar Firewall

```bash
# Permitir porta 3000 (HTTP Proxy)
ufw allow 3000/tcp

# Verificar regras
ufw status
```

**Nota**: A porta 8888 (SOCKS5) NÃO precisa ser aberta no firewall externo, pois é usada apenas localmente.

## 🧪 Passo 8: Testar a Conexão

### Teste Local (no VPS)

```bash
curl -X POST http://localhost:3000 \
  -H "X-Target-Endpoint: /fapi/v1/ping" \
  -H "X-Target-Method: GET" \
  -H "X-Target-Query: " \
  -H "X-API-Key: test"
```

Deve retornar: `{}`

### Teste Externo (do seu computador)

```bash
curl -X POST http://104.248.136.155:3000 \
  -H "X-Target-Endpoint: /fapi/v1/ping" \
  -H "X-Target-Method: GET" \
  -H "X-Target-Query: " \
  -H "X-API-Key: test"
```

## 📋 Comandos Úteis PM2

```bash
# Verificar status
pm2 status

# Reiniciar
pm2 restart binance-proxy-socks5

# Parar
pm2 stop binance-proxy-socks5

# Remover
pm2 delete binance-proxy-socks5

# Logs em tempo real
pm2 logs binance-proxy-socks5

# Monitoramento
pm2 monit
```

## ✅ Checklist de Verificação

- [ ] Dante SOCKS5 rodando na porta 8888
- [ ] Credenciais SOCKS5 configuradas (lovable-proxy / manu125523)
- [ ] Node.js 18+ instalado
- [ ] Arquivos criados em /opt/binance-proxy
- [ ] Dependências instaladas (npm install)
- [ ] PM2 instalado globalmente
- [ ] Proxy iniciado com PM2
- [ ] Firewall liberado na porta 3000
- [ ] Teste local bem-sucedido
- [ ] Teste externo bem-sucedido

## 🎯 Próximos Passos

Após a instalação bem-sucedida:

1. **Adicione o IP à whitelist da Binance**
   - Acesse: https://www.binance.com/en/my/settings/api-management
   - Adicione: `104.248.136.155`

2. **Teste no Lovable**
   - A variável `PROXY_URL` já está configurada como `http://104.248.136.155:3000`
   - Clique em "Testar Conexão Binance Account (via Proxy)"

## 🆘 Troubleshooting

### Proxy não inicia

```bash
# Verificar logs de erro
pm2 logs binance-proxy-socks5 --err

# Verificar se a porta está em uso
netstat -tulpn | grep 3000
```

### Erro de conexão SOCKS5

```bash
# Verificar se Dante está rodando
systemctl status danted

# Testar SOCKS5 diretamente
curl --socks5 lovable-proxy:manu125523@127.0.0.1:8888 https://fapi.binance.com/fapi/v1/ping
```

### Permissão negada

```bash
# Ajustar permissões do diretório
chown -R root:root /opt/binance-proxy
chmod -R 755 /opt/binance-proxy
```

## 📞 Suporte

Em caso de problemas, verifique:

1. Logs do PM2: `pm2 logs binance-proxy-socks5`
2. Status do Dante: `systemctl status danted`
3. Firewall: `ufw status`
4. Conexão de rede: `ping fapi.binance.com`
