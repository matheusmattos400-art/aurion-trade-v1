# Proxy WebSocket para Binance User Data Stream

⚠️ **IMPORTANTE - SEGURANÇA SSL/TLS:** Para usar este proxy com a Lovable (HTTPS), você **PRECISA** configurar SSL/TLS. Veja os arquivos:
- **`QUICK_FIX_WSS.md`** - Solução rápida com Cloudflare Tunnel (5 minutos, grátis)
- **`WEBSOCKET_SSL_SETUP.md`** - Solução completa com Nginx + Let's Encrypt (domínio próprio)

Este documento explica como configurar o proxy WebSocket no VPS (sem SSL). Para ambiente de produção com HTTPS, use uma das soluções acima.

## 📋 Visão Geral

O proxy WebSocket (`proxy-websocket.js`) roda na porta **3001** e roteia conexões WebSocket através do proxy SOCKS5 para o Binance Futures WebSocket (`fstream.binance.com`).

## 🚀 Instalação

### 1. Instalar Dependências

```bash
cd /opt/binance-proxy
npm install ws
```

### 2. Configurar Variáveis de Ambiente

Edite o arquivo `.env`:

```bash
# Porta HTTP (proxy REST)
PORT=3000

# Porta WebSocket (proxy WS)
WS_PORT=3001

# Configuração SOCKS5
SOCKS_HOST=127.0.0.1
SOCKS_PORT=8888
SOCKS_USER=lovable-proxy
SOCKS_PASSWORD=sua_senha_aqui
```

### 3. Executar com PM2

O arquivo `ecosystem.config.js` já está configurado para executar ambos os proxies:

```bash
# Reiniciar todos os processos
pm2 restart ecosystem.config.js

# Verificar status
pm2 status

# Ver logs do proxy WebSocket
pm2 logs binance-proxy-websocket

# Ver logs do proxy HTTP
pm2 logs binance-proxy-http
```

## 🔍 Como Funciona

### Fluxo de Conexão

1. **Cliente** (aplicação web) conecta ao proxy WebSocket na porta 3001
2. **Proxy WebSocket** estabelece conexão TCP via SOCKS5 para `fstream.binance.com:443`
3. **Proxy WebSocket** cria conexão WebSocket sobre o túnel SOCKS5
4. **Mensagens** são encaminhadas bidirecionalmente entre cliente e Binance

### Exemplo de Conexão do Cliente

```javascript
const proxyWsUrl = 'ws://104.248.136.155:3001';
const streamPath = '/ws/YOUR_LISTEN_KEY';
const wsUrl = `${proxyWsUrl}?stream=${encodeURIComponent(streamPath)}`;

const ws = new WebSocket(wsUrl);

ws.onopen = () => {
  console.log('Conectado ao User Data Stream');
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Update recebido:', data);
};
```

## 📊 Tipos de Eventos do User Data Stream

O Binance User Data Stream envia os seguintes tipos de eventos:

### 1. ACCOUNT_UPDATE
Atualização de saldo e posições

```json
{
  "e": "ACCOUNT_UPDATE",
  "T": 1564745798939,
  "a": {
    "B": [
      {
        "a": "USDT",
        "wb": "122624.12345678",
        "cw": "100.12345678"
      }
    ],
    "P": [
      {
        "s": "BTCUSDT",
        "pa": "0",
        "ep": "0.00000",
        "cr": "200",
        "up": "0",
        "mt": "isolated",
        "iw": "0.00000000",
        "ps": "BOTH"
      }
    ]
  }
}
```

### 2. ORDER_TRADE_UPDATE
Atualização de ordem

```json
{
  "e": "ORDER_TRADE_UPDATE",
  "T": 1568879465651,
  "o": {
    "s": "BTCUSDT",
    "c": "TEST",
    "S": "SELL",
    "o": "TRAILING_STOP_MARKET",
    "f": "GTC",
    "q": "0.001",
    "p": "0",
    "ap": "0",
    "sp": "7103.04",
    "x": "NEW",
    "X": "NEW",
    "i": 8886774,
    "l": "0",
    "z": "0",
    "L": "0",
    "T": 1568879465651,
    "t": 0
  }
}
```

## 🔐 Gerenciamento do ListenKey

O ListenKey é necessário para conectar ao User Data Stream:

### 1. Criar ListenKey (via API)

```typescript
const { data } = await supabase.functions.invoke('binance-trading', {
  body: { action: 'create_listen_key' }
});

const listenKey = data.data.listenKey;
```

### 2. Manter ListenKey Ativo

O ListenKey expira após 60 minutos. Deve ser renovado a cada 30 minutos:

```typescript
setInterval(async () => {
  await supabase.functions.invoke('binance-trading', {
    body: { 
      action: 'keepalive_listen_key',
      listenKey: currentListenKey 
    }
  });
}, 30 * 60 * 1000); // 30 minutos
```

## 🛠️ Troubleshooting

### Proxy não conecta ao SOCKS5

**Erro:** `Error: SOCKS connection failed`

**Solução:**
```bash
# Verificar se o Dante server está rodando
systemctl status danted

# Testar conectividade
telnet 127.0.0.1 8888
```

### Cliente não conecta ao proxy

**Erro:** `WebSocket connection failed`

**Solução:**
```bash
# Verificar se o proxy está rodando
pm2 status binance-proxy-websocket

# Verificar logs
pm2 logs binance-proxy-websocket --lines 50

# Testar porta
curl http://104.248.136.155:3001
```

### ListenKey inválido

**Erro:** `{"code":-1125,"msg":"This listenKey does not exist."}`

**Solução:**
- Criar novo ListenKey via API
- Verificar se o ListenKey não expirou (válido por 60 min)
- Garantir que a renovação automática está funcionando

### Reconexão não funciona

**Solução:**
```bash
# Ver logs de reconexão
pm2 logs binance-proxy-websocket | grep "reconectar"

# Reiniciar proxy se necessário
pm2 restart binance-proxy-websocket
```

## 📈 Monitoramento

### Ver logs em tempo real

```bash
# Logs do proxy WebSocket
pm2 logs binance-proxy-websocket --lines 100

# Logs do proxy HTTP
pm2 logs binance-proxy-http --lines 100

# Todos os logs
pm2 logs --lines 100
```

### Métricas

```bash
# Status e uso de recursos
pm2 monit

# Informações detalhadas
pm2 show binance-proxy-websocket
```

## 🔒 Segurança

1. **Firewall:** Garanta que apenas IPs autorizados possam acessar a porta 3001
2. **Credenciais:** Mantenha as credenciais SOCKS5 seguras no arquivo `.env`
3. **Logs:** Monitore logs regularmente para detectar acessos não autorizados
4. **SSL/TLS:** Considere usar WSS (WebSocket Secure) em produção

## 📚 Referências

- [Binance Futures WebSocket Documentation](https://binance-docs.github.io/apidocs/futures/en/#websocket-user-data-streams)
- [WebSocket API](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket)
- [SOCKS5 Protocol](https://www.ietf.org/rfc/rfc1928.txt)
