const WebSocket = require('ws');
const net = require('net');
const tls = require('tls');

const WS_PORT = process.env.WS_PORT || 3001;

console.log(`🚀 Proxy WebSocket (TLS) iniciando na porta ${WS_PORT}...`);

const wss = new WebSocket.Server({ 
  port: WS_PORT,
  perMessageDeflate: false 
});

wss.on('connection', (clientWs, req) => {
  const listenKey = req.url.replace('/ws/', '').replace('/ws', '');
  
  if (!listenKey || listenKey === '/') {
    console.error('❌ ListenKey inválida ou ausente');
    clientWs.close(1008, 'Missing listenKey');
    return;
  }

  console.log(`🎯 Tentativa de Conexão TLS: fstream.binance.com:443 (Path: /ws/${listenKey})`);

  // Conectar via TCP primeiro
  const tcpSocket = net.connect(443, 'fstream.binance.com', () => {
    console.log('✅ Conexão TCP Estabelecida (VPS -> Binance)');
    
    // Fazer TLS handshake sobre o socket TCP
    const tlsSocket = tls.connect({
      socket: tcpSocket,
      servername: 'fstream.binance.com',
      rejectUnauthorized: false // Para debug; use true em produção
    }, () => {
      console.log('✅ TLS Handshake Concluído (SSL/HTTPS)');
      console.log(`📡 Enviando WebSocket Handshake para: wss://fstream.binance.com/ws/${listenKey}`);
      
      // Agora enviar o WebSocket handshake via TLS
      const handshake = [
        `GET /ws/${listenKey} HTTP/1.1`,
        'Host: fstream.binance.com',
        'Upgrade: websocket',
        'Connection: Upgrade',
        'Sec-WebSocket-Key: ' + Buffer.from(Math.random().toString()).toString('base64').substring(0, 24),
        'Sec-WebSocket-Version: 13',
        '\r\n'
      ].join('\r\n');
      
      tlsSocket.write(handshake);
    });

    // Capturar resposta do handshake
    let handshakeComplete = false;
    let handshakeBuffer = '';

    tlsSocket.on('data', (chunk) => {
      if (!handshakeComplete) {
        handshakeBuffer += chunk.toString();
        
        if (handshakeBuffer.includes('\r\n\r\n')) {
          const lines = handshakeBuffer.split('\r\n');
          const statusLine = lines[0];
          
          console.log('📥 Resposta WebSocket (TLS):', statusLine);
          
          if (statusLine.includes('101 Switching Protocols')) {
            console.log('✅ WebSocket Handshake OK via TLS!');
            handshakeComplete = true;
            
            // Enviar dados restantes do buffer (após handshake)
            const headerEnd = handshakeBuffer.indexOf('\r\n\r\n') + 4;
            if (headerEnd < handshakeBuffer.length) {
              const remainingData = Buffer.from(handshakeBuffer.substring(headerEnd));
              clientWs.send(remainingData, { binary: true });
            }
          } else {
            console.error('❌ Handshake falhou:', statusLine);
            clientWs.close(1002, 'Binance handshake failed');
            tlsSocket.destroy();
            return;
          }
        }
      } else {
        // Dados WebSocket após handshake - encaminhar para cliente
        clientWs.send(chunk, { binary: true });
      }
    });

    tlsSocket.on('error', (err) => {
      console.error('❌ Erro no TLS Socket:', err.message);
      clientWs.close(1002, 'TLS error');
    });

    tlsSocket.on('end', () => {
      console.log('🔌 Conexão TLS fechada pela Binance');
      clientWs.close();
    });

    // Cliente -> Binance (via TLS)
    clientWs.on('message', (data) => {
      if (handshakeComplete) {
        tlsSocket.write(data);
      }
    });

    clientWs.on('close', () => {
      console.log('👋 Cliente desconectou');
      tlsSocket.destroy();
    });
  });

  tcpSocket.on('error', (err) => {
    console.error('❌ Erro TCP:', err.message);
    clientWs.close(1002, 'TCP connection failed');
  });
});

wss.on('error', (err) => {
  console.error('❌ Erro no servidor WebSocket:', err);
});

console.log(`✅ Servidor WebSocket rodando em ws://0.0.0.0:${WS_PORT}`);
console.log(`🔐 Roteando via TLS para: wss://fstream.binance.com/ws/<listenKey>`);

// Tratamento de erros
process.on('uncaughtException', (error) => {
  console.error('❌ Erro não capturado (FATAL):', error);
});

process.on('unhandledRejection', (reason) => {
  console.error('❌ Promise rejeitada:', reason);
});
