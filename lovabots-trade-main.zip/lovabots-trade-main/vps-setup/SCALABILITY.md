# Escalabilidade - Análise de Capacidade VPS

## 📊 Capacidade Estimada por Configuração VPS

### VPS Básico (1 vCPU, 1GB RAM, 25GB SSD)
- **Usuários simultâneos**: 10-20
- **Operações ativas**: 20-40
- **Verificações/segundo**: 0.5 (a cada 2s)
- **Custo mensal**: ~$5-10

### VPS Médio (2 vCPU, 2GB RAM, 50GB SSD) ⭐ **RECOMENDADO**
- **Usuários simultâneos**: 50-100
- **Operações ativas**: 100-200
- **Verificações/segundo**: 0.5 (a cada 2s)
- **Custo mensal**: ~$12-20

### VPS Alto (4 vCPU, 4GB RAM, 80GB SSD)
- **Usuários simultâneos**: 200-300
- **Operações ativas**: 400-600
- **Verificações/segundo**: 0.5 (a cada 2s)
- **Custo mensal**: ~$24-40

### VPS Premium (8 vCPU, 8GB RAM, 160GB SSD)
- **Usuários simultâneos**: 500-800
- **Operações ativas**: 1000-1600
- **Verificações/segundo**: 0.5 (a cada 2s)
- **Custo mensal**: ~$40-80

## 🔢 Cálculo de Recursos

### Por verificação (a cada 2s):
- **Query Database**: ~50-100ms
- **Request Binance**: ~100-300ms (via SOCKS5)
- **Processamento**: ~10-50ms
- **Total por operação**: ~200-450ms

### Exemplo com 100 operações ativas:
- **Tempo total por ciclo**: ~20-45 segundos
- **Intervalo configurado**: 2 segundos
- **Conclusão**: Precisaria de processamento paralelo ou otimização

## ⚡ Otimizações para Escalar

### 1. Processamento em Lotes (Batch)

```javascript
// Processar 10 operações por vez em paralelo
const BATCH_SIZE = 10;

async function monitorOperations() {
  const operations = await getActiveOperations();
  
  for (let i = 0; i < operations.length; i += BATCH_SIZE) {
    const batch = operations.slice(i, i + BATCH_SIZE);
    await Promise.all(batch.map(op => processOperation(op)));
  }
}
```

**Ganho**: Reduz tempo de 45s para ~5s com 100 operações

### 2. Cache de Preços Binance

```javascript
// Cache compartilhado de preços (atualizado a cada 2s)
const priceCache = new Map();

// Buscar todos os preços de uma vez
async function updatePriceCache() {
  const positions = await getBinancePositions();
  positions.forEach(p => {
    priceCache.set(p.symbol, parseFloat(p.markPrice));
  });
}

// Usar cache nas verificações
function getCurrentPrice(symbol) {
  return priceCache.get(symbol) || 0;
}
```

**Ganho**: 1 request Binance por ciclo ao invés de 2N (N = operações)

### 3. Múltiplas Instâncias PM2

```javascript
// ecosystem.config.js
{
  name: 'auto-close-monitor',
  script: 'auto-close-monitor.js',
  instances: 4, // 4 processos paralelos
  exec_mode: 'cluster'
}
```

**Ganho**: 4x throughput, processamento distribuído

### 4. Database Connection Pool

```javascript
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: DB_CONNECTION_STRING,
  max: 20, // 20 conexões simultâneas
  idleTimeoutMillis: 30000
});
```

**Ganho**: Reduz latência de conexão de ~100ms para ~5ms

## 📈 Recomendações por Fase

### Fase 1: MVP (0-50 usuários)
- **VPS**: 1 vCPU, 1GB RAM
- **Config**: Padrão atual (2s por verificação)
- **Custo**: $5-10/mês
- **Ação**: Nenhuma otimização necessária

### Fase 2: Crescimento (50-200 usuários)
- **VPS**: 2 vCPU, 2GB RAM
- **Config**: + Cache de preços + Connection pool
- **Custo**: $12-20/mês
- **Ação**: Implementar cache e pool

### Fase 3: Escala (200-500 usuários)
- **VPS**: 4 vCPU, 4GB RAM
- **Config**: + Processamento em lotes + 2 instâncias PM2
- **Custo**: $24-40/mês
- **Ação**: Refatorar para batches e cluster

### Fase 4: Enterprise (500+ usuários)
- **VPS**: 8+ vCPU, 8+ GB RAM ou múltiplos servidores
- **Config**: Todas otimizações + Load balancer
- **Custo**: $40-100+/mês
- **Ação**: Arquitetura distribuída, Redis cache, separar por região

## 🎯 Bottlenecks Principais

### 1. API Binance (Rate Limits)
- **Limite**: 2400 requests/min (40/s)
- **Solução**: Cache de preços, webhook Binance User Data Stream
- **Impacto**: Suporta ~400 operações simultâneas sem cache

### 2. Database Connections
- **Limite**: Supabase Free Tier = 60 conexões simultâneas
- **Solução**: Connection pooling
- **Impacto**: Suporta ~200 usuários com 1 operação cada

### 3. CPU/Memória VPS
- **Limite**: Depende da configuração
- **Solução**: Upgrade VPS ou cluster
- **Impacto**: Gargalo em 100+ operações ativas

### 4. Network I/O (SOCKS5)
- **Limite**: ~1000 conexões/s
- **Solução**: Múltiplos proxies SOCKS5
- **Impacto**: Raramente é gargalo

## 🔮 Previsão de Crescimento

| Usuários | Operações Ativas | VPS Recomendado | Custo/mês | Otimizações |
|----------|------------------|-----------------|-----------|-------------|
| 10       | 10-20            | 1 vCPU, 1GB     | $5-10     | Nenhuma     |
| 50       | 50-100           | 2 vCPU, 2GB     | $12-20    | Cache       |
| 200      | 200-400          | 4 vCPU, 4GB     | $24-40    | Cache + Pool + Batch |
| 500      | 500-1000         | 8 vCPU, 8GB     | $40-80    | Todas + Cluster |
| 1000+    | 1000+            | Multi-server    | $100+     | Arquitetura distribuída |

## 💡 Dicas de Monitoramento

```bash
# Ver uso de recursos em tempo real
pm2 monit

# Métricas de performance
pm2 show auto-close-monitor

# Logs de performance
tail -f /var/log/auto-close-monitor-out.log | grep "PnL"
```

## 🚨 Sinais de que Precisa Escalar

1. **Latência > 5s por ciclo**: Considere cache ou batch processing
2. **CPU > 80% constante**: Upgrade CPU ou cluster
3. **RAM > 80%**: Upgrade RAM
4. **Erros "too many connections"**: Aumentar pool de conexões
5. **Rate limit Binance**: Implementar cache agressivo

## 🔧 Implementação Rápida de Otimizações

### Script com cache (copiar para VPS):

```bash
# Criar versão otimizada
nano /opt/binance-proxy/auto-close-monitor-optimized.js
# (colar código com cache e batching)

# Testar
pm2 start auto-close-monitor-optimized.js --name monitor-v2
pm2 logs monitor-v2

# Se funcionar bem, substituir
pm2 delete auto-close-monitor
pm2 restart monitor-v2 --name auto-close-monitor
pm2 save
```

## 📊 Resumo Executivo

**Para começar**: VPS básico aguenta 10-20 usuários tranquilamente

**Para crescer**: Com $20-40/mês consegue suportar 200-500 usuários facilmente

**Para escalar**: Com otimizações adequadas, um único VPS premium ($80/mês) aguenta 500-1000 usuários ativos

**Chave do sucesso**: Monitorar métricas e otimizar conforme necessário
