import React from "react";
import { createRoot } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import App from "./App.tsx";
import "./index.css";
import { TradingModeProvider } from "./contexts/TradingModeContext";

const queryClient = new QueryClient();

createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <TradingModeProvider>
      <QueryClientProvider client={queryClient}>
        <App />
        <Toaster />
        <Sonner />
      </QueryClientProvider>
    </TradingModeProvider>
  </React.StrictMode>
);
