// Scanner automático de pares para encontrar oportunidades de trading

const ALL_CRYPTO_PAIRS = [
  "BNBUSDT", "SOLUSDT", "ADAUSDT", "DOGEUSDT", "XRPUSDT", 
  "DOTUSDT", "MATICUSDT", "AVAXUSDT", "LINKUSDT", "ATOMUSDT",
  "LTCUSDT", "ETCUSDT", "NEARUSDT", "FTMUSDT", "SANDUSDT",
  "UNIUSDT", "AAVEUSDT", "ICPUSDT", "FILUSDT", "APTUSDT"
] as const;

export type CryptoPair = typeof ALL_CRYPTO_PAIRS[number];

export interface TradingSignal {
  id: string;
  longSymbol: string;
  shortSymbol: string;
  strategy: "micro_distortion" | "partial_reversal" | "trend_follow";
  zScore: number;
  correlation: number;
  correlation5d: number;   // 5 dias (120h)
  correlation25d: number;  // 25 dias (600h)
  correlation2m: number;   // 2 meses (1440h)
  momentumAge: number; // minutos desde o início do momentum
  currentMomentum: number;
  avgBullish: number;
  avgBearish: number;
  liquidityRatio: number;
  message: string;
  timestamp: Date;
  status: "ready" | "pending"; // ready = pronto para entrar, pending = próximo de entrada
  pendingReason?: string; // motivo de estar pendente
}

// Calcular correlação de Pearson
const calculateCorrelation = (prices1: number[], prices2: number[]): number => {
  const returns1 = prices1.slice(1).map((price, i) => (price - prices1[i]) / prices1[i]);
  const returns2 = prices2.slice(1).map((price, i) => (price - prices2[i]) / prices2[i]);
  
  const mean1 = returns1.reduce((a, b) => a + b, 0) / returns1.length;
  const mean2 = returns2.reduce((a, b) => a + b, 0) / returns2.length;
  
  let num = 0, den1 = 0, den2 = 0;
  for (let i = 0; i < returns1.length; i++) {
    const diff1 = returns1[i] - mean1;
    const diff2 = returns2[i] - mean2;
    num += diff1 * diff2;
    den1 += diff1 * diff1;
    den2 += diff2 * diff2;
  }
  
  return num / Math.sqrt(den1 * den2);
};

// Analisar um par específico
const analyzePair = async (
  symbol1: string,
  symbol2: string
): Promise<TradingSignal | null> => {
  try {
    // Buscar dados em paralelo
    const [klines1_1h, klines2_1h, klines1_30m, klines2_30m, price1, price2] = await Promise.all([
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol1}&interval=1h&limit=168`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol2}&interval=1h&limit=168`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol1}&interval=30m&limit=48`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol2}&interval=30m&limit=48`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${symbol1}`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${symbol2}`).then(r => r.json()),
    ]);

    // Extrair preços
    const prices1_1h = klines1_1h.map((k: number[]) => parseFloat(String(k[4])));
    const prices2_1h = klines2_1h.map((k: number[]) => parseFloat(String(k[4])));
    
    // Filtrar apenas candles fechados
    const now = Date.now();
    const closedKlines1_30m = klines1_30m.filter((k: number[]) => k[6] < now);
    const closedKlines2_30m = klines2_30m.filter((k: number[]) => k[6] < now);
    
    const prices1_30m = closedKlines1_30m.map((k: number[]) => parseFloat(String(k[4])));
    const prices2_30m = closedKlines2_30m.map((k: number[]) => parseFloat(String(k[4])));
    const volumes1_1h = klines1_1h.map((k: number[]) => parseFloat(String(k[7])));
    const volumes2_1h = klines2_1h.map((k: number[]) => parseFloat(String(k[7])));

    // Calcular correlação
    const correlation = calculateCorrelation(prices1_1h, prices2_1h);
    
    // Validação de correlação (mínimo 0.65 para pendente, 0.70 para pronto)
    if (correlation < 0.65 || isNaN(correlation)) {
      return null;
    }

    // Calcular Z-Score
    const ratios = prices1_30m.map((p1, i) => (p1 / prices2_30m[i] - 1) * 100);
    const currentDifference = ratios[ratios.length - 1];
    const avgDifference = ratios.reduce((a, b) => a + b, 0) / ratios.length;
    const variance = ratios.reduce((sum, val) => sum + Math.pow(val - avgDifference, 2), 0) / ratios.length;
    const stdDev = Math.sqrt(variance);
    const zScore = (currentDifference - avgDifference) / stdDev;
    const absZScore = Math.abs(zScore);

    // Calcular momentum com preço atual em tempo real
    const currentPrice1 = parseFloat(price1.price);
    const currentPrice2 = parseFloat(price2.price);
    const lastRatio = prices1_30m[prices1_30m.length - 1] / prices2_30m[prices2_30m.length - 1];
    const currentRatio = currentPrice1 / currentPrice2;
    const currentMomentum = ((currentRatio - lastRatio) / lastRatio) * 100;

    // Calcular médias de momentum
    const momentumChanges = ratios.slice(1).map((r, i) => ((r - ratios[i]) / Math.abs(ratios[i])) * 100);
    const bullishChanges = momentumChanges.filter(m => m > 0);
    const bearishChanges = momentumChanges.filter(m => m < 0);
    const avgBullish = bullishChanges.length > 0 ? bullishChanges.reduce((a, b) => a + b, 0) / bullishChanges.length : 0;
    const avgBearish = bearishChanges.length > 0 ? bearishChanges.reduce((a, b) => a + b, 0) / bearishChanges.length : 0;

    // Calcular idade do momentum (quantos candles de 30min desde a distorção começou)
    let momentumAge = 0;
    const signOfCurrent = zScore > 0 ? 1 : -1;
    for (let i = ratios.length - 1; i >= 0; i--) {
      const signAtI = (ratios[i] - avgDifference) > 0 ? 1 : -1;
      if (signAtI === signOfCurrent) {
        momentumAge++;
      } else {
        break;
      }
    }
    // Converter para minutos (cada candle = 30 min)
    const momentumAgeMinutes = momentumAge * 30;

    // Determinar status: ready (<=23min), pending (24-35min), ou descarta (>35min)
    let status: "ready" | "pending" = "ready";
    let pendingReason: string | undefined;

    if (momentumAgeMinutes > 35) {
      return null; // Muito antigo
    } else if (momentumAgeMinutes > 23) {
      status = "pending";
      pendingReason = `Momentum: ${momentumAgeMinutes}min (ideal: ≤23min)`;
    }

    // Se correlação entre 65-70%, marcar como pendente
    if (correlation >= 0.65 && correlation < 0.70) {
      status = "pending";
      pendingReason = `Correlação: ${(correlation * 100).toFixed(1)}% (ideal: ≥70%)`;
    }

    // Calcular liquidez
    const avgVolume1 = volumes1_1h.reduce((a, b) => a + b, 0) / volumes1_1h.length;
    const avgVolume2 = volumes2_1h.reduce((a, b) => a + b, 0) / volumes2_1h.length;
    const liquidityRatio = Math.min(avgVolume1, avgVolume2) / Math.max(avgVolume1, avgVolume2);

    // Determinar estratégia
    let strategy: "micro_distortion" | "partial_reversal" | "trend_follow" | null = null;
    let message = "";

    // Prioridade 1: Reversão Extrema (Z-Score >= 2.5)
    if (absZScore >= 2.5) {
      strategy = "partial_reversal";
      message = `Reversão Extrema (Z: ${zScore.toFixed(2)})`;
    }
    // Prioridade 2: Micro Distorção (1.2 <= Z-Score < 1.6)
    else if (absZScore >= 1.2 && absZScore < 1.6) {
      strategy = "micro_distortion";
      message = `Micro Distorção (Z: ${zScore.toFixed(2)})`;
    }
    // Prioridade 3: Reversão Moderada (Z-Score >= 1.6)
    else if (absZScore >= 1.6) {
      strategy = "partial_reversal";
      message = `Reversão Moderada (Z: ${zScore.toFixed(2)})`;
    }
    // Prioridade 4: Trend Follow (momentum alinhado)
    else if (absZScore < 1.2) {
      const leadingCoin = avgVolume1 > avgVolume2 ? symbol1 : symbol2;
      const leaderPrices = leadingCoin === symbol1 ? prices1_30m : prices2_30m;
      const leaderMomentum = ((leaderPrices[leaderPrices.length - 1] - leaderPrices[leaderPrices.length - 2]) / leaderPrices[leaderPrices.length - 2]) * 100;
      const leaderAligned = zScore > 1.2 ? leaderMomentum > 0 : zScore < -1.2 ? leaderMomentum < 0 : true;
      
      if (leaderAligned && Math.abs(leaderMomentum) > 0.5) {
        strategy = "trend_follow";
        message = `Trend Follow (Mom: ${leaderMomentum.toFixed(2)}%)`;
      }
    }

    if (!strategy) {
      return null;
    }

    // Estratégia operacional: quando Z-Score > 0, consideramos que o símbolo1
    // está "forte" versus símbolo2 e queremos FICAR COMPRADO nele.
    //  - zScore > 0  → LONG symbol1, SHORT symbol2
    //  - zScore < 0  → LONG symbol2, SHORT symbol1
    const longSymbol = zScore > 0 ? symbol1 : symbol2;
    const shortSymbol = zScore > 0 ? symbol2 : symbol1;

    return {
      id: `${longSymbol}-${shortSymbol}-${Date.now()}`,
      longSymbol,
      shortSymbol,
      strategy,
      zScore,
      correlation,
      correlation5d: correlation,
      correlation25d: correlation,
      correlation2m: correlation,
      momentumAge: momentumAgeMinutes,
      currentMomentum,
      avgBullish,
      avgBearish,
      liquidityRatio,
      message,
      timestamp: new Date(),
      status,
      pendingReason,
    };
  } catch (error) {
    console.error(`Erro ao analisar par ${symbol1}/${symbol2}:`, error);
    return null;
  }
};

// Escanear todos os pares disponíveis
export const scanAllPairs = async (): Promise<TradingSignal[]> => {
  const signals: TradingSignal[] = [];
  const pairs = ALL_CRYPTO_PAIRS;

  console.log("🔍 Iniciando escaneamento de", pairs.length, "moedas...");

  // Criar todas as combinações de pares
  const combinations: [string, string][] = [];
  for (let i = 0; i < pairs.length; i++) {
    for (let j = i + 1; j < pairs.length; j++) {
      combinations.push([pairs[i], pairs[j]]);
    }
  }

  console.log("📊 Total de combinações a analisar:", combinations.length);

  // Processar em lotes para não sobrecarregar a API
  const batchSize = 5;
  for (let i = 0; i < combinations.length; i += batchSize) {
    const batch = combinations.slice(i, i + batchSize);
    const results = await Promise.all(
      batch.map(([s1, s2]) => analyzePair(s1, s2))
    );
    
    for (const result of results) {
      if (result) {
        signals.push(result);
      }
    }

    // Pequeno delay entre lotes
    if (i + batchSize < combinations.length) {
      await new Promise(r => setTimeout(r, 200));
    }
  }

  // Ordenar por prioridade de estratégia e Z-Score
  const strategyPriority = {
    "partial_reversal": 3,
    "micro_distortion": 2,
    "trend_follow": 1,
  };

  signals.sort((a, b) => {
    const priorityDiff = strategyPriority[b.strategy] - strategyPriority[a.strategy];
    if (priorityDiff !== 0) return priorityDiff;
    return Math.abs(b.zScore) - Math.abs(a.zScore);
  });

  console.log("✅ Escaneamento concluído!", signals.length, "sinais encontrados");
  
  return signals;
};

export { ALL_CRYPTO_PAIRS };
