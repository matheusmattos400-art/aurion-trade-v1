import { Connection, VersionedTransaction, PublicKey } from "@solana/web3.js";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

// Jupiter API endpoints (direct - used as fallback)
const JUPITER_QUOTE_API = "https://quote-api.jup.ag/v6/quote";
const JUPITER_SWAP_API = "https://quote-api.jup.ag/v6/swap";
const JUPITER_TRIGGER_API = "https://api.jup.ag/trigger/v1";

// Premium RPC endpoints (high-performance, free tiers)
const RPC_ENDPOINTS = [
  "https://mainnet.helius-rpc.com/?api-key=1d8740dc-e5f4-421c-b823-e1bad1889eff", // Helius free
  "https://rpc.ankr.com/solana", // Ankr free (high performance)
  "https://solana-mainnet.g.alchemy.com/v2/demo", // Alchemy demo
];

// Priority fee in lamports (0.001 SOL = 1,000,000 lamports)
const PRIORITY_FEE_LAMPORTS = 1_000_000;

let currentRpcIndex = 0;

// Common token addresses on Solana
export const SOLANA_TOKENS = {
  SOL: "So11111111111111111111111111111111111111112",
  USDC: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  USDT: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
};

interface JupiterQuote {
  inputMint: string;
  inAmount: string;
  outputMint: string;
  outAmount: string;
  otherAmountThreshold: string;
  swapMode: string;
  slippageBps: number;
  priceImpactPct: string;
  routePlan: unknown[];
}

interface SwapResult {
  success: boolean;
  signature?: string;
  error?: string;
  outputAmount?: string;
}

// Generic wallet provider interface (works with Phantom, Solflare, etc.)
interface WalletProvider {
  publicKey?: { toString: () => string };
  signTransaction?: <T>(transaction: T) => Promise<T>;
  signAllTransactions?: <T>(transactions: T[]) => Promise<T[]>;
  isConnected?: boolean;
}

/**
 * Get Solana connection with RPC rotation
 */
const getConnection = (): Connection => {
  const rpc = RPC_ENDPOINTS[currentRpcIndex];
  console.log(`🔌 Using RPC: ${rpc.substring(0, 50)}...`);
  return new Connection(rpc, "confirmed");
};

/**
 * Rotate to next RPC endpoint
 */
const rotateRpc = () => {
  currentRpcIndex = (currentRpcIndex + 1) % RPC_ENDPOINTS.length;
  console.log(`🔄 Rotated to RPC index: ${currentRpcIndex}`);
};

/**
 * Delay helper for retry logic
 */
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Jupiter error info for debugging
 */
type JupiterErrorInfo = {
  source: "proxy" | "direct" | "invoke";
  code?: string;
  message?: string;
  raw?: unknown;
};

type QuoteAttemptResult = {
  quote: JupiterQuote | null;
  error?: JupiterErrorInfo;
};

const extractJupiterErrorInfo = (raw: any, source: JupiterErrorInfo["source"]): JupiterErrorInfo => {
  const code =
    raw?.errorCode ||
    raw?.code ||
    raw?.details?.errorCode ||
    raw?.details?.code ||
    (typeof raw?.error === "string" && /^[A-Z0-9_]+$/.test(raw.error) ? raw.error : undefined);

  const message =
    raw?.error ||
    raw?.message ||
    raw?.details?.error ||
    raw?.details?.message ||
    (typeof raw === "string" ? raw : undefined);

  return { source, code, message, raw };
};

/**
 * Get Jupiter quote via backend proxy (avoids CORS)
 */
const getJupiterQuoteViaProxy = async (
  inputMint: string,
  outputMint: string,
  amount: number,
  slippageBps: number,
  userPublicKey?: string
): Promise<QuoteAttemptResult> => {
  try {
    console.log("🔄 Getting quote via proxy...", { slippageBps });

    const { data, error } = await supabase.functions.invoke("jupiter-proxy", {
      body: {
        action: "quote",
        params: { inputMint, outputMint, amount, slippageBps },
      },
      headers: userPublicKey ? { "x-user-public-key": userPublicKey } : {},
    });

    if (error) {
      console.error("Proxy quote invoke error:", error);
      return { quote: null, error: extractJupiterErrorInfo(error, "invoke") };
    }

    if (data?.error) {
      console.error("Jupiter quote error via proxy:", data);
      return { quote: null, error: extractJupiterErrorInfo(data, "proxy") };
    }

    console.log("✅ Quote via proxy:", data);
    return { quote: data };
  } catch (e) {
    console.error("Proxy request failed:", e);
    return { quote: null, error: extractJupiterErrorInfo(e, "proxy") };
  }
};

/**
 * Get Jupiter quote directly (fallback)
 */
const getJupiterQuoteDirect = async (
  inputMint: string,
  outputMint: string,
  amount: number,
  slippageBps: number
): Promise<QuoteAttemptResult> => {
  try {
    const params = new URLSearchParams({
      inputMint,
      outputMint,
      amount: amount.toString(),
      slippageBps: slippageBps.toString(),
      onlyDirectRoutes: "false",
      restrictIntermediateTokens: "false",
    });

    console.log("🔄 Getting quote direct...", { slippageBps });
    const response = await fetch(`${JUPITER_QUOTE_API}?${params.toString()}`);

    const json = await response.json().catch(() => ({}));

    if (!response.ok) {
      console.error("Direct Jupiter quote error:", json);
      return { quote: null, error: extractJupiterErrorInfo(json, "direct") };
    }

    return { quote: json };
  } catch (e) {
    console.error("Direct Jupiter quote request failed:", e);
    return { quote: null, error: extractJupiterErrorInfo(e, "direct") };
  }
};

/**
 * Get a quote from Jupiter with retry logic
 * PRIORITY: Direct call first (browser has no DNS issues), proxy as fallback
 * Shows detailed Jupiter error codes in console + toast
 */
export const getJupiterQuote = async (
  inputMint: string,
  outputMint: string,
  amount: number,
  slippageBps: number = 100,
  userPublicKey?: string,
  maxRetries: number = 3
): Promise<JupiterQuote | null> => {
  console.log("🔍 Getting Jupiter quote:", { inputMint, outputMint, amount, slippageBps });

  if (amount <= 0) {
    console.error("Invalid amount for quote:", amount);
    toast.error("Valor inválido para cotação");
    return null;
  }

  const amountInt = Math.floor(amount);
  if (!Number.isFinite(amountInt) || amountInt <= 0) {
    console.error("Invalid amount for quote (must be integer > 0):", amount);
    toast.error("Valor inválido para cotação");
    return null;
  }

  if (!isValidSolanaAddress(inputMint) || !isValidSolanaAddress(outputMint)) {
    console.error("Invalid mint address:", { inputMint, outputMint });
    toast.error("Endereço do token inválido (mint)");
    return null;
  }

  let lastError: JupiterErrorInfo | undefined;

  // Try with retry logic
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      if (attempt > 1) {
        console.log(`🔄 Retry attempt ${attempt}/${maxRetries}...`);
        await delay(1000 * attempt); // Exponential backoff
      }

      // PRIORITY: Direct API call first (browser has no DNS issues like Edge Functions)
      console.log("🔄 Trying direct Jupiter API (browser)...");
      const directRes = await getJupiterQuoteDirect(inputMint, outputMint, amountInt, slippageBps);
      if (directRes.quote) {
        console.log("✅ Jupiter quote received (direct):", directRes.quote);
        return directRes.quote;
      }
      if (directRes.error) lastError = directRes.error;

      // Fallback to proxy only if direct fails (e.g., CORS issues)
      console.log("⚠️ Direct failed, trying proxy fallback...");
      const proxyRes = await getJupiterQuoteViaProxy(inputMint, outputMint, amountInt, slippageBps, userPublicKey);
      if (proxyRes.quote) {
        console.log("✅ Jupiter quote received (proxy):", proxyRes.quote);
        return proxyRes.quote;
      }
      if (proxyRes.error) lastError = proxyRes.error;

      console.warn(`Attempt ${attempt} failed, will retry...`, lastError);
    } catch (error) {
      console.error(`Attempt ${attempt} error:`, error);

      // On network errors, rotate RPC for subsequent operations
      if (error instanceof TypeError && error.message.includes("fetch")) {
        rotateRpc();
      }

      lastError = extractJupiterErrorInfo(error, "direct");
    }
  }

  // Show detailed error to user
  const code = lastError?.code;
  const msg = lastError?.message;
  if (code) {
    console.error("❌ Quote failed (Jupiter):", lastError);
    toast.error(`Cotação falhou: ${code}${msg ? ` - ${msg}` : ""}`);
  } else {
    console.error(`❌ All ${maxRetries} quote attempts failed`, lastError);
    toast.error("Erro ao obter cotação - tente novamente em alguns segundos");
  }

  return null;
};

/**
 * Get swap transaction via backend proxy
 */
const getSwapTransactionViaProxy = async (
  quote: JupiterQuote,
  userPublicKey: string
): Promise<string | null> => {
  try {
    console.log("🔄 Getting swap tx via proxy...");
    
    const { data, error } = await supabase.functions.invoke("jupiter-proxy", {
      body: {
        action: "swap",
        params: { quoteResponse: quote, userPublicKey },
      },
      headers: { "x-user-public-key": userPublicKey },
    });

    if (error || data.error) {
      console.error("Proxy swap error:", error || data.error);
      return null;
    }

    return data.swapTransaction;
  } catch (e) {
    console.error("Proxy swap request failed:", e);
    return null;
  }
};

/**
 * Get swap transaction directly (fallback) with fixed priority fee
 */
const getSwapTransactionDirect = async (
  quote: JupiterQuote,
  userPublicKey: string
): Promise<string | null> => {
  const response = await fetch(JUPITER_SWAP_API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      quoteResponse: quote,
      userPublicKey,
      wrapAndUnwrapSol: true,
      dynamicComputeUnitLimit: true,
      // Fixed priority fee of 0.001 SOL for reliable transaction processing
      prioritizationFeeLamports: PRIORITY_FEE_LAMPORTS,
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    console.error("Direct swap error:", errorData);
    return null;
  }

  const { swapTransaction } = await response.json();
  return swapTransaction;
};

/**
 * Execute a swap on Jupiter using any Solana wallet (Phantom, Solflare, etc.) with retry logic
 */
export const executeJupiterSwap = async (
  inputMint: string,
  outputMint: string,
  amountInLamports: number,
  userPublicKey: string,
  walletProvider: WalletProvider,
  slippageBps: number = 100,
  maxRetries: number = 3
): Promise<SwapResult> => {
  const providerPubKey = walletProvider.publicKey?.toString?.();
  if (!walletProvider.isConnected || !providerPubKey) {
    return { success: false, error: "Carteira não está conectada. Conecte sua carteira primeiro." };
  }

  if (providerPubKey !== userPublicKey) {
    return { success: false, error: "Carteira conectada, mas a chave pública não corresponde. Reconecte a carteira." };
  }

  if (!walletProvider.signTransaction) {
    return { success: false, error: "Carteira conectada, mas ainda não está pronta para assinar transações." };
  }

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      if (attempt > 1) {
        console.log(`🔄 Swap retry ${attempt}/${maxRetries}...`);
        toast.info(`Tentativa ${attempt}/${maxRetries}...`);
        await delay(1000 * attempt);
        rotateRpc(); // Try different RPC
      }

      // Step 1: Get quote with userPublicKey for better validation
      toast.info("Obtendo cotação do Jupiter...");
      const quote = await getJupiterQuote(inputMint, outputMint, amountInLamports, slippageBps, userPublicKey);
      
      if (!quote) {
        if (attempt === maxRetries) {
          return { success: false, error: "Não foi possível obter cotação após várias tentativas" };
        }
        continue;
      }

      console.log("Jupiter quote:", quote);
      
      // Step 2: Get swap transaction (proxy first, then direct)
      toast.info("Preparando transação...");
      let swapTransaction = await getSwapTransactionViaProxy(quote, userPublicKey);
      
      if (!swapTransaction) {
        console.log("⚠️ Proxy swap failed, trying direct...");
        swapTransaction = await getSwapTransactionDirect(quote, userPublicKey);
      }

      if (!swapTransaction) {
        console.error("Failed to get swap transaction");
        if (attempt === maxRetries) {
          return { success: false, error: "Falha ao preparar transação de swap" };
        }
        continue;
      }
      
      // Step 3: Deserialize and sign transaction
      toast.info("Aguardando assinatura na carteira...");
      const transactionBuffer = Buffer.from(swapTransaction, "base64");
      const transaction = VersionedTransaction.deserialize(transactionBuffer);
      
      if (!walletProvider.signTransaction) {
        return { success: false, error: "Carteira não suporta assinatura de transações" };
      }
      
      const signedTransaction = await walletProvider.signTransaction(transaction);
      
      // Step 4: Send transaction with RPC rotation on failure
      toast.info("Enviando transação para a blockchain...");
      const connection = getConnection();
      const signature = await connection.sendRawTransaction(signedTransaction.serialize(), {
        skipPreflight: false,
        maxRetries: 3,
      });
      
      // Step 5: Confirm transaction
      toast.info("Confirmando transação...");
      const confirmation = await connection.confirmTransaction(signature, "confirmed");
      
      if (confirmation.value.err) {
        throw new Error(`Transação falhou: ${JSON.stringify(confirmation.value.err)}`);
      }
      
      return {
        success: true,
        signature,
        outputAmount: quote.outAmount,
      };
    } catch (error) {
      console.error(`Swap attempt ${attempt} error:`, error);
      
      // Don't retry on user rejection
      if (error instanceof Error && error.message.includes("User rejected")) {
        return { success: false, error: "Transação cancelada pelo usuário" };
      }
      
      // Rotate RPC on network errors
      if (error instanceof TypeError && error.message.includes("fetch")) {
        rotateRpc();
      }
      
      if (attempt === maxRetries) {
        return {
          success: false,
          error: error instanceof Error ? error.message : "Erro desconhecido ao executar swap",
        };
      }
    }
  }

  return { success: false, error: "Falha após múltiplas tentativas" };
};

/**
 * Get SOL price directly from CoinGecko (browser has no CORS issues with CoinGecko)
 */
const getSolPriceDirect = async (): Promise<number | null> => {
  try {
    console.log("🔄 Fetching SOL price from CoinGecko (direct)...");
    const response = await fetch(
      "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd"
    );
    
    if (response.ok) {
      const data = await response.json();
      if (data.solana?.usd) {
        console.log("✅ SOL price from CoinGecko:", data.solana.usd);
        return data.solana.usd;
      }
    }
    return null;
  } catch (e) {
    console.warn("Direct CoinGecko request failed:", e);
    return null;
  }
};

/**
 * Get SOL price via backend proxy (fallback)
 */
const getSolPriceViaProxy = async (): Promise<number | null> => {
  try {
    const { data, error } = await supabase.functions.invoke("jupiter-proxy", {
      body: { action: "solPrice", params: {} },
    });

    if (error || data.error) {
      console.warn("Proxy SOL price error:", error || data.error);
      return null;
    }

    console.log(`✅ SOL price via proxy (${data.source}):`, data.price);
    return data.price;
  } catch (e) {
    console.warn("Proxy SOL price request failed:", e);
    return null;
  }
};

/**
 * Calculate the amount of SOL/lamports needed for a given USD investment
 */
export const calculateSolAmount = async (usdAmount: number): Promise<number | null> => {
  try {
    console.log("💰 Calculating SOL amount for USD:", usdAmount);
    
    let solPrice: number | null = null;

    // PRIORITY: Direct CoinGecko first (browser works, Edge Functions have DNS issues)
    solPrice = await getSolPriceDirect();
    
    // Fallback to proxy if direct fails
    if (!solPrice) {
      console.log("⚠️ Direct price failed, trying proxy...");
      solPrice = await getSolPriceViaProxy();
    }
    
    // Last resort: Jupiter quote fallback
    if (!solPrice) {
      console.log("⚠️ Proxy price failed, trying Jupiter quote...");
      try {
        const response = await fetch(
          "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd"
        );
        
        if (response.ok) {
          const data = await response.json();
          solPrice = data.solana?.usd;
          console.log("SOL price from CoinGecko (direct):", solPrice);
        }
      } catch (cgError) {
        console.warn("Direct CoinGecko failed:", cgError);
      }
    }
    
    // Last resort: Jupiter quote
    if (!solPrice) {
      console.log("Using Jupiter quote as last resort...");
      const oneSOL = 1_000_000_000;
      const quote = await getJupiterQuote(SOLANA_TOKENS.SOL, SOLANA_TOKENS.USDC, oneSOL, 50);
      
      if (quote && quote.outAmount) {
        solPrice = parseInt(quote.outAmount) / 1_000_000;
        console.log("SOL price from Jupiter quote:", solPrice);
      }
    }
    
    if (!solPrice || solPrice <= 0) {
      console.error("Could not get SOL price from any source");
      toast.error("Não foi possível obter o preço do SOL");
      return null;
    }
    
    const solAmount = usdAmount / solPrice;
    const lamports = Math.floor(solAmount * 1e9);
    
    console.log(`💰 ${usdAmount} USD = ${solAmount.toFixed(4)} SOL = ${lamports} lamports`);
    
    return lamports;
  } catch (error) {
    console.error("Error calculating SOL amount:", error);
    toast.error("Erro ao calcular valor em SOL");
    return null;
  }
};

/**
 * Get SOL price in USD (with retry via proxy)
 */
export const getSolPrice = async (): Promise<number | null> => {
  // Try proxy first
  const proxyPrice = await getSolPriceViaProxy();
  if (proxyPrice) return proxyPrice;

  // Fallback to direct
  try {
    const response = await fetch(
      "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd"
    );
    const data = await response.json();
    return data.solana?.usd || null;
  } catch (error) {
    console.error("Error getting SOL price:", error);
    return null;
  }
};

/**
 * Format lamports to SOL
 */
export const lamportsToSol = (lamports: number): number => {
  return lamports / 1e9;
};

/**
 * Format SOL to lamports
 */
export const solToLamports = (sol: number): number => {
  return Math.floor(sol * 1e9);
};

/**
 * Validate if a string is a valid Solana address
 */
export const isValidSolanaAddress = (address: string): boolean => {
  try {
    new PublicKey(address);
    return true;
  } catch {
    return false;
  }
};

// ==================== JUPITER TRIGGER (LIMIT ORDERS) ====================

interface LimitOrderResult {
  success: boolean;
  orderId?: string;
  signature?: string;
  error?: string;
}

// Re-export WalletProvider type for external use
export type { WalletProvider };

interface WalletProviderExtended {
  publicKey?: { toString: () => string };
  signTransaction?: <T>(transaction: T) => Promise<T>;
  signAllTransactions?: <T>(transactions: T[]) => Promise<T[]>;
  isConnected?: boolean;
}

/**
 * Create a limit order (sell token when it reaches target price)
 * This creates a trigger order on Jupiter that will execute automatically
 * 
 * @param tokenMint - The token to sell
 * @param tokenAmount - Amount of token to sell (in smallest unit)
 * @param targetPriceUsd - Target price in USD to trigger the sell
 * @param userPublicKey - User's wallet public key
 * @param phantomProvider - Phantom wallet provider
 */
/**
 * Create a limit order with retry logic
 */
export const createJupiterLimitOrder = async (
  tokenMint: string,
  tokenAmount: number,
  targetPriceUsd: number,
  userPublicKey: string,
  walletProvider: WalletProviderExtended,
  maxRetries: number = 3
): Promise<LimitOrderResult> => {
  let lastError: string = "";
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      if (attempt > 1) {
        toast.info(`Tentativa ${attempt}/${maxRetries} de criar ordem limite...`);
        // Wait before retry
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
      } else {
        toast.info("Criando ordem limite no Jupiter...");
      }

      // Calculate the expected output amount in USDC based on target price
      const expectedUsdcOutput = Math.floor(tokenAmount * targetPriceUsd * 1e6);
      
      console.log(`[Attempt ${attempt}] Creating limit order:`, {
        tokenMint,
        tokenAmount,
        targetPriceUsd,
        expectedUsdcOutput,
      });

      // Step 1: Create the limit order via Jupiter Trigger API
      const createOrderResponse = await fetch(`${JUPITER_TRIGGER_API}/createOrder`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          inputMint: tokenMint,
          outputMint: SOLANA_TOKENS.USDC,
          maker: userPublicKey,
          payer: userPublicKey,
          params: {
            makingAmount: tokenAmount.toString(),
            takingAmount: expectedUsdcOutput.toString(),
          },
          computeUnitPrice: "auto",
          wrapAndUnwrapSol: true,
        }),
      });

      if (!createOrderResponse.ok) {
        const errorData = await createOrderResponse.json().catch(() => ({}));
        console.error(`[Attempt ${attempt}] Jupiter limit order error:`, errorData);
        lastError = errorData.error || `Falha ao criar ordem: ${createOrderResponse.statusText}`;
        
        // If it's a 4xx error (client error), don't retry
        if (createOrderResponse.status >= 400 && createOrderResponse.status < 500) {
          throw new Error(lastError);
        }
        continue; // Retry on 5xx errors
      }

      const orderData = await createOrderResponse.json();
      console.log(`[Attempt ${attempt}] Order created:`, orderData);

      // Step 2: Sign and submit the transaction
      if (orderData.tx) {
        toast.info("Aguardando assinatura na carteira...");
        
        const transactionBuffer = Buffer.from(orderData.tx, "base64");
        const transaction = VersionedTransaction.deserialize(transactionBuffer);
        
        if (!walletProvider.signTransaction) {
          return { success: false, error: "Carteira não suporta assinatura de transações" };
        }
        
        const signedTransaction = await walletProvider.signTransaction(transaction);
        
        // Send transaction
        toast.info("Enviando ordem para a blockchain...");
        const connection = getConnection();
        const signature = await connection.sendRawTransaction(signedTransaction.serialize(), {
          skipPreflight: false,
          maxRetries: 3,
        });
        
        // Confirm transaction
        toast.info("Confirmando ordem limite...");
        const confirmation = await connection.confirmTransaction(signature, "confirmed");
        
        if (confirmation.value.err) {
          lastError = `Transação falhou: ${JSON.stringify(confirmation.value.err)}`;
          console.error(`[Attempt ${attempt}] ${lastError}`);
          continue; // Retry
        }
        
        // Verify order was created by checking user's orders
        console.log("Verificando se ordem foi criada...");
        const userOrders = await getUserLimitOrders(userPublicKey);
        const orderCreated = userOrders.length > 0;
        
        if (orderCreated) {
          console.log("✅ Ordem verificada com sucesso!");
        } else {
          console.log("⚠️ Ordem enviada mas não encontrada na lista (pode levar alguns segundos)");
        }
        
        return {
          success: true,
          orderId: orderData.order || orderData.orderId,
          signature,
        };
      }

      return {
        success: true,
        orderId: orderData.order || orderData.orderId,
      };
    } catch (error) {
      console.error(`[Attempt ${attempt}] Error creating Jupiter limit order:`, error);
      
      // Don't retry on user rejection
      if (error instanceof Error && error.message.includes("User rejected")) {
        return { success: false, error: "Transação cancelada pelo usuário" };
      }
      
      lastError = error instanceof Error ? error.message : "Erro desconhecido ao criar ordem limite";
      
      // If this was the last attempt, throw
      if (attempt === maxRetries) {
        break;
      }
    }
  }
  
  // All retries failed
  console.error(`❌ Todas as ${maxRetries} tentativas falharam`);
  return {
    success: false,
    error: `Falha após ${maxRetries} tentativas: ${lastError}`,
  };
};

/**
 * Cancel a limit order on Jupiter
 */
export const cancelJupiterLimitOrder = async (
  orderId: string,
  userPublicKey: string,
  walletProvider: WalletProviderExtended
): Promise<LimitOrderResult> => {
  try {
    toast.info("Cancelando ordem limite...");

    const cancelResponse = await fetch(`${JUPITER_TRIGGER_API}/cancelOrder`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        maker: userPublicKey,
        orderId: orderId,
        computeUnitPrice: "auto",
      }),
    });

    if (!cancelResponse.ok) {
      const errorData = await cancelResponse.json().catch(() => ({}));
      console.error("Jupiter cancel order error:", errorData);
      throw new Error(errorData.error || `Falha ao cancelar ordem: ${cancelResponse.statusText}`);
    }

    const cancelData = await cancelResponse.json();
    
    if (cancelData.tx) {
      toast.info("Aguardando assinatura na carteira...");
      
      const transactionBuffer = Buffer.from(cancelData.tx, "base64");
      const transaction = VersionedTransaction.deserialize(transactionBuffer);
      
      if (!walletProvider.signTransaction) {
        return { success: false, error: "Carteira não suporta assinatura de transações" };
      }
      
      const signedTransaction = await walletProvider.signTransaction(transaction);
      
      toast.info("Enviando cancelamento...");
      const connection = getConnection();
      const signature = await connection.sendRawTransaction(signedTransaction.serialize(), {
        skipPreflight: false,
        maxRetries: 3,
      });
      
      await connection.confirmTransaction(signature, "confirmed");
      
      return { success: true, signature };
    }

    return { success: true };
  } catch (error) {
    console.error("Error canceling Jupiter limit order:", error);
    
    if (error instanceof Error && error.message.includes("User rejected")) {
      return { success: false, error: "Cancelamento recusado pelo usuário" };
    }
    
    return {
      success: false,
      error: error instanceof Error ? error.message : "Erro ao cancelar ordem",
    };
  }
};

/**
 * Get user's open limit orders
 */
export const getUserLimitOrders = async (userPublicKey: string): Promise<unknown[]> => {
  try {
    const response = await fetch(`${JUPITER_TRIGGER_API}/getOrders?wallet=${userPublicKey}`);
    
    if (!response.ok) {
      console.error("Error fetching orders:", response.statusText);
      return [];
    }
    
    const data = await response.json();
    return data.orders || [];
  } catch (error) {
    console.error("Error getting user orders:", error);
    return [];
  }
};
