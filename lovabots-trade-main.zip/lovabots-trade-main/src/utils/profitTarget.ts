// Retorna o alvo de lucro configurado pelo usuário
export const getProfitTarget = (profitTarget: number): number => {
  return profitTarget;
};
