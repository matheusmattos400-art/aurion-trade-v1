// Validação de pares para robô automático (sem hooks)

interface ValidationResult {
  isValid: boolean;
  strategy: "micro_distortion" | "partial_reversal" | "trend_follow" | "none";
  zScore: number;
  message: string;
}

// Calcular correlação de Pearson
const calculateCorrelation = (prices1: number[], prices2: number[]): number => {
  const returns1 = prices1.slice(1).map((price, i) => (price - prices1[i]) / prices1[i]);
  const returns2 = prices2.slice(1).map((price, i) => (price - prices2[i]) / prices2[i]);
  
  const mean1 = returns1.reduce((a, b) => a + b, 0) / returns1.length;
  const mean2 = returns2.reduce((a, b) => a + b, 0) / returns2.length;
  
  let num = 0, den1 = 0, den2 = 0;
  for (let i = 0; i < returns1.length; i++) {
    const diff1 = returns1[i] - mean1;
    const diff2 = returns2[i] - mean2;
    num += diff1 * diff2;
    den1 += diff1 * diff1;
    den2 += diff2 * diff2;
  }
  
  return num / Math.sqrt(den1 * den2);
};

// Calcular volatilidade
const calculateVolatility = (prices: number[]): number => {
  const returns = prices.slice(1).map((price, i) => (price - prices[i]) / prices[i]);
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((sum, ret) => sum + Math.pow(ret - mean, 2), 0) / returns.length;
  return Math.sqrt(variance) * 100;
};

export const validatePairStrategy = async (
  symbol1: string,
  symbol2: string
): Promise<ValidationResult> => {
  try {
    // Buscar dados de klines da Binance
    const [klines1_1h, klines2_1h, klines1_30m, klines2_30m, klines1_10d, klines2_10d, klines1_30d, klines2_30d] = await Promise.all([
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol1}&interval=1h&limit=168`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol2}&interval=1h&limit=168`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol1}&interval=30m&limit=48`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol2}&interval=30m&limit=48`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol1}&interval=1d&limit=10`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol2}&interval=1d&limit=10`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol1}&interval=1d&limit=30`).then(r => r.json()),
      fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol2}&interval=1d&limit=30`).then(r => r.json())
    ]);

    // Extrair preços
    const prices1_1h = klines1_1h.map((k: any) => parseFloat(k[4]));
    const prices2_1h = klines2_1h.map((k: any) => parseFloat(k[4]));
    const prices1_10d = klines1_10d.map((k: any) => parseFloat(k[4]));
    const prices2_10d = klines2_10d.map((k: any) => parseFloat(k[4]));
    const prices1_30d = klines1_30d.map((k: any) => parseFloat(k[4]));
    const prices2_30d = klines2_30d.map((k: any) => parseFloat(k[4]));
    const prices1_30m = klines1_30m.map((k: any) => parseFloat(k[4]));
    const prices2_30m = klines2_30m.map((k: any) => parseFloat(k[4]));
    const volumes1_1h = klines1_1h.map((k: any) => parseFloat(k[7]));
    const volumes2_1h = klines2_1h.map((k: any) => parseFloat(k[7]));

    // Calcular correlações
    const corr1h = calculateCorrelation(prices1_1h, prices2_1h);
    const corr10d = calculateCorrelation(prices1_10d, prices2_10d);
    const corr30d = calculateCorrelation(prices1_30d, prices2_30d);
    
    const avgCorrelation = (corr1h + corr10d + corr30d) / 3;
    
    // 🔥 Validação de correlação flexível (≥ 0.70)
    if (avgCorrelation < 0.70) {
      return {
        isValid: false,
        strategy: "none",
        zScore: 0,
        message: `Correlação insuficiente (${avgCorrelation.toFixed(2)})`
      };
    }

    // Calcular Z-Score
    const ratios = prices1_30m.map((p1, i) => (p1 / prices2_30m[i] - 1) * 100);
    const currentDifference = ratios[ratios.length - 1];
    const avgDifference = ratios.reduce((a, b) => a + b, 0) / ratios.length;
    const variance = ratios.reduce((sum, val) => sum + Math.pow(val - avgDifference, 2), 0) / ratios.length;
    const stdDev = Math.sqrt(variance);
    const zScore = (currentDifference - avgDifference) / stdDev;
    const absZScore = Math.abs(zScore);

    // Identificar moeda líder
    const avgVolume1 = volumes1_1h.reduce((a, b) => a + b, 0) / volumes1_1h.length;
    const avgVolume2 = volumes2_1h.reduce((a, b) => a + b, 0) / volumes2_1h.length;
    const leadingCoin = avgVolume1 > avgVolume2 ? symbol1 : symbol2;
    const leaderPrices = leadingCoin === symbol1 ? prices1_30m : prices2_30m;
    const leaderMomentum = ((leaderPrices[leaderPrices.length - 1] - leaderPrices[leaderPrices.length - 2]) / leaderPrices[leaderPrices.length - 2]) * 100;
    const leaderAligned = zScore > 1.2 ? leaderMomentum > 0 : zScore < -1.2 ? leaderMomentum < 0 : true;

    // Calcular volatilidade
    const volatility1 = calculateVolatility(prices1_30m.slice(-20));
    const volatility2 = calculateVolatility(prices2_30m.slice(-20));
    const avgVolatility = (volatility1 + volatility2) / 2;

    // Detectar esgotamento para reversão extrema
    const last3Candles = leaderPrices.slice(-3);
    const momentumChanges = last3Candles.slice(1).map((price, i) => 
      ((price - last3Candles[i]) / last3Candles[i]) * 100
    );
    const avgMomentumLast3 = momentumChanges.reduce((a, b) => a + b, 0) / momentumChanges.length;
    const isLosingMomentum = avgMomentumLast3 < 0.1;
    
    const leaderVolumes = leadingCoin === symbol1 ? volumes1_1h : volumes2_1h;
    const recentLeaderVolumes = leaderVolumes.slice(-3);
    const olderLeaderVolumes = leaderVolumes.slice(-6, -3);
    const recentLeaderAvg = recentLeaderVolumes.reduce((a, b) => a + b, 0) / recentLeaderVolumes.length;
    const olderLeaderAvg = olderLeaderVolumes.reduce((a, b) => a + b, 0) / olderLeaderVolumes.length;
    const hasAbsorption = recentLeaderAvg > olderLeaderAvg * 1.2 && isLosingMomentum;
    
    const zScoreExtreme = absZScore >= 2.5;
    const reversalConditionsMet = avgCorrelation >= 0.70 && isLosingMomentum && zScoreExtreme && hasAbsorption;

    // 🔥 PRIORIDADE 1: REVERSÃO EXTREMA
    if (reversalConditionsMet) {
      return {
        isValid: true,
        strategy: "partial_reversal",
        zScore,
        message: `Reversão Extrema detectada (Z-Score: ${zScore.toFixed(2)})`
      };
    }
    
    // 🔥 PRIORIDADE 2: MICRO DISTORÇÃO
    if (absZScore >= 1.2 && absZScore < 1.6) {
      return {
        isValid: true,
        strategy: "micro_distortion",
        zScore,
        message: `Micro Distorção (Z-Score: ${zScore.toFixed(2)})`
      };
    }
    
    // 🔥 PRIORIDADE 3: REVERSÃO MODERADA
    if (absZScore >= 1.6) {
      return {
        isValid: true,
        strategy: "partial_reversal",
        zScore,
        message: `Reversão Moderada (Z-Score: ${zScore.toFixed(2)})`
      };
    }
    
    // 🔥 PRIORIDADE 4: TREND FOLLOW
    if (absZScore < 1.2 && leaderAligned && Math.abs(leaderMomentum) > 0.5) {
      return {
        isValid: true,
        strategy: "trend_follow",
        zScore,
        message: `Trend Follow (Momentum: ${leaderMomentum.toFixed(2)}%)`
      };
    }

    // Não passou em nenhuma estratégia
    return {
      isValid: false,
      strategy: "none",
      zScore,
      message: `Z-Score neutro (${zScore.toFixed(2)}) ou critérios não atendidos`
    };

  } catch (error) {
    console.error('Erro ao validar par:', error);
    return {
      isValid: false,
      strategy: "none",
      zScore: 0,
      message: "Erro na validação"
    };
  }
};
