let didToastPaymentRequired = false;

const DISABLE_UNTIL_KEY = "aurion_ai_gateway_disable_until";

function safeGetSessionStorage(): Storage | null {
  try {
    return window.sessionStorage;
  } catch {
    return null;
  }
}

export function getInvokeErrorStatusCode(err: unknown): number | null {
  const msg =
    typeof err === "string"
      ? err
      : err && typeof err === "object" && "message" in err
        ? String((err as any).message)
        : "";

  const m = msg.match(/returned\s+(\d{3})/i);
  if (!m) return null;
  const n = Number(m[1]);
  return Number.isFinite(n) ? n : null;
}

export function isAIGatewayTemporarilyDisabled(): boolean {
  const s = safeGetSessionStorage();
  if (!s) return false;
  const until = Number(s.getItem(DISABLE_UNTIL_KEY) || 0);
  return Number.isFinite(until) && Date.now() < until;
}

export function disableAIGatewayForMinutes(minutes: number): void {
  const s = safeGetSessionStorage();
  if (!s) return;
  const until = Date.now() + Math.max(1, minutes) * 60 * 1000;
  s.setItem(DISABLE_UNTIL_KEY, String(until));
}

export function getAIGatewayUserMessage(status: number): string {
  if (status === 402) {
    return "AI is temporarily unavailable: workspace credits are required. Please add credits in Lovable → Settings → Workspace → Usage.";
  }
  if (status === 429) {
    return "AI is rate limited right now. Please wait a moment and try again.";
  }
  return "AI request failed. Please try again.";
}

/**
 * Shows the 402 message only once per session to avoid toast spam from background polling.
 */
export function shouldToastPaymentRequiredOnce(): boolean {
  if (didToastPaymentRequired) return false;
  didToastPaymentRequired = true;
  return true;
}
