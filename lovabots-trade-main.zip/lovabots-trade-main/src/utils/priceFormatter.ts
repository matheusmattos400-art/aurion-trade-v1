// Formata preços de forma inteligente baseado no valor
export const formatPrice = (price: number, currency: string = '$'): string => {
  // Garante que price é um número válido
  const numPrice = Number(price);
  if (!numPrice || isNaN(numPrice) || numPrice === 0) return `${currency}0.00`;
  
  // Para moedas baratas (< $1 = centavos), mostrar até 6 casas decimais
  if (numPrice < 1) {
    return `${currency}${numPrice.toFixed(6)}`;
  }
  // Para moedas normais (< $100), mostrar 3 casas decimais
  else if (numPrice < 100) {
    return `${currency}${numPrice.toFixed(3)}`;
  }
  // Para moedas caras (>= $100), mostrar 2 casas decimais
  else {
    return `${currency}${numPrice.toFixed(2)}`;
  }
};

// Retorna apenas o número de casas decimais apropriado
export const getPriceDecimals = (price: number): number => {
  if (price < 1) return 6;
  if (price < 100) return 3;
  return 2;
};
