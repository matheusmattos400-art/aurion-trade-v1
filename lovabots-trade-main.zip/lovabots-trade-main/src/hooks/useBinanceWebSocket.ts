import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

interface AccountUpdate {
  eventType: string;
  eventTime: number;
  balances?: Array<{
    asset: string;
    walletBalance: string;
    crossWalletBalance: string;
  }>;
  positions?: Array<{
    symbol: string;
    positionAmount: string;
    entryPrice: string;
    unrealizedProfit: string;
    marginType: string;
    isolatedWallet: string;
    positionSide: string;
  }>;
}

interface OrderUpdate {
  eventType: string;
  eventTime: number;
  symbol: string;
  clientOrderId: string;
  side: string;
  orderType: string;
  timeInForce: string;
  originalQuantity: string;
  originalPrice: string;
  averagePrice: string;
  stopPrice: string;
  executionType: string;
  orderStatus: string;
  orderId: number;
  lastFilledQuantity: string;
  cumulativeFilledQuantity: string;
  lastFilledPrice: string;
  commissionAsset: string;
  commissionAmount: string;
  orderTradeTime: number;
  tradeId: number;
  bidsNotional: string;
  asksNotional: string;
  isMakerSide: boolean;
  isReduceOnly: boolean;
  workingType: string;
  originalOrderType: string;
  positionSide: string;
  closeAll: boolean;
  activationPrice: string;
  callbackRate: string;
  realizedProfit: string;
}

export const useBinanceWebSocket = (enabled: boolean = true) => {
  const [accountData, setAccountData] = useState<AccountUpdate | null>(null);
  const [orderUpdate, setOrderUpdate] = useState<OrderUpdate | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const wsRef = useRef<WebSocket | null>(null);
  const listenKeyRef = useRef<string | null>(null);
  const keepAliveIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const fatalAuthErrorRef = useRef(false);
  
  // 🛑 PAUSED: Binance WebSocket disabled until PROXY_URL is configured as HTTP proxy
  // or API key IP restriction is removed
  const BINANCE_WS_PAUSED = true;

  const createListenKey = useCallback(async () => {
    try {
      const timestamp = new Date().toISOString();
      console.log('🔑 Criando NOVA listenKey...', timestamp);
      
      const { data, error } = await supabase.functions.invoke('binance-trading', {
        body: { action: 'create_listen_key' }
      });

      if (error) {
        console.error('❌ Erro ao criar listenKey:', error);
        throw error;
      }

      if (!data?.success || !data?.data?.listenKey) {
        console.error('❌ Resposta inválida ao criar listenKey:', data);
        throw new Error('Failed to create listenKey');
      }

      const listenKey = data.data.listenKey;
      console.log('✅ ListenKey NOVA criada:', {
        prefix: listenKey.substring(0, 10) + '...',
        length: listenKey.length,
        timestamp,
        full: listenKey // LOG COMPLETO para debug
      });
      return listenKey;
    } catch (err) {
      console.error('❌ Erro ao criar listenKey:', err);
      throw err;
    }
  }, []);

  const keepAliveListenKey = useCallback(async () => {
    if (!listenKeyRef.current) return;

    try {
      console.log('🔄 Renovando listenKey...');
      const { data, error } = await supabase.functions.invoke('binance-trading', {
        body: { 
          action: 'keepalive_listen_key',
          listenKey: listenKeyRef.current 
        }
      });

      if (error) {
        console.error('❌ Erro ao renovar listenKey:', error);
        return;
      }

      console.log('✅ ListenKey renovado com sucesso');
    } catch (err) {
      console.error('❌ Erro ao renovar listenKey:', err);
    }
  }, []);

  const connectWebSocket = useCallback(async () => {
    // 🛑 PAUSED: Do not attempt connection while PROXY_URL issue persists
    if (BINANCE_WS_PAUSED) {
      console.log('⏸️ Binance WebSocket está PAUSADO - aguardando configuração de proxy HTTP ou API key sem restrição de IP');
      setError('Binance WebSocket pausado: configure proxy HTTP ou remova restrição de IP da API key');
      return;
    }

    try {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        console.log('⚠️ WebSocket já conectado');
        return;
      }

      // Criar listenKey
      const listenKey = await createListenKey();
      listenKeyRef.current = listenKey;

      // URL do proxy via VPS/Nginx com path direto
      const proxyWsUrl = import.meta.env.VITE_PROXY_WS_URL || 'wss://ws.auriontrading.com.br';
      const wsUrl = `${proxyWsUrl}/ws/${listenKey}`;

      console.log('🔌 Conectando ao WebSocket (PROXY - Path direto):');
      console.log('   URL completa:', wsUrl);
      console.log('   ListenKey COMPLETA:', listenKey);
      console.log('   Timestamp da tentativa:', new Date().toISOString());

      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log('✅ WebSocket conectado via PROXY');
        setIsConnected(true);
        setError(null);

        // Configurar keep-alive a cada 30 minutos
        if (keepAliveIntervalRef.current) {
          clearInterval(keepAliveIntervalRef.current);
        }
        keepAliveIntervalRef.current = setInterval(keepAliveListenKey, 30 * 60 * 1000);
      };

      ws.onmessage = async (event) => {
        try {
          let messageText: string;
          
          // Verificar se é Blob e converter para texto
          if (event.data instanceof Blob) {
            console.log('📦 Recebido Blob, convertendo para texto...');
            messageText = await event.data.text();
          } else {
            messageText = event.data;
          }

          const data = JSON.parse(messageText);

          if (data.e === 'ACCOUNT_UPDATE') {
            console.log('📊 Account Update RAW recebido:', JSON.stringify(data, null, 2));
            
            // Mapear formato da Binance para o formato esperado
            const mappedData: AccountUpdate = {
              eventType: 'ACCOUNT_UPDATE',
              eventTime: data.E || Date.now(),
              positions: (data.a?.P || []).map((pos: any) => ({
                symbol: pos.s,
                positionAmount: pos.pa || '0',
                entryPrice: pos.ep || '0',
                accumulatedRealized: pos.cr || '0',
                unrealizedProfit: pos.up || '0', // ← Mapear corretamente o campo 'up'
                positionSide: pos.ps || 'BOTH'
              })),
              balances: (data.a?.B || []).map((bal: any) => ({
                asset: bal.a,
                walletBalance: bal.wb || '0',
                crossWalletBalance: bal.cw || '0',
                balanceChange: bal.bc || '0'
              }))
            };
            
            console.log('📊 Account Update MAPEADO:', JSON.stringify(mappedData, null, 2));
            setAccountData(mappedData);
          } else if (data.e === 'ORDER_TRADE_UPDATE') {
            console.log('📝 Order Update recebido:', data);
            setOrderUpdate(data);
          }
        } catch (err) {
          console.error('❌ Erro ao processar mensagem WebSocket:', err);
        }
      };

      ws.onerror = (event) => {
        console.error('❌ Erro no WebSocket (PROXY):', event);
        console.error('   Tipo do erro:', event.type);
        setError('Proxy connection error');
      };

      ws.onclose = (event) => {
        console.log('🔌 WebSocket (PROXY) fechado');
        console.log('   Código:', event.code);
        console.log('   Motivo:', event.reason || '(sem motivo especificado)');
        console.log('   Clean close:', event.wasClean);
        
        // Traduzir código de fechamento
        const closeReasons: Record<number, string> = {
          1000: 'Normal closure',
          1001: 'Going away',
          1002: 'Protocol error',
          1003: 'Unsupported data',
          1005: 'No status received',
          1006: 'Abnormal closure (sem handshake)',
          1007: 'Invalid frame payload',
          1008: 'Policy violation',
          1009: 'Message too big',
          1010: 'Missing extension',
          1011: 'Internal error',
          1015: 'TLS handshake failure'
        };
        
        console.log('   Descrição:', closeReasons[event.code] || 'Código desconhecido');
        
        setIsConnected(false);
        wsRef.current = null;

        if (keepAliveIntervalRef.current) {
          clearInterval(keepAliveIntervalRef.current);
          keepAliveIntervalRef.current = null;
        }

        // Reconnect apenas se não houver erro fatal de credenciais
        if (enabled && !fatalAuthErrorRef.current && !reconnectTimeoutRef.current) {
          console.log('🔄 Tentando reconectar via PROXY em 5 segundos...');
          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectTimeoutRef.current = null;
            connectWebSocket();
          }, 5000);
        }
      };

    } catch (err) {
      console.error('❌ Erro ao conectar WebSocket:', err);

      const msg = err instanceof Error ? err.message : 'Failed to connect';
      const isAuthError =
        msg.includes('BINANCE_AUTH_ERROR') ||
        msg.includes('Invalid API-key') ||
        msg.includes('permissions');

      const isProxyConfigError =
        msg.includes('PROXY_CONFIG_ERROR') ||
        msg.includes('socks5://') ||
        msg.includes('proxy HTTP');

      if (isAuthError) {
        fatalAuthErrorRef.current = true;
        setError('Binance bloqueou a API key por IP/permissões. Ajuste a restrição de IP na Binance (Unrestricted) ou use proxy com IP fixo.');
        setIsConnected(false);
        return; // não fica tentando reconectar infinito
      }

      if (isProxyConfigError) {
        // Também é um erro fatal (não adianta ficar tentando reconectar)
        fatalAuthErrorRef.current = true;
        setError('Proxy inválido: PROXY_URL está em socks5://. Configure PROXY_URL como http(s)://<SEU_VPS>:3000 (proxy HTTP→SOCKS5) ou remova a restrição de IP da API key na Binance.');
        setIsConnected(false);
        return;
      }

      setError(msg);

      // Tentar reconectar após 5 segundos
      if (enabled && !fatalAuthErrorRef.current && !reconnectTimeoutRef.current) {
        reconnectTimeoutRef.current = setTimeout(() => {
          reconnectTimeoutRef.current = null;
          connectWebSocket();
        }, 5000);
      }
    }
  }, [enabled, createListenKey, keepAliveListenKey]);

  const disconnect = useCallback(() => {
    console.log('🔌 Desconectando WebSocket...');

    fatalAuthErrorRef.current = false;
    setError(null);

    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    if (keepAliveIntervalRef.current) {
      clearInterval(keepAliveIntervalRef.current);
      keepAliveIntervalRef.current = null;
    }

    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }

    setIsConnected(false);
    listenKeyRef.current = null;
  }, []);

  useEffect(() => {
    if (enabled) {
      connectWebSocket();
    } else {
      disconnect();
    }

    return () => {
      disconnect();
    };
  }, [enabled, connectWebSocket, disconnect]);

  return {
    accountData,
    orderUpdate,
    isConnected,
    error,
    reconnect: connectWebSocket,
    disconnect
  };
};

