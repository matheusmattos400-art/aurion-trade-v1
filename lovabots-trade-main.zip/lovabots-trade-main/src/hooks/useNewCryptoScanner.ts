import { useState, useEffect, useCallback, useRef } from "react";

export interface NewCryptoSignal {
  id: string;
  symbol: string;
  direction: "LONG" | "SHORT";
  quality: "Excelente" | "Bom" | "Moderado";
  currentPrice: number;
  chandelierTrend: "LONG" | "SHORT";
  adxMomentum: "Forte" | "Moderado" | "Fraco";
  diAlignment: "Favorável" | "Neutro";
  rsiCondition: "Favorável" | "Neutro" | "Desfavorável";
  signalReason: string;
  timestamp: number;
  listingDate: Date;
  ageCategory: "1_day" | "5_days" | "3_weeks";
}

export interface UpcomingListing {
  symbol: string;
  name: string;
  expectedDate: string;
  type: string;
  announcementUrl?: string;
}

// Calcular RSI
const calculateRSI = (closes: number[], period: number = 14): number => {
  if (closes.length < period + 1) return 50;

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const change = closes[i] - closes[i - 1];
    if (change >= 0) {
      gains += change;
    } else {
      losses += Math.abs(change);
    }
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = period + 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    
    if (change >= 0) {
      avgGain = (avgGain * (period - 1) + change) / period;
      avgLoss = (avgLoss * (period - 1)) / period;
    } else {
      avgGain = (avgGain * (period - 1)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.abs(change)) / period;
    }
  }

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
};

// Wilder's smoothing (RMA)
const wilderSmooth = (values: number[], period: number): number[] => {
  const result: number[] = [];
  let prevSmoothed = 0;

  for (let i = 0; i < values.length; i++) {
    if (i < period - 1) {
      result.push(0);
    } else if (i === period - 1) {
      let sum = 0;
      for (let j = 0; j < period; j++) {
        sum += values[i - j];
      }
      prevSmoothed = sum / period;
      result.push(prevSmoothed);
    } else {
      prevSmoothed = (prevSmoothed * (period - 1) + values[i]) / period;
      result.push(prevSmoothed);
    }
  }
  return result;
};

// Calcular ADX e DI
const calculateADX = (klines: any[], period: number = 14): { adx: number; plusDI: number; minusDI: number } | null => {
  if (klines.length < period * 2) return null;

  const trValues: number[] = [];
  const plusDMValues: number[] = [];
  const minusDMValues: number[] = [];

  for (let i = 1; i < klines.length; i++) {
    const high = parseFloat(klines[i][2]);
    const low = parseFloat(klines[i][3]);
    const prevHigh = parseFloat(klines[i - 1][2]);
    const prevLow = parseFloat(klines[i - 1][3]);
    const prevClose = parseFloat(klines[i - 1][4]);

    const tr = Math.max(
      high - low,
      Math.abs(high - prevClose),
      Math.abs(low - prevClose)
    );
    trValues.push(tr);

    const upMove = high - prevHigh;
    const downMove = prevLow - low;

    const plusDM = upMove > downMove && upMove > 0 ? upMove : 0;
    const minusDM = downMove > upMove && downMove > 0 ? downMove : 0;

    plusDMValues.push(plusDM);
    minusDMValues.push(minusDM);
  }

  const smoothedTR = wilderSmooth(trValues, period);
  const smoothedPlusDM = wilderSmooth(plusDMValues, period);
  const smoothedMinusDM = wilderSmooth(minusDMValues, period);

  const lastIndex = smoothedTR.length - 1;
  if (lastIndex < 0 || smoothedTR[lastIndex] === 0) return null;

  const plusDI = (smoothedPlusDM[lastIndex] / smoothedTR[lastIndex]) * 100;
  const minusDI = (smoothedMinusDM[lastIndex] / smoothedTR[lastIndex]) * 100;

  const dx: number[] = [];
  for (let i = period - 1; i < smoothedTR.length; i++) {
    if (smoothedTR[i] === 0) {
      dx.push(0);
      continue;
    }
    const pdi = (smoothedPlusDM[i] / smoothedTR[i]) * 100;
    const mdi = (smoothedMinusDM[i] / smoothedTR[i]) * 100;
    const diSum = pdi + mdi;
    const dxValue = diSum === 0 ? 0 : (Math.abs(pdi - mdi) / diSum) * 100;
    dx.push(dxValue);
  }

  const adxValues = wilderSmooth(dx, period);
  const adx = adxValues[adxValues.length - 1] || 0;

  return { adx, plusDI, minusDI };
};

// Calcular Chandelier Exit
const calculateChandelierTrend = (klines: any[], period: number = 22, multiplier: number = 3): "LONG" | "SHORT" => {
  if (klines.length < period + 10) return "LONG";

  const trValues: number[] = [];
  for (let i = 1; i < klines.length; i++) {
    const high = parseFloat(klines[i][2]);
    const low = parseFloat(klines[i][3]);
    const prevClose = parseFloat(klines[i - 1][4]);
    
    const tr = Math.max(
      high - low,
      Math.abs(high - prevClose),
      Math.abs(low - prevClose)
    );
    trValues.push(tr);
  }

  const atrValues: number[] = [];
  for (let i = 0; i < trValues.length; i++) {
    if (i < period - 1) {
      atrValues.push(0);
    } else {
      const sum = trValues.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
      atrValues.push(sum / period);
    }
  }

  const lastIndex = klines.length - 1;
  const atrIndex = lastIndex - 1;
  if (atrIndex < 0 || atrIndex >= atrValues.length) return "LONG";

  const atr = atrValues[atrIndex];
  if (atr === 0) return "LONG";

  let highestHigh = 0;
  let lowestLow = Infinity;
  for (let j = Math.max(0, lastIndex - period); j <= lastIndex; j++) {
    const high = parseFloat(klines[j][2]);
    const low = parseFloat(klines[j][3]);
    if (high > highestHigh) highestHigh = high;
    if (low < lowestLow) lowestLow = low;
  }

  const close = parseFloat(klines[lastIndex][4]);
  const longStop = highestHigh - (atr * multiplier);
  const shortStop = lowestLow + (atr * multiplier);

  if (close > shortStop) return "LONG";
  if (close < longStop) return "SHORT";
  return "LONG";
};

// Buscar todas as moedas listadas na Binance Futures
const fetchAllFuturesSymbols = async (): Promise<{ symbol: string; onboardDate: number }[]> => {
  try {
    const response = await fetch("https://fapi.binance.com/fapi/v1/exchangeInfo");
    if (!response.ok) return [];
    
    const data = await response.json();
    
    return data.symbols
      .filter((s: any) => s.status === "TRADING" && s.quoteAsset === "USDT")
      .map((s: any) => ({
        symbol: s.symbol,
        onboardDate: s.onboardDate || Date.now()
      }));
  } catch (error) {
    console.error("Erro ao buscar símbolos:", error);
    return [];
  }
};

// Categorizar moedas por tempo de listagem
const categorizeByAge = (onboardDate: number): "1_day" | "5_days" | "3_weeks" | null => {
  const now = Date.now();
  const ageMs = now - onboardDate;
  
  const oneDay = 24 * 60 * 60 * 1000;
  const fiveDays = 5 * oneDay;
  const threeWeeks = 21 * oneDay;
  
  if (ageMs <= oneDay) return "1_day";
  if (ageMs <= fiveDays) return "5_days";
  if (ageMs <= threeWeeks) return "3_weeks";
  
  return null; // Mais antiga que 3 semanas
};

// Analisar símbolo
const analyzeNewCrypto = async (
  symbol: string, 
  onboardDate: number,
  ageCategory: "1_day" | "5_days" | "3_weeks"
): Promise<NewCryptoSignal | null> => {
  try {
    const response = await fetch(
      `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=15m&limit=100`
    );

    if (!response.ok) return null;

    const klines = await response.json();
    if (klines.length < 30) return null; // Precisa de dados mínimos

    const closes = klines.map((k: any[]) => parseFloat(k[4]));
    const currentPrice = closes[closes.length - 1];

    const rsi = calculateRSI(closes, 14);
    const adxData = calculateADX(klines, 14);
    if (!adxData) return null;

    const { adx, plusDI, minusDI } = adxData;
    const chandelierTrend = calculateChandelierTrend(klines, 22, 3);

    // Condições para LONG
    const isLongChande = chandelierTrend === "LONG";
    const isLongDI = plusDI > minusDI;
    const isLongRSI = rsi < 70;
    const isRSIFavorableLong = rsi <= 45;

    // Condições para SHORT
    const isShortChande = chandelierTrend === "SHORT";
    const isShortDI = minusDI > plusDI;
    const isShortRSI = rsi > 30;
    const isRSIFavorableShort = rsi >= 55;

    let adxMomentum: "Forte" | "Moderado" | "Fraco" = "Fraco";
    if (adx >= 25) adxMomentum = "Forte";
    else if (adx >= 20) adxMomentum = "Moderado";

    // Confluência
    const longConfluence = isLongChande && isLongDI && isLongRSI && adx >= 20;
    const shortConfluence = isShortChande && isShortDI && isShortRSI && adx >= 20;

    if (!longConfluence && !shortConfluence) return null;

    const direction = longConfluence ? "LONG" : "SHORT";
    
    let qualityScore = 0;
    if (direction === "LONG") {
      if (adx >= 25) qualityScore++;
      if (isRSIFavorableLong) qualityScore++;
      if (plusDI - minusDI > 5) qualityScore++;
    } else {
      if (adx >= 25) qualityScore++;
      if (isRSIFavorableShort) qualityScore++;
      if (minusDI - plusDI > 5) qualityScore++;
    }

    let quality: "Excelente" | "Bom" | "Moderado";
    if (qualityScore >= 3) quality = "Excelente";
    else if (qualityScore >= 2) quality = "Bom";
    else quality = "Moderado";

    const diAlignment = (direction === "LONG" && plusDI > minusDI) || 
                       (direction === "SHORT" && minusDI > plusDI) 
                       ? "Favorável" : "Neutro";

    let rsiCondition: "Favorável" | "Neutro" | "Desfavorável";
    if (direction === "LONG") {
      rsiCondition = rsi <= 40 ? "Favorável" : rsi <= 55 ? "Neutro" : "Desfavorável";
    } else {
      rsiCondition = rsi >= 60 ? "Favorável" : rsi >= 45 ? "Neutro" : "Desfavorável";
    }

    const reasons: string[] = [];
    if (quality === "Excelente") {
      reasons.push("Momento excelente");
    } else if (quality === "Bom") {
      reasons.push("Bom momento");
    } else {
      reasons.push("Momento moderado");
    }
    reasons.push(direction === "LONG" ? "Tendência de alta" : "Tendência de baixa");

    return {
      id: `${symbol}-${direction}-${Date.now()}`,
      symbol,
      direction,
      quality,
      currentPrice,
      chandelierTrend,
      adxMomentum,
      diAlignment,
      rsiCondition,
      signalReason: reasons.join(" • "),
      timestamp: Date.now(),
      listingDate: new Date(onboardDate),
      ageCategory,
    };
  } catch (error) {
    console.error(`Erro ao analisar ${symbol}:`, error);
    return null;
  }
};

export interface NewCryptoData {
  oneDayCoins: NewCryptoSignal[];
  fiveDaysCoins: NewCryptoSignal[];
  threeWeeksCoins: NewCryptoSignal[];
  upcomingListings: UpcomingListing[];
}

export const useNewCryptoScanner = (enabled: boolean = true, intervalMs: number = 120000) => {
  const [data, setData] = useState<NewCryptoData>({
    oneDayCoins: [],
    fiveDaysCoins: [],
    threeWeeksCoins: [],
    upcomingListings: [],
  });
  const [isScanning, setIsScanning] = useState(false);
  const [lastScanTime, setLastScanTime] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<NodeJS.Timeout>();

  const scan = useCallback(async () => {
    if (isScanning) return;
    
    setIsScanning(true);
    setError(null);

    try {
      // Buscar todos os símbolos
      const allSymbols = await fetchAllFuturesSymbols();
      
      // Filtrar por categoria de idade
      const recentSymbols = allSymbols
        .map(s => ({
          ...s,
          ageCategory: categorizeByAge(s.onboardDate)
        }))
        .filter(s => s.ageCategory !== null);

      const oneDaySignals: NewCryptoSignal[] = [];
      const fiveDaysSignals: NewCryptoSignal[] = [];
      const threeWeeksSignals: NewCryptoSignal[] = [];

      // Analisar em lotes
      const batchSize = 3;
      for (let i = 0; i < recentSymbols.length; i += batchSize) {
        const batch = recentSymbols.slice(i, i + batchSize);
        
        const results = await Promise.all(
          batch.map(s => analyzeNewCrypto(s.symbol, s.onboardDate, s.ageCategory!))
        );
        
        results.forEach(signal => {
          if (signal) {
            switch (signal.ageCategory) {
              case "1_day":
                oneDaySignals.push(signal);
                break;
              case "5_days":
                fiveDaysSignals.push(signal);
                break;
              case "3_weeks":
                threeWeeksSignals.push(signal);
                break;
            }
          }
        });

        if (i + batchSize < recentSymbols.length) {
          await new Promise(resolve => setTimeout(resolve, 300));
        }
      }

      // Ordenar por qualidade e pegar top 10
      const qualityOrder = { "Excelente": 3, "Bom": 2, "Moderado": 1 };
      const sortByQuality = (a: NewCryptoSignal, b: NewCryptoSignal) => 
        qualityOrder[b.quality] - qualityOrder[a.quality];

      // Buscar próximos lançamentos via Binance Announcements API
      let upcomingListings: UpcomingListing[] = [];
      try {
        const announcementsResponse = await fetch(
          "https://www.binance.com/bapi/composite/v1/public/cms/article/list/query?type=1&catalogId=48&pageNo=1&pageSize=20"
        );
        
        if (announcementsResponse.ok) {
          const announcementsData = await announcementsResponse.json();
          const articles = announcementsData?.data?.catalogs?.[0]?.articles || [];
          
          // Filtrar artigos que mencionam "will list" ou "perpetual" para futuros
          upcomingListings = articles
            .filter((article: any) => {
              const title = (article.title || "").toLowerCase();
              return (
                title.includes("will list") ||
                title.includes("perpetual") ||
                title.includes("futures") ||
                title.includes("new listing")
              );
            })
            .slice(0, 5)
            .map((article: any) => {
              // Extrair símbolo do título (padrão: "Will List XXX" ou "XXX Perpetual")
              const title = article.title || "";
              const symbolMatch = title.match(/\(([A-Z0-9]+)\)/);
              const symbol = symbolMatch ? symbolMatch[1] : "—";
              
              // Formatar data
              const releaseDate = article.releaseDate 
                ? new Date(article.releaseDate).toLocaleDateString("pt-BR", {
                    day: "2-digit",
                    month: "2-digit",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit"
                  })
                : "Em breve";
              
              return {
                symbol,
                name: title,
                expectedDate: releaseDate,
                type: title.toLowerCase().includes("perpetual") ? "Perpetual" : "Spot",
                announcementUrl: article.code 
                  ? `https://www.binance.com/en/support/announcement/${article.code}`
                  : undefined,
              };
            });
        }
      } catch (err) {
        console.error("Erro ao buscar anúncios:", err);
      }

      // Se não conseguiu buscar, usar fallback
      if (upcomingListings.length === 0) {
        upcomingListings = [
          { 
            symbol: "—", 
            name: "Verifique os anúncios oficiais da Binance", 
            expectedDate: "—", 
            type: "—",
            announcementUrl: "https://www.binance.com/en/support/announcement/new-cryptocurrency-listing?c=48"
          },
        ];
      }

      setData({
        oneDayCoins: oneDaySignals.sort(sortByQuality).slice(0, 10),
        fiveDaysCoins: fiveDaysSignals.sort(sortByQuality).slice(0, 10),
        threeWeeksCoins: threeWeeksSignals.sort(sortByQuality).slice(0, 10),
        upcomingListings,
      });
      
      setLastScanTime(new Date());
    } catch (err) {
      console.error("Erro no scan de novas criptos:", err);
      setError(err instanceof Error ? err.message : "Erro desconhecido");
    } finally {
      setIsScanning(false);
    }
  }, [isScanning]);

  useEffect(() => {
    if (!enabled) return;

    scan();
    intervalRef.current = setInterval(scan, intervalMs);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [enabled, intervalMs, scan]);

  return {
    data,
    isScanning,
    lastScanTime,
    error,
    rescan: scan,
  };
};
