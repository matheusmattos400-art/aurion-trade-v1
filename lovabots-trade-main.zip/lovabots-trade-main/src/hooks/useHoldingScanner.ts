import { useState, useEffect, useCallback, useRef } from "react";

export interface HoldingSignal {
  id: string;
  symbol: string;
  direction: "LONG" | "SHORT";
  quality: "Excelente" | "Bom" | "Moderado";
  currentPrice: number;
  chandelierTrend: "LONG" | "SHORT";
  adxMomentum: "Forte" | "Moderado" | "Fraco";
  diAlignment: "Favorável" | "Neutro";
  rsiCondition: "Favorável" | "Neutro" | "Desfavorável";
  signalReason: string;
  timestamp: number;
}

// Top 30 moedas por volume
const TOP_SYMBOLS = [
  "BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT",
  "DOGEUSDT", "ADAUSDT", "AVAXUSDT", "DOTUSDT", "MATICUSDT",
  "LINKUSDT", "LTCUSDT", "UNIUSDT", "ATOMUSDT", "XLMUSDT",
  "NEARUSDT", "APTUSDT", "ARBUSDT", "OPUSDT", "FILUSDT",
  "INJUSDT", "SUIUSDT", "WLDUSDT", "SEIUSDT", "TIAUSDT",
  "FETUSDT", "AGIXUSDT", "PEPEUSDT", "WIFUSDT", "BONKUSDT"
];

// Calcular RSI
const calculateRSI = (closes: number[], period: number = 14): number => {
  if (closes.length < period + 1) return 50;

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const change = closes[i] - closes[i - 1];
    if (change >= 0) {
      gains += change;
    } else {
      losses += Math.abs(change);
    }
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = period + 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    
    if (change >= 0) {
      avgGain = (avgGain * (period - 1) + change) / period;
      avgLoss = (avgLoss * (period - 1)) / period;
    } else {
      avgGain = (avgGain * (period - 1)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.abs(change)) / period;
    }
  }

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
};

// Wilder's smoothing (RMA)
const wilderSmooth = (values: number[], period: number): number[] => {
  const result: number[] = [];
  let prevSmoothed = 0;

  for (let i = 0; i < values.length; i++) {
    if (i < period - 1) {
      result.push(0);
    } else if (i === period - 1) {
      let sum = 0;
      for (let j = 0; j < period; j++) {
        sum += values[i - j];
      }
      prevSmoothed = sum / period;
      result.push(prevSmoothed);
    } else {
      prevSmoothed = (prevSmoothed * (period - 1) + values[i]) / period;
      result.push(prevSmoothed);
    }
  }
  return result;
};

// Calcular ADX e DI
const calculateADX = (klines: any[], period: number = 14): { adx: number; plusDI: number; minusDI: number } | null => {
  if (klines.length < period * 2) return null;

  const trValues: number[] = [];
  const plusDMValues: number[] = [];
  const minusDMValues: number[] = [];

  for (let i = 1; i < klines.length; i++) {
    const high = parseFloat(klines[i][2]);
    const low = parseFloat(klines[i][3]);
    const prevHigh = parseFloat(klines[i - 1][2]);
    const prevLow = parseFloat(klines[i - 1][3]);
    const prevClose = parseFloat(klines[i - 1][4]);

    const tr = Math.max(
      high - low,
      Math.abs(high - prevClose),
      Math.abs(low - prevClose)
    );
    trValues.push(tr);

    const upMove = high - prevHigh;
    const downMove = prevLow - low;

    const plusDM = upMove > downMove && upMove > 0 ? upMove : 0;
    const minusDM = downMove > upMove && downMove > 0 ? downMove : 0;

    plusDMValues.push(plusDM);
    minusDMValues.push(minusDM);
  }

  const smoothedTR = wilderSmooth(trValues, period);
  const smoothedPlusDM = wilderSmooth(plusDMValues, period);
  const smoothedMinusDM = wilderSmooth(minusDMValues, period);

  const lastIndex = smoothedTR.length - 1;
  if (lastIndex < 0 || smoothedTR[lastIndex] === 0) return null;

  const plusDI = (smoothedPlusDM[lastIndex] / smoothedTR[lastIndex]) * 100;
  const minusDI = (smoothedMinusDM[lastIndex] / smoothedTR[lastIndex]) * 100;

  // Calcular DX e ADX
  const dx: number[] = [];
  for (let i = period - 1; i < smoothedTR.length; i++) {
    if (smoothedTR[i] === 0) {
      dx.push(0);
      continue;
    }
    const pdi = (smoothedPlusDM[i] / smoothedTR[i]) * 100;
    const mdi = (smoothedMinusDM[i] / smoothedTR[i]) * 100;
    const diSum = pdi + mdi;
    const dxValue = diSum === 0 ? 0 : (Math.abs(pdi - mdi) / diSum) * 100;
    dx.push(dxValue);
  }

  const adxValues = wilderSmooth(dx, period);
  const adx = adxValues[adxValues.length - 1] || 0;

  return { adx, plusDI, minusDI };
};

// Calcular Chandelier Exit
const calculateChandelierTrend = (klines: any[], period: number = 22, multiplier: number = 3): "LONG" | "SHORT" => {
  if (klines.length < period + 10) return "LONG";

  // Calcular ATR
  const trValues: number[] = [];
  for (let i = 1; i < klines.length; i++) {
    const high = parseFloat(klines[i][2]);
    const low = parseFloat(klines[i][3]);
    const prevClose = parseFloat(klines[i - 1][4]);
    
    const tr = Math.max(
      high - low,
      Math.abs(high - prevClose),
      Math.abs(low - prevClose)
    );
    trValues.push(tr);
  }

  // ATR média móvel
  const atrValues: number[] = [];
  for (let i = 0; i < trValues.length; i++) {
    if (i < period - 1) {
      atrValues.push(0);
    } else {
      const sum = trValues.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
      atrValues.push(sum / period);
    }
  }

  // Último período
  const lastIndex = klines.length - 1;
  const atrIndex = lastIndex - 1;
  if (atrIndex < 0 || atrIndex >= atrValues.length) return "LONG";

  const atr = atrValues[atrIndex];
  if (atr === 0) return "LONG";

  // Calcular Highest High e Lowest Low
  let highestHigh = 0;
  let lowestLow = Infinity;
  for (let j = Math.max(0, lastIndex - period); j <= lastIndex; j++) {
    const high = parseFloat(klines[j][2]);
    const low = parseFloat(klines[j][3]);
    if (high > highestHigh) highestHigh = high;
    if (low < lowestLow) lowestLow = low;
  }

  const close = parseFloat(klines[lastIndex][4]);
  const longStop = highestHigh - (atr * multiplier);
  const shortStop = lowestLow + (atr * multiplier);

  if (close > shortStop) return "LONG";
  if (close < longStop) return "SHORT";
  return "LONG";
};

// Analisar um símbolo - APENAS sinais fortes com confluência total
const analyzeSymbol = async (symbol: string): Promise<HoldingSignal | null> => {
  try {
    // Usando 15min conforme solicitado
    const response = await fetch(
      `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=15m&limit=100`
    );

    if (!response.ok) return null;

    const klines = await response.json();
    if (klines.length < 50) return null;

    const closes = klines.map((k: any[]) => parseFloat(k[4]));
    const currentPrice = closes[closes.length - 1];

    // RSI
    const rsi = calculateRSI(closes, 14);

    // ADX e DI
    const adxData = calculateADX(klines, 14);
    if (!adxData) return null;

    const { adx, plusDI, minusDI } = adxData;

    // Chandelier Exit
    const chandelierTrend = calculateChandelierTrend(klines, 22, 3);

    // Avaliar condições para LONG
    const isLongChande = chandelierTrend === "LONG";
    const isLongDI = plusDI > minusDI;
    const isLongRSI = rsi < 70; // Não sobrecomprado
    const isRSIFavorableLong = rsi <= 45; // RSI baixo = bom para compra

    // Avaliar condições para SHORT
    const isShortChande = chandelierTrend === "SHORT";
    const isShortDI = minusDI > plusDI;
    const isShortRSI = rsi > 30; // Não sobrevendido
    const isRSIFavorableShort = rsi >= 55; // RSI alto = bom para venda

    // Momentum (ADX)
    let adxMomentum: "Forte" | "Moderado" | "Fraco" = "Fraco";
    if (adx >= 25) adxMomentum = "Forte";
    else if (adx >= 20) adxMomentum = "Moderado";

    // CONFLUÊNCIA TOTAL PARA LONG
    const longConfluence = isLongChande && isLongDI && isLongRSI && adx >= 20;
    
    // CONFLUÊNCIA TOTAL PARA SHORT
    const shortConfluence = isShortChande && isShortDI && isShortRSI && adx >= 20;

    // Só retornar se tiver confluência TOTAL
    if (!longConfluence && !shortConfluence) return null;

    const direction = longConfluence ? "LONG" : "SHORT";
    
    // Determinar qualidade do sinal
    let quality: "Excelente" | "Bom" | "Moderado";
    let qualityScore = 0;

    if (direction === "LONG") {
      // ADX forte = +1
      if (adx >= 25) qualityScore++;
      // RSI favorável (baixo) = +1
      if (isRSIFavorableLong) qualityScore++;
      // DI bem separados = +1
      if (plusDI - minusDI > 5) qualityScore++;
    } else {
      // ADX forte = +1
      if (adx >= 25) qualityScore++;
      // RSI favorável (alto) = +1
      if (isRSIFavorableShort) qualityScore++;
      // DI bem separados = +1
      if (minusDI - plusDI > 5) qualityScore++;
    }

    if (qualityScore >= 3) quality = "Excelente";
    else if (qualityScore >= 2) quality = "Bom";
    else quality = "Moderado";

    // Determinar condições descritivas
    const diAlignment = (direction === "LONG" && plusDI > minusDI) || 
                       (direction === "SHORT" && minusDI > plusDI) 
                       ? "Favorável" : "Neutro";

    let rsiCondition: "Favorável" | "Neutro" | "Desfavorável";
    if (direction === "LONG") {
      rsiCondition = rsi <= 40 ? "Favorável" : rsi <= 55 ? "Neutro" : "Desfavorável";
    } else {
      rsiCondition = rsi >= 60 ? "Favorável" : rsi >= 45 ? "Neutro" : "Desfavorável";
    }

    // Criar descrição em linguagem natural
    const reasons: string[] = [];
    if (quality === "Excelente") {
      reasons.push("Momento excelente para entrada");
    } else if (quality === "Bom") {
      reasons.push("Bom momento para entrada");
    } else {
      reasons.push("Momento moderado para entrada");
    }

    if (direction === "LONG") {
      reasons.push("Tendência de alta confirmada");
    } else {
      reasons.push("Tendência de baixa confirmada");
    }

    return {
      id: `${symbol}-${direction}-${Date.now()}`,
      symbol,
      direction,
      quality,
      currentPrice,
      chandelierTrend,
      adxMomentum,
      diAlignment,
      rsiCondition,
      signalReason: reasons.join(" • "),
      timestamp: Date.now(),
    };
  } catch (error) {
    console.error(`Erro ao analisar ${symbol}:`, error);
    return null;
  }
};

export const useHoldingScanner = (enabled: boolean = true, intervalMs: number = 60000) => {
  const [signals, setSignals] = useState<HoldingSignal[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [lastScanTime, setLastScanTime] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<NodeJS.Timeout>();

  const scan = useCallback(async () => {
    if (isScanning) return;
    
    setIsScanning(true);
    setError(null);

    try {
      // Analisar em lotes para não sobrecarregar
      const batchSize = 5;
      const allSignals: HoldingSignal[] = [];

      for (let i = 0; i < TOP_SYMBOLS.length; i += batchSize) {
        const batch = TOP_SYMBOLS.slice(i, i + batchSize);
        const results = await Promise.all(batch.map(analyzeSymbol));
        
        results.forEach(signal => {
          if (signal) allSignals.push(signal);
        });

        // Pequeno delay entre batches
        if (i + batchSize < TOP_SYMBOLS.length) {
          await new Promise(resolve => setTimeout(resolve, 200));
        }
      }

      // Ordenar por qualidade (Excelente > Bom > Moderado)
      const qualityOrder = { "Excelente": 3, "Bom": 2, "Moderado": 1 };
      allSignals.sort((a, b) => qualityOrder[b.quality] - qualityOrder[a.quality]);

      setSignals(allSignals);
      setLastScanTime(new Date());
    } catch (err) {
      console.error("Erro no scan de holding:", err);
      setError(err instanceof Error ? err.message : "Erro desconhecido");
    } finally {
      setIsScanning(false);
    }
  }, [isScanning]);

  useEffect(() => {
    if (!enabled) return;

    scan();
    intervalRef.current = setInterval(scan, intervalMs);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [enabled, intervalMs, scan]);

  return {
    signals,
    isScanning,
    lastScanTime,
    error,
    rescan: scan,
  };
};
