import { useState, useEffect, useCallback } from "react";
import { toast } from "sonner";
import nacl from "tweetnacl";
import bs58 from "bs58";

export interface PhantomDeepLinkState {
  isConnected: boolean;
  publicKey: string | null;
  balance: number | null;
  isConnecting: boolean;
  error: string | null;
  session: string | null;
}

interface PhantomProvider {
  isPhantom?: boolean;
  publicKey?: { toString: () => string };
  isConnected?: boolean;
  connect: (opts?: { onlyIfTrusted?: boolean }) => Promise<{ publicKey: { toString: () => string } }>;
  disconnect: () => Promise<void>;
  signTransaction?: (transaction: unknown) => Promise<unknown>;
  signAllTransactions?: (transactions: unknown[]) => Promise<unknown[]>;
  signMessage?: (message: Uint8Array) => Promise<{ signature: Uint8Array }>;
  on: (event: string, handler: (...args: unknown[]) => void) => void;
  off: (event: string, handler: (...args: unknown[]) => void) => void;
}

// Use existing global types from usePhantomWallet

const PHANTOM_CONNECT_URL = "https://phantom.app/ul/v1/connect";
const APP_URL = typeof window !== "undefined" ? window.location.origin : "";

// Generate or retrieve keypair for encryption
const getOrCreateKeypair = () => {
  const stored = localStorage.getItem("phantom_dapp_keypair");
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      return {
        publicKey: new Uint8Array(parsed.publicKey),
        secretKey: new Uint8Array(parsed.secretKey),
      };
    } catch {
      // Fall through to create new keypair
    }
  }
  
  const keypair = nacl.box.keyPair();
  localStorage.setItem("phantom_dapp_keypair", JSON.stringify({
    publicKey: Array.from(keypair.publicKey),
    secretKey: Array.from(keypair.secretKey),
  }));
  return keypair;
};

export const usePhantomDeepLink = () => {
  const [walletState, setWalletState] = useState<PhantomDeepLinkState>(() => {
    // Try to restore session from localStorage
    const savedSession = localStorage.getItem("phantom_session");
    const savedPublicKey = localStorage.getItem("phantom_public_key");
    
    return {
      isConnected: !!(savedSession && savedPublicKey),
      publicKey: savedPublicKey,
      balance: null,
      isConnecting: false,
      error: null,
      session: savedSession,
    };
  });

  const [hasPhantom, setHasPhantom] = useState<boolean>(false);
  
  const isMobile = typeof window !== "undefined" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  
  // Detect if we're inside Phantom's in-app browser
  const isInPhantomBrowser = typeof window !== "undefined" && 
    (navigator.userAgent.includes("Phantom") || 
     !!(window as Window & { phantom?: { solana?: PhantomProvider } }).phantom?.solana?.isPhantom);

  const getProvider = (): PhantomProvider | null => {
    if (typeof window === "undefined") return null;
    const win = window as Window & { phantom?: { solana?: PhantomProvider }; solana?: PhantomProvider };
    return win.phantom?.solana || win.solana || null;
  };

  // Check for Phantom extension on mount and sync state from provider
  useEffect(() => {
    const checkPhantom = async () => {
      const provider = getProvider();
      const detected = !!(provider?.isPhantom);
      setHasPhantom(detected);
      
      // If we're in Phantom browser and provider shows connected, sync state
      if (detected && provider?.isConnected && provider?.publicKey) {
        const pubKey = provider.publicKey.toString();
        console.log("[Phantom] Detected connected provider in-app:", pubKey);
        
        // Update state if not already connected or if public key differs
        setWalletState(prev => {
          if (!prev.isConnected || prev.publicKey !== pubKey) {
            localStorage.setItem("phantom_public_key", pubKey);
            localStorage.setItem("phantom_session", "extension");
            return {
              ...prev,
              isConnected: true,
              publicKey: pubKey,
              session: "extension",
            };
          }
          return prev;
        });
      }
    };
    
    checkPhantom();
    // Multiple checks to catch late-loading provider
    const timeout1 = setTimeout(checkPhantom, 300);
    const timeout2 = setTimeout(checkPhantom, 800);
    const timeout3 = setTimeout(checkPhantom, 1500);
    const timeout4 = setTimeout(checkPhantom, 3000);
    
    return () => {
      clearTimeout(timeout1);
      clearTimeout(timeout2);
      clearTimeout(timeout3);
      clearTimeout(timeout4);
    };
  }, []);

  // Fetch SOL balance (high-performance RPC only)
  const fetchBalance = useCallback(async (publicKey: string) => {
    const RPC_ENDPOINTS = [
      "https://rpc.ankr.com/solana",
      "https://api.mainnet-beta.solana.com",
    ];

    for (const rpc of RPC_ENDPOINTS) {
      try {
        const response = await fetch(rpc, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            jsonrpc: "2.0",
            id: 1,
            method: "getBalance",
            params: [publicKey],
          }),
        });

        if (!response.ok) continue;

        const data = await response.json().catch(() => ({}));
        if (data.result?.value !== undefined) {
          const solBalance = data.result.value / 1e9;
          setWalletState((prev) => ({ ...prev, balance: solBalance }));
          return;
        }
      } catch (error) {
        console.warn(`RPC ${rpc.substring(0, 30)}... failed:`, error);
      }
    }
  }, []);

  // Handle deep link response (from URL params)
  useEffect(() => {
    const handleDeepLinkResponse = () => {
      const url = new URL(window.location.href);
      const phantomPublicKey = url.searchParams.get("phantom_encryption_public_key");
      const nonce = url.searchParams.get("nonce");
      const data = url.searchParams.get("data");
      const errorCode = url.searchParams.get("errorCode");
      
      if (errorCode) {
        const errorMessage = url.searchParams.get("errorMessage") || "Conexão rejeitada";
        toast.error(errorMessage);
        setWalletState((prev) => ({ 
          ...prev, 
          isConnecting: false, 
          error: errorMessage 
        }));
        // Clean URL
        window.history.replaceState({}, "", window.location.pathname);
        return;
      }
      
      if (phantomPublicKey && nonce && data) {
        try {
          const keypair = getOrCreateKeypair();
          const sharedSecret = nacl.box.before(
            bs58.decode(phantomPublicKey),
            keypair.secretKey
          );
          
          const decryptedData = nacl.box.open.after(
            bs58.decode(data),
            bs58.decode(nonce),
            sharedSecret
          );
          
          if (decryptedData) {
            const decoded = JSON.parse(new TextDecoder().decode(decryptedData));
            const userPublicKey = decoded.public_key;
            const session = decoded.session;
            
            // Save to localStorage
            localStorage.setItem("phantom_session", session);
            localStorage.setItem("phantom_public_key", userPublicKey);
            localStorage.setItem("phantom_shared_secret", bs58.encode(sharedSecret));
            
            setWalletState({
              isConnected: true,
              publicKey: userPublicKey,
              balance: null,
              isConnecting: false,
              error: null,
              session,
            });
            
            fetchBalance(userPublicKey);
            toast.success(`Carteira conectada: ${userPublicKey.slice(0, 4)}...${userPublicKey.slice(-4)}`);
          }
        } catch (error) {
          console.error("Error decrypting Phantom response:", error);
          toast.error("Erro ao processar resposta do Phantom");
        }
        
        // Clean URL params
        window.history.replaceState({}, "", window.location.pathname);
      }
    };
    
    handleDeepLinkResponse();
  }, [fetchBalance]);

  // Fetch balance on mount if connected
  useEffect(() => {
    if (walletState.publicKey && walletState.isConnected) {
      fetchBalance(walletState.publicKey);
    }
  }, [walletState.publicKey, walletState.isConnected, fetchBalance]);

  // Keep balance fresh while connected (helps avoid "saldo indisponível")
  useEffect(() => {
    if (!walletState.publicKey || !walletState.isConnected) return;

    const id = setInterval(() => {
      fetchBalance(walletState.publicKey as string);
    }, 15000);

    return () => clearInterval(id);
  }, [walletState.publicKey, walletState.isConnected, fetchBalance]);

  // Connect via extension (desktop)
  const connectViaExtension = useCallback(async () => {
    const provider = getProvider();
    
    if (!provider) {
      return false;
    }

    setWalletState((prev) => ({ ...prev, isConnecting: true, error: null }));

    try {
      const response = await provider.connect();
      const publicKey = response.publicKey.toString();

      localStorage.setItem("phantom_public_key", publicKey);
      
      setWalletState({
        isConnected: true,
        publicKey,
        balance: null,
        isConnecting: false,
        error: null,
        session: "extension",
      });

      await fetchBalance(publicKey);
      toast.success(`Carteira conectada: ${publicKey.slice(0, 4)}...${publicKey.slice(-4)}`);
      return true;
    } catch (error: unknown) {
      const err = error as { code?: number; message?: string };
      console.error("Error connecting Phantom:", err);
      const errorMessage = err.code === 4001 
        ? "Conexão rejeitada pelo usuário" 
        : "Erro ao conectar carteira";
      
      toast.error(errorMessage);
      setWalletState((prev) => ({
        ...prev,
        isConnecting: false,
        error: errorMessage,
      }));
      return false;
    }
  }, [fetchBalance]);

  // Connect via deep link (mobile / when extension not available)
  const connectViaDeepLink = useCallback(() => {
    setWalletState((prev) => ({ ...prev, isConnecting: true, error: null }));

    const keypair = getOrCreateKeypair();
    const dappPublicKey = bs58.encode(keypair.publicKey);

    // Use current full URL as redirect
    const currentUrl = window.location.origin + window.location.pathname;

    const params = new URLSearchParams({
      dapp_encryption_public_key: dappPublicKey,
      cluster: "mainnet-beta",
      app_url: window.location.origin,
      redirect_link: currentUrl,
    });

    // Universal link (works in most browsers)
    const connectUrl = `${PHANTOM_CONNECT_URL}?${params.toString()}`;

    // Custom scheme (more reliable when Phantom is installed)
    // IMPORTANT: must be phantom://ul/... (no extra slash), otherwise Phantom may open without showing the connect screen.
    const phantomSchemeUrl = `phantom://ul/v1/connect?${params.toString()}`;

    console.log("Phantom connect URL:", connectUrl);
    console.log("Phantom scheme URL:", phantomSchemeUrl);

    if (isMobile) {
      // 1) Try to open the Phantom app directly
      window.location.href = phantomSchemeUrl;

      // 2) Fallback to universal link (some browsers block custom schemes)
      setTimeout(() => {
        if (!document.hidden) {
          window.location.href = connectUrl;
        }
      }, 1200);

      return;
    }

    // Desktop without extension: open universal link
    window.location.href = connectUrl;
  }, [isMobile]);

  // Main connect function - tries extension first, then deep link
  const connectWallet = useCallback(async () => {
    // If extension is available, use it
    if (hasPhantom) {
      return await connectViaExtension();
    }
    
    // Otherwise use deep link
    connectViaDeepLink();
    return false; // Will return true via deep link callback
  }, [hasPhantom, connectViaExtension, connectViaDeepLink]);

  // Disconnect wallet
  const disconnectWallet = useCallback(async () => {
    const provider = getProvider();
    
    if (provider && walletState.session === "extension") {
      try {
        await provider.disconnect();
      } catch (error) {
        console.error("Error disconnecting:", error);
      }
    }
    
    // Clear localStorage
    localStorage.removeItem("phantom_session");
    localStorage.removeItem("phantom_public_key");
    localStorage.removeItem("phantom_shared_secret");
    
    setWalletState({
      isConnected: false,
      publicKey: null,
      balance: null,
      isConnecting: false,
      error: null,
      session: null,
    });
    toast.info("Carteira desconectada");
  }, [walletState.session]);

  // Listen for extension account changes
  useEffect(() => {
    const provider = getProvider();
    if (!provider) return;

    const handleAccountChanged = (publicKey: unknown) => {
      if (publicKey) {
        const pubKeyStr = (publicKey as { toString: () => string }).toString();
        localStorage.setItem("phantom_public_key", pubKeyStr);
        setWalletState((prev) => ({
          ...prev,
          publicKey: pubKeyStr,
          isConnected: true,
        }));
        fetchBalance(pubKeyStr);
      } else {
        disconnectWallet();
      }
    };

    const handleDisconnect = () => {
      disconnectWallet();
    };

    provider.on("accountChanged", handleAccountChanged);
    provider.on("disconnect", handleDisconnect);

    return () => {
      provider.off("accountChanged", handleAccountChanged);
      provider.off("disconnect", handleDisconnect);
    };
  }, [fetchBalance, disconnectWallet]);

  // Try silent connect on mount (extension only)
  useEffect(() => {
    const provider = getProvider();
    if (!provider || walletState.isConnected) return;

    const checkConnection = async () => {
      try {
        const response = await provider.connect({ onlyIfTrusted: true });
        const publicKey = response.publicKey.toString();
        
        localStorage.setItem("phantom_public_key", publicKey);
        
        setWalletState({
          isConnected: true,
          publicKey,
          balance: null,
          isConnecting: false,
          error: null,
          session: "extension",
        });

        await fetchBalance(publicKey);
      } catch {
        // Not previously connected, that's fine
      }
    };

    checkConnection();
  }, [fetchBalance, walletState.isConnected]);

  return {
    ...walletState,
    hasPhantom,
    isMobile,
    isInPhantomBrowser,
    connectWallet,
    disconnectWallet,
    connectViaDeepLink,
    getProvider,
  };
};
