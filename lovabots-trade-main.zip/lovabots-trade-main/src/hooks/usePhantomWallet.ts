import { useState, useEffect, useCallback } from "react";
import { toast } from "sonner";

export interface PhantomWalletState {
  isConnected: boolean;
  publicKey: string | null;
  balance: number | null;
  isConnecting: boolean;
  error: string | null;
}

interface PhantomProvider {
  isPhantom?: boolean;
  publicKey?: { toString: () => string };
  isConnected?: boolean;
  connect: (opts?: { onlyIfTrusted?: boolean }) => Promise<{ publicKey: { toString: () => string } }>;
  disconnect: () => Promise<void>;
  signTransaction?: (transaction: unknown) => Promise<unknown>;
  signAllTransactions?: (transactions: unknown[]) => Promise<unknown[]>;
  signMessage?: (message: Uint8Array) => Promise<{ signature: Uint8Array }>;
  on: (event: string, handler: (...args: unknown[]) => void) => void;
  off: (event: string, handler: (...args: unknown[]) => void) => void;
}

export const usePhantomWallet = () => {
  const [walletState, setWalletState] = useState<PhantomWalletState>(() => ({
    isConnected: false,
    publicKey: null,
    balance: null,
    isConnecting: false,
    error: null,
  }));

  const [hasPhantom, setHasPhantom] = useState<boolean>(false);
  
  const isMobile = typeof window !== "undefined" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

  const getProvider = useCallback((): PhantomProvider | null => {
    if (typeof window === "undefined") return null;
    const win = window as Window & { phantom?: { solana?: PhantomProvider }; solana?: PhantomProvider };
    const provider = win.phantom?.solana || win.solana || null;
    console.log("[Phantom] getProvider check:", {
      hasPhantomObject: !!win.phantom,
      hasPhantomSolana: !!win.phantom?.solana,
      hasSolana: !!win.solana,
      isPhantom: provider?.isPhantom,
    });
    return provider;
  }, []);

  // Check for Phantom on mount (handles delayed injection)
  useEffect(() => {
    const checkPhantom = () => {
      const provider = getProvider();
      const detected = !!(provider?.isPhantom);
      console.log("[Phantom] Detection check - isPhantom:", detected);
      setHasPhantom(detected);
    };
    
    // Check immediately
    checkPhantom();
    
    // Check again after delays (Phantom can inject after page load)
    const timeout1 = setTimeout(checkPhantom, 500);
    const timeout2 = setTimeout(checkPhantom, 1500);
    const timeout3 = setTimeout(checkPhantom, 3000);
    
    // Also listen for the provider injection event
    const handleProviderInjected = () => {
      console.log("[Phantom] Provider injection event detected");
      checkPhantom();
    };
    window.addEventListener("phantom#initialized", handleProviderInjected);
    
    return () => {
      clearTimeout(timeout1);
      clearTimeout(timeout2);
      clearTimeout(timeout3);
      window.removeEventListener("phantom#initialized", handleProviderInjected);
    };
  }, [getProvider]);

  const fetchBalance = useCallback(async (publicKey: string) => {
    const RPC_ENDPOINTS = [
      "https://mainnet.helius-rpc.com/?api-key=1d8740dc-e5f4-421c-b823-e1bad1889eff",
      "https://rpc.ankr.com/solana",
    ];

    for (const rpc of RPC_ENDPOINTS) {
      try {
        const response = await fetch(rpc, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            jsonrpc: "2.0",
            id: 1,
            method: "getBalance",
            params: [publicKey],
          }),
        });

        if (!response.ok) continue;

        const data = await response.json().catch(() => ({}));
        if (data.result?.value !== undefined) {
          // Convert lamports to SOL (1 SOL = 1e9 lamports)
          const solBalance = data.result.value / 1e9;
          setWalletState((prev) => ({
            ...prev,
            balance: solBalance,
          }));
          return;
        }
      } catch (error) {
        console.warn(`RPC ${rpc.substring(0, 30)}... failed:`, error);
      }
    }
  }, []);

  const connectWallet = useCallback(async () => {
    console.log("[Phantom] connectWallet called");
    const provider = getProvider();
    
    if (!provider) {
      console.log("[Phantom] Provider not found, opening download page");
      toast.error("Phantom não detectado! Verifique se a extensão está ativa.", {
        action: {
          label: "Baixar",
          onClick: () => window.open("https://phantom.app/download", "_blank"),
        },
      });
      setWalletState((prev) => ({
        ...prev,
        error: "Phantom não detectado",
      }));
      return false;
    }

    console.log("[Phantom] Provider found, attempting connection...");
    setWalletState((prev) => ({ ...prev, isConnecting: true, error: null }));

    try {
      const response = await provider.connect();
      const publicKey = response.publicKey.toString();
      console.log("[Phantom] Connected successfully:", publicKey);

      setWalletState({
        isConnected: true,
        publicKey,
        balance: null,
        isConnecting: false,
        error: null,
      });

      await fetchBalance(publicKey);

      toast.success(`Carteira conectada: ${publicKey.slice(0, 4)}...${publicKey.slice(-4)}`);
      return true;
    } catch (error: unknown) {
      const err = error as { code?: number; message?: string };
      console.error("[Phantom] Error connecting:", err);
      const errorMessage = err.code === 4001 
        ? "Conexão rejeitada pelo usuário" 
        : `Erro ao conectar: ${err.message || "tente novamente"}`;
      
      toast.error(errorMessage);
      setWalletState((prev) => ({
        ...prev,
        isConnecting: false,
        error: errorMessage,
      }));
      return false;
    }
  }, [fetchBalance, getProvider]);

  const disconnectWallet = useCallback(async () => {
    const provider = getProvider();
    
    if (provider) {
      try {
        await provider.disconnect();
      } catch (error) {
        console.error("Error disconnecting:", error);
      }
    }
    
    setWalletState({
      isConnected: false,
      publicKey: null,
      balance: null,
      isConnecting: false,
      error: null,
    });
    toast.info("Carteira desconectada");
  }, []);

  // Listen for account changes
  useEffect(() => {
    const provider = getProvider();
    if (!provider) return;

    const handleAccountChanged = (publicKey: unknown) => {
      if (publicKey) {
        const pubKeyStr = (publicKey as { toString: () => string }).toString();
        setWalletState((prev) => ({
          ...prev,
          publicKey: pubKeyStr,
          isConnected: true,
        }));
        fetchBalance(pubKeyStr);
      } else {
        // User disconnected
        setWalletState({
          isConnected: false,
          publicKey: null,
          balance: null,
          isConnecting: false,
          error: null,
        });
      }
    };

    const handleDisconnect = () => {
      setWalletState({
        isConnected: false,
        publicKey: null,
        balance: null,
        isConnecting: false,
        error: null,
      });
    };

    provider.on("accountChanged", handleAccountChanged);
    provider.on("disconnect", handleDisconnect);

    return () => {
      provider.off("accountChanged", handleAccountChanged);
      provider.off("disconnect", handleDisconnect);
    };
  }, [fetchBalance]);

  // Check if already connected on mount
  useEffect(() => {
    const provider = getProvider();
    if (!provider) return;

    const checkConnection = async () => {
      try {
        // Try to connect silently (only if trusted)
        const response = await provider.connect({ onlyIfTrusted: true });
        const publicKey = response.publicKey.toString();
        
        setWalletState({
          isConnected: true,
          publicKey,
          balance: null,
          isConnecting: false,
          error: null,
        });

        await fetchBalance(publicKey);
      } catch {
        // User hasn't connected before or rejected, that's fine
      }
    };

    checkConnection();
  }, [fetchBalance]);


  const openPhantomOrDownload = () => {
    if (isMobile) {
      // Mobile: open the dApp inside the Phantom app browser
      const dappUrl = window.location.href.replace(/^https?:\/\//, "");
      window.location.href = `https://phantom.app/ul/browse/${encodeURIComponent(`https://${dappUrl}`)}`;
      return;
    }

    // Desktop: guide to install the extension
    window.open("https://phantom.app/download", "_blank");
  };

  return {
    ...walletState,
    hasPhantom,
    isMobile,
    connectWallet,
    disconnectWallet,
    openPhantomOrDownload,
    getProvider,
  };
};
