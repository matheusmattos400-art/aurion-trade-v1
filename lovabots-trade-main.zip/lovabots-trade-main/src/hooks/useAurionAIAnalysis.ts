import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  disableAIGatewayForMinutes,
  getAIGatewayUserMessage,
  getInvokeErrorStatusCode,
  isAIGatewayTemporarilyDisabled,
  shouldToastPaymentRequiredOnce,
} from "@/utils/aiCreditsGuard";

// Tipos para a análise completa da IA
export interface ForensicItem {
  status: "SAFE" | "WARNING" | "DANGER";
  detail: string;
}

export interface ForensicAnalysis {
  mintAuthority: ForensicItem;
  freezeAuthority: ForensicItem;
  lpStatus: ForensicItem;
  creatorHistory: ForensicItem;
  liquidityAnalysis: ForensicItem;
  holderDistribution: ForensicItem;
  socialAnalysis?: SocialAnalysis;
}

export interface SocialAnalysis {
  hasTwitter: boolean;
  twitterUrl: string | null;
  hasWebsite: boolean;
  websiteUrl: string | null;
  hasTelegram: boolean;
  telegramUrl: string | null;
  hasDiscord: boolean;
  discordUrl: string | null;
  socialScore: number;
  socialRisk: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  socialRiskReason: string;
  totalSocials: number;
}

export interface TechnicalAnalysis {
  trend: "BULLISH" | "BEARISH" | "NEUTRAL";
  strength: "STRONG" | "MODERATE" | "WEAK";
  entryZone: "GOOD" | "NEUTRAL" | "BAD";
  detail: string;
}

export interface TradePlan {
  entry: string;
  stopLoss: string;
  takeProfit1: string;
  takeProfit2: string;
  timeframe: string;
  riskReward: string;
}

export interface TokenInfo {
  symbol: string;
  name: string;
  address: string;
  price: number;
  liquidity: number;
  volume24h: number;
  priceChange24h: number;
  age: string;
}

export interface AIAnalysisResult {
  score: number;
  verdict: "APROVADO" | "APROVADO_COM_RESSALVAS" | "NEUTRO" | "REPROVADO" | "PERIGOSO" | "SCAM_CONFIRMADO";
  tradeProfile: "SCALP" | "SWING" | "HOLD" | "NAO_OPERAR";
  confidence: number;
  summary: string;
  forensicAnalysis: ForensicAnalysis;
  technicalAnalysis: TechnicalAnalysis;
  tradePlan: TradePlan | null;
  warnings: string[];
  positives: string[];
  finalRecommendation: string;
  analyzedAt: string;
  tokenInfo: TokenInfo;
  dataSource: {
    dexscreener: boolean;
    rugcheck: boolean;
  };
}

export interface TokenData {
  symbol: string;
  name: string;
  address: string;
  chainId: string;
  pairAddress: string;
  price?: number;
  priceChange24h?: number;
  volume24h?: number;
  liquidity?: number;
  marketCap?: number;
  fdv?: number;
  pairCreatedAt?: number;
  securityScore?: number;
  mintAuthority?: string | null;
  freezeAuthority?: string | null;
  lpLocked?: boolean;
  chandelierExit?: { trend: string; price: number };
  adx?: { value: number; plusDI: number; minusDI: number };
  rsi?: number;
  topHolders?: Array<{ address: string; percentage: number }>;
  creatorAddress?: string;
  website?: string;
  twitter?: string;
}

export function useAurionAIAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AIAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const analyzeToken = useCallback(async (token: TokenData): Promise<AIAnalysisResult | null> => {
    if (isAIGatewayTemporarilyDisabled()) {
      const msg = getAIGatewayUserMessage(402);
      setError(msg);
      // Avoid spamming the user with toasts from repeated clicks.
      if (shouldToastPaymentRequiredOnce()) toast.error(msg);
      return null;
    }

    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      // Obter usuário atual se disponível
      const { data: { user } } = await supabase.auth.getUser();
      const userId = user?.id;

      // Obter conversationId ativo do localStorage
      const conversationId = localStorage.getItem("aurion_ai_active_conversation_id");

      console.log("Aurion AI Analysis - userId:", userId, "conversationId:", conversationId);

      // Chamar a função central de análise com conversationId
      const { data, error: fnError } = await supabase.functions.invoke("aurion-full-analysis", {
        body: {
          token,
          userId,
          conversationId, // Passa o ID da conversa ativa para sincronizar instruções
        },
      });

       if (fnError) {
         const status = getInvokeErrorStatusCode(fnError) ?? null;
         if (status === 402) {
           disableAIGatewayForMinutes(10);
           const msg = getAIGatewayUserMessage(402);
           throw new Error(msg);
         }
         if (status === 429) {
           const msg = getAIGatewayUserMessage(429);
           throw new Error(msg);
         }
         throw new Error(fnError.message);
       }

      if (data.error) {
        throw new Error(data.error);
      }

      setResult(data as AIAnalysisResult);
      toast.success("Análise Aurion AI concluída!");
      return data as AIAnalysisResult;

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Erro desconhecido na análise";
      setError(errorMessage);
      toast.error(`Erro na análise: ${errorMessage}`);
      return null;
    } finally {
      setIsAnalyzing(false);
    }
  }, []);

  const clearAnalysis = useCallback(() => {
    setResult(null);
    setError(null);
  }, []);

  return {
    analyzeToken,
    clearAnalysis,
    isAnalyzing,
    result,
    error,
  };
}
