import { useState, useEffect, useRef } from "react";
import { useTradingMode } from "@/contexts/TradingModeContext";

interface AnalysisResult {
  isValid: boolean;
  signal: "long_first" | "short_first" | "none";
  longSymbol: string;  // Qual moeda comprar (long)
  shortSymbol: string; // Qual moeda vender (short)
  currentMomentum: number;
  avgBullishMomentum: number;  // Média apenas dos momentums positivos
  avgBearishMomentum: number;  // Média apenas dos momentums negativos
  momentumDistortion: number;  // Diferença do momentum atual vs média correspondente
  correlationValid: boolean;
  correlations: {
    period1h: number;
    period10d: number;
    period30d: number;
  };
  liquidityRatio: number;
  message: string;
}

interface MomentumHistoryPoint {
  timestamp: number;
  momentum: number;
}

// Janela de análise configurável (em períodos de 30min)
const MOMENTUM_WINDOW_PERIODS = 48; // 24 horas

export const useAdvancedPairAnalysis = (symbol1: string, symbol2: string) => {
  const { isB3Mode } = useTradingMode();
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Referência para detectar mudança de par
  const lastPairRef = useRef<string>("");

  // Quando o par muda, resetar o estado
  useEffect(() => {
    const currentPair = `${symbol1}-${symbol2}`;
    if (lastPairRef.current && lastPairRef.current !== currentPair) {
      // Par mudou - o novo cálculo virá da API com dados do novo par
      setAnalysis(null);
    }
    lastPairRef.current = currentPair;
  }, [symbol1, symbol2]);

  // Calcular correlação de Pearson
  const calculateCorrelation = (prices1: number[], prices2: number[]): number => {
    const returns1 = prices1.slice(1).map((price, i) => (price - prices1[i]) / prices1[i]);
    const returns2 = prices2.slice(1).map((price, i) => (price - prices2[i]) / prices2[i]);
    
    const mean1 = returns1.reduce((a, b) => a + b, 0) / returns1.length;
    const mean2 = returns2.reduce((a, b) => a + b, 0) / returns2.length;
    
    let num = 0, den1 = 0, den2 = 0;
    for (let i = 0; i < returns1.length; i++) {
      const diff1 = returns1[i] - mean1;
      const diff2 = returns2[i] - mean2;
      num += diff1 * diff2;
      den1 += diff1 * diff1;
      den2 += diff2 * diff2;
    }
    
    return num / Math.sqrt(den1 * den2);
  };

  useEffect(() => {
    if (!symbol1 || !symbol2 || isB3Mode) {
      setAnalysis(null);
      return;
    }

    const analyzeAdvanced = async () => {
      try {
        setIsLoading(true);
        setError(null);

        // Buscar dados para correlação (1h, 10d, 30d) e momentum (30min)
        const [klines1_1h, klines2_1h, klines1_30m, klines2_30m, klines1_10d, klines2_10d, klines1_30d, klines2_30d] = await Promise.all([
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol1}&interval=1h&limit=168`).then(r => r.json()),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol2}&interval=1h&limit=168`).then(r => r.json()),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol1}&interval=30m&limit=${MOMENTUM_WINDOW_PERIODS}`).then(r => r.json()),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol2}&interval=30m&limit=${MOMENTUM_WINDOW_PERIODS}`).then(r => r.json()),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol1}&interval=1d&limit=10`).then(r => r.json()),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol2}&interval=1d&limit=10`).then(r => r.json()),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol1}&interval=1d&limit=30`).then(r => r.json()),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol2}&interval=1d&limit=30`).then(r => r.json())
        ]);

        // PRIMEIRO FILTRO: Análise de Correlação
        const prices1_1h = klines1_1h.map((k: any) => parseFloat(k[4]));
        const prices2_1h = klines2_1h.map((k: any) => parseFloat(k[4]));
        const prices1_10d = klines1_10d.map((k: any) => parseFloat(k[4]));
        const prices2_10d = klines2_10d.map((k: any) => parseFloat(k[4]));
        const prices1_30d = klines1_30d.map((k: any) => parseFloat(k[4]));
        const prices2_30d = klines2_30d.map((k: any) => parseFloat(k[4]));

        const corr1h = calculateCorrelation(prices1_1h, prices2_1h);
        const corr10d = calculateCorrelation(prices1_10d, prices2_10d);
        const corr30d = calculateCorrelation(prices1_30d, prices2_30d);

        // Correlação mínima de 0.70
        const correlations = [corr1h, corr10d, corr30d];
        const avgCorrelation = correlations.reduce((a, b) => a + b, 0) / correlations.length;
        const correlationValid = avgCorrelation >= 0.70;

        // Se correlação não passar, retornar resultado negativo imediatamente
        if (!correlationValid) {
          setAnalysis({
            isValid: false,
            signal: "none",
            longSymbol: "",
            shortSymbol: "",
            currentMomentum: 0,
            avgBullishMomentum: 0,
            avgBearishMomentum: 0,
            momentumDistortion: 0,
            correlationValid: false,
            correlations: {
              period1h: corr1h,
              period10d: corr10d,
              period30d: corr30d
            },
            liquidityRatio: 1,
            message: `❌ Correlação insuficiente (média: ${avgCorrelation.toFixed(2)}). Necessário: ≥ 0.70`
          });
          setIsLoading(false);
          return;
        }

        // ===== CÁLCULO DO MOMENTUM PURO =====
        // Usar o mesmo cálculo que o gráfico MomentumIndicator
        const currentTimestamp = Date.now();
        
        // Filtrar apenas candles fechados (closeTime < currentTimestamp)
        const closedKlines1 = klines1_30m.filter((k: any) => k[6] < currentTimestamp);
        const closedKlines2 = klines2_30m.filter((k: any) => k[6] < currentTimestamp);
        
        // Usar o menor array para garantir consistência
        const minLength = Math.min(closedKlines1.length, closedKlines2.length);
        const prices1_30m = closedKlines1.slice(-minLength).map((k: any) => parseFloat(k[4]));
        const prices2_30m = closedKlines2.slice(-minLength).map((k: any) => parseFloat(k[4]));
        
        const volumes1_1h = klines1_1h.map((k: any) => parseFloat(k[7]));
        const volumes2_1h = klines2_1h.map((k: any) => parseFloat(k[7]));

        // Verificar se temos dados suficientes
        if (prices1_30m.length < 2 || prices2_30m.length < 2) {
          console.log('[MOMENTUM DEBUG] Aguardando mais candles fechados...');
          setIsLoading(false);
          return;
        }

        // Calcular ratio (symbol1 / symbol2) para cada período
        const ratios = prices1_30m.map((p1: number, i: number) => p1 / prices2_30m[i]);
        
        // Calcular momentum do ratio para cada período (variação percentual)
        const momentums: number[] = [];
        for (let i = 1; i < ratios.length; i++) {
          const momentum = ((ratios[i] - ratios[i - 1]) / ratios[i - 1]) * 100;
          momentums.push(momentum);
        }

        // ===== BUSCAR PREÇOS EM TEMPO REAL (igual ao gráfico) =====
        const [priceRes1, priceRes2] = await Promise.all([
          fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${symbol1}`).then(r => r.json()),
          fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${symbol2}`).then(r => r.json())
        ]);
        
        const currentPrice1 = parseFloat(priceRes1.price);
        const currentPrice2 = parseFloat(priceRes2.price);
        
        // Pegar último candle fechado
        const lastClosedPrice1 = prices1_30m[prices1_30m.length - 1];
        const lastClosedPrice2 = prices2_30m[prices2_30m.length - 1];
        
        // Calcular momentum em tempo real (MESMA FÓRMULA DO GRÁFICO)
        const prevRatio = lastClosedPrice1 / lastClosedPrice2;
        const currentRatio = currentPrice1 / currentPrice2;
        const currentMomentum = ((currentRatio - prevRatio) / prevRatio) * 100;
        
        console.log(`[MOMENTUM DEBUG] Par: ${symbol1}/${symbol2}`);
        console.log(`[MOMENTUM DEBUG] Preço atual ${symbol1}: ${currentPrice1}, ${symbol2}: ${currentPrice2}`);
        console.log(`[MOMENTUM DEBUG] Último fechado ${symbol1}: ${lastClosedPrice1}, ${symbol2}: ${lastClosedPrice2}`);
        console.log(`[MOMENTUM DEBUG] Ratio atual: ${currentRatio.toFixed(6)}, Ratio anterior: ${prevRatio.toFixed(6)}`);
        console.log(`[MOMENTUM DEBUG] Momentum em tempo real: ${currentMomentum.toFixed(4)}%`);

        // ===== CALCULAR MÉDIAS SEPARADAS: ALTA E BAIXA =====
        const bullishMomentums = momentums.filter(m => m > 0);
        const bearishMomentums = momentums.filter(m => m < 0);

        const avgBullishMomentum = bullishMomentums.length > 0 
          ? bullishMomentums.reduce((a, b) => a + b, 0) / bullishMomentums.length 
          : 0;
        
        const avgBearishMomentum = bearishMomentums.length > 0 
          ? bearishMomentums.reduce((a, b) => a + b, 0) / bearishMomentums.length 
          : 0;

        console.log(`[MOMENTUM DEBUG] Média Alta: ${avgBullishMomentum.toFixed(4)}%, Média Baixa: ${avgBearishMomentum.toFixed(4)}%`);
        console.log(`[MOMENTUM DEBUG] Sinal válido? Momentum ${currentMomentum.toFixed(4)} >= MédiaAlta ${avgBullishMomentum.toFixed(4)} = ${currentMomentum >= avgBullishMomentum && currentMomentum > 0}`);
        console.log(`[MOMENTUM DEBUG] Sinal válido? Momentum ${currentMomentum.toFixed(4)} <= MédiaBaixa ${avgBearishMomentum.toFixed(4)} = ${currentMomentum <= avgBearishMomentum && currentMomentum < 0}`);

        // Calcular liquidez (volume médio)
        const avgVolume1 = volumes1_1h.reduce((a: number, b: number) => a + b, 0) / volumes1_1h.length;
        const avgVolume2 = volumes2_1h.reduce((a: number, b: number) => a + b, 0) / volumes2_1h.length;
        const liquidityRatio = Math.max(avgVolume1, avgVolume2) / Math.min(avgVolume1, avgVolume2);

        // ===== LÓGICA DE SINAL BASEADA EXCLUSIVAMENTE EM MOMENTUM =====
        let signal: "long_first" | "short_first" | "none" = "none";
        let longSymbol = "";
        let shortSymbol = "";
        let message = "";
        let isValid = false;
        let momentumDistortion = 0;

        // Distorção: quão longe o momentum atual está da média correspondente
        // Se momentum positivo: comparar com média de alta
        // Se momentum negativo: comparar com média de baixa
        if (currentMomentum > 0) {
          momentumDistortion = currentMomentum - avgBullishMomentum;
        } else {
          momentumDistortion = currentMomentum - avgBearishMomentum;
        }

        // REGRA DE ENTRADA (REVERSÃO À MÉDIA):
        // - Se momentum atual >= média de alta: symbol1 superou demais → SHORT symbol1, LONG symbol2
        // - Se momentum atual <= média de baixa: symbol1 ficou para trás → LONG symbol1, SHORT symbol2
        
        if (currentMomentum >= avgBullishMomentum && currentMomentum > 0) {
          // Momentum positivo atingiu/ultrapassou a média de alta
          // symbol1 superou symbol2 demais → esperar reversão: SHORT symbol1, LONG symbol2
          isValid = true;
          signal = "long_first";
          longSymbol = symbol2;
          shortSymbol = symbol1;
          message = `📈 COMPRAR ${symbol2.replace('USDT', '')} / VENDER ${symbol1.replace('USDT', '')} – Momentum ${currentMomentum.toFixed(3)}% ≥ Média Alta ${avgBullishMomentum.toFixed(3)}%`;
        } 
        else if (currentMomentum <= avgBearishMomentum && currentMomentum < 0) {
          // Momentum negativo atingiu/ultrapassou a média de baixa
          // symbol1 ficou para trás demais → esperar reversão: LONG symbol1, SHORT symbol2
          isValid = true;
          signal = "short_first";
          longSymbol = symbol1;
          shortSymbol = symbol2;
          message = `📉 COMPRAR ${symbol1.replace('USDT', '')} / VENDER ${symbol2.replace('USDT', '')} – Momentum ${currentMomentum.toFixed(3)}% ≤ Média Baixa ${avgBearishMomentum.toFixed(3)}%`;
        }
        else {
          // Momentum entre as médias - sem sinal
          message = `⏸️ Aguardando – Momentum ${currentMomentum.toFixed(3)}% entre médias (Alta: ${avgBullishMomentum.toFixed(3)}% | Baixa: ${avgBearishMomentum.toFixed(3)}%)`;
        }

        setAnalysis({
          isValid,
          signal,
          longSymbol: longSymbol.replace('USDT', ''),
          shortSymbol: shortSymbol.replace('USDT', ''),
          currentMomentum,
          avgBullishMomentum,
          avgBearishMomentum,
          momentumDistortion,
          correlationValid: true,
          correlations: {
            period1h: corr1h,
            period10d: corr10d,
            period30d: corr30d
          },
          liquidityRatio,
          message
        });

        setIsLoading(false);
      } catch (err) {
        console.error('Erro na análise avançada:', err);
        setError(err instanceof Error ? err.message : 'Erro desconhecido');
        setIsLoading(false);
      }
    };

    analyzeAdvanced();
    const interval = setInterval(analyzeAdvanced, 1000); // Atualizar a cada 1 segundo igual ao gráfico

    return () => clearInterval(interval);
  }, [symbol1, symbol2, isB3Mode]);

  return { analysis, isLoading, error };
};
