import { useState, useEffect, useCallback, useMemo } from "react";
import { useWallet } from "@solana/wallet-adapter-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { WalletProvider as JupiterWalletProvider } from "@/utils/jupiterSwap";

export interface SolanaWalletState {
  isConnected: boolean;
  publicKey: string | null;
  balance: number | null;
  isConnecting: boolean;
  walletName: string | null;
}

// Client-side RPCs (may be blocked by CORS on some mobile/in-app browsers)
const RPC_ENDPOINTS = [
  "https://rpc.ankr.com/solana",
  "https://api.mainnet-beta.solana.com",
];

export const useSolanaWallet = () => {
  const { 
    publicKey, 
    connected, 
    connecting, 
    wallet, 
    connect, 
    disconnect, 
    signTransaction,
    signAllTransactions 
  } = useWallet();
  const [balance, setBalance] = useState<number | null>(null);
  const [balanceLoading, setBalanceLoading] = useState(false);

  // Detect mobile and in-app browser
  const isMobile = typeof window !== "undefined" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  
  const isInWalletBrowser = useMemo(() => {
    if (typeof window === "undefined") return false;
    const ua = navigator.userAgent;
    // Detect Phantom, Solflare, or Backpack in-app browsers
    return ua.includes("Phantom") || ua.includes("Solflare") || ua.includes("Backpack") ||
           !!(window as any).phantom?.solana?.isPhantom ||
           !!(window as any).solflare?.isSolflare ||
           !!(window as any).backpack?.isBackpack;
  }, []);

  // Get public key as string
  const publicKeyString = useMemo(() => {
    return publicKey?.toString() || null;
  }, [publicKey]);

  // Wallet name
  const walletName = useMemo(() => {
    return wallet?.adapter?.name || null;
  }, [wallet]);

  // Fetch balance (prefer backend function to avoid CORS / blocked RPC in mobile browsers)
  const fetchBalance = useCallback(async (pubKey: string) => {
    if (!pubKey) return;

    setBalanceLoading(true);

    // 1) Backend function (most reliable)
    try {
      const { data, error } = await supabase.functions.invoke("solana-balance", {
        body: { publicKey: pubKey },
      });

      const balanceSol = (data as any)?.balanceSol;
      if (!error && typeof balanceSol === "number") {
        setBalance(balanceSol);
        setBalanceLoading(false);
        return;
      }
    } catch {
      // ignore and fallback
    }

    // 2) Client-side RPC (best-effort)
    for (const rpc of RPC_ENDPOINTS) {
      try {
        const response = await fetch(rpc, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            jsonrpc: "2.0",
            id: 1,
            method: "getBalance",
            params: [pubKey],
          }),
        });

        const data = await response.json().catch(() => null);
        if (!response.ok) continue;

        const lamports = data?.result?.value;
        if (typeof lamports === "number") {
          const solBalance = lamports / 1e9;
          setBalance(solBalance);
          setBalanceLoading(false);
          return;
        }
      } catch {
        continue;
      }
    }

    // 3) Do NOT fallback to adapter connection.getBalance here (can be blocked by RPC providers)
    setBalanceLoading(false);
  }, []);

  // Fetch balance when connected
  useEffect(() => {
    if (connected && publicKeyString) {
      fetchBalance(publicKeyString);
      
      // Keep balance fresh
      const interval = setInterval(() => {
        fetchBalance(publicKeyString);
      }, 15000);
      
      return () => clearInterval(interval);
    } else {
      setBalance(null);
    }
  }, [connected, publicKeyString, fetchBalance]);

  // Connect wallet
  const connectWallet = useCallback(async () => {
    try {
      await connect();
      return true;
    } catch (error: any) {
      console.error("Wallet connection error:", error);
      if (error?.name === "WalletNotReadyError") {
        toast.error("Carteira não está pronta. Verifique se está instalada.");
      } else if (error?.name === "WalletConnectionError") {
        toast.error("Erro ao conectar carteira.");
      }
      return false;
    }
  }, [connect]);

  // Disconnect wallet
  const disconnectWallet = useCallback(async () => {
    try {
      await disconnect();
      setBalance(null);
      toast.info("Carteira desconectada");
    } catch (error) {
      console.error("Error disconnecting:", error);
    }
  }, [disconnect]);

  // Get provider compatible with Jupiter swap functions
  const getProvider = useCallback((): JupiterWalletProvider | null => {
    if (!connected || !publicKey) return null;
    
    return {
      publicKey: { toString: () => publicKey.toString() },
      signTransaction: signTransaction as any,
      signAllTransactions: signAllTransactions as any,
      isConnected: connected,
    };
  }, [connected, publicKey, signTransaction, signAllTransactions]);

  // Check if wallet is ready to sign
  const isWalletReady = useMemo(() => {
    return connected && publicKey && signTransaction;
  }, [connected, publicKey, signTransaction]);

  return {
    // State
    isConnected: connected,
    publicKey: publicKeyString,
    balance,
    isConnecting: connecting,
    walletName,
    isWalletReady,
    balanceLoading,
    
    // Flags
    isMobile,
    isInWalletBrowser,
    
    // Actions
    connectWallet,
    disconnectWallet,
    getProvider,
    fetchBalance,
  };
};
