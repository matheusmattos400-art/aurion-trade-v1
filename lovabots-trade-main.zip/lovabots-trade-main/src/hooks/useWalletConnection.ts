import { useState, useEffect, useCallback } from "react";
import { ethers } from "ethers";
import { toast } from "sonner";

export interface WalletState {
  isConnected: boolean;
  address: string | null;
  chainId: number | null;
  balance: string | null;
  isConnecting: boolean;
  error: string | null;
}

declare global {
  interface Window {
    ethereum?: any;
  }
}

const SUPPORTED_CHAINS = {
  1: "Ethereum Mainnet",
  56: "BNB Chain",
  137: "Polygon",
  42161: "Arbitrum",
  10: "Optimism",
  8453: "Base",
  43114: "Avalanche",
};

export const useWalletConnection = () => {
  const [walletState, setWalletState] = useState<WalletState>(() => ({
    isConnected: false,
    address: null,
    chainId: null,
    balance: null,
    isConnecting: false,
    error: null,
  }));

  const [hasMetaMask, setHasMetaMask] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return !!(window.ethereum?.isMetaMask || window.ethereum);
  });

  // Check for MetaMask on mount (handles delayed injection)
  useEffect(() => {
    const checkMetaMask = () => {
      const detected = typeof window !== "undefined" && !!(window.ethereum?.isMetaMask || window.ethereum);
      if (detected !== hasMetaMask) {
        setHasMetaMask(detected);
      }
    };
    
    // Check again after a short delay (MetaMask can inject after page load)
    const timeout = setTimeout(checkMetaMask, 1000);
    
    return () => clearTimeout(timeout);
  }, [hasMetaMask]);

  const updateBalance = useCallback(async (address: string) => {
    if (!window.ethereum) return;
    
    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const balance = await provider.getBalance(address);
      setWalletState((prev) => ({
        ...prev,
        balance: ethers.formatEther(balance),
      }));
    } catch (error) {
      console.error("Error fetching balance:", error);
    }
  }, []);

  const connectWallet = useCallback(async () => {
    if (!window.ethereum) {
      toast.error("MetaMask não detectado! Por favor, instale a extensão.");
      setWalletState((prev) => ({
        ...prev,
        error: "MetaMask não detectado",
      }));
      return false;
    }

    setWalletState((prev) => ({ ...prev, isConnecting: true, error: null }));

    try {
      const accounts = (await window.ethereum.request({
        method: "eth_requestAccounts",
      })) as string[];

      const chainIdHex = (await window.ethereum.request({
        method: "eth_chainId",
      })) as string;

      const chainId = parseInt(chainIdHex, 16);
      const address = accounts[0];

      setWalletState({
        isConnected: true,
        address,
        chainId,
        balance: null,
        isConnecting: false,
        error: null,
      });

      await updateBalance(address);

      toast.success(`Carteira conectada: ${address.slice(0, 6)}...${address.slice(-4)}`);
      return true;
    } catch (error: unknown) {
      const err = error as { code?: number; message?: string };
      console.error("Error connecting wallet:", err);
      const errorMessage = err.code === 4001 
        ? "Conexão rejeitada pelo usuário" 
        : "Erro ao conectar carteira";
      
      toast.error(errorMessage);
      setWalletState((prev) => ({
        ...prev,
        isConnecting: false,
        error: errorMessage,
      }));
      return false;
    }
  }, [updateBalance]);

  const disconnectWallet = useCallback(() => {
    setWalletState({
      isConnected: false,
      address: null,
      chainId: null,
      balance: null,
      isConnecting: false,
      error: null,
    });
    toast.info("Carteira desconectada");
  }, []);

  const switchChain = useCallback(async (targetChainId: number) => {
    if (!window.ethereum) return false;

    try {
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: `0x${targetChainId.toString(16)}` }],
      });
      return true;
    } catch (error: unknown) {
      console.error("Error switching chain:", error);
      toast.error("Erro ao trocar de rede");
      return false;
    }
  }, []);

  // Listen for account changes
  useEffect(() => {
    if (!window.ethereum) return;

    const handleAccountsChanged = (accounts: unknown) => {
      const accountsArray = accounts as string[];
      if (accountsArray.length === 0) {
        disconnectWallet();
      } else if (accountsArray[0] !== walletState.address) {
        setWalletState((prev) => ({
          ...prev,
          address: accountsArray[0],
        }));
        updateBalance(accountsArray[0]);
      }
    };

    const handleChainChanged = (chainIdHex: unknown) => {
      const newChainId = parseInt(chainIdHex as string, 16);
      setWalletState((prev) => ({
        ...prev,
        chainId: newChainId,
      }));
      if (walletState.address) {
        updateBalance(walletState.address);
      }
    };

    window.ethereum.on("accountsChanged", handleAccountsChanged);
    window.ethereum.on("chainChanged", handleChainChanged);

    return () => {
      window.ethereum?.removeListener("accountsChanged", handleAccountsChanged);
      window.ethereum?.removeListener("chainChanged", handleChainChanged);
    };
  }, [walletState.address, disconnectWallet, updateBalance]);

  // Check if already connected on mount
  useEffect(() => {
    if (!window.ethereum) return;

    const checkConnection = async () => {
      try {
        const accounts = (await window.ethereum!.request({
          method: "eth_accounts",
        })) as string[];

        if (accounts.length > 0) {
          const chainIdHex = (await window.ethereum!.request({
            method: "eth_chainId",
          })) as string;

          const chainId = parseInt(chainIdHex, 16);
          
          setWalletState({
            isConnected: true,
            address: accounts[0],
            chainId,
            balance: null,
            isConnecting: false,
            error: null,
          });

          await updateBalance(accounts[0]);
        }
      } catch (error) {
        console.error("Error checking connection:", error);
      }
    };

    checkConnection();
  }, [updateBalance]);

  const getChainName = (chainId: number | null): string => {
    if (!chainId) return "Desconhecido";
    return SUPPORTED_CHAINS[chainId as keyof typeof SUPPORTED_CHAINS] || `Chain ${chainId}`;
  };

  return {
    ...walletState,
    hasMetaMask,
    connectWallet,
    disconnectWallet,
    switchChain,
    getChainName,
    supportedChains: SUPPORTED_CHAINS,
  };
};
