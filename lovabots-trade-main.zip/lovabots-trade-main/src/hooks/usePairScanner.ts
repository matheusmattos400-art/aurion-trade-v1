import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface TradingSignal {
  id: string;
  longSymbol: string;
  shortSymbol: string;
  strategy: "micro_distortion" | "partial_reversal" | "trend_follow";
  zScore: number;
  correlation: number;
  correlation5d: number;   // 5 dias (120h)
  correlation25d: number;  // 25 dias (600h)
  correlation2m: number;   // 2 meses (1440h)
  momentumAge: number;
  currentMomentum: number;
  avgBullish: number;
  avgBearish: number;
  liquidityRatio: number;
  message: string;
  timestamp: Date;
  status: "ready" | "pending";
  pendingReason?: string;
}

interface UsePairScannerResult {
  signals: TradingSignal[];
  isScanning: boolean;
  lastScanTime: Date | null;
  error: string | null;
  rescan: () => Promise<void>;
}

export const usePairScanner = (autoScan = true, intervalMs = 30000): UsePairScannerResult => {
  const [signals, setSignals] = useState<TradingSignal[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [lastScanTime, setLastScanTime] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const isScanningRef = useRef(false);

  const scan = useCallback(async () => {
    if (isScanningRef.current) return;
    
    isScanningRef.current = true;
    setIsScanning(true);
    setError(null);
    
    try {
      console.log("🚀 Chamando backend para escaneamento de pares...");
      
      const { data, error: fnError } = await supabase.functions.invoke('pair-scanner');
      
      if (fnError) {
        throw new Error(fnError.message);
      }
      
      if (!data.success) {
        throw new Error(data.error || "Erro desconhecido no scanner");
      }
      
      // Convert timestamp strings to Date objects
      const signalsWithDates = data.signals.map((s: any) => ({
        ...s,
        timestamp: new Date(s.timestamp)
      }));
      
      setSignals(signalsWithDates);
      setLastScanTime(new Date());
      console.log("✅ Escaneamento concluído:", signalsWithDates.length, "sinais");
    } catch (err) {
      console.error("❌ Erro no escaneamento:", err);
      setError(err instanceof Error ? err.message : "Erro desconhecido");
    } finally {
      isScanningRef.current = false;
      setIsScanning(false);
    }
  }, []);

  // Escaneamento inicial e automático
  useEffect(() => {
    if (!autoScan) return;
    
    scan();
    
    const interval = setInterval(scan, intervalMs);
    return () => clearInterval(interval);
  }, [autoScan, intervalMs, scan]);

  return {
    signals,
    isScanning,
    lastScanTime,
    error,
    rescan: scan,
  };
};
