import { useCallback, useEffect, useRef } from "react";

/**
 * Keeps auto-scroll user-controlled:
 * - If user is at (or near) the bottom, new messages will be brought into view.
 * - If user scrolled up, we DO NOT force-scroll on new messages.
 *
 * Additionally, when we auto-scroll we align the *start* of the last item,
 * so long AI messages don't jump the user straight to the end.
 */
export function useUserControlledAutoScroll<T extends HTMLElement = HTMLDivElement>(deps: any[]) {
  const scrollContainerRef = useRef<T>(null);
  const lastItemRef = useRef<HTMLDivElement>(null);
  const isUserNearBottomRef = useRef(true);

  const recomputeIsNearBottom = useCallback(() => {
    const el = scrollContainerRef.current;
    if (!el) return;

    const { scrollTop, scrollHeight, clientHeight } = el;
    // Near-bottom threshold (px)
    isUserNearBottomRef.current = scrollHeight - scrollTop - clientHeight < 120;
  }, []);

  const onScroll = useCallback(() => {
    recomputeIsNearBottom();
  }, [recomputeIsNearBottom]);

  // Initialize near-bottom detection on mount.
  useEffect(() => {
    recomputeIsNearBottom();
  }, [recomputeIsNearBottom]);

  // Only auto-scroll if the user was already at the bottom.
  useEffect(() => {
    if (!isUserNearBottomRef.current) return;
    lastItemRef.current?.scrollIntoView({ behavior: "auto", block: "start" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return {
    scrollContainerRef,
    lastItemRef,
    onScroll,
    isUserNearBottomRef,
  };
}
