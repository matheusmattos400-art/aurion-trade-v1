import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface AurionToken {
  id: string;
  chainId: string;
  pairAddress: string;
  tokenAddress: string;
  name: string;
  symbol: string;
  dexId: string;
  url: string;
  imageUrl?: string;

  // Price data
  priceUsd: number;
  priceChange5m: number;
  priceChange1h: number;
  priceChange6h: number;
  priceChange24h: number;

  // Volume & Liquidity
  volume24h: number;
  volume1h: number;
  volume5m?: number;
  liquidity: number;
  marketCap: number;

  // Transactions
  buys24h: number;
  sells24h: number;
  buys1h: number;
  sells1h: number;
  buys5m?: number;
  sells5m?: number;

  // Age & Category
  ageHours: number;
  category: "main" | "radar" | "top";
  createdAt: number;
  boostAmount?: number;

  // Security
  securityScore: number;
  passesSecurityFilter: boolean;
  securityReasons: string[];
  isVerified: boolean;
  isHoneypot: boolean;
  isMintable: boolean;
  hasBlacklist: boolean;
  lpLocked: boolean;

  // Holder data (forensic analysis)
  topHolderPercent?: number;
  top10HolderPercent?: number;
  creatorPercent?: number;
  devSoldAll?: boolean;
  holdersCount?: number;

  // Social
  hasWebsite: boolean;
  hasSocials: boolean;
  websites: Array<{ url: string }>;
  socials: Array<{ type: string; url: string }>;

  // Technical Analysis
  technicalStatus: "pending" | "analyzing" | "confirmed" | "rejected";
  chandelierSignal: "LONG" | "SHORT" | null;
  adxSignal: { adx: number; plusDI: number; minusDI: number } | null;
  rsiSignal: number | null;
  aurionConfirmed: boolean;
  confirmationTime?: number;
}

export interface AurionScanResult {
  main: AurionToken[];
  radar: AurionToken[];
  rejected: AurionToken[];
  totalScanned: number;
  timestamp: number;
}


// Technical analysis functions (same as useHoldingScanner)
const calculateRSI = (closes: number[], period: number = 14): number => {
  if (closes.length < period + 1) return 50;

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const change = closes[i] - closes[i - 1];
    if (change >= 0) gains += change;
    else losses += Math.abs(change);
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = period + 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    if (change >= 0) {
      avgGain = (avgGain * (period - 1) + change) / period;
      avgLoss = (avgLoss * (period - 1)) / period;
    } else {
      avgGain = (avgGain * (period - 1)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.abs(change)) / period;
    }
  }

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
};

const wilderSmooth = (values: number[], period: number): number[] => {
  const result: number[] = [];
  let prevSmoothed = 0;

  for (let i = 0; i < values.length; i++) {
    if (i < period - 1) {
      result.push(0);
    } else if (i === period - 1) {
      let sum = 0;
      for (let j = 0; j < period; j++) sum += values[i - j];
      prevSmoothed = sum / period;
      result.push(prevSmoothed);
    } else {
      prevSmoothed = (prevSmoothed * (period - 1) + values[i]) / period;
      result.push(prevSmoothed);
    }
  }
  return result;
};

const calculateADX = (candles: number[][], period: number = 14): { adx: number; plusDI: number; minusDI: number } | null => {
  if (candles.length < period * 2) return null;

  const trValues: number[] = [];
  const plusDMValues: number[] = [];
  const minusDMValues: number[] = [];

  for (let i = 1; i < candles.length; i++) {
    const [, , high, low, close] = candles[i];
    const [, , prevHigh, prevLow, prevClose] = candles[i - 1];

    const tr = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
    trValues.push(tr);

    const upMove = high - prevHigh;
    const downMove = prevLow - low;
    plusDMValues.push(upMove > downMove && upMove > 0 ? upMove : 0);
    minusDMValues.push(downMove > upMove && downMove > 0 ? downMove : 0);
  }

  const smoothedTR = wilderSmooth(trValues, period);
  const smoothedPlusDM = wilderSmooth(plusDMValues, period);
  const smoothedMinusDM = wilderSmooth(minusDMValues, period);

  const lastIndex = smoothedTR.length - 1;
  if (lastIndex < 0 || smoothedTR[lastIndex] === 0) return null;

  const plusDI = (smoothedPlusDM[lastIndex] / smoothedTR[lastIndex]) * 100;
  const minusDI = (smoothedMinusDM[lastIndex] / smoothedTR[lastIndex]) * 100;

  const dx: number[] = [];
  for (let i = period - 1; i < smoothedTR.length; i++) {
    if (smoothedTR[i] === 0) {
      dx.push(0);
      continue;
    }
    const pdi = (smoothedPlusDM[i] / smoothedTR[i]) * 100;
    const mdi = (smoothedMinusDM[i] / smoothedTR[i]) * 100;
    const diSum = pdi + mdi;
    dx.push(diSum === 0 ? 0 : (Math.abs(pdi - mdi) / diSum) * 100);
  }

  const adxValues = wilderSmooth(dx, period);
  const adx = adxValues[adxValues.length - 1] || 0;

  return { adx, plusDI, minusDI };
};

const calculateChandelierTrend = (candles: number[][], period: number = 22, multiplier: number = 3): "LONG" | "SHORT" => {
  if (candles.length < period + 10) return "LONG";

  const trValues: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const [, , high, low, close] = candles[i];
    const [, , , , prevClose] = candles[i - 1];
    const tr = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
    trValues.push(tr);
  }

  const atrValues: number[] = [];
  for (let i = 0; i < trValues.length; i++) {
    if (i < period - 1) atrValues.push(0);
    else {
      const sum = trValues.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
      atrValues.push(sum / period);
    }
  }

  const lastIndex = candles.length - 1;
  const atrIndex = lastIndex - 1;
  if (atrIndex < 0 || atrIndex >= atrValues.length) return "LONG";

  const atr = atrValues[atrIndex];
  if (atr === 0) return "LONG";

  let highestHigh = 0;
  let lowestLow = Infinity;
  for (let j = Math.max(0, lastIndex - period); j <= lastIndex; j++) {
    const [, , high, low] = candles[j];
    if (high > highestHigh) highestHigh = high;
    if (low < lowestLow) lowestLow = low;
  }

  const [, , , , close] = candles[lastIndex];
  const longStop = highestHigh - (atr * multiplier);
  const shortStop = lowestLow + (atr * multiplier);

  if (close > shortStop) return "LONG";
  if (close < longStop) return "SHORT";
  return "LONG";
};

// Fetch candle data from DexScreener
async function fetchDexScreenerCandles(chainId: string, pairAddress: string): Promise<number[][] | null> {
  try {
    // Use correct DexScreener API endpoint with chainId
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
    
    const response = await fetch(
      `https://api.dexscreener.com/latest/dex/pairs/${chainId}/${pairAddress}`,
      { signal: controller.signal }
    );
    clearTimeout(timeoutId);
    
    if (!response.ok) {
      console.log(`DexScreener returned ${response.status} for ${pairAddress}`);
      return null;
    }

    const data = await response.json();
    const pair = data.pair || data.pairs?.[0];
    if (!pair) return null;

    // Generate synthetic candles from available data (for demo)
    // In production, use proper OHLCV data source
    const price = parseFloat(pair.priceUsd || "0");
    const change = pair.priceChange?.h1 || 0;
    
    const candles: number[][] = [];
    for (let i = 0; i < 100; i++) {
      const factor = 1 + (change / 100) * ((100 - i) / 100) + (Math.random() - 0.5) * 0.02;
      const c = price * factor;
      const h = c * (1 + Math.random() * 0.02);
      const l = c * (1 - Math.random() * 0.02);
      const o = c * (1 + (Math.random() - 0.5) * 0.01);
      candles.unshift([Date.now() - i * 3600000, o, h, l, c]);
    }

    return candles;
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      console.log(`Timeout fetching candles for ${pairAddress}`);
    } else {
      console.error("Error fetching candles:", error);
    }
    return null;
  }
}

export interface SimulatedTrade {
  id: string;
  token: AurionToken;
  entryPrice: number;
  entryTime: number;
  exitPrice?: number;
  exitTime?: number;
  pnlPercent?: number;
  pnlUsd?: number;
  status: "open" | "stopped" | "manual_exit";
  chandelierExitPrice?: number;
  investmentAmount?: number;
}

export interface DailyPerformance {
  date: string;
  totalTrades: number;
  winners: number;
  losers: number;
  winRate: number;
  totalPnlPercent: number;
}

export const useAurionScanner = (enabled: boolean = true, intervalMs: number = 120000) => {
  const [tokens, setTokens] = useState<AurionScanResult | null>(null);
  const [topTokens, setTopTokens] = useState<AurionToken[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [isLoadingTop, setIsLoadingTop] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastScanTime, setLastScanTime] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [simulatedTrades, setSimulatedTrades] = useState<SimulatedTrade[]>([]);
  const [dailyPerformance, setDailyPerformance] = useState<DailyPerformance[]>([]);
  const intervalRef = useRef<NodeJS.Timeout>();
  const [userId, setUserId] = useState<string | null>(null);
  const tradesLoadedRef = useRef(false);

  // Avoid stale closures in intervals
  const simulatedTradesRef = useRef<SimulatedTrade[]>([]);
  const tokensRef = useRef<AurionScanResult | null>(null);
  const userIdRef = useRef<string | null>(null);

  useEffect(() => {
    simulatedTradesRef.current = simulatedTrades;
  }, [simulatedTrades]);

  useEffect(() => {
    tokensRef.current = tokens;
  }, [tokens]);

  useEffect(() => {
    userIdRef.current = userId;
  }, [userId]);

  // Get current user
  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUserId(user?.id || null);
    };
    getUser();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUserId(session?.user?.id || null);
      tradesLoadedRef.current = false; // Reset to reload trades on auth change
    });

    return () => subscription.unsubscribe();
  }, []);

  // Load simulated trades from database
  useEffect(() => {
    const loadTrades = async () => {
      if (!userId || tradesLoadedRef.current) return;
      
      try {
        console.log("📥 Loading Aurion trades from database...");
        // Using type assertion since the table was just created and types aren't regenerated yet
        const { data, error } = await (supabase as any)
          .from("aurion_simulated_trades")
          .select("*")
          .eq("user_id", userId);

        if (error) {
          console.error("Error loading trades:", error);
          // Fallback to localStorage
          const savedTrades = localStorage.getItem("aurion_simulated_trades");
          if (savedTrades) {
            setSimulatedTrades(JSON.parse(savedTrades));
          }
          return;
        }

        if (data && data.length > 0) {
          const trades: SimulatedTrade[] = data.map((row: any) => ({
            id: row.trade_id,
            token: row.token_data as AurionToken,
            entryPrice: Number(row.entry_price),
            entryTime: Number(row.entry_time),
            exitPrice: row.exit_price ? Number(row.exit_price) : undefined,
            exitTime: row.exit_time ? Number(row.exit_time) : undefined,
            pnlPercent: row.pnl_percent ? Number(row.pnl_percent) : undefined,
            pnlUsd: row.pnl_usd ? Number(row.pnl_usd) : undefined,
            status: row.status as "open" | "stopped" | "manual_exit",
            chandelierExitPrice: row.chandelier_exit_price ? Number(row.chandelier_exit_price) : undefined,
            investmentAmount: row.investment_amount ? Number(row.investment_amount) : 100,
          }));
          setSimulatedTrades(trades);
          console.log(`✅ Loaded ${trades.length} trades from database`);
        }
        tradesLoadedRef.current = true;
      } catch (err) {
        console.error("Error loading trades:", err);
      }
    };

    loadTrades();
  }, [userId]);

  // Load daily performance from localStorage (less critical)
  useEffect(() => {
    const savedPerformance = localStorage.getItem("aurion_daily_performance");
    if (savedPerformance) {
      try {
        setDailyPerformance(JSON.parse(savedPerformance));
      } catch (e) {
        console.error("Error loading performance:", e);
      }
    }
  }, []);

  // Save daily performance to localStorage
  useEffect(() => {
    localStorage.setItem("aurion_daily_performance", JSON.stringify(dailyPerformance));
  }, [dailyPerformance]);

  // Sync trade to database
  const syncTradeToDb = useCallback(async (trade: SimulatedTrade) => {
    const uid = userIdRef.current;
    if (!uid) return;

    const payload = {
      user_id: uid,
      trade_id: trade.id,
      token_data: trade.token,
      entry_price: trade.entryPrice,
      entry_time: trade.entryTime,
      exit_price: trade.exitPrice || null,
      exit_time: trade.exitTime || null,
      pnl_percent: trade.pnlPercent || null,
      pnl_usd: trade.pnlUsd || null,
      status: trade.status,
      chandelier_exit_price: trade.chandelierExitPrice || null,
      investment_amount: trade.investmentAmount || 100,
    };

    try {
      // Prefer UPDATE-by (user_id, trade_id) to avoid relying on a DB unique constraint
      const { data: updatedRows, error: updateError } = await (supabase as any)
        .from("aurion_simulated_trades")
        .update(payload)
        .eq("user_id", uid)
        .eq("trade_id", trade.id)
        .select("id");

      if (updateError) {
        console.error("Error syncing trade (update):", updateError);
      }

      // If nothing was updated, insert a new row
      if (!updatedRows || updatedRows.length === 0) {
        const { error: insertError } = await (supabase as any)
          .from("aurion_simulated_trades")
          .insert(payload);

        if (insertError) {
          console.error("Error syncing trade (insert):", insertError);
        }
      }
    } catch (err) {
      console.error("Error syncing trade:", err);
    }
  }, []);

  // Delete trade from database
  const deleteTradeFromDb = useCallback(async (tradeId: string) => {
    const uid = userIdRef.current;
    if (!uid) return;

    try {
      await (supabase as any)
        .from("aurion_simulated_trades")
        .delete()
        .eq("user_id", uid)
        .eq("trade_id", tradeId);
    } catch (err) {
      console.error("Error deleting trade:", err);
    }
  }, []);

  // Analyze token technical indicators
  const analyzeToken = useCallback(async (token: AurionToken): Promise<AurionToken> => {
    try {
      const candles = await fetchDexScreenerCandles(token.chainId, token.pairAddress);
      if (!candles || candles.length < 50) {
        return { ...token, technicalStatus: "rejected" };
      }

      const closes = candles.map(c => c[4]);
      const rsi = calculateRSI(closes, 14);
      const adxData = calculateADX(candles, 14);
      const chandelierTrend = calculateChandelierTrend(candles, 22, 3);

      // Check AURION GOLD confluence
      const isLongChande = chandelierTrend === "LONG";
      const isLongDI = adxData && adxData.plusDI > adxData.minusDI;
      const isLongRSI = rsi < 70 && rsi > 30;
      const isStrongADX = adxData && adxData.adx >= 20;

      const aurionConfirmed = isLongChande && isLongDI && isLongRSI && isStrongADX;

      return {
        ...token,
        technicalStatus: aurionConfirmed ? "confirmed" : "rejected",
        chandelierSignal: chandelierTrend,
        adxSignal: adxData,
        rsiSignal: rsi,
        aurionConfirmed,
        confirmationTime: aurionConfirmed ? Date.now() : undefined,
      };
    } catch (error) {
      console.error(`Error analyzing ${token.symbol}:`, error);
      return { ...token, technicalStatus: "rejected" };
    }
  }, []);

  // Main scan function
  const scan = useCallback(async () => {
    if (isScanning) return;

    setIsScanning(true);
    setError(null);

    try {
      console.log("🔍 Starting Aurion scan...");

      const { data, error: invokeError } = await supabase.functions.invoke("dexscreener-scanner", {
        body: { action: "scan", chain: "solana" }
      });

      if (invokeError) throw invokeError;
      if (!data?.success) throw new Error(data?.error || "Scan failed");

      const result: AurionScanResult = data.data;
      
      setTokens(result);
      setLastScanTime(new Date());

      // Start technical analysis for approved tokens
      setIsAnalyzing(true);
      
      // Analyze main tokens in batches
      const analyzedMain: AurionToken[] = [];
      const batchSize = 5;
      
      for (let i = 0; i < Math.min(result.main.length, 30); i += batchSize) {
        const batch = result.main.slice(i, i + batchSize);
        const analyzed = await Promise.all(batch.map(analyzeToken));
        analyzedMain.push(...analyzed);
        
        // Update state progressively
        setTokens(prev => prev ? {
          ...prev,
          main: [
            ...analyzedMain,
            ...prev.main.slice(analyzedMain.length)
          ]
        } : null);

        if (i + batchSize < result.main.length) {
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }

      // Sort by confirmation status
      setTokens(prev => prev ? {
        ...prev,
        main: [...analyzedMain].sort((a, b) => {
          if (a.aurionConfirmed && !b.aurionConfirmed) return -1;
          if (!a.aurionConfirmed && b.aurionConfirmed) return 1;
          return (b.confirmationTime || 0) - (a.confirmationTime || 0);
        })
      } : null);

      setIsAnalyzing(false);

    } catch (err) {
      console.error("Error in Aurion scan:", err);
      setError(err instanceof Error ? err.message : "Erro desconhecido");
      setIsAnalyzing(false);
    } finally {
      setIsScanning(false);
    }
  }, [isScanning, analyzeToken]);

  // Fetch top boosted tokens from DexScreener API
  const fetchTopTokens = useCallback(async () => {
    if (isLoadingTop) return;
    
    try {
      setIsLoadingTop(true);
      console.log("🚀 Fetching top boosted tokens...");
      
      const { data, error } = await supabase.functions.invoke("dexscreener-scanner", {
        body: { action: "top", chain: "solana" },
      });

      if (error) {
        console.error("Error fetching top tokens:", error);
        return;
      }

      if (data?.success && data.data) {
        setTopTokens(data.data);
        console.log(`✅ Loaded ${data.data.length} top tokens`);
      }
    } catch (err) {
      console.error("Error fetching top tokens:", err);
    } finally {
      setIsLoadingTop(false);
    }
  }, [isLoadingTop]);

  // Simulate entry
  const simulateEntry = useCallback((token: AurionToken, investmentAmount: number = 100) => {
    const trade: SimulatedTrade = {
      id: `${token.id}-${Date.now()}`,
      token,
      entryPrice: token.priceUsd,
      entryTime: Date.now(),
      status: "open",
      investmentAmount,
    };

    setSimulatedTrades(prev => [...prev, trade]);
    
    // Sync to database
    syncTradeToDb(trade);
    toast.success(`Operação aberta: ${token.symbol}`);
    
    return trade;
  }, [syncTradeToDb]);

  // Update open trades with current prices and check stop loss
  const updateOpenTrades = useCallback(async () => {
    const tradesSnapshot = simulatedTradesRef.current;
    const openTrades = tradesSnapshot.filter(t => t.status === "open");
    if (openTrades.length === 0) return;

    const updatedTrades = await Promise.all(
      openTrades.map(async (trade) => {
        try {
          let currentPrice: number | null = null;

          try {
            const { data, error } = await supabase.functions.invoke("dexscreener-scanner", {
              body: {
                action: "getPrice",
                pairAddress: trade.token.pairAddress,
                chainId: trade.token.chainId,
              },
            });

            if (!error && data?.price) {
              currentPrice = parseFloat(data.price);
            }
          } catch {
            // ignore and fallback below
          }

          if (currentPrice === null || Number.isNaN(currentPrice)) return trade;

          const pnlPercent = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100;

          // Check chandelier exit (stop loss)
          const candles = await fetchDexScreenerCandles(trade.token.chainId, trade.token.pairAddress);
          if (candles && candles.length > 50) {
            const chandelierTrend = calculateChandelierTrend(candles, 22, 3);

            if (chandelierTrend === "SHORT") {
              // Stop loss triggered
              const investment = trade.investmentAmount || 100;
              const stoppedTrade: SimulatedTrade = {
                ...trade,
                exitPrice: currentPrice,
                exitTime: Date.now(),
                pnlPercent,
                pnlUsd: (pnlPercent / 100) * investment,
                status: "stopped",
              };

              await syncTradeToDb(stoppedTrade);
              toast.info(
                `Stop Loss ativado: ${trade.token.symbol} (${pnlPercent >= 0 ? "+" : ""}${pnlPercent.toFixed(2)}%)`
              );
              return stoppedTrade;
            }
          }

          return trade;
        } catch {
          return trade;
        }
      })
    );

    const byId = new Map(updatedTrades.map(t => [t.id, t] as const));
    const mergedForPerf = tradesSnapshot.map(t => byId.get(t.id) ?? t);

    // Update trades (patch only the trades we refreshed)
    setSimulatedTrades(prev => prev.map(t => byId.get(t.id) ?? t));

    // Update daily performance
    const today = new Date().toISOString().split("T")[0];
    const todayTrades = mergedForPerf.filter(t =>
      t.status !== "open" &&
      new Date(t.exitTime || 0).toISOString().split("T")[0] === today
    );

    if (todayTrades.length > 0) {
      const winners = todayTrades.filter(t => (t.pnlPercent || 0) > 0).length;
      const totalPnl = todayTrades.reduce((sum, t) => sum + (t.pnlPercent || 0), 0);

      setDailyPerformance(prev => {
        const existing = prev.find(p => p.date === today);
        if (existing) {
          return prev.map(p => p.date === today ? {
            ...p,
            totalTrades: todayTrades.length,
            winners,
            losers: todayTrades.length - winners,
            winRate: (winners / todayTrades.length) * 100,
            totalPnlPercent: totalPnl,
          } : p);
        }
        return [...prev, {
          date: today,
          totalTrades: todayTrades.length,
          winners,
          losers: todayTrades.length - winners,
          winRate: (winners / todayTrades.length) * 100,
          totalPnlPercent: totalPnl,
        }];
      });
    }
  }, [syncTradeToDb]);

  // Manual exit
  const exitTrade = useCallback(async (tradeId: string) => {
    const trade = simulatedTradesRef.current.find(t => t.id === tradeId);
    if (!trade || trade.status !== "open") return;

    try {
      // Use the token's current price from state or fetch via edge function
      let currentPrice = trade.entryPrice;

      try {
        const { data, error } = await supabase.functions.invoke("dexscreener-scanner", {
          body: {
            action: "getPrice",
            pairAddress: trade.token.pairAddress,
            chainId: trade.token.chainId,
          },
        });

        if (!error && data?.price) {
          currentPrice = parseFloat(data.price);
        }
      } catch {
        // Fallback: use the token's stored price if available
        const snapshot = tokensRef.current;
        const allTokens = [...(snapshot?.main || []), ...(snapshot?.radar || [])];
        const storedToken = allTokens.find(t => t.id === trade.token.id);
        if (storedToken) {
          currentPrice = storedToken.priceUsd;
        }
      }

      const pnlPercent = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100;
      const investment = trade.investmentAmount || 100;

      const updatedTrade: SimulatedTrade = {
        ...trade,
        exitPrice: currentPrice,
        exitTime: Date.now(),
        pnlPercent,
        pnlUsd: (pnlPercent / 100) * investment,
        status: "manual_exit",
      };

      setSimulatedTrades(prev => prev.map(t => t.id === tradeId ? updatedTrade : t));

      await syncTradeToDb(updatedTrade);
      toast.success(
        `Operação encerrada: ${trade.token.symbol} (${pnlPercent >= 0 ? "+" : ""}${pnlPercent.toFixed(2)}%)`
      );
    } catch (error) {
      console.error("Error exiting trade:", error);
      toast.error("Erro ao encerrar operação");
    }
  }, [syncTradeToDb]);

  // Clear trade history
  const clearTradeHistory = useCallback(async () => {
    // Delete all trades from database
    if (userId) {
      try {
        await (supabase as any)
          .from("aurion_simulated_trades")
          .delete()
          .eq("user_id", userId);
      } catch (err) {
        console.error("Error clearing trades from database:", err);
      }
    }
    setSimulatedTrades([]);
    setDailyPerformance([]);
    localStorage.removeItem("aurion_simulated_trades");
    localStorage.removeItem("aurion_daily_performance");
    toast.success("Histórico limpo");
  }, [userId]);

  // Initial scan and interval
  useEffect(() => {
    if (!enabled) return;

    // Initial scan with delay to avoid rapid re-renders
    const initialScanTimeout = setTimeout(() => {
      scan();
      fetchTopTokens();
    }, 1000);

    // Set up interval for periodic scans
    const scanInterval = setInterval(() => {
      scan();
    }, intervalMs);

    // Fetch top tokens every 60 seconds
    const topTokensInterval = setInterval(() => {
      fetchTopTokens();
    }, 60000);

    // Update open trades every 30 seconds
    const tradeUpdateInterval = setInterval(updateOpenTrades, 30000);

    return () => {
      clearTimeout(initialScanTimeout);
      clearInterval(scanInterval);
      clearInterval(topTokensInterval);
      clearInterval(tradeUpdateInterval);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, intervalMs]); // Remove scan and updateOpenTrades from dependencies to prevent infinite loop

  return {
    tokens,
    topTokens,
    isScanning,
    isLoadingTop,
    isAnalyzing,
    lastScanTime,
    error,
    simulatedTrades,
    dailyPerformance,
    rescan: scan,
    refetchTopTokens: fetchTopTokens,
    simulateEntry,
    exitTrade,
    clearTradeHistory,
  };
};
