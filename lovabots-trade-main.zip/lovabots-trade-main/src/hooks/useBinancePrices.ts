import { useState, useEffect } from "react";
import { useTradingMode } from "@/contexts/TradingModeContext";
import { supabase } from "@/integrations/supabase/client";

export interface CryptoPrice {
  symbol: string;
  price: number;
  change24h: number;
  change1h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  volume1h: number;
}

// Simulação de dados B3 para demonstração
const B3_MOCK_DATA: Record<string, CryptoPrice> = {
  "PETR4": { symbol: "PETR4", price: 38.45, change24h: 2.3, change1h: 0.5, high24h: 38.90, low24h: 37.80, volume24h: 15000000, volume1h: 1200000 },
  "VALE3": { symbol: "VALE3", price: 65.20, change24h: -1.2, change1h: -0.3, high24h: 66.10, low24h: 64.50, volume24h: 25000000, volume1h: 2000000 },
  "ITUB4": { symbol: "ITUB4", price: 28.75, change24h: 0.8, change1h: 0.2, high24h: 29.00, low24h: 28.40, volume24h: 18000000, volume1h: 1500000 },
  "BBDC4": { symbol: "BBDC4", price: 14.32, change24h: 1.5, change1h: 0.4, high24h: 14.50, low24h: 14.10, volume24h: 12000000, volume1h: 1000000 },
  "ABEV3": { symbol: "ABEV3", price: 11.85, change24h: -0.5, change1h: -0.1, high24h: 12.00, low24h: 11.70, volume24h: 20000000, volume1h: 1600000 },
  "WEGE3": { symbol: "WEGE3", price: 42.10, change24h: 3.1, change1h: 0.7, high24h: 42.50, low24h: 40.80, volume24h: 8000000, volume1h: 650000 },
  "BBAS3": { symbol: "BBAS3", price: 30.25, change24h: 1.8, change1h: 0.5, high24h: 30.60, low24h: 29.80, volume24h: 14000000, volume1h: 1150000 },
  "MGLU3": { symbol: "MGLU3", price: 5.45, change24h: -2.1, change1h: -0.4, high24h: 5.60, low24h: 5.30, volume24h: 22000000, volume1h: 1800000 },
  "RENT3": { symbol: "RENT3", price: 42.30, change24h: 0.9, change1h: 0.2, high24h: 42.80, low24h: 41.90, volume24h: 6000000, volume1h: 500000 },
  "ELET3": { symbol: "ELET3", price: 38.70, change24h: 1.2, change1h: 0.3, high24h: 39.10, low24h: 38.20, volume24h: 9000000, volume1h: 750000 },
};

export const useBinancePrices = (symbols: string[]) => {
  const { isB3Mode } = useTradingMode();
  const [prices, setPrices] = useState<CryptoPrice[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (symbols.length === 0 || symbols.some(s => !s)) {
      console.log("⚠️ useBinancePrices - símbolos vazios ou inválidos");
      setPrices([]);
      setIsLoading(false);
      return;
    }

    if (isB3Mode) {
      // Modo B3: usar dados mockados e atualizar a cada segundo
      const updateB3Prices = () => {
        const b3Prices = symbols.map(symbol => {
          const mockData = B3_MOCK_DATA[symbol];
          if (mockData) {
            return {
              ...mockData,
              price: mockData.price * (1 + (Math.random() - 0.5) * 0.005),
              change24h: mockData.change24h + (Math.random() - 0.5) * 0.2,
              change1h: mockData.change1h + (Math.random() - 0.5) * 0.1,
            };
          }
          return {
            symbol,
            price: 0,
            change24h: 0,
            change1h: 0,
            high24h: 0,
            low24h: 0,
            volume24h: 0,
            volume1h: 0,
          };
        });
        setPrices(b3Prices);
        setIsLoading(false);
        setError(null);
      };

      updateB3Prices();
      const interval = setInterval(updateB3Prices, 1000);
      return () => clearInterval(interval);
    }

    // Modo Cripto: buscar dados completos via API e usar WebSocket só para preços
    console.log("🔌 Iniciando busca de preços para símbolos:", symbols);
    
    const priceMap = new Map<string, CryptoPrice>();
    let ws: WebSocket | null = null;
    let reconnectTimeout: NodeJS.Timeout;
    let enrichmentInterval: NodeJS.Timeout;

    // Buscar dados completos (variações, volumes) via API
    const fetchEnrichedData = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('binance-trading', {
          body: { action: 'get_prices', symbols }
        });

        if (error || !data?.success) {
          console.error('Erro ao buscar dados enriquecidos:', error || data?.error);
          return;
        }

        const apiPrices = data.data as any[];
        
        // Atualizar mapa com dados completos EXATAMENTE como vêm da Binance
        apiPrices.forEach(item => {
          const existing = priceMap.get(item.symbol);
          
          // Usar dados exatos da Binance, sem arredondamentos
          const binanceData = {
            symbol: item.symbol,
            price: existing?.price || Number(item.lastPrice),
            change24h: Number(item.priceChangePercent || 0),
            change1h: Number(item.priceChangePercent1h || 0),
            high24h: Number(item.highPrice || 0),
            low24h: Number(item.lowPrice || 0),
            volume24h: Number(item.quoteVolume || 0),
            volume1h: Number(item.volume1h || 0),
          };
          
          priceMap.set(item.symbol, binanceData);
        });

        const updatedPrices = symbols
          .map(sym => priceMap.get(sym))
          .filter((p): p is CryptoPrice => p !== undefined);
        
        if (updatedPrices.length > 0) {
          setPrices(updatedPrices);
          setIsLoading(false);
          console.log('📊 Dados atualizados da Binance:', updatedPrices.map(p => ({
            symbol: p.symbol,
            change24h: `${p.change24h.toFixed(3)}%`,
            change1h: `${p.change1h.toFixed(3)}%`
          })));
        }
      } catch (err) {
        console.error("Erro ao buscar dados enriquecidos:", err);
      }
    };

    // Buscar dados completos inicialmente e depois a cada 15 segundos (já que preço em tempo real vem do WebSocket)
    fetchEnrichedData();
    enrichmentInterval = setInterval(fetchEnrichedData, 15000);

    const connect = () => {
      try {
        // Criar streams para todos os símbolos (ticker em miniatura para menor latência)
        const streams = symbols.map(s => `${s.toLowerCase()}@miniTicker`).join('/');
        ws = new WebSocket(`wss://fstream.binance.com/stream?streams=${streams}`);

        ws.onopen = () => {
          console.log("✅ WebSocket conectado");
          setError(null);
        };

        ws.onmessage = (event) => {
          try {
            const response = JSON.parse(event.data);
            if (response.data) {
              const data = response.data;
              const symbol = data.s;
              
              const price = parseFloat(data.c);
              const existing = priceMap.get(symbol);
              
              if (existing) {
                // Atualizar apenas o preço, mantendo as variações
                priceMap.set(symbol, {
                  ...existing,
                  price: isNaN(price) ? existing.price : price,
                });

                const updatedPrices = symbols
                  .map(sym => priceMap.get(sym))
                  .filter((p): p is CryptoPrice => p !== undefined);
                
                if (updatedPrices.length > 0) {
                  setPrices(updatedPrices);
                }
              }
            }
          } catch (err) {
            console.error("Erro ao processar mensagem WebSocket:", err);
          }
        };

        ws.onerror = (error) => {
          console.error("❌ Erro WebSocket:", error);
          setError("Erro na conexão WebSocket");
        };

        ws.onclose = () => {
          console.log("🔌 WebSocket desconectado, reconectando em 3s...");
          reconnectTimeout = setTimeout(connect, 3000);
        };

      } catch (err) {
        console.error("Erro ao criar WebSocket:", err);
        setError("Erro ao conectar WebSocket");
        reconnectTimeout = setTimeout(connect, 3000);
      }
    };

    connect();

    return () => {
      if (ws) {
        ws.close();
      }
      if (reconnectTimeout) {
        clearTimeout(reconnectTimeout);
      }
      if (enrichmentInterval) {
        clearInterval(enrichmentInterval);
      }
    };
  }, [symbols.join(','), isB3Mode]);

  return { prices, isLoading, error };
};
