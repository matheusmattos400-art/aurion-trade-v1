import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface FundingRate {
  symbol: string;
  fundingRate: number; // Taxa em % (ex: 0.01 = 0.01%)
  fundingTime: number; // Próximo funding em ms
  lastFundingRate: number; // Última taxa aplicada
  estimatedFundingFee: number; // Taxa estimada em USDT
}

export const useFundingRate = (symbols: string[], positionSizes: Record<string, number>) => {
  const [fundingRates, setFundingRates] = useState<FundingRate[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (symbols.length === 0) return;

    const fetchFundingRates = async () => {
      try {
        const { data: response, error } = await supabase.functions.invoke('binance-trading', {
          body: { 
            action: 'get_funding_rates',
            symbols: symbols,
          }
        });

        if (error) {
          console.error('Erro ao buscar funding rates:', error);
          return;
        }

        if (response.success) {
          const rates = response.data.map((item: any) => {
            const positionSize = positionSizes[item.symbol] || 0;
            const estimatedFundingFee = (positionSize * Math.abs(item.lastFundingRate)) / 100;
            
            return {
              symbol: item.symbol,
              fundingRate: item.fundingRate * 100, // Converter para %
              fundingTime: item.fundingTime,
              lastFundingRate: item.lastFundingRate * 100, // Última taxa aplicada em %
              estimatedFundingFee,
            };
          });
          
          console.log('✅ Funding Rates recebidos:', rates);
          setFundingRates(rates);
          setIsLoading(false);
        }
      } catch (err) {
        console.error("Erro ao buscar funding rates:", err);
      }
    };

    fetchFundingRates();
    // Atualizar a cada 60 segundos (funding muda poucas vezes por dia)
    const interval = setInterval(fetchFundingRates, 60000);

    return () => clearInterval(interval);
  }, [symbols.join(','), JSON.stringify(positionSizes)]);

  return { fundingRates, isLoading };
};
