import { useState, useEffect } from "react";
import { useTradingMode } from "@/contexts/TradingModeContext";

const CRYPTO_PAIRS = [
  "BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "ADAUSDT",
  "DOGEUSDT", "XRPUSDT", "DOTUSDT", "MATICUSDT", "AVAXUSDT"
] as const;

const B3_PAIRS = [
  "PETR4", "VALE3", "ITUB4", "BBDC4", "ABEV3", "WEGE3",
  "BBAS3", "MGLU3", "RENT3", "ELET3"
] as const;

// Dados mockados de correlação B3 (simulação baseada em setores)
const B3_MOCK_CORRELATIONS: Record<string, Record<string, { corr1h: number; corr10d: number; corr30d: number }>> = {
  "PETR4": {
    "VALE3": { corr1h: 0.68, corr10d: 0.72, corr30d: 0.75 },
    "ITUB4": { corr1h: 0.42, corr10d: 0.38, corr30d: 0.35 },
    "BBDC4": { corr1h: 0.44, corr10d: 0.41, corr30d: 0.38 },
    "ABEV3": { corr1h: 0.32, corr10d: 0.28, corr30d: 0.25 },
    "WEGE3": { corr1h: 0.55, corr10d: 0.58, corr30d: 0.61 },
    "BBAS3": { corr1h: 0.43, corr10d: 0.40, corr30d: 0.37 },
    "MGLU3": { corr1h: 0.22, corr10d: 0.18, corr30d: 0.15 },
    "RENT3": { corr1h: 0.35, corr10d: 0.32, corr30d: 0.29 },
    "ELET3": { corr1h: 0.61, corr10d: 0.65, corr30d: 0.68 },
  },
  "VALE3": {
    "PETR4": { corr1h: 0.68, corr10d: 0.72, corr30d: 0.75 },
    "ITUB4": { corr1h: 0.39, corr10d: 0.35, corr30d: 0.32 },
    "BBDC4": { corr1h: 0.41, corr10d: 0.38, corr30d: 0.35 },
    "ABEV3": { corr1h: 0.29, corr10d: 0.25, corr30d: 0.22 },
    "WEGE3": { corr1h: 0.58, corr10d: 0.62, corr30d: 0.65 },
    "BBAS3": { corr1h: 0.40, corr10d: 0.37, corr30d: 0.34 },
    "MGLU3": { corr1h: 0.19, corr10d: 0.15, corr30d: 0.12 },
    "RENT3": { corr1h: 0.32, corr10d: 0.29, corr30d: 0.26 },
    "ELET3": { corr1h: 0.64, corr10d: 0.68, corr30d: 0.71 },
  },
  "ITUB4": {
    "PETR4": { corr1h: 0.42, corr10d: 0.38, corr30d: 0.35 },
    "VALE3": { corr1h: 0.39, corr10d: 0.35, corr30d: 0.32 },
    "BBDC4": { corr1h: 0.94, corr10d: 0.96, corr30d: 0.97 },
    "ABEV3": { corr1h: 0.35, corr10d: 0.32, corr30d: 0.29 },
    "WEGE3": { corr1h: 0.45, corr10d: 0.42, corr30d: 0.39 },
    "BBAS3": { corr1h: 0.90, corr10d: 0.93, corr30d: 0.95 },
    "MGLU3": { corr1h: 0.32, corr10d: 0.28, corr30d: 0.25 },
    "RENT3": { corr1h: 0.39, corr10d: 0.36, corr30d: 0.33 },
    "ELET3": { corr1h: 0.49, corr10d: 0.46, corr30d: 0.43 },
  },
  "BBDC4": {
    "PETR4": { corr1h: 0.44, corr10d: 0.41, corr30d: 0.38 },
    "VALE3": { corr1h: 0.41, corr10d: 0.38, corr30d: 0.35 },
    "ITUB4": { corr1h: 0.94, corr10d: 0.96, corr30d: 0.97 },
    "ABEV3": { corr1h: 0.37, corr10d: 0.34, corr30d: 0.31 },
    "WEGE3": { corr1h: 0.47, corr10d: 0.44, corr30d: 0.41 },
    "BBAS3": { corr1h: 0.92, corr10d: 0.95, corr30d: 0.97 },
    "MGLU3": { corr1h: 0.34, corr10d: 0.30, corr30d: 0.27 },
    "RENT3": { corr1h: 0.41, corr10d: 0.38, corr30d: 0.35 },
    "ELET3": { corr1h: 0.51, corr10d: 0.48, corr30d: 0.45 },
  },
  "ABEV3": {
    "PETR4": { corr1h: 0.32, corr10d: 0.28, corr30d: 0.25 },
    "VALE3": { corr1h: 0.29, corr10d: 0.25, corr30d: 0.22 },
    "ITUB4": { corr1h: 0.35, corr10d: 0.32, corr30d: 0.29 },
    "BBDC4": { corr1h: 0.37, corr10d: 0.34, corr30d: 0.31 },
    "WEGE3": { corr1h: 0.58, corr10d: 0.62, corr30d: 0.65 },
    "BBAS3": { corr1h: 0.36, corr10d: 0.33, corr30d: 0.30 },
    "MGLU3": { corr1h: 0.45, corr10d: 0.42, corr30d: 0.39 },
    "RENT3": { corr1h: 0.49, corr10d: 0.46, corr30d: 0.43 },
    "ELET3": { corr1h: 0.39, corr10d: 0.36, corr30d: 0.33 },
  },
  "WEGE3": {
    "PETR4": { corr1h: 0.55, corr10d: 0.58, corr30d: 0.61 },
    "VALE3": { corr1h: 0.58, corr10d: 0.62, corr30d: 0.65 },
    "ITUB4": { corr1h: 0.45, corr10d: 0.42, corr30d: 0.39 },
    "BBDC4": { corr1h: 0.47, corr10d: 0.44, corr30d: 0.41 },
    "ABEV3": { corr1h: 0.58, corr10d: 0.62, corr30d: 0.65 },
    "BBAS3": { corr1h: 0.46, corr10d: 0.43, corr30d: 0.40 },
    "MGLU3": { corr1h: 0.61, corr10d: 0.65, corr30d: 0.68 },
    "RENT3": { corr1h: 0.65, corr10d: 0.69, corr30d: 0.72 },
    "ELET3": { corr1h: 0.71, corr10d: 0.75, corr30d: 0.78 },
  },
  "BBAS3": {
    "PETR4": { corr1h: 0.43, corr10d: 0.40, corr30d: 0.37 },
    "VALE3": { corr1h: 0.40, corr10d: 0.37, corr30d: 0.34 },
    "ITUB4": { corr1h: 0.90, corr10d: 0.93, corr30d: 0.95 },
    "BBDC4": { corr1h: 0.92, corr10d: 0.95, corr30d: 0.97 },
    "ABEV3": { corr1h: 0.36, corr10d: 0.33, corr30d: 0.30 },
    "WEGE3": { corr1h: 0.46, corr10d: 0.43, corr30d: 0.40 },
    "MGLU3": { corr1h: 0.33, corr10d: 0.29, corr30d: 0.26 },
    "RENT3": { corr1h: 0.40, corr10d: 0.37, corr30d: 0.34 },
    "ELET3": { corr1h: 0.50, corr10d: 0.47, corr30d: 0.44 },
  },
  "MGLU3": {
    "PETR4": { corr1h: 0.22, corr10d: 0.18, corr30d: 0.15 },
    "VALE3": { corr1h: 0.19, corr10d: 0.15, corr30d: 0.12 },
    "ITUB4": { corr1h: 0.32, corr10d: 0.28, corr30d: 0.25 },
    "BBDC4": { corr1h: 0.34, corr10d: 0.30, corr30d: 0.27 },
    "ABEV3": { corr1h: 0.45, corr10d: 0.42, corr30d: 0.39 },
    "WEGE3": { corr1h: 0.61, corr10d: 0.65, corr30d: 0.68 },
    "BBAS3": { corr1h: 0.33, corr10d: 0.29, corr30d: 0.26 },
    "RENT3": { corr1h: 0.75, corr10d: 0.79, corr30d: 0.82 },
    "ELET3": { corr1h: 0.29, corr10d: 0.25, corr30d: 0.22 },
  },
  "RENT3": {
    "PETR4": { corr1h: 0.35, corr10d: 0.32, corr30d: 0.29 },
    "VALE3": { corr1h: 0.32, corr10d: 0.29, corr30d: 0.26 },
    "ITUB4": { corr1h: 0.39, corr10d: 0.36, corr30d: 0.33 },
    "BBDC4": { corr1h: 0.41, corr10d: 0.38, corr30d: 0.35 },
    "ABEV3": { corr1h: 0.49, corr10d: 0.46, corr30d: 0.43 },
    "WEGE3": { corr1h: 0.65, corr10d: 0.69, corr30d: 0.72 },
    "BBAS3": { corr1h: 0.40, corr10d: 0.37, corr30d: 0.34 },
    "MGLU3": { corr1h: 0.75, corr10d: 0.79, corr30d: 0.82 },
    "ELET3": { corr1h: 0.45, corr10d: 0.42, corr30d: 0.39 },
  },
  "ELET3": {
    "PETR4": { corr1h: 0.61, corr10d: 0.65, corr30d: 0.68 },
    "VALE3": { corr1h: 0.64, corr10d: 0.68, corr30d: 0.71 },
    "ITUB4": { corr1h: 0.49, corr10d: 0.46, corr30d: 0.43 },
    "BBDC4": { corr1h: 0.51, corr10d: 0.48, corr30d: 0.45 },
    "ABEV3": { corr1h: 0.39, corr10d: 0.36, corr30d: 0.33 },
    "WEGE3": { corr1h: 0.71, corr10d: 0.75, corr30d: 0.78 },
    "BBAS3": { corr1h: 0.50, corr10d: 0.47, corr30d: 0.44 },
    "MGLU3": { corr1h: 0.29, corr10d: 0.25, corr30d: 0.22 },
    "RENT3": { corr1h: 0.45, corr10d: 0.42, corr30d: 0.39 },
  },
};

interface CorrelationData {
  symbol: string;
  corr1h: number; // 1 hora
  corr10d: number; // 10 dias
  corr30d: number; // 30 dias
}

interface CachedData {
  [symbol: string]: {
    prices: number[];
    timestamp: number;
  };
}

// Calculate log returns from prices
function logReturns(prices: number[]): number[] {
  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    returns.push(Math.log(prices[i] / prices[i - 1]));
  }
  return returns;
}

// Calculate Pearson correlation coefficient
function pearsonCorrelation(x: number[], y: number[]): number {
  const n = Math.min(x.length, y.length);
  if (n === 0) return 0;

  const meanX = x.slice(0, n).reduce((a, b) => a + b, 0) / n;
  const meanY = y.slice(0, n).reduce((a, b) => a + b, 0) / n;

  let num = 0, denX = 0, denY = 0;
  for (let i = 0; i < n; i++) {
    const dx = x[i] - meanX;
    const dy = y[i] - meanY;
    num += dx * dy;
    denX += dx ** 2;
    denY += dy ** 2;
  }

  const denominator = Math.sqrt(denX * denY);
  return denominator === 0 ? 0 : num / denominator;
}

// Fetch klines from Binance Futures API
async function fetchKlinesBinance(symbol: string, interval: string, limit: number): Promise<number[]> {
  try {
    await new Promise(resolve => setTimeout(resolve, 100)); // Rate limiting
    
    const response = await fetch(
      `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`
    );
    
    if (response.status === 418 || response.status === 429) {
      console.warn(`⚠️ Rate limit atingido para ${symbol}. Aguardando...`);
      await new Promise(resolve => setTimeout(resolve, 5000));
      return [];
    }
    
    if (!response.ok) {
      console.error(`HTTP error for ${symbol}! status: ${response.status}`);
      return [];
    }
    
    const data = await response.json();
    return data.map((candle: any[]) => parseFloat(candle[4])); // Close price
  } catch (error) {
    console.error(`Error fetching klines for ${symbol}:`, error);
    return [];
  }
}

export const useCorrelation = (selectedPair: string) => {
  const { isB3Mode } = useTradingMode();
  const [correlations, setCorrelations] = useState<CorrelationData[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  useEffect(() => {
    if (!selectedPair) {
      setCorrelations([]);
      return;
    }

    const calculateCorrelations = async () => {
      setIsLoading(true);
      
      try {
        if (isB3Mode) {
          // Modo B3: usar correlações mockadas
          const mockCorrelations = B3_MOCK_CORRELATIONS[selectedPair];
          
          if (!mockCorrelations) {
            setCorrelations([]);
            setIsLoading(false);
            return;
          }

          const results: CorrelationData[] = B3_PAIRS
            .filter(pair => pair !== selectedPair)
            .map(pair => ({
              symbol: pair,
              corr1h: mockCorrelations[pair]?.corr1h || 0,
              corr10d: mockCorrelations[pair]?.corr10d || 0,
              corr30d: mockCorrelations[pair]?.corr30d || 0,
            }))
            .sort((a, b) => b.corr1h - a.corr1h);

          setCorrelations(results);
          setLastUpdate(new Date());
          setIsLoading(false);
          return;
        }

        // Modo Cripto: calcular correlações da Binance usando 1h, 10d, 30d
        const results: CorrelationData[] = [];
        
        // Buscar dados do par selecionado
        const [selected1h, selected10d, selected30d] = await Promise.all([
          fetchKlinesBinance(selectedPair, '1h', 168), // 1 semana de dados horários
          fetchKlinesBinance(selectedPair, '1d', 10),
          fetchKlinesBinance(selectedPair, '1d', 30)
        ]);

        if (selected1h.length === 0 || selected10d.length === 0 || selected30d.length === 0) {
          setIsLoading(false);
          return;
        }

        const selectedReturns1h = logReturns(selected1h);
        const selectedReturns10d = logReturns(selected10d);
        const selectedReturns30d = logReturns(selected30d);
        
        for (const symbol of CRYPTO_PAIRS) {
          if (symbol === selectedPair) continue;
          
          const [prices1h, prices10d, prices30d] = await Promise.all([
            fetchKlinesBinance(symbol, '1h', 168),
            fetchKlinesBinance(symbol, '1d', 10),
            fetchKlinesBinance(symbol, '1d', 30)
          ]);
          
          if (prices1h.length === 0 || prices10d.length === 0 || prices30d.length === 0) continue;
          
          const returns1h = logReturns(prices1h);
          const returns10d = logReturns(prices10d);
          const returns30d = logReturns(prices30d);
          
          const corr1h = pearsonCorrelation(selectedReturns1h, returns1h);
          const corr10d = pearsonCorrelation(selectedReturns10d, returns10d);
          const corr30d = pearsonCorrelation(selectedReturns30d, returns30d);
          
          results.push({ symbol, corr1h, corr10d, corr30d });
        }
        
        // Ordenar por correlação de 1 hora
        results.sort((a, b) => b.corr1h - a.corr1h);
        setCorrelations(results);
        setLastUpdate(new Date());
        
      } catch (error) {
        console.error('Error calculating correlations:', error);
      }
      
      setIsLoading(false);
    };

    calculateCorrelations();
  }, [selectedPair, isB3Mode]);

  return { correlations, isLoading, lastUpdate };
};
