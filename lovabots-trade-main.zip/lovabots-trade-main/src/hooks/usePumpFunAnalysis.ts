import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { AurionPlusAnalysis } from "@/components/AurionPlusCard";
import {
  disableAIGatewayForMinutes,
  getAIGatewayUserMessage,
  getInvokeErrorStatusCode,
  isAIGatewayTemporarilyDisabled,
} from "@/utils/aiCreditsGuard";

interface PumpFunDataRequest {
  tokenMint: string;
  deployerAddress?: string;
  marketCap?: number;
  liquidity?: number;
  volume24h?: number;
  holders?: number;
  ageMinutes?: number;
  tokenSymbol?: string;
  tokenName?: string;
}

// Dados brutos coletados da Helius
interface HeliusRawData {
  tokenMint: string;
  collectedAt: string;
  block0: {
    creationSlot: number | null;
    creationTime: string | null;
    wallets: string[];
    transactionCount: number;
    totalTransactionsAnalyzed: number;
  } | null;
  holders: {
    count: number;
    topAccounts: Array<{ address: string; balance: number }>;
  } | null;
  devWallet: {
    address: string;
    transactionCount: number;
    transactions: Array<{
      signature: string;
      blockTime: number;
      balanceChangeLamports: number;
      instructionCount: number;
      hasError: boolean;
    }>;
  } | null;
  _meta: {
    heliusCallsSuccessful: boolean;
  };
}

export function usePumpFunAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisCache, setAnalysisCache] = useState<Record<string, AurionPlusAnalysis>>({});
  const [error, setError] = useState<string | null>(null);

  // Passo 1: Coletar dados brutos da Helius
  const collectRawData = useCallback(async (params: PumpFunDataRequest): Promise<HeliusRawData | null> => {
    try {
      console.log(`[PumpFun] Step 1: Collecting raw data from Helius for ${params.tokenMint}`);

      const { data, error: fnError } = await supabase.functions.invoke("pump-fun-data-collector", {
        body: {
          tokenMint: params.tokenMint,
          deployerAddress: params.deployerAddress,
          includeHolders: true,
          includeDevHistory: !!params.deployerAddress,
        },
      });

      if (fnError) {
        console.error(`[PumpFun] Helius data collection error:`, fnError);
        return null;
      }

      console.log(`[PumpFun] Raw data collected:`, {
        block0Wallets: data?.block0?.wallets?.length || 0,
        holders: data?.holders?.count || 0,
        devTxs: data?.devWallet?.transactionCount || 0,
      });

      return data as HeliusRawData;
    } catch (err) {
      console.error(`[PumpFun] Error collecting raw data:`, err);
      return null;
    }
  }, []);

  // Passo 2: Passar dados brutos para a Aurion AI analisar
  const analyzeWithAurionAI = useCallback(async (
    params: PumpFunDataRequest,
    rawData: HeliusRawData | null
  ): Promise<AurionPlusAnalysis> => {
    try {
      if (isAIGatewayTemporarilyDisabled()) {
        return {
          bundleRetention: 0,
          devPnlEstimated: 0,
          devGreedAverage: 0,
          devRugRisk: "LOW",
          bundleHolding: false,
          devClean: true,
          mcInRange: false,
          inWindow: false,
          volumeLateralizing: false,
          bundleSelling: false,
          status: "NEUTRAL",
          warnings: [getAIGatewayUserMessage(402)],
        };
      }

      console.log(`[PumpFun] Step 2: Sending data to Aurion AI for analysis`);

      // Recuperar userId e conversationId do localStorage
      const userId = localStorage.getItem('aurion_user_id') || undefined;
      const conversationId = localStorage.getItem('aurion_conversation_id') || undefined;

      // Construir token data para a aurion-full-analysis
      const tokenData = {
        symbol: params.tokenSymbol || "UNKNOWN",
        name: params.tokenName || "Unknown Token",
        address: params.tokenMint,
        chainId: "solana",
        pairAddress: params.tokenMint, // Pump.fun usa mint como pair
        price: 0,
        priceChange24h: 0,
        volume24h: params.volume24h || 0,
        liquidity: params.liquidity || 0,
        marketCap: params.marketCap || 0,
        fdv: params.marketCap || 0,
        creatorAddress: params.deployerAddress,
        // Dados brutos da Helius para a IA analisar
        heliusRawData: rawData,
        pumpFunContext: {
          ageMinutes: params.ageMinutes || 0,
          holdersCount: params.holders || 0,
          isAurionPlusAnalysis: true, // Flag para a IA saber que é análise Aurion Plus
        },
      };

      const { data, error: fnError } = await supabase.functions.invoke("aurion-full-analysis", {
        body: {
          token: tokenData,
          userId,
          conversationId,
        },
      });

      if (fnError) {
        console.error(`[PumpFun] Aurion AI analysis error:`, fnError);
        const status = getInvokeErrorStatusCode(fnError) ?? null;
        if (status === 402) {
          disableAIGatewayForMinutes(10);
          throw new Error(getAIGatewayUserMessage(402));
        }
        if (status === 429) {
          throw new Error(getAIGatewayUserMessage(429));
        }
        throw new Error(fnError.message);
      }

      // Extrair análise Aurion Plus do resultado da IA
      const analysis: AurionPlusAnalysis = {
        bundleRetention: data?.bundleAnalysis?.bundleRetention || 0,
        devPnlEstimated: data?.devDNA?.devPnlEstimated || 0,
        devGreedAverage: data?.devDNA?.devGreedAverage || 0,
        devRugRisk: data?.devDNA?.devRugRisk || "LOW",
        bundleHolding: data?.bundleAnalysis?.bundleHolding || false,
        devClean: data?.devDNA?.devClean || true,
        mcInRange: data?.windowAnalysis?.mcInRange || false,
        inWindow: data?.windowAnalysis?.inWindow || false,
        volumeLateralizing: false,
        bundleSelling: data?.bundleAnalysis?.bundleSelling || false,
        status: data?.aurionPlusStatus || "NEUTRAL",
        warnings: data?.warnings || [],
      };

      console.log(`[PumpFun] Aurion AI analysis complete: ${analysis.status}`);
      return analysis;

    } catch (err) {
      console.error(`[PumpFun] Error in Aurion AI analysis:`, err);
      
      // Fallback analysis
      return {
        bundleRetention: 0,
        devPnlEstimated: 0,
        devGreedAverage: 0,
        devRugRisk: "LOW",
        bundleHolding: false,
        devClean: true,
        mcInRange: false,
        inWindow: false,
        volumeLateralizing: false,
        bundleSelling: false,
        status: "NEUTRAL",
        warnings: ["Análise não disponível"],
      };
    }
  }, []);

  // Função principal: Coleta dados e envia para IA
  const analyzeToken = useCallback(async (params: PumpFunDataRequest): Promise<AurionPlusAnalysis | null> => {
    const cacheKey = params.tokenMint;
    
    // Check cache first
    if (analysisCache[cacheKey]) {
      return analysisCache[cacheKey];
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      console.log(`[PumpFun] Starting full analysis pipeline for ${params.tokenMint}`);

      // Step 1: Coletar dados brutos da Helius
      const rawData = await collectRawData(params);

      // Step 2: Enviar para Aurion AI analisar
      const analysis = await analyzeWithAurionAI(params, rawData);

      // Update cache
      setAnalysisCache(prev => ({
        ...prev,
        [cacheKey]: analysis,
      }));

      console.log(`[PumpFun] Full analysis complete for ${params.tokenMint}: ${analysis.status}`);
      return analysis;

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      console.error(`[PumpFun] Pipeline error: ${errorMessage}`);
      setError(errorMessage);
      
      // Return fallback analysis
      const fallbackAnalysis: AurionPlusAnalysis = {
        bundleRetention: 0,
        devPnlEstimated: 0,
        devGreedAverage: 0,
        devRugRisk: "LOW",
        bundleHolding: false,
        devClean: true,
        mcInRange: false,
        inWindow: false,
        volumeLateralizing: false,
        bundleSelling: false,
        status: "NEUTRAL",
        warnings: ["Análise do Pump.fun não disponível"],
      };
      
      return fallbackAnalysis;
    } finally {
      setIsAnalyzing(false);
    }
  }, [analysisCache, collectRawData, analyzeWithAurionAI]);

  const analyzeTokenBatch = useCallback(async (
    tokens: Array<{
      address: string;
      creatorAddress?: string;
      marketCap: number;
      liquidity: number;
      volume24h: number;
      holders?: number;
      ageHours: number;
      symbol?: string;
      name?: string;
    }>
  ): Promise<Record<string, AurionPlusAnalysis>> => {
    const results: Record<string, AurionPlusAnalysis> = {};
    
    // Process in parallel, max 3 at a time (to avoid rate limits)
    const batchSize = 3;
    for (let i = 0; i < tokens.length; i += batchSize) {
      const batch = tokens.slice(i, i + batchSize);
      
      const batchResults = await Promise.all(
        batch.map(async (token) => {
          const analysis = await analyzeToken({
            tokenMint: token.address,
            deployerAddress: token.creatorAddress,
            marketCap: token.marketCap,
            liquidity: token.liquidity,
            volume24h: token.volume24h,
            holders: token.holders || 0,
            ageMinutes: token.ageHours * 60,
            tokenSymbol: token.symbol,
            tokenName: token.name,
          });
          
          return { address: token.address, analysis };
        })
      );

      for (const { address, analysis } of batchResults) {
        if (analysis) {
          results[address] = analysis;
        }
      }
    }

    return results;
  }, [analyzeToken]);

  const clearCache = useCallback(() => {
    setAnalysisCache({});
  }, []);

  return {
    analyzeToken,
    analyzeTokenBatch,
    clearCache,
    isAnalyzing,
    analysisCache,
    error,
  };
}
