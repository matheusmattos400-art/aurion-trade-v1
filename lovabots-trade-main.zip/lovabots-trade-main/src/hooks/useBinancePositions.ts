import { useState, useEffect, useMemo } from "react";
import { useBinanceWebSocket } from "./useBinanceWebSocket";
import { supabase } from "@/integrations/supabase/client";

interface BinancePosition {
  symbol: string;
  positionAmt: string;
  entryPrice: string;
  markPrice: string;
  unRealizedProfit: string;
  liquidationPrice: string;
  leverage: string;
  positionSide: string;
}

export const useBinancePositions = (symbols: string[], enabled: boolean = true) => {
  const [positions, setPositions] = useState<BinancePosition[]>([]);
  const [totalPnl, setTotalPnl] = useState<number>(0);
  const [restFallbackUsed, setRestFallbackUsed] = useState(false);

  // Conectar ao WebSocket quando habilitado
  const { accountData, isConnected } = useBinanceWebSocket(enabled);

  // Buscar posições via REST API como fallback
  const fetchPositionsREST = async () => {
    try {
      console.log('📡 Buscando posições via REST API como fallback...');
      const { data, error } = await supabase.functions.invoke('binance-trading', {
        body: { action: 'get_positions' }
      });

      if (error) {
        console.error('❌ Erro ao buscar posições REST:', error);
        return;
      }

      if (data?.success && data?.data?.positions) {
        console.log('✅ Posições REST recebidas:', data.data.positions.length);
        const restPositions: BinancePosition[] = data.data.positions
          .filter((pos: any) => symbols.includes(pos.symbol))
          .map((pos: any) => ({
            symbol: pos.symbol,
            positionAmt: pos.positionAmt,
            entryPrice: pos.entryPrice,
            markPrice: pos.markPrice,
            unRealizedProfit: pos.unRealizedProfit,
            liquidationPrice: pos.liquidationPrice,
            leverage: pos.leverage,
            positionSide: pos.positionSide
          }));

        console.log('📊 Posições REST filtradas:', {
          total: restPositions.length,
          positions: restPositions.map(p => ({ 
            symbol: p.symbol, 
            pnl: p.unRealizedProfit,
            amount: p.positionAmt 
          }))
        });
        setPositions(restPositions);

        const total = restPositions.reduce((sum, pos) => 
          sum + parseFloat(pos.unRealizedProfit || '0'), 0
        );
        console.log('💰 PnL REST Total:', total);
        setTotalPnl(total);
      }
    } catch (err) {
      console.error('❌ Erro ao buscar posições REST:', err);
    }
  };

  // Processar updates do WebSocket
  useEffect(() => {
    // Se hook desabilitado ou sem símbolos válidos, não faz nada
    if (!enabled || symbols.length === 0) return;

    if (!accountData || !accountData.positions) {
      console.log('⚠️ Sem dados de posições do WebSocket, tentando REST API fallback pontual');
      // Usa REST apenas uma vez enquanto não houver dados do WS
      if (!restFallbackUsed) {
        setRestFallbackUsed(true);
        fetchPositionsREST();
      }
      return;
    }

    // Se o WebSocket voltar a fornecer dados, liberamos novo fallback futuro se precisar
    if (restFallbackUsed) {
      setRestFallbackUsed(false);
    }

    console.log('📊 Processando update de posições via WebSocket:', {
      totalPositions: accountData.positions.length,
      symbols: symbols,
      positions: accountData.positions.map(p => ({
        symbol: p.symbol,
        positionAmount: p.positionAmount,
        unrealizedProfit: p.unrealizedProfit,
        entryPrice: p.entryPrice
      }))
    });

    // Converter formato do WebSocket para o formato esperado
    const wsPositions: BinancePosition[] = accountData.positions
      .filter(pos => {
        const hasPosition = parseFloat(pos.positionAmount) !== 0;
        const included = symbols.includes(pos.symbol);
        console.log(`  ${included && hasPosition ? '✅' : '❌'} ${pos.symbol} - Amount: ${pos.positionAmount}, PnL: ${pos.unrealizedProfit}`);
        return included && hasPosition;
      })
      .map(pos => ({
        symbol: pos.symbol,
        positionAmt: pos.positionAmount,
        entryPrice: pos.entryPrice,
        markPrice: '0', // Será atualizado via ticker
        unRealizedProfit: pos.unrealizedProfit,
        liquidationPrice: '0', // Não vem no update
        leverage: '0', // Não vem no update
        positionSide: pos.positionSide
      }));

    console.log('📈 Posições filtradas:', wsPositions.length);
    setPositions(wsPositions);

    // Calcular PnL total
    const total = wsPositions.reduce((sum, pos) => 
      sum + parseFloat(pos.unRealizedProfit || '0'), 0
    );
    console.log('💰 PnL Total calculado:', total);
    setTotalPnl(total);

  }, [accountData, symbols, enabled, restFallbackUsed]);

  // Fallback: se não conectado, retornar dados vazios
  const isLoading = enabled && !isConnected;

  // Memoizar posições relevantes
  const relevantPositions = useMemo(() => 
    positions.filter(pos => symbols.includes(pos.symbol)),
    [positions, symbols]
  );

  return { 
    positions: relevantPositions, 
    totalPnl, 
    isLoading,
    isConnected,
    refetch: () => {} // WebSocket não precisa de refetch manual
  };
};
