/**
 * Direct Gemini API Client
 * 
 * This module provides direct access to Google's Gemini API without going through
 * Lovable's AI Gateway. Use this for standalone deployments (Vercel, etc.)
 * 
 * Required Environment Variable:
 * - GEMINI_API_KEY (for backend/edge functions)
 */

export interface GeminiMessage {
  role: 'user' | 'model';
  parts: Array<{ text: string } | { inline_data: { mime_type: string; data: string } }>;
}

export interface GeminiConfig {
  model?: string;
  temperature?: number;
  maxOutputTokens?: number;
  apiKey?: string;
}

const DEFAULT_MODEL = 'gemini-1.5-flash';
const GEMINI_API_BASE = 'https://generativelanguage.googleapis.com/v1beta/models';

/**
 * Call Gemini API directly
 */
export async function callGeminiDirect(
  messages: GeminiMessage[],
  config: GeminiConfig = {}
): Promise<{ text: string; error?: string }> {
  const {
    model = DEFAULT_MODEL,
    temperature = 0.7,
    maxOutputTokens = 2048,
    apiKey
  } = config;

  const geminiApiKey = apiKey || getGeminiApiKey();
  
  if (!geminiApiKey) {
    return { text: '', error: 'GEMINI_API_KEY not configured' };
  }

  try {
    const response = await fetch(
      `${GEMINI_API_BASE}/${model}:generateContent?key=${geminiApiKey}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: messages,
          generationConfig: {
            temperature,
            maxOutputTokens,
          },
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Gemini API error:', response.status, errorText);
      
      if (response.status === 429) {
        return { text: '', error: 'Rate limit exceeded. Please wait a moment.' };
      }
      
      return { text: '', error: `Gemini API error: ${response.status}` };
    }

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    
    return { text };
  } catch (error) {
    console.error('Gemini call failed:', error);
    return { text: '', error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

/**
 * Get Gemini API key from environment
 * Works in both Deno (edge functions) and Node.js environments
 */
export function getGeminiApiKey(): string | undefined {
  // Deno environment (Supabase Edge Functions)
  // @ts-ignore - Deno is available in edge function context
  if (typeof globalThis.Deno !== 'undefined') {
    // @ts-ignore - Deno global
    return globalThis.Deno.env.get('GEMINI_API_KEY');
  }
  
  // Node.js environment
  if (typeof process !== 'undefined' && process.env) {
    return process.env.GEMINI_API_KEY;
  }
  
  return undefined;
}

/**
 * Convert OpenAI-style messages to Gemini format
 */
export function convertToGeminiFormat(
  messages: Array<{ role: string; content: string }>
): GeminiMessage[] {
  return messages.map(msg => ({
    role: msg.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: msg.content }]
  }));
}

/**
 * Simple chat completion using Gemini (similar to OpenAI API)
 */
export async function geminiChatCompletion(
  systemPrompt: string,
  userMessage: string,
  config: GeminiConfig = {}
): Promise<{ text: string; error?: string }> {
  const messages: GeminiMessage[] = [
    { role: 'user', parts: [{ text: systemPrompt }] },
    { role: 'model', parts: [{ text: 'Understood. I will follow these instructions.' }] },
    { role: 'user', parts: [{ text: userMessage }] }
  ];

  return callGeminiDirect(messages, config);
}
