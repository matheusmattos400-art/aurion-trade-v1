/**
 * Standalone Supabase Client for External Deployment (Vercel)
 * 
 * This file provides a Supabase client that works outside Lovable's infrastructure.
 * It uses standard environment variables that can be configured in Vercel or any hosting provider.
 * 
 * Required Environment Variables:
 * - VITE_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_URL or SUPABASE_URL
 * - VITE_SUPABASE_ANON_KEY or NEXT_PUBLIC_SUPABASE_ANON_KEY or SUPABASE_ANON_KEY
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Priority order for environment variables (Vite -> Next.js -> Standard)
function getEnvVar(viteKey: string, nextKey: string, standardKey: string): string {
  // Check Vite environment (for development with Vite)
  if (typeof import.meta !== 'undefined' && import.meta.env) {
    const viteValue = import.meta.env[viteKey];
    if (viteValue) return viteValue;
  }
  
  // Check process.env (for Node.js/Next.js/Vercel)
  if (typeof process !== 'undefined' && process.env) {
    const nextValue = process.env[nextKey];
    if (nextValue) return nextValue;
    
    const standardValue = process.env[standardKey];
    if (standardValue) return standardValue;
  }
  
  return '';
}

const SUPABASE_URL = getEnvVar(
  'VITE_SUPABASE_URL',
  'NEXT_PUBLIC_SUPABASE_URL', 
  'SUPABASE_URL'
);

const SUPABASE_ANON_KEY = getEnvVar(
  'VITE_SUPABASE_PUBLISHABLE_KEY',
  'NEXT_PUBLIC_SUPABASE_ANON_KEY',
  'SUPABASE_ANON_KEY'
);

if (!SUPABASE_URL) {
  console.warn('⚠️ SUPABASE_URL not configured. Set one of: VITE_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_URL, or SUPABASE_URL');
}

if (!SUPABASE_ANON_KEY) {
  console.warn('⚠️ SUPABASE_ANON_KEY not configured. Set one of: VITE_SUPABASE_PUBLISHABLE_KEY, NEXT_PUBLIC_SUPABASE_ANON_KEY, or SUPABASE_ANON_KEY');
}

// Create the standalone client
export const supabaseStandalone: SupabaseClient = createClient(
  SUPABASE_URL || 'https://placeholder.supabase.co',
  SUPABASE_ANON_KEY || 'placeholder-key',
  {
    auth: {
      storage: typeof window !== 'undefined' ? localStorage : undefined,
      persistSession: true,
      autoRefreshToken: true,
    }
  }
);

// Export configuration for debugging
export const supabaseConfig = {
  url: SUPABASE_URL,
  hasKey: !!SUPABASE_ANON_KEY,
  isConfigured: !!(SUPABASE_URL && SUPABASE_ANON_KEY),
};

// Function to check if Supabase is properly configured
export function isSupabaseConfigured(): boolean {
  return !!(SUPABASE_URL && SUPABASE_ANON_KEY);
}

// Function to get the configured Supabase URL (for edge function calls)
export function getSupabaseUrl(): string {
  return SUPABASE_URL;
}
