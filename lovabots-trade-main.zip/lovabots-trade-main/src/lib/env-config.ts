/**
 * Environment Configuration for Standalone Deployment
 * 
 * This file centralizes all environment variable access for the application.
 * It supports multiple deployment environments: Lovable, Vercel, and standard Node.js.
 * 
 * Required Environment Variables:
 * - VITE_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_URL / SUPABASE_URL
 * - VITE_SUPABASE_PUBLISHABLE_KEY / NEXT_PUBLIC_SUPABASE_ANON_KEY / SUPABASE_ANON_KEY
 * 
 * Optional (for AI features):
 * - GEMINI_API_KEY (backend only)
 * 
 * Optional (for WebSocket proxy):
 * - VITE_PROXY_WS_URL
 */

// Type-safe environment getter
function getEnv(key: string, fallback: string = ''): string {
  // Vite environment (client-side)
  if (typeof import.meta !== 'undefined' && import.meta.env) {
    const value = import.meta.env[key];
    if (value) return value;
  }
  
  // Node.js/Vercel environment
  if (typeof process !== 'undefined' && process.env) {
    const value = process.env[key];
    if (value) return value;
  }
  
  return fallback;
}

// Supabase Configuration
export const ENV = {
  // Supabase
  SUPABASE_URL: getEnv('VITE_SUPABASE_URL') || 
                getEnv('NEXT_PUBLIC_SUPABASE_URL') || 
                getEnv('SUPABASE_URL'),
  
  SUPABASE_ANON_KEY: getEnv('VITE_SUPABASE_PUBLISHABLE_KEY') || 
                     getEnv('NEXT_PUBLIC_SUPABASE_ANON_KEY') || 
                     getEnv('SUPABASE_ANON_KEY'),
  
  SUPABASE_PROJECT_ID: getEnv('VITE_SUPABASE_PROJECT_ID') || 
                       getEnv('NEXT_PUBLIC_SUPABASE_PROJECT_ID') || 
                       getEnv('SUPABASE_PROJECT_ID'),
  
  // WebSocket Proxy
  PROXY_WS_URL: getEnv('VITE_PROXY_WS_URL') || 
                getEnv('NEXT_PUBLIC_PROXY_WS_URL') || 
                getEnv('PROXY_WS_URL'),
  
  // Deployment detection
  IS_VERCEL: getEnv('VERCEL') === '1' || getEnv('VERCEL') === 'true',
  IS_PRODUCTION: getEnv('NODE_ENV') === 'production',
  IS_LOVABLE: typeof import.meta !== 'undefined' && 
              import.meta.env?.VITE_SUPABASE_URL?.includes('supabase.co'),
};

// Validation function
export function validateEnvConfig(): { valid: boolean; missing: string[] } {
  const missing: string[] = [];
  
  if (!ENV.SUPABASE_URL) {
    missing.push('SUPABASE_URL (or VITE_SUPABASE_URL)');
  }
  
  if (!ENV.SUPABASE_ANON_KEY) {
    missing.push('SUPABASE_ANON_KEY (or VITE_SUPABASE_PUBLISHABLE_KEY)');
  }
  
  return {
    valid: missing.length === 0,
    missing
  };
}

// Edge function URL builder
export function getEdgeFunctionUrl(functionName: string): string {
  if (!ENV.SUPABASE_URL) {
    console.warn('SUPABASE_URL not configured, edge function calls will fail');
    return '';
  }
  return `${ENV.SUPABASE_URL}/functions/v1/${functionName}`;
}

// Log configuration status (useful for debugging)
export function logEnvStatus(): void {
  console.log('🔧 Environment Configuration:');
  console.log(`  - Supabase URL: ${ENV.SUPABASE_URL ? '✅ Configured' : '❌ Missing'}`);
  console.log(`  - Supabase Key: ${ENV.SUPABASE_ANON_KEY ? '✅ Configured' : '❌ Missing'}`);
  console.log(`  - WebSocket Proxy: ${ENV.PROXY_WS_URL ? '✅ Configured' : '⚠️ Not set'}`);
  console.log(`  - Is Vercel: ${ENV.IS_VERCEL}`);
  console.log(`  - Is Production: ${ENV.IS_PRODUCTION}`);
}
