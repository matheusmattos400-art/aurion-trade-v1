import React, { useEffect, useState } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Session } from "@supabase/supabase-js";
import { TradingModeProvider } from "@/contexts/TradingModeContext";
import { SolanaWalletProvider } from "@/contexts/SolanaWalletContext";
import Index from "./pages/Index";
import History from "./pages/History";
import AurionStrategy from "./pages/AurionStrategy";
import AurionIntelligence from "./pages/AurionIntelligence";
import NotFound from "./pages/NotFound";
import { AuthForm } from "./components/AuthForm";

const queryClient = new QueryClient();

const AppContent = () => {
  return (
    <div className="min-h-screen w-full">
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/history" element={<History />} />
        <Route path="/aurion-strategy" element={<AurionStrategy />} />
        <Route path="/aurion" element={<AurionIntelligence />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
};

const App = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-primary text-xl">Carregando...</div>
      </div>
    );
  }

  if (!session) {
    return (
      <QueryClientProvider client={queryClient}>
        <Toaster />
        <Sonner />
        <AuthForm />
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <SolanaWalletProvider>
        <TradingModeProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AppContent />
          </BrowserRouter>
        </TradingModeProvider>
      </SolanaWalletProvider>
    </QueryClientProvider>
  );
};

export default App;
