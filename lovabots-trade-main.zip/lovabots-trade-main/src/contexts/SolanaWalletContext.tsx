import React, { useMemo, ReactNode } from 'react';
import { ConnectionProvider, WalletProvider } from '@solana/wallet-adapter-react';
import { WalletModalProvider } from '@solana/wallet-adapter-react-ui';

// Import wallet adapter CSS
import '@solana/wallet-adapter-react-ui/styles.css';

interface SolanaWalletProviderProps {
  children: ReactNode;
}

// Public RPC endpoint (no API key) to avoid 401 errors
const SOLANA_RPC = "https://rpc.ankr.com/solana";

export const SolanaWalletProvider: React.FC<SolanaWalletProviderProps> = ({ children }) => {
  const endpoint = useMemo(() => SOLANA_RPC, []);

  // Important:
  // - Keep adapters list empty so Wallet Standard auto-detection works (extensions)
  // - On mobile web, the wallet-adapter automatically injects Mobile Wallet Adapter
  //   (so Phantom/Solflare installed apps can be used without redirect to download pages)
  const wallets = useMemo(() => [], []);

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect>
        <WalletModalProvider>
          {children}
        </WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
};
