import { createContext, useContext, useState, useEffect, ReactNode } from "react";

type TradingMode = "crypto" | "b3";

interface TradingModeContextType {
  mode: TradingMode;
  toggleMode: () => void;
  isCryptoMode: boolean;
  isB3Mode: boolean;
}

const TradingModeContext = createContext<TradingModeContextType | undefined>(undefined);

export const TradingModeProvider = ({ children }: { children: ReactNode }) => {
  const [mode, setMode] = useState<TradingMode>(() => {
    const saved = localStorage.getItem("aurion_mode");
    return (saved === "b3" ? "b3" : "crypto") as TradingMode;
  });

  useEffect(() => {
    // Aplicar tema
    document.body.classList.remove("theme-crypto", "theme-b3");
    document.body.classList.add(`theme-${mode}`);
    
    // Salvar no localStorage
    localStorage.setItem("aurion_mode", mode);
  }, [mode]);

  const toggleMode = () => {
    setMode(prev => prev === "crypto" ? "b3" : "crypto");
  };

  return (
    <TradingModeContext.Provider
      value={{
        mode,
        toggleMode,
        isCryptoMode: mode === "crypto",
        isB3Mode: mode === "b3",
      }}
    >
      {children}
    </TradingModeContext.Provider>
  );
};

export const useTradingMode = () => {
  const context = useContext(TradingModeContext);
  if (!context) {
    throw new Error("useTradingMode must be used within TradingModeProvider");
  }
  return context;
};
