export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      active_operations: {
        Row: {
          auto_close_enabled: boolean | null
          auto_mode_completed: number | null
          auto_mode_enabled: boolean | null
          auto_mode_is_test: boolean | null
          auto_mode_paused: boolean | null
          auto_mode_target: number | null
          current_pnl: number | null
          custom_order_created: boolean | null
          custom_order_id: string | null
          custom_order_price: number | null
          entry_momentum: number | null
          entry_price_long: number | null
          entry_price_short: number | null
          id: string
          investment_amount: number
          is_test: boolean | null
          leverage: number
          leverage_long: number
          leverage_short: number
          limit_order_created: boolean | null
          limit_order_id: string | null
          long_close_pnl: number | null
          long_closed: boolean | null
          long_order_id: string | null
          long_symbol: string
          profit_target: number | null
          short_close_pnl: number | null
          short_closed: boolean | null
          short_order_id: string | null
          short_symbol: string
          started_at: string | null
          status: string | null
          trading_mode: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          auto_close_enabled?: boolean | null
          auto_mode_completed?: number | null
          auto_mode_enabled?: boolean | null
          auto_mode_is_test?: boolean | null
          auto_mode_paused?: boolean | null
          auto_mode_target?: number | null
          current_pnl?: number | null
          custom_order_created?: boolean | null
          custom_order_id?: string | null
          custom_order_price?: number | null
          entry_momentum?: number | null
          entry_price_long?: number | null
          entry_price_short?: number | null
          id?: string
          investment_amount: number
          is_test?: boolean | null
          leverage: number
          leverage_long: number
          leverage_short: number
          limit_order_created?: boolean | null
          limit_order_id?: string | null
          long_close_pnl?: number | null
          long_closed?: boolean | null
          long_order_id?: string | null
          long_symbol: string
          profit_target?: number | null
          short_close_pnl?: number | null
          short_closed?: boolean | null
          short_order_id?: string | null
          short_symbol: string
          started_at?: string | null
          status?: string | null
          trading_mode?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          auto_close_enabled?: boolean | null
          auto_mode_completed?: number | null
          auto_mode_enabled?: boolean | null
          auto_mode_is_test?: boolean | null
          auto_mode_paused?: boolean | null
          auto_mode_target?: number | null
          current_pnl?: number | null
          custom_order_created?: boolean | null
          custom_order_id?: string | null
          custom_order_price?: number | null
          entry_momentum?: number | null
          entry_price_long?: number | null
          entry_price_short?: number | null
          id?: string
          investment_amount?: number
          is_test?: boolean | null
          leverage?: number
          leverage_long?: number
          leverage_short?: number
          limit_order_created?: boolean | null
          limit_order_id?: string | null
          long_close_pnl?: number | null
          long_closed?: boolean | null
          long_order_id?: string | null
          long_symbol?: string
          profit_target?: number | null
          short_close_pnl?: number | null
          short_closed?: boolean | null
          short_order_id?: string | null
          short_symbol?: string
          started_at?: string | null
          status?: string | null
          trading_mode?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      aurion_ai_conversations: {
        Row: {
          created_at: string
          id: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      aurion_ai_instructions: {
        Row: {
          content: string
          created_at: string
          id: string
          is_active: boolean
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          is_active?: boolean
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          is_active?: boolean
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      aurion_ai_messages: {
        Row: {
          content: string
          conversation_id: string
          created_at: string
          id: string
          role: string
          user_id: string
        }
        Insert: {
          content: string
          conversation_id: string
          created_at?: string
          id?: string
          role: string
          user_id: string
        }
        Update: {
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "aurion_ai_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "aurion_ai_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      aurion_simulated_trades: {
        Row: {
          chandelier_exit_price: number | null
          created_at: string
          entry_price: number
          entry_time: number
          exit_price: number | null
          exit_time: number | null
          id: string
          investment_amount: number | null
          pnl_percent: number | null
          pnl_usd: number | null
          status: string
          token_data: Json
          trade_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          chandelier_exit_price?: number | null
          created_at?: string
          entry_price: number
          entry_time: number
          exit_price?: number | null
          exit_time?: number | null
          id?: string
          investment_amount?: number | null
          pnl_percent?: number | null
          pnl_usd?: number | null
          status?: string
          token_data: Json
          trade_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          chandelier_exit_price?: number | null
          created_at?: string
          entry_price?: number
          entry_time?: number
          exit_price?: number | null
          exit_time?: number | null
          id?: string
          investment_amount?: number | null
          pnl_percent?: number | null
          pnl_usd?: number | null
          status?: string
          token_data?: Json
          trade_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      binance_credentials: {
        Row: {
          api_key: string
          api_secret: string
          created_at: string | null
          id: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          api_key: string
          api_secret: string
          created_at?: string | null
          id?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          api_key?: string
          api_secret?: string
          created_at?: string | null
          id?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      credit_transactions: {
        Row: {
          amount_paid: number
          created_at: string
          credits: number
          id: string
          order_id: string | null
          payment_method: string
          reference_id: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount_paid: number
          created_at?: string
          credits: number
          id?: string
          order_id?: string | null
          payment_method?: string
          reference_id?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount_paid?: number
          created_at?: string
          credits?: number
          id?: string
          order_id?: string | null
          payment_method?: string
          reference_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      momentum_history: {
        Row: {
          created_at: string
          id: string
          long_symbol: string
          momentum: number
          short_symbol: string
          timestamp: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          long_symbol: string
          momentum: number
          short_symbol: string
          timestamp: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          long_symbol?: string
          momentum?: number
          short_symbol?: string
          timestamp?: string
          user_id?: string
        }
        Relationships: []
      }
      profit_totals: {
        Row: {
          created_at: string
          id: string
          last_reset_at: string
          total_profit: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          last_reset_at?: string
          total_profit?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          last_reset_at?: string
          total_profit?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      trade_history: {
        Row: {
          created_at: string | null
          duration_seconds: number
          ended_at: string | null
          id: string
          investment_amount: number
          is_test: boolean | null
          leverage: number
          leverage_long: number
          leverage_short: number
          long_symbol: string
          profit: number
          short_symbol: string
          started_at: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          duration_seconds: number
          ended_at?: string | null
          id?: string
          investment_amount: number
          is_test?: boolean | null
          leverage: number
          leverage_long: number
          leverage_short: number
          long_symbol: string
          profit: number
          short_symbol: string
          started_at: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          duration_seconds?: number
          ended_at?: string | null
          id?: string
          investment_amount?: number
          is_test?: boolean | null
          leverage?: number
          leverage_long?: number
          leverage_short?: number
          long_symbol?: string
          profit?: number
          short_symbol?: string
          started_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_credits: {
        Row: {
          created_at: string
          credits: number
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          credits?: number
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          credits?: number
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_trading_settings: {
        Row: {
          auto_close_enabled: boolean
          created_at: string
          id: string
          investment_amount: number
          leverage: number
          profit_target: number
          updated_at: string
          user_id: string
        }
        Insert: {
          auto_close_enabled?: boolean
          created_at?: string
          id?: string
          investment_amount?: number
          leverage?: number
          profit_target?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          auto_close_enabled?: boolean
          created_at?: string
          id?: string
          investment_amount?: number
          leverage?: number
          profit_target?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
