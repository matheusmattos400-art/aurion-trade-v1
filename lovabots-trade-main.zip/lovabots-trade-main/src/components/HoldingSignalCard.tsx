import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Eye, Loader2, Sparkles, CheckCircle, AlertCircle } from "lucide-react";
import { HoldingSignal } from "@/hooks/useHoldingScanner";

interface HoldingSignalCardProps {
  signal: HoldingSignal;
  onShowDetails: (signal: HoldingSignal) => void;
  onOpenTrade: (signal: HoldingSignal, isTest: boolean) => void;
  isLoading: boolean;
  disabled: boolean;
}

export const HoldingSignalCard = ({
  signal,
  onShowDetails,
  onOpenTrade,
  isLoading,
  disabled,
}: HoldingSignalCardProps) => {
  const isLong = signal.direction === "LONG";

  const getQualityStyle = () => {
    switch (signal.quality) {
      case "Excelente":
        return {
          bg: "bg-green-500/20",
          border: "border-green-500/40",
          text: "text-green-400",
          icon: <Sparkles className="h-3 w-3" />,
        };
      case "Bom":
        return {
          bg: "bg-blue-500/20",
          border: "border-blue-500/40",
          text: "text-blue-400",
          icon: <CheckCircle className="h-3 w-3" />,
        };
      default:
        return {
          bg: "bg-amber-500/20",
          border: "border-amber-500/40",
          text: "text-amber-400",
          icon: <AlertCircle className="h-3 w-3" />,
        };
    }
  };

  const qualityStyle = getQualityStyle();

  const getConditionBadge = (condition: string, isFavorable: boolean) => {
    if (isFavorable || condition === "Favorável" || condition === "Forte") {
      return <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/30 text-xs">{condition}</Badge>;
    }
    if (condition === "Moderado" || condition === "Neutro") {
      return <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/30 text-xs">{condition}</Badge>;
    }
    return <Badge variant="outline" className="bg-muted/20 text-muted-foreground border-border/30 text-xs">{condition}</Badge>;
  };

  return (
    <Card className="relative overflow-hidden bg-card/60 border-border/40 hover:border-primary/40 transition-all">
      {/* Quality indicator */}
      <div className="absolute top-0 right-0">
        <div className={`px-3 py-1 rounded-bl-lg text-xs font-bold border flex items-center gap-1 ${qualityStyle.bg} ${qualityStyle.border} ${qualityStyle.text}`}>
          {qualityStyle.icon}
          {signal.quality}
        </div>
      </div>

      <div className="p-4 pt-8">
        {/* Symbol + Direction */}
        <div className="flex items-center gap-3 mb-3">
          <div className={`p-2 rounded-lg ${isLong ? "bg-green-500/10" : "bg-red-500/10"}`}>
            {isLong ? (
              <TrendingUp className="h-5 w-5 text-green-500" />
            ) : (
              <TrendingDown className="h-5 w-5 text-red-500" />
            )}
          </div>
          <div>
            <h3 className="font-bold text-lg">{signal.symbol.replace("USDT", "")}</h3>
            <span className={`text-sm font-medium ${isLong ? "text-green-500" : "text-red-500"}`}>
              {isLong ? "COMPRAR" : "VENDER"}
            </span>
          </div>
          <div className="ml-auto text-right">
            <p className="text-xs text-muted-foreground">Preço Atual</p>
            <p className="font-mono font-bold">${signal.currentPrice.toFixed(4)}</p>
          </div>
        </div>

        {/* Indicators - Descriptive */}
        <div className="grid grid-cols-3 gap-2 mb-3 text-xs">
          <div className="text-center p-2 bg-muted/20 rounded">
            <p className="text-muted-foreground mb-1">Tendência</p>
            <p className={signal.chandelierTrend === "LONG" ? "text-green-400 font-bold" : "text-red-400 font-bold"}>
              {signal.chandelierTrend === "LONG" ? "Alta" : "Baixa"}
            </p>
          </div>
          <div className="text-center p-2 bg-muted/20 rounded">
            <p className="text-muted-foreground mb-1">Momentum</p>
            {getConditionBadge(signal.adxMomentum, signal.adxMomentum === "Forte")}
          </div>
          <div className="text-center p-2 bg-muted/20 rounded">
            <p className="text-muted-foreground mb-1">RSI</p>
            {getConditionBadge(signal.rsiCondition, signal.rsiCondition === "Favorável")}
          </div>
        </div>

        {/* DI info */}
        <div className="flex justify-center mb-3 text-xs">
          {getConditionBadge(`Direção: ${signal.diAlignment}`, signal.diAlignment === "Favorável")}
        </div>

        {/* Reason */}
        <p className="text-xs text-muted-foreground mb-4 text-center italic">
          {signal.signalReason}
        </p>

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => onShowDetails(signal)}
          >
            <Eye className="h-4 w-4 mr-1" />
            Ver Gráfico
          </Button>
          <Button
            size="sm"
            className={`flex-1 ${isLong ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"}`}
            onClick={() => onOpenTrade(signal, false)}
            disabled={isLoading || disabled}
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                {isLong ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
                Operar
              </>
            )}
          </Button>
        </div>
      </div>
    </Card>
  );
};
