import { useState, useEffect, useRef, useCallback } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useUserControlledAutoScroll } from "@/hooks/useUserControlledAutoScroll";
import { 
  Send, 
  RefreshCw, 
  Radar,
  TrendingUp,
  TrendingDown,
  Shield,
  Clock,
  Target,
  Loader2,
  Zap,
  BarChart3
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { AurionToken } from "@/hooks/useAurionScanner";
import {
  isAIGatewayTemporarilyDisabled,
  disableAIGatewayForMinutes,
  getAIGatewayUserMessage,
  shouldToastPaymentRequiredOnce,
} from "@/utils/aiCreditsGuard";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface AurionRadarChatProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  token: AurionToken | null;
}

// Estratégia Radar: Análise técnica + momentum + early gems
const RADAR_STRATEGY_PROMPT = `
Você é um ANALISTA SÊNIOR ESPECIALISTA EM MEMECOINS RECÉM-LANÇADAS, com mais de 10 anos de experiência em trading de criptomoedas e especialização em tokens da rede Solana.

## SUA IDENTIDADE
- Nome: Aurion Radar Analyst
- Especialidade: Detecção de EARLY GEMS entre 30min e 4h de idade
- Abordagem: Análise técnica rigorosa + avaliação de momentum + investigação de segurança

## CRITÉRIOS DE ANÁLISE RADAR

### 1. MOMENTUM SCORE (0-100)
- Razão Buyers/Sellers: >2x = Excelente, 1.5x = Bom, <1x = Ruim
- Volume relativo: Alto volume vs Market Cap = força compradora
- Crescimento de holders: Rápido = orgânico, Lento = desinteresse

### 2. ANÁLISE TÉCNICA
- Chandelier Exit: LONG = tendência de alta confirmada
- ADX: >25 = tendência forte, <20 = lateralizado
- RSI: <40 = oversold (oportunidade), >70 = sobrecomprado

### 3. SEGURANÇA BÁSICA
- Score >= 80 = Excelente
- Mint Authority, Freeze Authority, LP Status

### 4. TIMING
- 30min-1h: Muito cedo, alto risco/recompensa
- 1h-2h: Janela ideal se momentum forte
- 2h-4h: Mais seguro, mas menor upside

### 5. ANÁLISE DO DEV (quando disponível)
- Histórico de transações
- Carteiras associadas
- Padrão de comportamento

### 6. REDES SOCIAIS (INFORMATIVO)
- Analise os links fornecidos
- Red flags: contas novas, poucos seguidores
- NOTA: Análise social é APENAS INFORMATIVA, não exclui tokens automaticamente

## FORMATO DE RESPOSTA

📊 **RADAR SCAN: [SYMBOL]**

**📜 CONTRATO:** \`[CA completo]\`

**🎯 MOMENTUM SCORE: [X]/100**
- Buyers vs Sellers: [análise]
- Volume/MC Ratio: [análise]

**📈 ANÁLISE TÉCNICA**
- Chandelier: [LONG/SHORT]
- ADX: [valor] - [interpretação]
- RSI: [valor] - [interpretação]

**🔒 SEGURANÇA: [Score]/100**
[Resumo dos pilares]

**👨‍💻 ANÁLISE DO DEV:**
[Se disponível: histórico, comportamento, red flags]

**🌐 REDES SOCIAIS:**
[Avaliação dos links - INFORMATIVO APENAS]

**⏱️ TIMING: [idade]**
[Análise da janela de entrada]

**🚨 VEREDITO: [MONITORAR / ENTRADA AGRESSIVA / AGUARDAR / EVITAR]**
[Explicação curta e direta]

**💡 ESTRATÉGIA SUGERIDA:**
- Entry: [condição]
- Take Profit: [alvo %]
- Stop Loss: [nível %]

---
Responda em português brasileiro. Seja direto, técnico e profissional.
`;

interface HeliusRawData {
  tokenMint: string;
  collectedAt: string;
  block0: {
    creationSlot: number | null;
    creationTime: string | null;
    wallets: string[];
    transactionCount: number;
    totalTransactionsAnalyzed: number;
  };
  holders: {
    count: number;
    topAccounts: { address: string; balance: number }[];
  };
  devWallet: null | {
    address: string;
    inferred?: boolean;
    transactionCount: number;
    transactions: any[];
  };
  _meta?: Record<string, any>;
}

export function AurionRadarChat({
  open,
  onOpenChange,
  token
}: AurionRadarChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const [heliusData, setHeliusData] = useState<HeliusRawData | null>(null);
  const { scrollContainerRef, lastItemRef, onScroll } = useUserControlledAutoScroll<HTMLDivElement>([
    messages,
  ]);
  const hasInitialized = useRef(false);

  const isSolanaAddress = (addr: string) => /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(addr);

  const collectHeliusData = async (): Promise<HeliusRawData | null> => {
    if (!token?.tokenAddress || !isSolanaAddress(token.tokenAddress)) return null;

    try {
      console.log("[RadarChat] Collecting Helius data for:", token.tokenAddress);

      const { data, error } = await supabase.functions.invoke("pump-fun-data-collector", {
        body: {
          tokenMint: token.tokenAddress,
          includeHolders: true,
          includeDevHistory: true,
        },
      });

      if (error) {
        console.error("[RadarChat] Error collecting Helius data:", error);
        return null;
      }

      const raw = data as HeliusRawData | undefined;
      if (!raw?.block0?.wallets || !raw?.holders?.topAccounts) {
        console.warn("[RadarChat] Unexpected collector payload:", data);
        return null;
      }

      console.log("[RadarChat] Helius data received:", {
        block0Wallets: raw.block0.wallets.length,
        topHolders: raw.holders.topAccounts.length,
        devWallet: raw.devWallet?.address || null,
      });

      return raw;
    } catch (err) {
      console.error("[RadarChat] Error calling pump-fun-data-collector:", err);
      return null;
    }
  };

  // Auto-scroll behavior is user-controlled (see hook).

  // Start analysis when chat opens
  useEffect(() => {
    if (open && token && !hasInitialized.current) {
      hasInitialized.current = true;
      initializeRadarChat();
    }
  }, [open, token]);

  // Reset when closed
  useEffect(() => {
    if (!open) {
      hasInitialized.current = false;
      setMessages([]);
      setHeliusData(null);
    }
  }, [open]);

  const initializeRadarChat = async () => {
    if (!token) return;

    // Check circuit breaker first
    if (isAIGatewayTemporarilyDisabled()) {
      setMessages([{
        role: "assistant",
        content: `⚠️ ${getAIGatewayUserMessage(402)}`,
        timestamp: new Date()
      }]);
      return;
    }

    setIsInitializing(true);

    // Add welcome message
    setMessages([
      {
        role: "assistant",
        content: `🔍 **Iniciando Radar Scan para ${token.symbol}...**\n\n⏳ Coletando dados do contrato, Dev e indicadores técnicos...`,
        timestamp: new Date()
      }
    ]);

    try {
      // Collect Helius data for Solana tokens
      let rawData: HeliusRawData | null = null;
      if (token.tokenAddress && isSolanaAddress(token.tokenAddress)) {
        rawData = await collectHeliusData();
        setHeliusData(rawData);
      }

      // Prepare token data for analysis
      const tokenContext = buildTokenContext(token, rawData);

      // Call AI for initial analysis
      const { data, error } = await supabase.functions.invoke("aurion-ai-chat", {
        body: {
          messages: [
            {
              role: "system",
              content: RADAR_STRATEGY_PROMPT
            },
            {
              role: "user",
              content: `Analise este token para a estratégia RADAR:\n\n${tokenContext}\n\nForneça seu RADAR SCAN completo.`
            }
          ]
        }
      });

      if (error) {
        const errMsg = error.message || "";
        if (errMsg.includes("402") || errMsg.toLowerCase().includes("payment")) {
          disableAIGatewayForMinutes(10);
          if (shouldToastPaymentRequiredOnce()) {
            toast.error(getAIGatewayUserMessage(402));
          }
          throw new Error(getAIGatewayUserMessage(402));
        }
        throw error;
      }

      const aiResponse = data?.response || data?.content || "Erro ao processar análise.";

      setMessages(prev => [
        ...prev.slice(0, -1), // Remove loading message
        {
          role: "assistant",
          content: aiResponse,
          timestamp: new Date()
        }
      ]);
    } catch (err) {
      console.error("[RadarChat] Error:", err);
      const errMsg = err instanceof Error ? err.message : "Erro desconhecido";
      setMessages(prev => [
        ...prev.slice(0, -1),
        {
          role: "assistant",
          content: errMsg.includes("credits") || errMsg.includes("Payment")
            ? `⚠️ ${errMsg}`
            : "❌ Erro ao realizar análise. Tente novamente.",
          timestamp: new Date()
        }
      ]);
      if (!errMsg.includes("credits") && !errMsg.includes("Payment")) {
        toast.error("Erro ao iniciar análise Radar");
      }
    } finally {
      setIsInitializing(false);
    }
  };

  const buildTokenContext = (t: AurionToken, helius: HeliusRawData | null): string => {
    const ageMinutes = Math.round(t.ageHours * 60);
    const ageFormatted = ageMinutes < 60 
      ? `${ageMinutes}min` 
      : `${Math.round(t.ageHours)}h`;

    // Build social links section
    const socialLinks: string[] = [];
    if ((t as any).twitter) socialLinks.push(`Twitter: ${(t as any).twitter}`);
    if ((t as any).telegram) socialLinks.push(`Telegram: ${(t as any).telegram}`);
    if ((t as any).website) socialLinks.push(`Website: ${(t as any).website}`);
    if ((t as any).discord) socialLinks.push(`Discord: ${(t as any).discord}`);
    
    const socialLinksText = socialLinks.length > 0 
      ? socialLinks.join('\n') 
      : 'Nenhum link social encontrado';

    // Build dev info section
    let devInfoText = 'Dados do Dev não disponíveis';
    if (helius?.devWallet) {
      devInfoText = `
- **Endereço:** ${helius.devWallet.address}
- **Inferido:** ${helius.devWallet.inferred ? 'Sim' : 'Não'}
- **Total de Transações:** ${helius.devWallet.transactionCount}
`;
    }

    return `
## DADOS DO TOKEN
- **Nome:** ${t.name}
- **Símbolo:** ${t.symbol}
- **Contrato (CA):** ${t.tokenAddress || 'N/D'}
- **Chain:** ${t.chainId}
- **Idade:** ${ageFormatted}

## PREÇO & VOLUME
- **Preço USD:** $${t.priceUsd.toFixed(8)}
- **Variação 24h:** ${t.priceChange24h.toFixed(2)}%
- **Market Cap:** $${(t.marketCap || 0).toLocaleString()}
- **Liquidez:** $${t.liquidity.toLocaleString()}
- **Volume 24h:** $${t.volume24h.toLocaleString()}

## MOMENTUM (1h)
- **Compras:** ${t.buys1h}
- **Vendas:** ${t.sells1h}
- **Ratio B/S:** ${t.sells1h > 0 ? (t.buys1h / t.sells1h).toFixed(2) : 'N/A'}x

## MOMENTUM (24h)
- **Compras:** ${t.buys24h}
- **Vendas:** ${t.sells24h}
- **Ratio B/S:** ${t.sells24h > 0 ? (t.buys24h / t.sells24h).toFixed(2) : 'N/A'}x

## INDICADORES TÉCNICOS
- **Chandelier Exit:** ${t.chandelierSignal || 'N/A'}
- **ADX:** ${t.adxSignal ? `${t.adxSignal.adx.toFixed(1)} (DI+: ${t.adxSignal.plusDI.toFixed(1)}, DI-: ${t.adxSignal.minusDI.toFixed(1)})` : 'N/A'}
- **RSI:** ${t.rsiSignal ? t.rsiSignal.toFixed(1) : 'N/A'}
- **Status Técnico:** ${t.technicalStatus}

## SEGURANÇA
- **Security Score:** ${t.securityScore}/100
- **Mint Authority:** ${t.isMintable ? '⚠️ ATIVO' : '✅ Renunciado'}
- **Freeze Authority:** ${t.hasBlacklist ? '⚠️ ATIVO' : '✅ Renunciado'}
- **LP Status:** ${t.lpLocked ? '✅ Locked/Burned' : '⚠️ Não verificado'}
- **Aurion Confirmed:** ${t.aurionConfirmed ? 'SIM' : 'NÃO'}

## INFORMAÇÕES DO DEV
${devInfoText}

## REDES SOCIAIS (INFORMATIVO APENAS)
${socialLinksText}

## LINKS ÚTEIS
- **DexScreener:** ${t.url}
`.trim();
  };

  const sendMessage = async () => {
    if (!userInput.trim() || isLoading || !token) return;

    const userMessage = userInput.trim();
    setUserInput("");
    setIsLoading(true);

    // Add user message
    setMessages(prev => [
      ...prev,
      { role: "user", content: userMessage, timestamp: new Date() }
    ]);

    try {
      const tokenContext = buildTokenContext(token, heliusData);

      // Build conversation history
      const conversationHistory = messages.map(m => ({
        role: m.role as "user" | "assistant",
        content: m.content
      }));

      const { data, error } = await supabase.functions.invoke("aurion-ai-chat", {
        body: {
          messages: [
            {
              role: "system",
              content: RADAR_STRATEGY_PROMPT + `\n\n## CONTEXTO DO TOKEN ATUAL:\n${tokenContext}`
            },
            ...conversationHistory,
            {
              role: "user",
              content: userMessage
            }
          ]
        }
      });

      if (error) throw error;

      const aiResponse = data?.response || data?.content || "Erro ao processar.";

      setMessages(prev => [
        ...prev,
        { role: "assistant", content: aiResponse, timestamp: new Date() }
      ]);
    } catch (err) {
      console.error("[RadarChat] Send error:", err);
      toast.error("Erro ao enviar mensagem");
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleRefresh = () => {
    hasInitialized.current = false;
    setMessages([]);
    setHeliusData(null);
    initializeRadarChat();
  };

  if (!token) return null;

  const isPositive = token.priceChange24h >= 0;
  const buyersWinning = token.buys1h > token.sells1h;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent 
        side="bottom" 
        className="h-[90vh] sm:h-auto sm:max-h-[90vh] bg-background/95 backdrop-blur-xl border-t sm:border-l border-cyan-500/30 rounded-t-2xl sm:rounded-none flex flex-col"
      >
        <SheetHeader className="border-b border-cyan-500/20 pb-3 sm:pb-4 shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Radar className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-400" />
              <SheetTitle className="text-base sm:text-lg">Radar Analyst</SheetTitle>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleRefresh}
              disabled={isInitializing || isLoading}
              className="text-cyan-400 hover:text-cyan-300 h-8 w-8 sm:h-9 sm:w-9"
            >
              <RefreshCw className={`w-4 h-4 ${isInitializing ? 'animate-spin' : ''}`} />
            </Button>
          </div>

          {/* Token Info */}
          <div className="flex items-center gap-2 sm:gap-3 mt-2 sm:mt-3">
            {token.imageUrl ? (
              <img 
                src={token.imageUrl} 
                alt={token.symbol}
                className="w-8 h-8 sm:w-10 sm:h-10 rounded-full"
              />
            ) : (
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
                <span className="text-cyan-400 font-bold text-sm sm:text-base">{token.symbol.slice(0, 2)}</span>
              </div>
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm sm:text-base truncate">{token.symbol}</span>
                <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-[10px] sm:text-xs shrink-0">
                  Radar
                </Badge>
              </div>
              <div className="flex items-center gap-2 sm:gap-3 text-[10px] sm:text-xs text-muted-foreground">
                <span className={isPositive ? 'text-profit' : 'text-loss'}>
                  {isPositive ? '+' : ''}{token.priceChange24h.toFixed(2)}%
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {token.ageHours < 1 
                    ? `${Math.round(token.ageHours * 60)}m`
                    : `${Math.round(token.ageHours)}h`
                  }
                </span>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-1.5 sm:gap-2 mt-2 sm:mt-3">
            <div className="p-1.5 sm:p-2 rounded-lg bg-card/50 border border-border/50 text-center">
              <div className="text-[10px] sm:text-xs text-muted-foreground">Score</div>
              <div className={`font-bold text-sm sm:text-base ${token.securityScore >= 80 ? 'text-green-400' : 'text-yellow-400'}`}>
                {token.securityScore}
              </div>
            </div>
            <div className="p-1.5 sm:p-2 rounded-lg bg-card/50 border border-border/50 text-center">
              <div className="text-[10px] sm:text-xs text-muted-foreground">B/S</div>
              <div className={`font-bold text-sm sm:text-base flex items-center justify-center gap-1 ${buyersWinning ? 'text-profit' : 'text-loss'}`}>
                {buyersWinning ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {token.sells1h > 0 ? (token.buys1h / token.sells1h).toFixed(1) : '∞'}x
              </div>
            </div>
            <div className="p-1.5 sm:p-2 rounded-lg bg-card/50 border border-border/50 text-center">
              <div className="text-[10px] sm:text-xs text-muted-foreground">Chandelier</div>
              <div className={`font-bold text-[10px] sm:text-xs ${token.chandelierSignal === 'LONG' ? 'text-profit' : token.chandelierSignal === 'SHORT' ? 'text-loss' : 'text-muted-foreground'}`}>
                {token.chandelierSignal || 'N/A'}
              </div>
            </div>
          </div>
        </SheetHeader>

        {/* Messages */}
        <div
          ref={scrollContainerRef}
          onScroll={onScroll}
          className="flex-1 min-h-0 mt-2 sm:mt-4 pr-2 sm:pr-4 overflow-y-auto"
        >
          <div className="space-y-3 sm:space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] sm:max-w-[90%] p-2 sm:p-3 rounded-lg text-xs sm:text-sm whitespace-pre-wrap ${
                    msg.role === "user"
                      ? "bg-cyan-500/20 text-cyan-100 border border-cyan-500/30"
                      : "bg-card/80 border border-border/50"
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-card/80 border border-border/50 p-2 sm:p-3 rounded-lg">
                  <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                </div>
              </div>
            )}
            <div ref={lastItemRef} />
          </div>
        </div>

        {/* Quick Questions */}
        <div className="flex flex-wrap gap-1.5 sm:gap-2 mt-2 sm:mt-4 mb-2 sm:mb-3 shrink-0">
          {[
            "Momento ideal para entrar?",
            "Qual stop loss usar?",
            "Sinais de alerta?",
            "Comparar com mercado"
          ].map((q, i) => (
            <Button
              key={i}
              variant="outline"
              size="sm"
              className="text-[10px] sm:text-xs h-7 sm:h-8 px-2 sm:px-3 border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/10"
              onClick={() => {
                setUserInput(q);
                setTimeout(() => sendMessage(), 100);
              }}
              disabled={isLoading || isInitializing}
            >
              {q}
            </Button>
          ))}
        </div>

        {/* Input */}
        <div className="flex gap-2 pt-2 border-t border-border/50 shrink-0">
          <Input
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="Pergunte sobre o token..."
            disabled={isLoading || isInitializing}
            className="flex-1 h-9 sm:h-10 text-sm bg-card/50 border-cyan-500/30 focus:border-cyan-400"
          />
          <Button
            onClick={sendMessage}
            disabled={!userInput.trim() || isLoading || isInitializing}
            className="h-9 sm:h-10 w-9 sm:w-10 p-0 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border border-cyan-500/30"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
