import { useState, useEffect, type ComponentType } from "react";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerFooter,
  DrawerClose,
} from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Sparkles,
  Shield,
  ShieldAlert,
  TrendingUp,
  TrendingDown,
  Target,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Loader2,
  BarChart3,
  Lock,
  Users,
  Twitter,
  Globe,
  MessageCircle,
  ExternalLink,
  X,
  Skull,
  Eye,
  Activity,
  PieChart,
  UserX,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { AurionToken } from "@/hooks/useAurionScanner";
import { toast } from "sonner";

interface AurionAIAnalysisDrawerProps {
  token: AurionToken | null;
  isOpen: boolean;
  onClose: () => void;
  onBuy?: (token: AurionToken) => void;
}

interface ForensicAnalysis {
  suspiciousVolume: boolean;
  suspiciousVolumeReason: string;
  distributionDetected: boolean;
  distributionReason: string;
  top10Selling: boolean;
  top10SellingReason: string;
  creatorRisk: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  creatorRiskReason: string;
  dangerDistribution: boolean;
}

interface SocialAnalysis {
  hasTwitter: boolean;
  twitterUrl: string | null;
  hasWebsite: boolean;
  websiteUrl: string | null;
  hasTelegram: boolean;
  telegramUrl: string | null;
  hasDiscord: boolean;
  discordUrl: string | null;
  socialScore: number;
  socialRisk: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  socialRiskReason: string;
  totalSocials: number;
}

const SocialItem = ({
  icon: Icon,
  label,
  hasItem,
  url,
}: {
  icon: ComponentType<{ className?: string }>;
  label: string;
  hasItem: boolean;
  url: string | null;
}) => {
  return (
    <div
      className={`flex items-center justify-between p-3 rounded-lg border ${
        hasItem
          ? "bg-emerald-500/10 border-emerald-500/30"
          : "bg-red-500/10 border-red-500/30"
      }`}
    >
      <div className="flex items-center gap-2">
        <Icon className={`w-4 h-4 ${hasItem ? "text-emerald-400" : "text-red-400"}`} />
        <span className={`text-sm font-medium ${hasItem ? "text-emerald-300" : "text-red-300"}`}>{label}</span>
      </div>

      {hasItem && url ? (
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1 text-xs text-primary hover:underline"
        >
          <ExternalLink className="w-3 h-3" />
          Abrir
        </a>
      ) : (
        <span className="text-xs text-muted-foreground">Não encontrado</span>
      )}
    </div>
  );
};

interface AnalysisResult {
  verdict: string;
  score: number;
  tradeProfile: string;
  buyReason: string;
  analysis: string;
  forensicAnalysis?: ForensicAnalysis;
}

interface PreCalculated {
  volumeToLiquidityRatio: number;
  isGoldenRatio: boolean;
  isEliteLiquidity: boolean;
  isProjectElite: boolean;
  isPotentialCTO: boolean;
  isWashTrading: boolean;
  finalScore: number;
  dangerDistribution?: boolean;
  forensicAnalysis?: ForensicAnalysis;
}


export const AurionAIAnalysisDrawer = ({
  token,
  isOpen,
  onClose,
  onBuy,
}: AurionAIAnalysisDrawerProps) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [preCalculated, setPreCalculated] = useState<PreCalculated | null>(null);
  const [socialAnalysis, setSocialAnalysis] = useState<SocialAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Reset state when token changes or drawer opens
  useEffect(() => {
    if (isOpen && token) {
      setResult(null);
      setPreCalculated(null);
      setSocialAnalysis(null);
      setError(null);
      analyzeToken();
    }
  }, [isOpen, token?.id]);

  const analyzeToken = async () => {
    if (!token) return;

    setIsAnalyzing(true);
    setError(null);
    setSocialAnalysis(null);

    try {
      // Get current user for strategy context injection
      const { data: { user } } = await supabase.auth.getUser();

      // Use the same conversation the user is chatting in (stored by AurionAIChatPanel)
      const conversationId = localStorage.getItem("aurion_ai_active_conversation_id") || undefined;

      // Call backend function with LIVE pairAddress; it will fetch LIVE data + apply chat directives
      const { data, error: fnError } = await supabase.functions.invoke(
        "aurion-gemini-analysis",
        {
          body: {
            token: {
              pairAddress: token.pairAddress,
              chainId: token.chainId || "solana",
              symbol: token.symbol, // For logging only
            },
            userId: user?.id,
            conversationId,
          },
        },
      );

      if (fnError) {
        throw new Error(fnError.message);
      }

      if (data?.error) {
        throw new Error(data.error);
      }

      // Update result with live data from backend function
      setResult(data.result);
      setPreCalculated(data.preCalculated);
      setSocialAnalysis(data.liveData?.socialAnalysis || null);

      // Show live data source indicator
      if (data.dataSource === "LIVE_DEXSCREENER") {
        toast.success(`Dados ao vivo: ${data.liveData?.symbol} | $${data.liveData?.priceUsd?.toFixed(6)}`);
      }
    } catch (err) {
      console.error("Error analyzing token:", err);
      const errorMessage = err instanceof Error ? err.message : "Erro ao analisar token";
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getVerdictStyle = (verdict: string) => {
    switch (verdict) {
      case "PERIGO: DISTRIBUIÇÃO":
        return "bg-gradient-to-r from-red-600 to-red-800 text-white animate-pulse";
      case "OPORTUNIDADE IMEDIATA":
        return "bg-gradient-to-r from-amber-500 to-yellow-500 text-black";
      case "ALTA CONVICÇÃO":
        return "bg-gradient-to-r from-emerald-500 to-green-500 text-white";
      case "PROJETO DE ELITE":
        return "bg-gradient-to-r from-purple-500 to-violet-500 text-white";
      case "ENTRADA PROFISSIONAL":
        return "bg-gradient-to-r from-blue-500 to-cyan-500 text-white";
      case "POTENCIAL CTO":
        return "bg-gradient-to-r from-orange-500 to-red-500 text-white";
      case "IGNORE":
        return "bg-destructive text-destructive-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getScoreColor = (score: number) => {
    if (score === 0) return "text-red-500";
    if (score >= 85) return "text-emerald-400";
    if (score >= 70) return "text-green-400";
    if (score >= 50) return "text-yellow-400";
    return "text-red-400";
  };

  const getScoreLabel = (score: number) => {
    if (score === 0) return "⛔ PERIGO";
    if (score >= 85) return "Excelente";
    if (score >= 70) return "Bom";
    if (score >= 50) return "Moderado";
    return "Alto Risco";
  };

  const formatNumber = (num: number) => {
    if (num >= 1_000_000) return `$${(num / 1_000_000).toFixed(2)}M`;
    if (num >= 1_000) return `$${(num / 1_000).toFixed(2)}K`;
    return `$${num.toFixed(2)}`;
  };

  const getCreatorRiskColor = (risk: string) => {
    switch (risk) {
      case "CRITICAL": return "bg-red-500/20 text-red-400 border-red-500/30";
      case "HIGH": return "bg-orange-500/20 text-orange-400 border-orange-500/30";
      case "MEDIUM": return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
      default: return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
    }
  };

  const forensic = result?.forensicAnalysis || preCalculated?.forensicAnalysis;
  const isDanger = preCalculated?.dangerDistribution || result?.verdict === "PERIGO: DISTRIBUIÇÃO";

  return (
    <Drawer open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DrawerContent className={`max-h-[90vh] ${isDanger ? 'border-red-500/50' : ''}`}>
        <div className="mx-auto w-full max-w-lg">
          <DrawerHeader className="relative">
            <DrawerClose className="absolute right-4 top-4">
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <X className="h-4 w-4" />
              </Button>
            </DrawerClose>
            
            <div className="flex items-center gap-3">
              {token?.imageUrl ? (
                <img
                  src={token.imageUrl}
                  alt={token?.symbol}
                  className={`w-12 h-12 rounded-full bg-muted ${isDanger ? 'ring-2 ring-red-500 animate-pulse' : ''}`}
                />
              ) : (
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${isDanger ? 'bg-red-500/20' : 'bg-primary/20'}`}>
                  {isDanger ? <Skull className="w-6 h-6 text-red-500" /> : <Sparkles className="w-6 h-6 text-primary" />}
                </div>
              )}
              <div>
                <DrawerTitle className="flex items-center gap-2">
                  <span>Análise Aurion AI</span>
                  <Badge variant="outline" className={isDanger ? "bg-red-500/20 text-red-400 border-red-500/30" : "bg-purple-500/20 text-purple-400 border-purple-500/30"}>
                    {isDanger ? <ShieldAlert className="w-3 h-3 mr-1" /> : <Sparkles className="w-3 h-3 mr-1" />}
                    {isDanger ? "FORENSE" : "Gemini"}
                  </Badge>
                </DrawerTitle>
                <DrawerDescription>
                  {token?.symbol} • {token?.name}
                </DrawerDescription>
              </div>
            </div>
          </DrawerHeader>

          <div className="px-4 pb-4 space-y-4 overflow-y-auto max-h-[60vh]">
            {/* Loading State */}
            {isAnalyzing && (
              <div className="flex flex-col items-center justify-center py-12 space-y-4">
                <div className="relative">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 animate-pulse" />
                  <Loader2 className="w-8 h-8 text-white absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-spin" />
                </div>
                <p className="text-sm text-muted-foreground animate-pulse">
                  Executando análise forense em tempo real...
                </p>
                <div className="w-48">
                  <Progress value={undefined} className="h-1" />
                </div>
              </div>
            )}

            {/* Error State */}
            {error && !isAnalyzing && (
              <Card className="p-4 bg-destructive/10 border-destructive/30">
                <div className="flex items-center gap-2 text-destructive">
                  <XCircle className="w-5 h-5" />
                  <span className="font-medium">{error}</span>
                </div>
                <Button
                  onClick={analyzeToken}
                  variant="outline"
                  className="mt-3 w-full"
                >
                  Tentar Novamente
                </Button>
              </Card>
            )}

            {/* Results */}
            {result && !isAnalyzing && (
              <>
                {/* DANGER ALERT */}
                {isDanger && (
                  <Card className="p-4 bg-red-500/10 border-red-500/50 animate-pulse">
                    <div className="flex items-center gap-3">
                      <Skull className="w-8 h-8 text-red-500" />
                      <div>
                        <h3 className="font-bold text-red-500">⛔ TRAVA DE SEGURANÇA ATIVADA</h3>
                        <p className="text-sm text-red-400">
                          {(token?.liquidity || 0) < 5000 
                            ? `Liquidez crítica: ${formatNumber(token?.liquidity || 0)} (< $5.000)`
                            : `Queda de ${Math.abs(token?.priceChange5m || 0).toFixed(1)}% em 5 minutos`}
                        </p>
                      </div>
                    </div>
                  </Card>
                )}

                {/* Risk Score */}
                <Card className={`p-4 space-y-3 ${isDanger ? 'border-red-500/30' : ''}`}>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Score de Risco Forense</span>
                    <span className={`text-2xl font-bold ${getScoreColor(result.score)}`}>
                      {result.score}/100
                    </span>
                  </div>
                  <Progress value={result.score} className={`h-2 ${isDanger ? '[&>div]:bg-red-500' : ''}`} />
                  <div className="flex items-center justify-between text-xs">
                    <span className={getScoreColor(result.score)}>
                      {getScoreLabel(result.score)}
                    </span>
                    {preCalculated?.volumeToLiquidityRatio && (
                      <span className="text-muted-foreground">
                        Vol/Liq: {preCalculated.volumeToLiquidityRatio.toFixed(2)}x
                      </span>
                    )}
                  </div>
                </Card>

                {/* Verdict Badge */}
                <div className="flex justify-center">
                  <Badge className={`text-sm px-4 py-2 ${getVerdictStyle(result.verdict)}`}>
                    {result.verdict === "PERIGO: DISTRIBUIÇÃO" && <Skull className="w-4 h-4 mr-2" />}
                    {result.verdict}
                  </Badge>
                </div>

                {/* FORENSIC ANALYSIS - 4 NEW FIELDS */}
                {forensic && (
                  <Card className="p-4 space-y-3 bg-gradient-to-br from-slate-900/50 to-slate-800/50 border-slate-700/50">
                    <h4 className="font-semibold flex items-center gap-2 text-amber-400">
                      <Eye className="w-4 h-4" />
                      Análise Forense em Tempo Real
                    </h4>
                    
                    <div className="space-y-2">
                      {/* 1. Suspicious Volume */}
                      <div className={`p-3 rounded-lg border ${forensic.suspiciousVolume ? 'bg-red-500/10 border-red-500/30' : 'bg-emerald-500/10 border-emerald-500/30'}`}>
                        <div className="flex items-center gap-2 mb-1">
                          <Activity className={`w-4 h-4 ${forensic.suspiciousVolume ? 'text-red-400' : 'text-emerald-400'}`} />
                          <span className="font-medium text-sm">Volume Suspeito</span>
                          <Badge variant="outline" className={`ml-auto text-[10px] ${forensic.suspiciousVolume ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
                            {forensic.suspiciousVolume ? '⚠️ DETECTADO' : '✅ NORMAL'}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">{forensic.suspiciousVolumeReason}</p>
                      </div>

                      {/* 2. Distribution Detected */}
                      <div className={`p-3 rounded-lg border ${forensic.distributionDetected ? 'bg-red-500/10 border-red-500/30' : 'bg-emerald-500/10 border-emerald-500/30'}`}>
                        <div className="flex items-center gap-2 mb-1">
                          <TrendingDown className={`w-4 h-4 ${forensic.distributionDetected ? 'text-red-400' : 'text-emerald-400'}`} />
                          <span className="font-medium text-sm">Distribuição Detectada</span>
                          <Badge variant="outline" className={`ml-auto text-[10px] ${forensic.distributionDetected ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
                            {forensic.distributionDetected ? '🚨 DUMP' : '✅ EQUILIBRADO'}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">{forensic.distributionReason}</p>
                      </div>

                      {/* 3. Top 10 Selling */}
                      <div className={`p-3 rounded-lg border ${forensic.top10Selling ? 'bg-red-500/10 border-red-500/30' : 'bg-emerald-500/10 border-emerald-500/30'}`}>
                        <div className="flex items-center gap-2 mb-1">
                          <PieChart className={`w-4 h-4 ${forensic.top10Selling ? 'text-red-400' : 'text-emerald-400'}`} />
                          <span className="font-medium text-sm">Venda das Top 10</span>
                          <Badge variant="outline" className={`ml-auto text-[10px] ${forensic.top10Selling ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
                            {forensic.top10Selling ? '⚠️ SAINDO' : '✅ SEGURO'}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">{forensic.top10SellingReason}</p>
                      </div>

                      {/* 4. Creator Participation */}
                      <div className={`p-3 rounded-lg border ${getCreatorRiskColor(forensic.creatorRisk)}`}>
                        <div className="flex items-center gap-2 mb-1">
                          <UserX className={`w-4 h-4 ${forensic.creatorRisk === 'LOW' ? 'text-emerald-400' : forensic.creatorRisk === 'MEDIUM' ? 'text-yellow-400' : forensic.creatorRisk === 'HIGH' ? 'text-orange-400' : 'text-red-400'}`} />
                          <span className="font-medium text-sm">Participação do Criador</span>
                          <Badge variant="outline" className={`ml-auto text-[10px] ${getCreatorRiskColor(forensic.creatorRisk)}`}>
                            {forensic.creatorRisk}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">{forensic.creatorRiskReason}</p>
                      </div>
                    </div>
                  </Card>
                )}

                {/* Redes Sociais em Tempo Real */}
                {socialAnalysis && (
                  <Card className="p-4 space-y-3 bg-gradient-to-br from-slate-900/50 to-slate-800/50 border-slate-700/50">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-cyan-400" />
                      <h4 className="font-semibold">Redes Sociais em Tempo Real</h4>
                      <Badge
                        variant="outline"
                        className={`ml-auto text-[10px] ${
                          socialAnalysis.socialRisk === "LOW"
                            ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                            : socialAnalysis.socialRisk === "MEDIUM"
                              ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                              : socialAnalysis.socialRisk === "HIGH"
                                ? "bg-orange-500/20 text-orange-400 border-orange-500/30"
                                : "bg-red-500/20 text-red-400 border-red-500/30"
                        }`}
                      >
                        Score: {socialAnalysis.socialScore}/100
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <SocialItem
                        icon={Twitter}
                        label="Twitter/X"
                        hasItem={socialAnalysis.hasTwitter}
                        url={socialAnalysis.twitterUrl}
                      />
                      <SocialItem
                        icon={Globe}
                        label="Website"
                        hasItem={socialAnalysis.hasWebsite}
                        url={socialAnalysis.websiteUrl}
                      />
                      <SocialItem
                        icon={MessageCircle}
                        label="Telegram"
                        hasItem={socialAnalysis.hasTelegram}
                        url={socialAnalysis.telegramUrl}
                      />
                      <SocialItem
                        icon={Users}
                        label="Discord"
                        hasItem={socialAnalysis.hasDiscord}
                        url={socialAnalysis.discordUrl}
                      />
                    </div>

                    <div
                      className={`p-3 rounded-lg border ${
                        socialAnalysis.socialRisk === "LOW"
                          ? "bg-emerald-500/10 border-emerald-500/30"
                          : socialAnalysis.socialRisk === "MEDIUM"
                            ? "bg-yellow-500/10 border-yellow-500/30"
                            : socialAnalysis.socialRisk === "HIGH"
                              ? "bg-orange-500/10 border-orange-500/30"
                              : "bg-red-500/10 border-red-500/30"
                      }`}
                    >
                      <p className="text-xs text-muted-foreground">{socialAnalysis.socialRiskReason}</p>
                      <p className="text-[10px] text-muted-foreground mt-1">
                        {socialAnalysis.totalSocials} de 4 redes sociais encontradas
                      </p>
                    </div>
                  </Card>
                )}

                {/* Security Verification */}
                <Card className="p-4 space-y-3">
                  <h4 className="font-semibold flex items-center gap-2">
                    <Shield className="w-4 h-4 text-primary" />
                    Veredito Técnico
                  </h4>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className={`flex flex-col items-center gap-1 p-2 rounded-lg ${
                      !token?.isMintable 
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                        : 'bg-red-500/20 text-red-400 border border-red-500/30'
                    }`}>
                      {!token?.isMintable ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                      <span>Mint</span>
                      <span className="font-medium">{!token?.isMintable ? 'Revogado' : 'Ativo'}</span>
                    </div>
                    <div className={`flex flex-col items-center gap-1 p-2 rounded-lg ${
                      !token?.hasBlacklist 
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                        : 'bg-red-500/20 text-red-400 border border-red-500/30'
                    }`}>
                      {!token?.hasBlacklist ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                      <span>Freeze</span>
                      <span className="font-medium">{!token?.hasBlacklist ? 'Seguro' : 'Ativo'}</span>
                    </div>
                    <div className={`flex flex-col items-center gap-1 p-2 rounded-lg ${
                      token?.lpLocked 
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                        : 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                    }`}>
                      {token?.lpLocked ? <Lock className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                      <span>LP</span>
                      <span className="font-medium">{token?.lpLocked ? 'Travada' : 'Solta'}</span>
                    </div>
                  </div>
                </Card>

                {/* Token Metrics */}
                <Card className="p-4 space-y-3">
                  <h4 className="font-semibold flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-primary" />
                    Métricas em Tempo Real
                  </h4>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${(token?.liquidity || 0) < 5000 ? 'bg-red-500 animate-pulse' : 'bg-blue-400'}`} />
                      <span className="text-muted-foreground">Liquidez:</span>
                      <span className={`font-medium ${(token?.liquidity || 0) < 5000 ? 'text-red-400' : ''}`}>
                        {formatNumber(token?.liquidity || 0)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-purple-400" />
                      <span className="text-muted-foreground">Volume:</span>
                      <span className="font-medium">{formatNumber(token?.volume24h || 0)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <TrendingUp className={`w-4 h-4 ${(token?.priceChange5m || 0) < -15 ? 'text-red-400' : 'text-emerald-400'}`} />
                      <span className="text-muted-foreground">Δ 5min:</span>
                      <span className={`font-medium ${(token?.priceChange5m || 0) < -15 ? 'text-red-400' : (token?.priceChange5m || 0) > 0 ? 'text-emerald-400' : 'text-yellow-400'}`}>
                        {(token?.priceChange5m || 0).toFixed(2)}%
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-cyan-400" />
                      <span className="text-muted-foreground">Compras/Vendas:</span>
                      <span className="font-medium">{token?.buys1h || 0}/{token?.sells1h || 0}</span>
                    </div>
                  </div>
                  
                  {/* Pre-calculated flags */}
                  {preCalculated && (
                    <div className="flex flex-wrap gap-1.5 pt-2 border-t border-border/50">
                      {preCalculated.dangerDistribution && (
                        <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-[10px] animate-pulse">
                          ⛔ DISTRIBUIÇÃO
                        </Badge>
                      )}
                      {preCalculated.isWashTrading && (
                        <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-[10px]">
                          ⚠️ Wash Trading
                        </Badge>
                      )}
                      {preCalculated.isGoldenRatio && !preCalculated.dangerDistribution && (
                        <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-[10px]">
                          Golden Ratio
                        </Badge>
                      )}
                      {preCalculated.isEliteLiquidity && !preCalculated.dangerDistribution && (
                        <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30 text-[10px]">
                          Elite Liquidity
                        </Badge>
                      )}
                      {preCalculated.isProjectElite && !preCalculated.dangerDistribution && (
                        <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-[10px]">
                          Projeto Elite
                        </Badge>
                      )}
                      {preCalculated.isPotentialCTO && !preCalculated.dangerDistribution && (
                        <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30 text-[10px]">
                          Potencial CTO
                        </Badge>
                      )}
                    </div>
                  )}
                </Card>

                {/* Trade Plan */}
                <Card className={`p-4 space-y-3 ${isDanger ? 'bg-red-500/5 border-red-500/30' : 'bg-gradient-to-br from-primary/5 to-purple-500/5 border-primary/30'}`}>
                  <h4 className="font-semibold flex items-center gap-2">
                    <Target className={`w-4 h-4 ${isDanger ? 'text-red-400' : 'text-primary'}`} />
                    {isDanger ? 'Análise de Risco' : 'Plano de Trade'}
                  </h4>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Badge variant="outline" className="text-xs">Perfil</Badge>
                      <span className={`font-medium ${isDanger ? 'text-red-400' : ''}`}>{result.tradeProfile}</span>
                    </div>
                    
                    <div className="text-sm text-muted-foreground">
                      <strong className={isDanger ? 'text-red-400' : 'text-foreground'}>
                        {isDanger ? 'Razão do Alerta:' : 'Motivo de Entrada:'}
                      </strong>
                      <p className="mt-1">{result.buyReason}</p>
                    </div>
                    
                    <div className="text-sm text-muted-foreground pt-2 border-t border-border/50">
                      <strong className="text-foreground">Análise Detalhada:</strong>
                      <p className="mt-1 leading-relaxed">{result.analysis}</p>
                    </div>
                  </div>
                </Card>
              </>
            )}
          </div>

          <DrawerFooter>
            {result && !isAnalyzing && !isDanger && result.verdict !== "IGNORE" && onBuy && token && (
              <Button
                onClick={() => {
                  onBuy(token);
                  onClose();
                }}
                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700"
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Executar Trade
              </Button>
            )}
            {isDanger && (
              <Button
                variant="destructive"
                onClick={onClose}
                className="w-full"
              >
                <Skull className="w-4 h-4 mr-2" />
                Evitar Este Token
              </Button>
            )}
            <Button variant="outline" onClick={onClose}>
              Fechar
            </Button>
          </DrawerFooter>
        </div>
      </DrawerContent>
    </Drawer>
  );
};
