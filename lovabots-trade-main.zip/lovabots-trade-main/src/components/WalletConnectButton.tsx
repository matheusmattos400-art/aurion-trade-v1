import { memo } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Wallet, LogOut, Copy, ExternalLink, AlertTriangle, Loader2 } from "lucide-react";
import { useWalletConnection } from "@/hooks/useWalletConnection";
import { toast } from "sonner";

export const WalletConnectButton = memo(() => {
  const {
    isConnected,
    address,
    chainId,
    balance,
    isConnecting,
    hasMetaMask,
    connectWallet,
    disconnectWallet,
    getChainName,
  } = useWalletConnection();

  const isMobile = typeof window !== "undefined" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

  const openMetaMaskOrDownload = () => {
    if (isMobile) {
      // Mobile browsers don't have extensions; open the dApp inside the MetaMask app browser
      const dappUrl = window.location.href.replace(/^https?:\/\//, "");
      window.location.href = `https://metamask.app.link/dapp/${dappUrl}`;
      return;
    }

    // Desktop: guide to install the extension
    window.open("https://metamask.io/download/", "_blank");
  };

  const copyAddress = () => {
    if (address) {
      navigator.clipboard.writeText(address);
      toast.success("Endereço copiado!");
    }
  };

  const openExplorer = () => {
    if (!address || !chainId) return;
    
    const explorers: Record<number, string> = {
      1: "https://etherscan.io/address/",
      56: "https://bscscan.com/address/",
      137: "https://polygonscan.com/address/",
      42161: "https://arbiscan.io/address/",
      10: "https://optimistic.etherscan.io/address/",
      8453: "https://basescan.org/address/",
      43114: "https://snowtrace.io/address/",
    };
    
    const baseUrl = explorers[chainId] || "https://etherscan.io/address/";
    window.open(`${baseUrl}${address}`, "_blank");
  };

  if (!hasMetaMask) {
    return (
      <Button 
        variant="outline" 
        size="sm" 
        className="border-yellow-500/50 text-yellow-500 hover:bg-yellow-500/10"
        onClick={openMetaMaskOrDownload}
      >
        <AlertTriangle className="w-4 h-4 mr-1" />
        {isMobile ? (
          <span>Abrir no MetaMask</span>
        ) : (
          <>
            <span className="hidden sm:inline">Instalar MetaMask</span>
            <span className="sm:hidden">MetaMask</span>
          </>
        )}
      </Button>
    );
  }

  if (!isConnected) {
    return (
      <Button 
        onClick={connectWallet} 
        disabled={isConnecting}
        size="sm"
        className="gradient-button"
      >
        {isConnecting ? (
          <Loader2 className="w-4 h-4 animate-spin mr-1" />
        ) : (
          <Wallet className="w-4 h-4 mr-1" />
        )}
        <span className="hidden sm:inline">{isConnecting ? "Conectando..." : "Conectar Carteira"}</span>
        <span className="sm:hidden">{isConnecting ? "..." : "Wallet"}</span>
      </Button>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="border-green-500/50 text-green-500 hover:bg-green-500/10">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse mr-2" />
          <span className="font-mono text-xs">
            {address?.slice(0, 6)}...{address?.slice(-4)}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium">Carteira Conectada</p>
            <p className="text-xs text-muted-foreground font-mono">
              {address?.slice(0, 10)}...{address?.slice(-8)}
            </p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        <div className="px-2 py-1.5 space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs text-muted-foreground">Rede:</span>
            <Badge variant="outline" className="text-xs">
              {getChainName(chainId)}
            </Badge>
          </div>
          {balance && (
            <div className="flex justify-between items-center">
              <span className="text-xs text-muted-foreground">Saldo:</span>
              <span className="text-xs font-mono">
                {parseFloat(balance).toFixed(4)} ETH
              </span>
            </div>
          )}
        </div>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={copyAddress}>
          <Copy className="w-4 h-4 mr-2" />
          Copiar Endereço
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={openExplorer}>
          <ExternalLink className="w-4 h-4 mr-2" />
          Ver no Explorer
        </DropdownMenuItem>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={disconnectWallet} className="text-destructive focus:text-destructive">
          <LogOut className="w-4 h-4 mr-2" />
          Desconectar
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
});

WalletConnectButton.displayName = "WalletConnectButton";
