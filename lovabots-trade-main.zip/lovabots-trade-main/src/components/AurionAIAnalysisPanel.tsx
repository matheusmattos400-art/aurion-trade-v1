import React, { memo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Brain,
  Shield,
  ShieldAlert,
  ShieldCheck,
  ShieldX,
  TrendingUp,
  TrendingDown,
  Minus,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock,
  Target,
  Zap,
  RefreshCw,
  ExternalLink,
  Twitter,
  Globe,
  MessageCircle,
  Users,
} from "lucide-react";
import type { AIAnalysisResult, ForensicItem, SocialAnalysis } from "@/hooks/useAurionAIAnalysis";

interface AurionAIAnalysisPanelProps {
  result: AIAnalysisResult | null;
  isAnalyzing: boolean;
  error: string | null;
  onRefresh?: () => void;
  onExecuteTrade?: () => void;
  onAvoidToken?: () => void;
}

// Componente para exibir status forense individual
const ForensicItemDisplay = memo(({ label, item }: { label: string; item: ForensicItem }) => {
  const getStatusIcon = () => {
    switch (item.status) {
      case "SAFE":
        return <ShieldCheck className="w-4 h-4 text-green-500" />;
      case "WARNING":
        return <ShieldAlert className="w-4 h-4 text-yellow-500" />;
      case "DANGER":
        return <ShieldX className="w-4 h-4 text-red-500" />;
    }
  };

  const getStatusColor = () => {
    switch (item.status) {
      case "SAFE":
        return "bg-green-500/10 border-green-500/30 text-green-400";
      case "WARNING":
        return "bg-yellow-500/10 border-yellow-500/30 text-yellow-400";
      case "DANGER":
        return "bg-red-500/10 border-red-500/30 text-red-400";
    }
  };

  return (
    <div className={`p-3 rounded-lg border ${getStatusColor()}`}>
      <div className="flex items-center gap-2 mb-1">
        {getStatusIcon()}
        <span className="font-medium text-sm">{label}</span>
      </div>
      <p className="text-xs opacity-80">{item.detail}</p>
    </div>
  );
});

ForensicItemDisplay.displayName = "ForensicItemDisplay";

// Componente para exibir análise de redes sociais
const SocialItem = memo(({ 
  icon: Icon, 
  label, 
  hasItem, 
  url 
}: { 
  icon: React.ComponentType<{ className?: string }>; 
  label: string; 
  hasItem: boolean; 
  url: string | null;
}) => {
  return (
    <div className={`flex items-center justify-between p-2 rounded-lg ${
      hasItem ? "bg-green-500/10 border border-green-500/30" : "bg-red-500/10 border border-red-500/30"
    }`}>
      <div className="flex items-center gap-2">
        <Icon className={`w-4 h-4 ${hasItem ? "text-green-500" : "text-red-500"}`} />
        <span className={`text-sm ${hasItem ? "text-green-400" : "text-red-400"}`}>{label}</span>
      </div>
      {hasItem && url ? (
        <a 
          href={url} 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center gap-1 text-xs text-primary hover:underline"
        >
          <ExternalLink className="w-3 h-3" />
          Abrir
        </a>
      ) : (
        <span className="text-xs text-muted-foreground">
          {hasItem ? "✓" : "Não encontrado"}
        </span>
      )}
    </div>
  );
});

SocialItem.displayName = "SocialItem";

// Componente principal
export const AurionAIAnalysisPanel = memo(({
  result,
  isAnalyzing,
  error,
  onRefresh,
  onExecuteTrade,
  onAvoidToken,
}: AurionAIAnalysisPanelProps) => {
  
  // Estado de loading
  if (isAnalyzing) {
    return (
      <Card className="bg-card/50 border-primary/20">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Brain className="w-12 h-12 text-primary animate-pulse mb-4" />
          <p className="text-lg font-medium">Aurion AI analisando...</p>
          <p className="text-sm text-muted-foreground mt-2">
            Verificando segurança, liquidez e indicadores técnicos
          </p>
        </CardContent>
      </Card>
    );
  }

  // Estado de erro
  if (error) {
    return (
      <Card className="bg-destructive/10 border-destructive/30">
        <CardContent className="flex flex-col items-center justify-center py-8">
          <XCircle className="w-10 h-10 text-destructive mb-3" />
          <p className="text-destructive font-medium">Erro na análise</p>
          <p className="text-sm text-muted-foreground mt-1">{error}</p>
          {onRefresh && (
            <Button variant="outline" size="sm" className="mt-4" onClick={onRefresh}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Tentar novamente
            </Button>
          )}
        </CardContent>
      </Card>
    );
  }

  // Sem resultado ainda
  if (!result) {
    return (
      <Card className="bg-card/50 border-border">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Brain className="w-10 h-10 text-muted-foreground mb-3" />
          <p className="text-muted-foreground">
            Clique em "Aurion AI" para iniciar a análise
          </p>
        </CardContent>
      </Card>
    );
  }

  // Helpers para estilização baseada no veredito da IA
  const getVerdictStyle = () => {
    switch (result.verdict) {
      case "APROVADO":
        return "bg-green-500 text-white";
      case "APROVADO_COM_RESSALVAS":
        return "bg-emerald-500 text-white";
      case "NEUTRO":
        return "bg-yellow-500 text-black";
      case "REPROVADO":
        return "bg-orange-500 text-white";
      case "PERIGOSO":
        return "bg-red-500 text-white";
      case "SCAM_CONFIRMADO":
        return "bg-red-700 text-white animate-pulse";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const getVerdictLabel = () => {
    switch (result.verdict) {
      case "APROVADO":
        return "✅ APROVADO";
      case "APROVADO_COM_RESSALVAS":
        return "⚠️ APROVADO COM RESSALVAS";
      case "NEUTRO":
        return "🔶 NEUTRO";
      case "REPROVADO":
        return "❌ REPROVADO";
      case "PERIGOSO":
        return "🚨 PERIGOSO";
      case "SCAM_CONFIRMADO":
        return "💀 SCAM CONFIRMADO";
      default:
        return result.verdict;
    }
  };

  const getScoreColor = () => {
    if (result.score >= 80) return "text-green-500";
    if (result.score >= 60) return "text-emerald-500";
    if (result.score >= 40) return "text-yellow-500";
    if (result.score >= 20) return "text-orange-500";
    return "text-red-500";
  };

  const getTrendIcon = () => {
    switch (result.technicalAnalysis.trend) {
      case "BULLISH":
        return <TrendingUp className="w-5 h-5 text-green-500" />;
      case "BEARISH":
        return <TrendingDown className="w-5 h-5 text-red-500" />;
      default:
        return <Minus className="w-5 h-5 text-yellow-500" />;
    }
  };

  const getProfileBadge = () => {
    switch (result.tradeProfile) {
      case "SCALP":
        return <Badge className="bg-purple-500">⚡ SCALP</Badge>;
      case "SWING":
        return <Badge className="bg-blue-500">📊 SWING</Badge>;
      case "HOLD":
        return <Badge className="bg-green-500">💎 HOLD</Badge>;
      case "NAO_OPERAR":
        return <Badge variant="destructive">🚫 NÃO OPERAR</Badge>;
    }
  };

  return (
    <ScrollArea className="h-[600px]">
      <div className="space-y-4 pr-4">
        {/* Header com Score e Veredito - DEFINIDO PELA IA */}
        <Card className="bg-gradient-to-br from-card to-card/50 border-primary/20">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-full bg-primary/20">
                  <Brain className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">{result.tokenInfo.symbol}</h3>
                  <p className="text-sm text-muted-foreground">{result.tokenInfo.name}</p>
                </div>
              </div>
              <Badge variant="outline" className="text-xs">
                <Clock className="w-3 h-3 mr-1" />
                {new Date(result.analyzedAt).toLocaleTimeString("pt-BR")}
              </Badge>
            </div>

            {/* Score e Veredito da IA */}
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="text-center p-4 rounded-lg bg-background/50">
                <p className="text-xs text-muted-foreground mb-1">Score de Risco</p>
                <p className={`text-4xl font-bold ${getScoreColor()}`}>
                  {result.score}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Confiança: {result.confidence}%
                </p>
              </div>
              <div className="text-center p-4 rounded-lg bg-background/50">
                <p className="text-xs text-muted-foreground mb-1">Veredito</p>
                <Badge className={`text-sm px-3 py-1 ${getVerdictStyle()}`}>
                  {getVerdictLabel()}
                </Badge>
                <div className="mt-2">
                  {getProfileBadge()}
                </div>
              </div>
            </div>

            {/* Resumo da IA */}
            <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
              <p className="text-sm">{result.summary}</p>
            </div>
          </CardContent>
        </Card>

        {/* Análise Forense - DEFINIDA PELA IA */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Análise Forense
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-3">
            <ForensicItemDisplay label="Mint Authority" item={result.forensicAnalysis.mintAuthority} />
            <ForensicItemDisplay label="Freeze Authority" item={result.forensicAnalysis.freezeAuthority} />
            <ForensicItemDisplay label="Status LP" item={result.forensicAnalysis.lpStatus} />
            <ForensicItemDisplay label="Histórico Criador" item={result.forensicAnalysis.creatorHistory} />
            <ForensicItemDisplay label="Liquidez" item={result.forensicAnalysis.liquidityAnalysis} />
            <ForensicItemDisplay label="Distribuição" item={result.forensicAnalysis.holderDistribution} />
          </CardContent>
        </Card>

        {/* Análise de Redes Sociais em Tempo Real - NOVO */}
        {result.forensicAnalysis.socialAnalysis && (
          <Card className="border-primary/30 bg-gradient-to-br from-card to-primary/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                Redes Sociais em Tempo Real
                <Badge 
                  variant="outline" 
                  className={`ml-auto text-xs ${
                    result.forensicAnalysis.socialAnalysis.socialRisk === "LOW" 
                      ? "bg-green-500/20 text-green-400 border-green-500/30"
                      : result.forensicAnalysis.socialAnalysis.socialRisk === "MEDIUM"
                        ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                        : result.forensicAnalysis.socialAnalysis.socialRisk === "HIGH"
                          ? "bg-orange-500/20 text-orange-400 border-orange-500/30"
                          : "bg-red-500/20 text-red-400 border-red-500/30"
                  }`}
                >
                  Score: {result.forensicAnalysis.socialAnalysis.socialScore}/100
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Grid de redes sociais */}
              <div className="grid grid-cols-2 gap-2">
                <SocialItem 
                  icon={Twitter} 
                  label="Twitter/X" 
                  hasItem={result.forensicAnalysis.socialAnalysis.hasTwitter}
                  url={result.forensicAnalysis.socialAnalysis.twitterUrl}
                />
                <SocialItem 
                  icon={Globe} 
                  label="Website" 
                  hasItem={result.forensicAnalysis.socialAnalysis.hasWebsite}
                  url={result.forensicAnalysis.socialAnalysis.websiteUrl}
                />
                <SocialItem 
                  icon={MessageCircle} 
                  label="Telegram" 
                  hasItem={result.forensicAnalysis.socialAnalysis.hasTelegram}
                  url={result.forensicAnalysis.socialAnalysis.telegramUrl}
                />
                <SocialItem 
                  icon={Users} 
                  label="Discord" 
                  hasItem={result.forensicAnalysis.socialAnalysis.hasDiscord}
                  url={result.forensicAnalysis.socialAnalysis.discordUrl}
                />
              </div>

              {/* Resumo do risco */}
              <div className={`p-3 rounded-lg border ${
                result.forensicAnalysis.socialAnalysis.socialRisk === "LOW" 
                  ? "bg-green-500/10 border-green-500/30"
                  : result.forensicAnalysis.socialAnalysis.socialRisk === "MEDIUM"
                    ? "bg-yellow-500/10 border-yellow-500/30"
                    : result.forensicAnalysis.socialAnalysis.socialRisk === "HIGH"
                      ? "bg-orange-500/10 border-orange-500/30"
                      : "bg-red-500/10 border-red-500/30"
              }`}>
                <p className="text-sm">{result.forensicAnalysis.socialAnalysis.socialRiskReason}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {result.forensicAnalysis.socialAnalysis.totalSocials} de 4 redes sociais encontradas
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Análise Técnica - DEFINIDA PELA IA */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              {getTrendIcon()}
              Análise Técnica
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 mb-3">
              <Badge variant="outline">
                Tendência: {result.technicalAnalysis.trend}
              </Badge>
              <Badge variant="outline">
                Força: {result.technicalAnalysis.strength}
              </Badge>
              <Badge variant="outline">
                Entrada: {result.technicalAnalysis.entryZone}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">{result.technicalAnalysis.detail}</p>
          </CardContent>
        </Card>

        {/* Plano de Trade - DEFINIDO PELA IA */}
        {result.tradePlan && (
          <Card className="border-primary/30">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                Plano de Trade
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-2 rounded bg-green-500/10 border border-green-500/30">
                  <p className="text-xs text-muted-foreground">Entrada</p>
                  <p className="font-medium text-green-400">{result.tradePlan.entry}</p>
                </div>
                <div className="p-2 rounded bg-red-500/10 border border-red-500/30">
                  <p className="text-xs text-muted-foreground">Stop Loss</p>
                  <p className="font-medium text-red-400">{result.tradePlan.stopLoss}</p>
                </div>
                <div className="p-2 rounded bg-blue-500/10 border border-blue-500/30">
                  <p className="text-xs text-muted-foreground">Take Profit 1</p>
                  <p className="font-medium text-blue-400">{result.tradePlan.takeProfit1}</p>
                </div>
                <div className="p-2 rounded bg-purple-500/10 border border-purple-500/30">
                  <p className="text-xs text-muted-foreground">Take Profit 2</p>
                  <p className="font-medium text-purple-400">{result.tradePlan.takeProfit2}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <span className="text-muted-foreground">
                  <Clock className="w-4 h-4 inline mr-1" />
                  {result.tradePlan.timeframe}
                </span>
                <span className="text-muted-foreground">
                  <Zap className="w-4 h-4 inline mr-1" />
                  R/R: {result.tradePlan.riskReward}
                </span>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Alertas e Pontos Positivos - DEFINIDOS PELA IA */}
        <div className="grid grid-cols-2 gap-4">
          {/* Alertas */}
          {result.warnings.length > 0 && (
            <Card className="border-orange-500/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2 text-orange-400">
                  <AlertTriangle className="w-4 h-4" />
                  Alertas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-1">
                  {result.warnings.map((warning, idx) => (
                    <li key={idx} className="text-xs text-orange-300 flex items-start gap-1">
                      <span>•</span>
                      <span>{warning}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Positivos */}
          {result.positives.length > 0 && (
            <Card className="border-green-500/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2 text-green-400">
                  <CheckCircle2 className="w-4 h-4" />
                  Pontos Positivos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-1">
                  {result.positives.map((positive, idx) => (
                    <li key={idx} className="text-xs text-green-300 flex items-start gap-1">
                      <span>•</span>
                      <span>{positive}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Recomendação Final - DEFINIDA PELA IA */}
        <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="pt-4">
            <p className="text-sm font-medium mb-2">📋 Recomendação Final da IA:</p>
            <p className="text-sm text-muted-foreground">{result.finalRecommendation}</p>
          </CardContent>
        </Card>

        {/* Botões de Ação */}
        <div className="flex gap-3">
          {result.verdict === "APROVADO" || result.verdict === "APROVADO_COM_RESSALVAS" ? (
            <Button
              className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
              onClick={onExecuteTrade}
            >
              <Zap className="w-4 h-4 mr-2" />
              Executar Trade
            </Button>
          ) : null}

          {result.verdict === "PERIGOSO" || result.verdict === "SCAM_CONFIRMADO" ? (
            <Button
              variant="destructive"
              className="flex-1"
              onClick={onAvoidToken}
            >
              <XCircle className="w-4 h-4 mr-2" />
              Evitar Este Token
            </Button>
          ) : null}

          {onRefresh && (
            <Button variant="outline" onClick={onRefresh}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Reanalisar
            </Button>
          )}
        </div>

        {/* Footer com informações de fonte de dados */}
        <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground pt-2">
          <Badge variant="outline" className="text-xs">
            <Brain className="w-3 h-3 mr-1" />
            Analisado por Aurion AI
          </Badge>
          {result.dataSource.dexscreener && (
            <Badge variant="outline" className="text-xs">DexScreener ✓</Badge>
          )}
          {result.dataSource.rugcheck && (
            <Badge variant="outline" className="text-xs">RugCheck ✓</Badge>
          )}
        </div>
      </div>
    </ScrollArea>
  );
});

AurionAIAnalysisPanel.displayName = "AurionAIAnalysisPanel";

export default AurionAIAnalysisPanel;
