import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Droplets, AlertTriangle, CheckCircle, TrendingUp, TrendingDown } from "lucide-react";

interface LiquidityAnomalyIndicatorProps {
  longSymbol: string;
  shortSymbol: string;
}

interface LiquidityData {
  symbol: string;
  currentVolume: number;
  avgVolume30m: number;
  ratio: number;
  status: "normal" | "low" | "high";
  trend: "up" | "down" | "stable";
}

export const LiquidityAnomalyIndicator = ({
  longSymbol,
  shortSymbol,
}: LiquidityAnomalyIndicatorProps) => {
  const [longLiquidity, setLongLiquidity] = useState<LiquidityData | null>(null);
  const [shortLiquidity, setShortLiquidity] = useState<LiquidityData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const analyzeLiquidity = (currentVol: number, avgVol: number): { status: "normal" | "low" | "high", trend: "up" | "down" | "stable" } => {
    const ratio = avgVol > 0 ? currentVol / avgVol : 1;
    
    let status: "normal" | "low" | "high";
    let trend: "up" | "down" | "stable";
    
    if (ratio < 0.7) {
      status = "low";
      trend = "down";
    } else if (ratio > 1.5) {
      status = "high";
      trend = "up";
    } else {
      status = "normal";
      trend = "stable";
    }
    
    return { status, trend };
  };

  useEffect(() => {
    const fetchLiquidity = async () => {
      try {
        // Buscar klines de 5 minutos (últimos 7 candles = 35 min para ter média de 30min + atual)
        const [longKlines, shortKlines] = await Promise.all([
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${longSymbol}&interval=5m&limit=7`).then(r => r.json()),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${shortSymbol}&interval=5m&limit=7`).then(r => r.json()),
        ]);

        // Calcular volume médio dos últimos 6 candles (30min) e volume atual
        const calculateVolumes = (klines: any[]) => {
          if (klines.length < 2) return { current: 0, avg: 0 };
          
          const currentVolume = parseFloat(klines[klines.length - 1][7]); // Quote volume do candle atual
          const pastKlines = klines.slice(0, -1); // Todos menos o atual
          const avgVolume = pastKlines.reduce((sum: number, k: any) => sum + parseFloat(k[7]), 0) / pastKlines.length;
          
          return { current: currentVolume, avg: avgVolume };
        };

        const longVols = calculateVolumes(longKlines);
        const shortVols = calculateVolumes(shortKlines);

        const longAnalysis = analyzeLiquidity(longVols.current, longVols.avg);
        const shortAnalysis = analyzeLiquidity(shortVols.current, shortVols.avg);

        const longRatio = longVols.avg > 0 ? longVols.current / longVols.avg : 1;
        const shortRatio = shortVols.avg > 0 ? shortVols.current / shortVols.avg : 1;

        setLongLiquidity({
          symbol: longSymbol,
          currentVolume: longVols.current,
          avgVolume30m: longVols.avg,
          ratio: longRatio,
          status: longAnalysis.status,
          trend: longAnalysis.trend,
        });

        setShortLiquidity({
          symbol: shortSymbol,
          currentVolume: shortVols.current,
          avgVolume30m: shortVols.avg,
          ratio: shortRatio,
          status: shortAnalysis.status,
          trend: shortAnalysis.trend,
        });

        setIsLoading(false);
      } catch (error) {
        console.error("Erro ao buscar liquidez:", error);
        setIsLoading(false);
      }
    };

    fetchLiquidity();
    intervalRef.current = setInterval(fetchLiquidity, 30000); // Atualizar a cada 30 segundos

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [longSymbol, shortSymbol]);

  const getStatusConfig = (status: "normal" | "low" | "high") => {
    switch (status) {
      case "low":
        return {
          label: "Baixa",
          color: "text-amber-400",
          bgGradient: "from-amber-500/20 to-amber-600/10",
          borderColor: "border-amber-500/40",
        };
      case "high":
        return {
          label: "Alta",
          color: "text-blue-400",
          bgGradient: "from-blue-500/20 to-blue-600/10",
          borderColor: "border-blue-500/40",
        };
      default:
        return {
          label: "Normal",
          color: "text-emerald-400",
          bgGradient: "from-emerald-500/20 to-emerald-600/10",
          borderColor: "border-emerald-500/40",
        };
    }
  };

  const formatVolume = (value: number | undefined) => {
    if (value === undefined || value === null || isNaN(value)) return "$0";
    if (value >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
    if (value >= 1e3) return `${(value / 1e3).toFixed(1)}K`;
    return value.toFixed(0);
  };

  // Determinar status geral
  const hasAnomaly = longLiquidity?.status !== "normal" || shortLiquidity?.status !== "normal";

  if (isLoading) {
    return (
      <Card className="p-4 bg-card/40 border-border/30">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Droplets className="h-4 w-4 animate-pulse" />
          <span className="text-sm">Analisando liquidez...</span>
        </div>
      </Card>
    );
  }

  const renderLiquidityBar = (data: LiquidityData, label: string) => {
    const config = getStatusConfig(data.status);
    const percentage = Math.min(data.ratio * 100, 200);
    const barWidth = Math.min(percentage, 100);
    
    return (
      <div className="flex-1">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className={`text-xs font-medium ${label === "LONG" ? "text-emerald-400" : "text-red-400"}`}>
              {label}
            </span>
            <span className="text-xs text-muted-foreground">
              {data.symbol.replace("USDT", "")}
            </span>
          </div>
          <div className="flex items-center gap-1">
            {data.trend === "up" && <TrendingUp className="h-3 w-3 text-blue-400" />}
            {data.trend === "down" && <TrendingDown className="h-3 w-3 text-amber-400" />}
            <span className={`text-xs font-semibold ${config.color}`}>
              {(data.ratio * 100).toFixed(0)}%
            </span>
          </div>
        </div>
        
        {/* Barra de progresso */}
        <div className="relative h-2 bg-muted/30 rounded-full overflow-hidden">
          <div 
            className={`absolute left-0 top-0 h-full rounded-full transition-all duration-500 bg-gradient-to-r ${config.bgGradient}`}
            style={{ width: `${barWidth}%` }}
          />
          {/* Marcador de 100% (média) */}
          <div className="absolute top-0 h-full w-0.5 bg-muted-foreground/50" style={{ left: '50%' }} />
        </div>
        
        <div className="flex justify-between mt-1">
          <span className="text-[10px] text-muted-foreground">
            Atual: ${formatVolume(data.currentVolume)}
          </span>
          <span className="text-[10px] text-muted-foreground">
            Média 30m: ${formatVolume(data.avgVolume30m)}
          </span>
        </div>
      </div>
    );
  };

  return (
    <Card className="p-4 bg-gradient-to-br from-card/60 to-card/40 border-border/30 backdrop-blur-sm">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-primary/10">
            <Droplets className="h-4 w-4 text-primary" />
          </div>
          <span className="text-sm font-medium">Liquidez em Tempo Real</span>
        </div>
        
        <div className={`flex items-center gap-1.5 px-2 py-1 rounded-full text-xs ${
          hasAnomaly 
            ? "bg-amber-500/10 text-amber-400 border border-amber-500/30" 
            : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
        }`}>
          {hasAnomaly ? (
            <>
              <AlertTriangle className="h-3 w-3" />
              Anomalia
            </>
          ) : (
            <>
              <CheckCircle className="h-3 w-3" />
              Normal
            </>
          )}
        </div>
      </div>

      {/* Barras de Liquidez */}
      <div className="space-y-4">
        {longLiquidity && renderLiquidityBar(longLiquidity, "LONG")}
        {shortLiquidity && renderLiquidityBar(shortLiquidity, "SHORT")}
      </div>

      {/* Legenda */}
      <div className="flex justify-center gap-4 mt-4 pt-3 border-t border-border/20">
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-amber-400" />
          <span className="text-[10px] text-muted-foreground">{"<70% Baixa"}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-emerald-400" />
          <span className="text-[10px] text-muted-foreground">70-150% Normal</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-blue-400" />
          <span className="text-[10px] text-muted-foreground">{">150% Alta"}</span>
        </div>
      </div>
    </Card>
  );
};
