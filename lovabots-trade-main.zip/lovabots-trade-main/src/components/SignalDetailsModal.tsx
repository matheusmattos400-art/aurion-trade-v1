import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { 
  TrendingUp, 
  Zap, 
  RotateCcw, 
  Activity,
  BarChart3,
  Clock,
  Droplets,
  FlaskConical,
  ArrowLeftRight,
  CheckCircle2,
  AlertTriangle
} from "lucide-react";
import { TradingSignal } from "@/utils/pairScanner";
import { MomentumIndicator } from "./MomentumIndicator";
import { LiquidityAnomalyIndicator } from "./LiquidityAnomalyIndicator";

interface SignalDetailsModalProps {
  signal: TradingSignal | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenTrade: (signal: TradingSignal, isTest?: boolean) => void;
}

const strategyConfig = {
  micro_distortion: {
    label: "Micro Distorção",
    color: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    icon: Zap,
    description: "Pequena distorção detectada na relação entre os ativos. Oportunidade de reversão rápida.",
  },
  partial_reversal: {
    label: "Reversão",
    color: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    icon: RotateCcw,
    description: "Distorção significativa detectada. Alta probabilidade de reversão para a média.",
  },
  trend_follow: {
    label: "Trend Follow",
    color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
    icon: TrendingUp,
    description: "Momentum alinhado entre os ativos. Seguindo a tendência dominante.",
  },
};

export const SignalDetailsModal = ({ 
  signal, 
  isOpen, 
  onClose, 
  onOpenTrade 
}: SignalDetailsModalProps) => {
  const [isSwapped, setIsSwapped] = useState(false);
  const [showSwapConfirmation, setShowSwapConfirmation] = useState(false);

  // Reset swap state when modal opens with a new signal
  useEffect(() => {
    if (isOpen) {
      setIsSwapped(false);
      setShowSwapConfirmation(false);
    }
  }, [isOpen, signal?.longSymbol, signal?.shortSymbol]);

  // Hide confirmation after 3 seconds
  useEffect(() => {
    if (showSwapConfirmation) {
      const timer = setTimeout(() => setShowSwapConfirmation(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [showSwapConfirmation]);

  if (!signal) return null;

  // Get display symbols based on swap state
  const displayLongSymbol = isSwapped ? signal.shortSymbol : signal.longSymbol;
  const displayShortSymbol = isSwapped ? signal.longSymbol : signal.shortSymbol;

  const handleSwapSides = () => {
    setIsSwapped(!isSwapped);
    setShowSwapConfirmation(true);
  };

  // Create a modified signal for the swap
  const getDisplaySignal = (): TradingSignal => {
    if (!isSwapped) return signal;
    return {
      ...signal,
      longSymbol: signal.shortSymbol,
      shortSymbol: signal.longSymbol,
      currentMomentum: -signal.currentMomentum,
      avgBullish: Math.abs(signal.avgBearish),
      avgBearish: -signal.avgBullish,
    };
  };

  const strategy = strategyConfig[signal.strategy];
  const StrategyIcon = strategy.icon;

  // Helper para formatar correlação com cor
  const formatCorrelation = (value: number) => {
    const percentage = (value * 100).toFixed(1);
    const colorClass = value >= 0.9 ? 'text-emerald-400' : value >= 0.8 ? 'text-amber-400' : 'text-red-400';
    return { percentage, colorClass };
  };

  const corr5d = formatCorrelation(signal.correlation5d || signal.correlation);
  const corr25d = formatCorrelation(signal.correlation25d || signal.correlation);
  const corr2m = formatCorrelation(signal.correlation2m || signal.correlation);

  const displaySignal = getDisplaySignal();

  // Check if momentum tends to be below average (suggests swap)
  const tendsBelow = Math.abs(signal.avgBearish) > signal.avgBullish;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-background/95 backdrop-blur-xl border-border/50">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <Badge variant="outline" className={`${strategy.color} px-3 py-1.5`}>
              <StrategyIcon className="h-4 w-4 mr-2" />
              {strategy.label}
            </Badge>
            <span className="text-muted-foreground">|</span>
            <span className="text-emerald-400">{displayLongSymbol.replace("USDT", "")}</span>
            <span className="text-muted-foreground">/</span>
            <span className="text-red-400">{displayShortSymbol.replace("USDT", "")}</span>
            {isSwapped && (
              <Badge variant="outline" className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-xs">
                Invertido
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>

        {/* Confirmação de troca */}
        {showSwapConfirmation && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-500/20 border border-emerald-500/30 animate-in fade-in slide-in-from-top-2 duration-300">
            <CheckCircle2 className="h-5 w-5 text-emerald-400" />
            <span className="text-sm text-emerald-400 font-medium">
              Lados trocados! Agora: Long {displayLongSymbol.replace("USDT", "")} / Short {displayShortSymbol.replace("USDT", "")}
            </span>
          </div>
        )}

        <div className="space-y-4 mt-4">
          {/* Descrição da Estratégia */}
          <Card className="p-3 bg-muted/20 border-border/50">
            <p className="text-sm text-muted-foreground">{strategy.description}</p>
          </Card>

          {/* Correlação nos 3 períodos */}
          <Card className="p-4 bg-card/50 border-border/50">
            <h3 className="text-sm font-medium text-muted-foreground mb-3 flex items-center gap-2">
              <Activity className="h-4 w-4 text-primary" />
              Correlação por Período
            </h3>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-3 rounded-lg bg-muted/30">
                <span className="text-xs text-muted-foreground block mb-1">5 dias</span>
                <span className={`text-xl font-bold ${corr5d.colorClass}`}>
                  {corr5d.percentage}%
                </span>
              </div>
              <div className="text-center p-3 rounded-lg bg-muted/30">
                <span className="text-xs text-muted-foreground block mb-1">25 dias</span>
                <span className={`text-xl font-bold ${corr25d.colorClass}`}>
                  {corr25d.percentage}%
                </span>
              </div>
              <div className="text-center p-3 rounded-lg bg-muted/30">
                <span className="text-xs text-muted-foreground block mb-1">2 meses</span>
                <span className={`text-xl font-bold ${corr2m.colorClass}`}>
                  {corr2m.percentage}%
                </span>
              </div>
            </div>
          </Card>

          {/* Métricas Principais */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card className="p-3 bg-card/50 border-border/50">
              <div className="flex items-center gap-2 mb-1">
                <BarChart3 className="h-3 w-3 text-primary" />
                <span className="text-xs text-muted-foreground">Z-Score</span>
              </div>
              <span className={`text-xl font-bold ${Math.abs(signal.zScore) >= 2 ? 'text-amber-400' : 'text-foreground'}`}>
                {signal.zScore.toFixed(2)}
              </span>
            </Card>
            
            <Card className="p-3 bg-card/50 border-border/50">
              <div className="flex items-center gap-2 mb-1">
                <Clock className="h-3 w-3 text-primary" />
                <span className="text-xs text-muted-foreground">Idade</span>
              </div>
              <span className="text-xl font-bold">{signal.momentumAge}min</span>
            </Card>
            
            <Card className="p-3 bg-card/50 border-border/50">
              <div className="flex items-center gap-2 mb-1">
                <Droplets className="h-3 w-3 text-primary" />
                <span className="text-xs text-muted-foreground">Liquidez</span>
              </div>
              <span className="text-xl font-bold">{(signal.liquidityRatio * 100).toFixed(0)}%</span>
            </Card>

            <Card className="p-3 bg-card/50 border-border/50">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="h-3 w-3 text-primary" />
                <span className="text-xs text-muted-foreground">Momentum</span>
              </div>
              <span className={`text-xl font-bold ${signal.currentMomentum >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {signal.currentMomentum >= 0 ? '+' : ''}{signal.currentMomentum.toFixed(3)}%
              </span>
            </Card>
          </div>

          {/* Médias de Momentum e Análise de Tendência */}
          <Card className="p-4 bg-card/50 border-border/50">
            <h3 className="text-sm font-medium text-muted-foreground mb-3 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Médias de Momentum
            </h3>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="text-center p-3 rounded-lg bg-muted/30">
                <span className="text-xs text-muted-foreground block mb-1">Média Bullish</span>
                <span className="text-lg font-bold text-emerald-400">+{signal.avgBullish.toFixed(4)}%</span>
              </div>
              <div className="text-center p-3 rounded-lg bg-muted/30">
                <span className="text-xs text-muted-foreground block mb-1">Média Bearish</span>
                <span className="text-lg font-bold text-red-400">{signal.avgBearish.toFixed(4)}%</span>
              </div>
            </div>

            {/* Análise de Tendência do Momentum com Sugestão de Troca */}
            {(() => {
              const tendsAbove = signal.avgBullish > Math.abs(signal.avgBearish);
              
              return (
                <div className="space-y-3">
                  <div className={`p-3 rounded-lg border ${
                    tendsAbove 
                      ? 'bg-emerald-500/10 border-emerald-500/30' 
                      : 'bg-red-500/10 border-red-500/30'
                  }`}>
                    <div className="flex items-center gap-2">
                      <div className={`w-2.5 h-2.5 rounded-full ${tendsAbove ? 'bg-emerald-500' : 'bg-red-500'}`} />
                      <span className="text-sm">
                        Este par tende a ficar mais{' '}
                        <span className={`font-semibold ${tendsAbove ? 'text-emerald-400' : 'text-red-400'}`}>
                          {tendsAbove ? 'acima' : 'abaixo'}
                        </span>
                        {' '}da média no gráfico
                      </span>
                    </div>
                  </div>

                  {/* Sugestão de Troca quando momentum tende a ficar abaixo */}
                  {tendsBelow && !isSwapped && (
                    <div className="p-3 rounded-lg border bg-amber-500/10 border-amber-500/30">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4 text-amber-400" />
                          <span className="text-sm text-amber-300">
                            Momentum tende a ficar abaixo. Considere trocar os lados.
                          </span>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-amber-500/50 text-amber-400 hover:bg-amber-500/20 whitespace-nowrap"
                          onClick={handleSwapSides}
                        >
                          <ArrowLeftRight className="h-3 w-3 mr-1.5" />
                          Trocar Lados
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Botão para trocar de volta ou trocar manualmente */}
                  {isSwapped && (
                    <div className="p-3 rounded-lg border bg-primary/10 border-primary/30">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <ArrowLeftRight className="h-4 w-4 text-primary" />
                          <span className="text-sm">
                            Operando invertido: Long {displayLongSymbol.replace("USDT", "")} / Short {displayShortSymbol.replace("USDT", "")}
                          </span>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-primary/50 text-primary hover:bg-primary/20 whitespace-nowrap"
                          onClick={handleSwapSides}
                        >
                          <RotateCcw className="h-3 w-3 mr-1.5" />
                          Desfazer
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}
          </Card>

          {/* Indicador de Liquidez em Tempo Real */}
          <LiquidityAnomalyIndicator
            longSymbol={displayLongSymbol}
            shortSymbol={displayShortSymbol}
          />

          {/* Gráficos de Momentum e Liquidez - sempre com símbolos originais */}
          <Card className="p-4 bg-card/50 border-border/50 min-h-[350px]">
            <MomentumIndicator
              longSymbol={signal.longSymbol}
              shortSymbol={signal.shortSymbol}
            />
          </Card>

          {/* Ações */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-border/50">
            <Button
              variant="outline"
              className="flex-1"
              onClick={onClose}
            >
              Fechar
            </Button>
            <Button
              variant="outline"
              className="flex-1 border-amber-500/50 text-amber-400 hover:bg-amber-500/10"
              onClick={() => {
                onOpenTrade(displaySignal, true);
                onClose();
              }}
            >
              <FlaskConical className="h-4 w-4 mr-2" />
              Operação Teste
            </Button>
            <Button
              className="flex-1 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
              onClick={() => {
                onOpenTrade(displaySignal, false);
                onClose();
              }}
            >
              <Zap className="h-4 w-4 mr-2" />
              Operação Real
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
