import { useState, useRef, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import {
  Brain,
  RefreshCw,
  TrendingUp,
  Clock,
  Zap,
  Shield,
  Users,
  Ban,
  Target,
  Pause,
  Play,
  Activity,
  BarChart3,
  Crosshair,
  AlertCircle,
  LineChart,
  ShoppingCart,
  ExternalLink,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { AurionToken } from "@/hooks/useAurionScanner";

interface AurionIAPanelProps {
  excellentTokens: AurionToken[];
  onViewChart?: (token: AurionToken) => void;
  onBuy?: (token: AurionToken) => void;
}

interface AnalysisResult {
  symbol: string;
  pairAddress?: string;
  tokenData?: AurionToken;
  verdict: "ALTA CONVICÇÃO" | "PROJETO DE ELITE" | "POTENCIAL CTO" | "IGNORE" | "NEUTRO" | "ENTRADA PROFISSIONAL" | "OPORTUNIDADE IMEDIATA";
  score: number;
  tradeProfile: string;
  buyReason: string;
  analysis: string;
  preCalculated?: {
    volumeToLiquidityRatio: number;
    isGoldenRatio: boolean;
    isEliteLiquidity: boolean;
    isProjectElite: boolean;
    isPotentialCTO: boolean;
    isWashTrading: boolean;
    finalScore: number;
  };
  isImmediateOpportunity?: boolean;
  analysisTimeMs?: number;
}

// HIGH PERFORMANCE MODE
const MAX_QUEUE_SIZE = 20;
const CONCURRENT_REQUESTS = 5;

export const AurionIAPanel = ({ excellentTokens, onViewChart, onBuy }: AurionIAPanelProps) => {
  const [analyses, setAnalyses] = useState<Record<string, AnalysisResult>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentTokens, setCurrentTokens] = useState<string[]>([]);
  const [analyzedCount, setAnalyzedCount] = useState(0);
  const [lastAnalysisTime, setLastAnalysisTime] = useState<Date | null>(null);
  const [queuedTokens, setQueuedTokens] = useState<AurionToken[]>([]);
  const [avgResponseTime, setAvgResponseTime] = useState<number>(0);
  const [totalResponseTimes, setTotalResponseTimes] = useState<number[]>([]);

  const abortRef = useRef(false);
  const pauseRef = useRef(false);

  const filterInstitutionalTokens = useCallback((tokens: AurionToken[]): AurionToken[] => {
    return tokens.filter(token => {
      const ageMinutes = token.ageHours * 60;
      if (ageMinutes < 10) return false;
      if (token.liquidity < 10000) return false;
      if (token.securityScore < 80) return false;
      return true;
    }).sort((a, b) => {
      const aIsImmediate = a.liquidity > 40000 && a.volume24h > 100000;
      const bIsImmediate = b.liquidity > 40000 && b.volume24h > 100000;
      if (aIsImmediate && !bIsImmediate) return -1;
      if (!aIsImmediate && bIsImmediate) return 1;
      const aIsElite = a.liquidity > 100000;
      const bIsElite = b.liquidity > 100000;
      if (aIsElite && !bIsElite) return -1;
      if (!aIsElite && bIsElite) return 1;
      const ratioA = a.volume24h / (a.liquidity || 1);
      const ratioB = b.volume24h / (b.liquidity || 1);
      return ratioB - ratioA;
    }).slice(0, MAX_QUEUE_SIZE);
  }, []);

  const isImmediateOpportunity = (token: AurionToken): boolean => {
    return token.liquidity > 40000 && token.volume24h > 100000;
  };

  const analyzeToken = async (token: AurionToken): Promise<AnalysisResult | null> => {
    const startTime = performance.now();
    
    const tokenData = {
      symbol: token.symbol,
      name: token.name,
      priceUsd: token.priceUsd,
      priceChange1h: token.priceChange1h,
      priceChange24h: token.priceChange24h,
      liquidity: token.liquidity,
      volume24h: token.volume24h,
      marketCap: token.marketCap,
      ageHours: token.ageHours,
      buys1h: token.buys1h,
      sells1h: token.sells1h,
      buys24h: token.buys24h,
      sells24h: token.sells24h,
      securityScore: token.securityScore,
      isMintable: token.isMintable,
      hasBlacklist: token.hasBlacklist,
      lpLocked: token.lpLocked,
      chandelierSignal: token.chandelierSignal,
      adxSignal: token.adxSignal,
      rsiSignal: token.rsiSignal,
      pairAddress: token.pairAddress,
      topHolderPercent: 0,
      devSoldAll: false,
      holdersCount: 0,
      isImmediateOpportunity: isImmediateOpportunity(token),
    };

    const { data: sessionData } = await supabase.auth.getSession();
    const accessToken = sessionData.session?.access_token;

    const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/aurion-gemini-analysis`;
    const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

    const resp = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: publishableKey,
        Authorization: `Bearer ${accessToken ?? publishableKey}`,
      },
      body: JSON.stringify({ token: tokenData }),
    });

    const endTime = performance.now();
    const responseTimeMs = Math.round(endTime - startTime);

    let payload: any = {};
    try {
      payload = await resp.json();
    } catch {
      payload = {};
    }

    if (!resp.ok) {
      throw new Error(payload?.error || `Erro na análise (HTTP ${resp.status})`);
    }

    const result = payload?.result;
    if (result) {
      result.analysisTimeMs = responseTimeMs;
      result.isImmediateOpportunity = isImmediateOpportunity(token);
      
      if (result.isImmediateOpportunity && result.verdict !== "IGNORE") {
        result.verdict = "OPORTUNIDADE IMEDIATA";
        result.score = Math.max(result.score, 90);
      }
    }

    return result || null;
  };

  const processBatch = async (tokens: AurionToken[]): Promise<void> => {
    const promises = tokens.map(async (token) => {
      if (abortRef.current) return null;
      
      while (pauseRef.current) {
        await new Promise(resolve => setTimeout(resolve, 100));
        if (abortRef.current) return null;
      }

      try {
        const result = await analyzeToken(token);
        
        if (result) {
          if (result.analysisTimeMs) {
            setTotalResponseTimes(prev => {
              const newTimes = [...prev, result.analysisTimeMs!];
              const avg = newTimes.reduce((a, b) => a + b, 0) / newTimes.length;
              setAvgResponseTime(Math.round(avg));
              return newTimes;
            });
          }

          if (result.score >= 80 && result.verdict !== "IGNORE") {
            // Store token reference along with analysis result
            result.pairAddress = token.pairAddress;
            result.tokenData = token;
            setAnalyses(prev => ({
              ...prev,
              [token.symbol]: result
            }));
          }
        }

        setAnalyzedCount(prev => prev + 1);
        return result;
      } catch (error: any) {
        console.error(`Error analyzing ${token.symbol}:`, error);
        setAnalyzedCount(prev => prev + 1);
        return null;
      }
    });

    await Promise.allSettled(promises);
  };

  const startAnalysis = async () => {
    const filteredTokens = filterInstitutionalTokens(excellentTokens);

    if (filteredTokens.length === 0) {
      toast.info("Sem oportunidades no momento", {
        duration: 3000,
      });
      return;
    }

    const immediateTokens = filteredTokens.filter(t => isImmediateOpportunity(t));
    const regularTokens = filteredTokens.filter(t => !isImmediateOpportunity(t));

    if (immediateTokens.length > 0) {
      toast.success(`${immediateTokens.length} oportunidade(s) prioritária(s)`, {
        duration: 3000,
      });
    }

    setQueuedTokens(filteredTokens);
    setIsLoading(true);
    setAnalyses({});
    setAnalyzedCount(0);
    setTotalResponseTimes([]);
    setAvgResponseTime(0);
    abortRef.current = false;
    pauseRef.current = false;

    if (immediateTokens.length > 0) {
      setCurrentTokens(immediateTokens.map(t => t.symbol));
      await processBatch(immediateTokens);
    }

    for (let i = 0; i < regularTokens.length; i += CONCURRENT_REQUESTS) {
      if (abortRef.current) break;
      const batch = regularTokens.slice(i, i + CONCURRENT_REQUESTS);
      setCurrentTokens(batch.map(t => t.symbol));
      await processBatch(batch);
    }

    setCurrentTokens([]);
    setIsLoading(false);
    setLastAnalysisTime(new Date());
    setIsPaused(false);
  };

  const togglePause = () => {
    pauseRef.current = !pauseRef.current;
    setIsPaused(!isPaused);
  };

  const stopAnalysis = () => {
    abortRef.current = true;
    pauseRef.current = false;
    setIsPaused(false);
  };

  // Score color based on value
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-emerald-400";
    if (score >= 50) return "text-amber-400";
    return "text-rose-400";
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 80) return "bg-emerald-500/10 border-emerald-500/20";
    if (score >= 50) return "bg-amber-500/10 border-amber-500/20";
    return "bg-rose-500/10 border-rose-500/20";
  };

  // Format currency
  const formatCurrency = (value: number) => {
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value.toFixed(0)}`;
  };

  // Golden Ratio bar component
  const GoldenRatioBar = ({ ratio }: { ratio: number }) => {
    const isGolden = ratio >= 3;
    const barWidth = Math.min(ratio / 5 * 100, 100);
    
    return (
      <div className="flex items-center gap-2">
        <span className="text-[10px] text-slate-500 uppercase tracking-wider">Vol/Liq</span>
        <div className="flex-1 h-1 bg-slate-800 rounded-full overflow-hidden">
          <div 
            className={`h-full rounded-full transition-all ${isGolden ? 'bg-emerald-500' : 'bg-slate-600'}`}
            style={{ width: `${barWidth}%` }}
          />
        </div>
        <span className={`text-xs font-mono ${isGolden ? 'text-emerald-400' : 'text-slate-500'}`}>
          {ratio.toFixed(1)}x
        </span>
      </div>
    );
  };

  const professionalAnalyses = Object.entries(analyses)
    .filter(([_, result]) => result.score >= 80)
    .sort((a, b) => {
      if (a[1].isImmediateOpportunity && !b[1].isImmediateOpportunity) return -1;
      if (!a[1].isImmediateOpportunity && b[1].isImmediateOpportunity) return 1;
      return b[1].score - a[1].score;
    });

  const progressPercent = queuedTokens.length > 0 
    ? (analyzedCount / queuedTokens.length) * 100 
    : 0;

  return (
    <div className="space-y-6" style={{ background: '#0A0E17' }}>
      {/* Header - Minimal */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-slate-800/50 border border-slate-700/50 flex items-center justify-center">
            <Brain className="w-5 h-5 text-slate-400" />
          </div>
          <div>
            <h2 className="text-sm font-medium text-slate-200 tracking-wide">AURION INTELLIGENCE</h2>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest">
              Institutional Analysis Engine
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {avgResponseTime > 0 && (
            <span className="text-[10px] text-slate-500 font-mono">
              {(avgResponseTime / 1000).toFixed(1)}s avg
            </span>
          )}
          {lastAnalysisTime && (
            <span className="text-[10px] text-slate-600 font-mono">
              {lastAnalysisTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
            </span>
          )}
        </div>
      </div>

      {/* Controls - Minimal */}
      <div className="flex items-center gap-3">
        <Button
          onClick={startAnalysis}
          disabled={isLoading || excellentTokens.length === 0}
          size="sm"
          className="bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700/50 h-8 px-4 text-xs font-medium"
        >
          {isLoading ? (
            <>
              <RefreshCw className="w-3 h-3 mr-2 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Zap className="w-3 h-3 mr-2" />
              Start Scan
            </>
          )}
        </Button>

        {isLoading && (
          <>
            <Button
              onClick={togglePause}
              size="sm"
              variant="ghost"
              className="h-8 w-8 p-0 text-slate-500 hover:text-slate-300"
            >
              {isPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
            </Button>
            <Button
              onClick={stopAnalysis}
              size="sm"
              variant="ghost"
              className="h-8 w-8 p-0 text-slate-500 hover:text-rose-400"
            >
              <Ban className="w-3 h-3" />
            </Button>
            <span className="text-[10px] text-slate-500 font-mono">
              {analyzedCount}/{queuedTokens.length}
            </span>
          </>
        )}

        <div className="flex-1" />

        <div className="flex items-center gap-4 text-[10px] text-slate-600">
          <span className="flex items-center gap-1">
            <Activity className="w-3 h-3" />
            {CONCURRENT_REQUESTS}x parallel
          </span>
          <span className="flex items-center gap-1">
            <BarChart3 className="w-3 h-3" />
            {excellentTokens.length} available
          </span>
        </div>
      </div>

      {/* Progress - Minimal */}
      {isLoading && (
        <div className="h-0.5 bg-slate-800 rounded-full overflow-hidden">
          <div 
            className="h-full bg-slate-600 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      )}

      {/* Results */}
      <div className="min-h-[500px]">
        {isLoading && professionalAnalyses.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-[400px] gap-4">
            <div className="w-12 h-12 rounded-lg bg-slate-800/30 border border-slate-700/30 flex items-center justify-center">
              <RefreshCw className="w-5 h-5 text-slate-500 animate-spin" />
            </div>
            <div className="text-center">
              <p className="text-xs text-slate-500">Processing {currentTokens.length} token(s)</p>
              <div className="flex flex-wrap justify-center gap-1 mt-2 max-w-md">
                {currentTokens.slice(0, 5).map(symbol => (
                  <span key={symbol} className="text-[10px] text-slate-600 font-mono px-2 py-0.5 bg-slate-800/50 rounded">
                    {symbol}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ) : professionalAnalyses.length > 0 ? (
          <ScrollArea className="h-[600px]">
            <div className="space-y-4 pr-4">
              {professionalAnalyses.map(([symbol, result]) => (
                <Card 
                  key={symbol} 
                  className="p-5 bg-slate-900/40 backdrop-blur-xl border border-slate-800/50 rounded-xl"
                  style={{ background: 'rgba(15, 23, 42, 0.6)' }}
                >
                  {/* Card Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="flex flex-col">
                        <span className="text-lg font-semibold text-slate-200 tracking-wide">
                          {symbol}
                        </span>
                        <span className="text-[10px] text-slate-500 uppercase tracking-wider">
                          {result.tradeProfile}
                        </span>
                      </div>
                    </div>

                    {/* Score */}
                    <div className={`flex flex-col items-end px-3 py-2 rounded-lg border ${getScoreBgColor(result.score)}`}>
                      <span className={`text-2xl font-light ${getScoreColor(result.score)}`}>
                        {result.score}
                      </span>
                      <span className="text-[8px] text-slate-500 uppercase tracking-widest">Score</span>
                    </div>
                  </div>

                  {/* Badges Row */}
                  <div className="flex flex-wrap items-center gap-2 mb-4">
                    {result.preCalculated && (
                      <>
                        <Badge variant="outline" className="text-[10px] bg-slate-800/50 border-slate-700/50 text-slate-400 font-normal">
                          <TrendingUp className="w-3 h-3 mr-1" />
                          Liq {formatCurrency(result.preCalculated.finalScore * 1000)}
                        </Badge>
                        {result.preCalculated.isGoldenRatio && (
                          <Badge variant="outline" className="text-[10px] bg-emerald-500/10 border-emerald-500/30 text-emerald-400 font-normal">
                            Golden Ratio
                          </Badge>
                        )}
                        {result.preCalculated.isProjectElite && (
                          <Badge variant="outline" className="text-[10px] bg-amber-500/10 border-amber-500/30 text-amber-400 font-normal">
                            Elite Project
                          </Badge>
                        )}
                        {result.isImmediateOpportunity && (
                          <Badge variant="outline" className="text-[10px] bg-rose-500/10 border-rose-500/30 text-rose-400 font-normal">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            Priority
                          </Badge>
                        )}
                      </>
                    )}
                    {result.analysisTimeMs && (
                      <span className="text-[10px] text-slate-600 font-mono ml-auto">
                        {(result.analysisTimeMs / 1000).toFixed(1)}s
                      </span>
                    )}
                  </div>

                  {/* Golden Ratio Bar */}
                  {result.preCalculated && (
                    <div className="mb-4">
                      <GoldenRatioBar ratio={result.preCalculated.volumeToLiquidityRatio} />
                    </div>
                  )}

                  {/* Analysis Text */}
                  <p className="text-xs text-slate-400 leading-relaxed mb-5 border-l-2 border-slate-700 pl-3">
                    {result.analysis}
                  </p>

                  {/* Trade Strategy Table */}
                  <div className="bg-slate-800/30 rounded-lg border border-slate-700/30 overflow-hidden">
                    <div className="grid grid-cols-3 divide-x divide-slate-700/30">
                      <div className="p-3 text-center">
                        <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">Entry</div>
                        <div className="text-xs text-slate-300 font-mono flex items-center justify-center gap-1">
                          <Crosshair className="w-3 h-3 text-emerald-500" />
                          Market
                        </div>
                      </div>
                      <div className="p-3 text-center">
                        <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">Stop Loss</div>
                        <div className="text-xs text-rose-400 font-mono">-15%</div>
                      </div>
                      <div className="p-3 text-center">
                        <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">Target</div>
                        <div className="text-xs text-emerald-400 font-mono">+50%</div>
                      </div>
                    </div>
                  </div>

                  {/* Buy Reason Footer */}
                  <div className="mt-4 pt-4 border-t border-slate-800/50">
                    <div className="flex items-start gap-2 mb-4">
                      <Target className="w-3 h-3 text-slate-500 mt-0.5 shrink-0" />
                      <p className="text-[11px] text-slate-500 leading-relaxed">
                        {result.buyReason}
                      </p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-2">
                      {onViewChart && result.tokenData && (
                        <Button
                          onClick={() => onViewChart(result.tokenData!)}
                          size="sm"
                          variant="outline"
                          className="flex-1 h-9 bg-slate-800/50 border-slate-700/50 hover:bg-slate-700/50 hover:border-slate-600 text-slate-300"
                        >
                          <LineChart className="w-4 h-4 mr-2" />
                          Gráfico
                        </Button>
                      )}
                      {onBuy && result.tokenData && (
                        <Button
                          onClick={() => onBuy(result.tokenData!)}
                          size="sm"
                          className="flex-1 h-9 bg-emerald-600/80 hover:bg-emerald-500 text-white border-0"
                        >
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          Comprar
                        </Button>
                      )}
                      {result.pairAddress && (
                        <Button
                          onClick={() => window.open(`https://dexscreener.com/solana/${result.pairAddress}`, '_blank')}
                          size="sm"
                          variant="ghost"
                          className="h-9 w-9 p-0 text-slate-500 hover:text-slate-300"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </ScrollArea>
        ) : (
          <div className="flex flex-col items-center justify-center h-[400px] gap-4">
            <div className="w-16 h-16 rounded-xl bg-slate-800/30 border border-slate-700/30 flex items-center justify-center">
              <Shield className="w-6 h-6 text-slate-600" />
            </div>
            <div className="text-center">
              <p className="text-sm text-slate-400">Ready for Analysis</p>
              <p className="text-[11px] text-slate-600 mt-1 max-w-xs">
                Click "Start Scan" to analyze {excellentTokens.length} tokens using institutional-grade AI
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
