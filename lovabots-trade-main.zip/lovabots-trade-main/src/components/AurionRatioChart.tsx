import { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useTradingMode } from "@/contexts/TradingModeContext";

interface AurionRatioChartProps {
  longSymbol: string;
  shortSymbol: string;
}

interface RatioData {
  date: string;
  ratio: number;
  mean: number;
  upperBand: number;
  lowerBand: number;
}

interface Statistics {
  mean: number;
  upperBand: number;
  lowerBand: number;
}

/**
 * Aurion Ratio Chart
 * 
 * Este gráfico mede quanto a relação entre duas moedas se desvia da média.
 * 
 * Interpretação:
 * - Quando o ratio está acima de +1σ, o par LONG pode estar sobrevalorizado (sinal de venda)
 * - Quando o ratio está abaixo de -1σ, o par LONG pode estar subvalorizado (sinal de compra)
 * - A linha média (μ) representa o equilíbrio histórico
 */
export const AurionRatioChart = ({ longSymbol, shortSymbol }: AurionRatioChartProps) => {
  const { isB3Mode } = useTradingMode();
  const [data, setData] = useState<RatioData[]>([]);
  const [stats, setStats] = useState<Statistics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [period, setPeriod] = useState<"1m" | "6m" | "1y">("6m");
  const [isRateLimited, setIsRateLimited] = useState(false);

  const periodConfig = {
    "1m": { days: 30, label: "1 mês" },
    "6m": { days: 180, label: "6 meses" },
    "1y": { days: 365, label: "1 ano" }
  };

  useEffect(() => {
    const fetchRatioData = async () => {
      if (!longSymbol || !shortSymbol) {
        setIsLoading(false);
        return;
      }

      // Se está em rate limit, não tentar novamente ainda
      if (isRateLimited) {
        console.log('⏳ Aguardando rate limit no gráfico de ratio...');
        return;
      }

      try {
        setIsLoading(true);
        setError(null);

        const days = periodConfig[period].days;

        // Modo B3: gerar dados mockados
        if (isB3Mode) {
          // Simular ratios com tendência e volatilidade
          const baseRatio = Math.random() * 0.5 + 0.8; // Entre 0.8 e 1.3
          const ratios = Array.from({ length: days }, (_, i) => {
            const trend = (i / days) * 0.1; // Tendência leve
            const noise = (Math.random() - 0.5) * 0.05; // Volatilidade
            return baseRatio + trend + noise;
          });

          // Calcular estatísticas
          const mean = ratios.reduce((a, b) => a + b, 0) / ratios.length;
          const variance = ratios.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / ratios.length;
          const std = Math.sqrt(variance);
          const upperBand = mean + std;
          const lowerBand = mean - std;

          setStats({ mean, upperBand, lowerBand });

          // Formatar dados para o gráfico
          const today = new Date();
          const chartData: RatioData[] = ratios.map((ratio, i) => {
            const date = new Date(today);
            date.setDate(date.getDate() - (days - i - 1));
            return {
              date: date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
              ratio,
              mean,
              upperBand,
              lowerBand
            };
          });

          setData(chartData);
          setIsLoading(false);
          return;
        }

        // Buscar dados para ambas as moedas
        const [longResponse, shortResponse] = await Promise.all([
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${longSymbol}&interval=1d&limit=${days}`),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${shortSymbol}&interval=1d&limit=${days}`)
        ]);

        // Verificar rate limit (erro 418)
        if (longResponse.status === 418 || shortResponse.status === 418) {
          console.warn('⚠️ Rate limit no gráfico de ratio. Mantendo dados anteriores...');
          setIsRateLimited(true);
          
          // Liberar após 10 segundos
          setTimeout(() => {
            setIsRateLimited(false);
            console.log('✅ Rate limit liberado no gráfico');
          }, 10000);
          
          // Se não tem dados anteriores, mostrar mensagem amigável
          if (data.length === 0) {
            setError("Aguardando API da Binance... Tentando novamente em instantes.");
          }
          setIsLoading(false);
          return;
        }

        if (!longResponse.ok || !shortResponse.ok) {
          console.error(`Erro ao buscar dados: ${longResponse.status}/${shortResponse.status}`);
          // Manter dados anteriores se houver
          if (data.length === 0) {
            setError(`Erro ao buscar dados da Binance`);
          }
          setIsLoading(false);
          return;
        }

        const longKlines = await longResponse.json();
        const shortKlines = await shortResponse.json();

        if (longKlines.length < days || shortKlines.length < days) {
          throw new Error("Dados insuficientes para cálculo do ratio.");
        }

        // Extrair preços de fechamento
        const longPrices = longKlines.map((k: any) => parseFloat(k[4]));
        const shortPrices = shortKlines.map((k: any) => parseFloat(k[4]));

        // Calcular ratios
        const ratios = longPrices.map((p: number, i: number) => p / shortPrices[i]);

        // Calcular estatísticas
        const mean = ratios.reduce((a: number, b: number) => a + b, 0) / ratios.length;
        const variance = ratios.reduce((a: number, b: number) => a + Math.pow(b - mean, 2), 0) / ratios.length;
        const std = Math.sqrt(variance);
        const upperBand = mean + std;
        const lowerBand = mean - std;

        setStats({
          mean,
          upperBand,
          lowerBand
        });

        // Formatar dados para o gráfico
        const chartData: RatioData[] = ratios.map((ratio: number, i: number) => ({
          date: new Date(longKlines[i][0]).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
          ratio,
          mean,
          upperBand,
          lowerBand
        }));

        setData(chartData);
        setIsLoading(false);
      } catch (err) {
        console.error('Erro ao calcular ratio:', err);
        setError(err instanceof Error ? err.message : 'Erro desconhecido');
        setIsLoading(false);
      }
    };

    fetchRatioData();
  }, [longSymbol, shortSymbol, period, isB3Mode]);

  if (!longSymbol || !shortSymbol) {
    return (
      <div className="text-center py-4 text-muted-foreground text-xs">
        Selecione os pares LONG e SHORT para visualizar o ratio
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="text-center py-4 text-muted-foreground text-xs">
        Calculando ratio...
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-4 text-destructive text-xs">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {/* Título e Seletor de Período */}
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-light text-[#a6a6ff]">
          Aurion Ratio Chart
        </h3>
        <div className="flex items-center gap-2">
          <Label htmlFor="period-select" className="text-[10px] text-muted-foreground">
            Período:
          </Label>
          <Select value={period} onValueChange={(value: "1m" | "6m" | "1y") => setPeriod(value)}>
            <SelectTrigger id="period-select" className="h-7 w-[110px] text-xs bg-card border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-card border-border z-50">
              <SelectItem value="1m" className="text-xs">1 mês</SelectItem>
              <SelectItem value="6m" className="text-xs">6 meses</SelectItem>
              <SelectItem value="1y" className="text-xs">1 ano</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Gráfico */}
      <div className="h-32">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <XAxis 
              dataKey="date" 
              stroke="hsl(var(--muted-foreground))"
              style={{ fontSize: '10px' }}
              tickLine={false}
            />
            <YAxis 
              stroke="hsl(var(--muted-foreground))"
              style={{ fontSize: '10px' }}
              tickLine={false}
              domain={['auto', 'auto']}
              tickFormatter={(value) => value.toFixed(4)}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
                fontSize: '11px'
              }}
              formatter={(value: any) => [value.toFixed(4), '']}
            />
            <Legend 
              wrapperStyle={{ fontSize: '10px' }}
              iconSize={8}
            />
            
            {/* Linha +1σ (verde) */}
            <Line 
              type="monotone" 
              dataKey="upperBand" 
              stroke="#22c55e"
              strokeWidth={1.5}
              dot={false}
              name="+1σ"
              strokeDasharray="3 3"
            />
            
            {/* Linha média (amarela) */}
            <Line 
              type="monotone" 
              dataKey="mean" 
              stroke="#eab308"
              strokeWidth={1.5}
              dot={false}
              name="μ (média)"
              strokeDasharray="3 3"
            />
            
            {/* Linha -1σ (vermelha) */}
            <Line 
              type="monotone" 
              dataKey="lowerBand" 
              stroke="#ef4444"
              strokeWidth={1.5}
              dot={false}
              name="-1σ"
              strokeDasharray="3 3"
            />
            
            {/* Linha ratio principal (azul clara) */}
            <Line 
              type="monotone" 
              dataKey="ratio" 
              stroke="#60a5fa"
              strokeWidth={2}
              dot={{ r: 2 }}
              name="Ratio"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Estatísticas */}
      {stats && (
        <div className="flex justify-around text-xs pt-2 border-t border-border/50">
          <div className="text-center">
            <div className="text-muted-foreground">Média</div>
            <div className="text-foreground font-semibold">{stats.mean.toFixed(4)}</div>
          </div>
          <div className="text-center">
            <div className="text-muted-foreground">+1σ</div>
            <div className="text-profit font-semibold">{stats.upperBand.toFixed(4)}</div>
          </div>
          <div className="text-center">
            <div className="text-muted-foreground">-1σ</div>
            <div className="text-loss font-semibold">{stats.lowerBand.toFixed(4)}</div>
          </div>
        </div>
      )}
    </div>
  );
};