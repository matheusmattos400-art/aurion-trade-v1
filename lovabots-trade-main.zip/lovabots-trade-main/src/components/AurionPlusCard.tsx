import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { 
  Sparkles, 
  TrendingUp, 
  LineChart,
  Shield,
  AlertTriangle,
  Wallet,
  Users,
  Clock,
  DollarSign,
  Eye
} from "lucide-react";
import type { AurionToken } from "@/hooks/useAurionScanner";

export interface AurionPlusAnalysis {
  bundleRetention: number; // % de retenção do Bundle
  devPnlEstimated: number; // PnL estimado do Dev em SOL
  devGreedAverage: number; // Média de ganância do Dev
  devRugRisk: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  bundleHolding: boolean; // Diamond Hands
  devClean: boolean; // Histórico limpo
  mcInRange: boolean; // MC entre $50k-$150k
  inWindow: boolean; // Janela de 30-90 min
  volumeLateralizing: boolean;
  bundleSelling: boolean;
  status: "PROMISING" | "WATCH" | "NEUTRAL";
  warnings: string[];
}

interface AurionPlusCardProps {
  token: AurionToken;
  analysis?: AurionPlusAnalysis;
  onSimulateEntry: (token: AurionToken) => void;
  onViewChart: (token: AurionToken) => void;
  onAurionAI: (token: AurionToken) => void;
}

export function AurionPlusCard({
  token,
  analysis,
  onSimulateEntry,
  onViewChart,
  onAurionAI,
}: AurionPlusCardProps) {
  // Determinar a cor da borda com base no status
  const getBorderColor = () => {
    if (!analysis) return "border-border/50";
    
    switch (analysis.status) {
      case "PROMISING":
        // Verde: Bundle segurando, Dev limpo, MC $50k-$150k, janela 30-90min
        return "border-green-500 shadow-[0_0_20px_rgba(34,197,94,0.3)]";
      case "WATCH":
        // Amarelo: Segura mas volume lateralizando ou Bundle vendendo frações
        return "border-yellow-500 shadow-[0_0_20px_rgba(234,179,8,0.3)]";
      case "NEUTRAL":
      default:
        // Branco/padrão: Não atingiu critérios mínimos
        return "border-border/50";
    }
  };

  const getStatusLabel = () => {
    if (!analysis) return null;
    
    switch (analysis.status) {
      case "PROMISING":
        return (
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            <TrendingUp className="w-3 h-3 mr-1" />
            Promissora
          </Badge>
        );
      case "WATCH":
        return (
          <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
            <Eye className="w-3 h-3 mr-1" />
            Acompanhar
          </Badge>
        );
      default:
        return null;
    }
  };

  // Formatar números grandes
  const formatNumber = (num: number) => {
    if (num >= 1000000) return `$${(num / 1000000).toFixed(2)}M`;
    if (num >= 1000) return `$${(num / 1000).toFixed(1)}K`;
    return `$${num.toFixed(2)}`;
  };

  // Idade formatada
  const formatAge = () => {
    if (token.ageHours < 1) return `${Math.floor(token.ageHours * 60)}min`;
    if (token.ageHours < 24) return `${token.ageHours.toFixed(1)}h`;
    return `${(token.ageHours / 24).toFixed(1)}d`;
  };

  return (
    <Card className={`glass-card p-4 transition-all duration-300 ${getBorderColor()}`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          {token.imageUrl && (
            <img 
              src={token.imageUrl} 
              alt={token.symbol} 
              className="w-8 h-8 rounded-full bg-card"
              onError={(e) => (e.currentTarget.style.display = 'none')}
            />
          )}
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-foreground">{token.symbol}</h3>
              {getStatusLabel()}
            </div>
            <p className="text-xs text-muted-foreground truncate max-w-[150px]">
              {token.name}
            </p>
          </div>
        </div>
        
        <div className="text-right">
          <div className="flex items-center gap-1">
            <Badge variant="outline" className="text-xs">
              Score: {token.securityScore}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
            <Clock className="w-3 h-3" />
            {formatAge()}
          </p>
        </div>
      </div>

      {/* Dados de Mercado */}
      <div className="grid grid-cols-2 gap-2 mb-3 text-sm">
        <div className="flex flex-col">
          <span className="text-xs text-muted-foreground">Preço</span>
          <span className="font-mono font-medium">
            ${token.priceUsd < 0.01 ? token.priceUsd.toExponential(2) : token.priceUsd.toFixed(4)}
          </span>
        </div>
        <div className="flex flex-col">
          <span className="text-xs text-muted-foreground">24h</span>
          <span className={`font-medium ${token.priceChange24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {token.priceChange24h >= 0 ? '+' : ''}{token.priceChange24h.toFixed(1)}%
          </span>
        </div>
        <div className="flex flex-col">
          <span className="text-xs text-muted-foreground">Liquidez</span>
          <span className="font-medium">{formatNumber(token.liquidity)}</span>
        </div>
        <div className="flex flex-col">
          <span className="text-xs text-muted-foreground">MC</span>
          <span className="font-medium">{formatNumber(token.marketCap)}</span>
        </div>
      </div>

      {/* Dados do Bundle/Dev (se disponíveis) */}
      {analysis && (
        <div className="bg-card/50 rounded-lg p-3 mb-3 space-y-2">
          <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground mb-2">
            <Users className="w-3 h-3" />
            <span>Bundle & Dev Analysis</span>
          </div>
          
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">% Retenção Bundle</span>
              <span className={`font-bold ${analysis.bundleRetention > 80 ? 'text-green-400' : analysis.bundleRetention > 50 ? 'text-yellow-400' : 'text-red-400'}`}>
                {analysis.bundleRetention.toFixed(1)}%
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">PnL Est. Dev</span>
              <span className={`font-bold ${analysis.devPnlEstimated < analysis.devGreedAverage * 0.5 ? 'text-green-400' : analysis.devPnlEstimated < analysis.devGreedAverage * 0.8 ? 'text-yellow-400' : 'text-red-400'}`}>
                {analysis.devPnlEstimated.toFixed(2)} SOL
              </span>
            </div>
          </div>

          {/* Indicadores visuais */}
          <div className="flex flex-wrap gap-1 mt-2">
            {analysis.bundleHolding && (
              <Badge className="bg-green-500/10 text-green-400 border-green-500/30 text-xs">
                💎 Diamond Hands
              </Badge>
            )}
            {analysis.devClean && (
              <Badge className="bg-green-500/10 text-green-400 border-green-500/30 text-xs">
                ✓ Dev Limpo
              </Badge>
            )}
            {analysis.mcInRange && (
              <Badge className="bg-cyan-500/10 text-cyan-400 border-cyan-500/30 text-xs">
                📊 MC Ideal
              </Badge>
            )}
            {analysis.inWindow && (
              <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/30 text-xs">
                ⏱️ Janela 30-90min
              </Badge>
            )}
          </div>

          {/* Avisos */}
          {analysis.warnings.length > 0 && (
            <div className="flex items-start gap-1 mt-2 p-2 rounded bg-yellow-500/10 border border-yellow-500/30">
              <AlertTriangle className="w-3 h-3 text-yellow-400 mt-0.5 shrink-0" />
              <span className="text-xs text-yellow-400">
                {analysis.warnings[0]}
              </span>
            </div>
          )}

          {/* Dev Rug Risk */}
          {analysis.devRugRisk === "CRITICAL" && (
            <div className="flex items-start gap-1 mt-2 p-2 rounded bg-red-500/10 border border-red-500/30">
              <AlertTriangle className="w-3 h-3 text-red-400 mt-0.5 shrink-0" />
              <span className="text-xs text-red-400">
                ⚠️ Teto de Lucro do Dev Atingido!
              </span>
            </div>
          )}
        </div>
      )}

      {/* Segurança */}
      <div className="flex flex-wrap gap-1 mb-3">
        {!token.isMintable && (
          <Badge variant="outline" className="text-xs border-green-500/30 text-green-400">
            <Shield className="w-3 h-3 mr-1" />
            Mint Revoked
          </Badge>
        )}
        {token.lpLocked && (
          <Badge variant="outline" className="text-xs border-green-500/30 text-green-400">
            🔒 LP Locked
          </Badge>
        )}
        {!token.hasBlacklist && (
          <Badge variant="outline" className="text-xs border-green-500/30 text-green-400">
            ✓ No Blacklist
          </Badge>
        )}
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <Button 
          size="sm" 
          className="flex-1 gradient-button"
          onClick={() => onAurionAI(token)}
        >
          <Sparkles className="w-4 h-4 mr-1" />
          Aurion AI
        </Button>
        <Button 
          size="sm" 
          variant="outline"
          onClick={() => onViewChart(token)}
        >
          <LineChart className="w-4 h-4" />
        </Button>
        <Button 
          size="sm" 
          variant="outline"
          onClick={() => onSimulateEntry(token)}
        >
          <Wallet className="w-4 h-4" />
        </Button>
      </div>
    </Card>
  );
}

export default AurionPlusCard;
