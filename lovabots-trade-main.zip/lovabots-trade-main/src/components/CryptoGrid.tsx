import { useBinancePrices } from "@/hooks/useBinancePrices";
import { TrendingUp, TrendingDown } from "lucide-react";
import { useTradingMode } from "@/contexts/TradingModeContext";
import { formatPrice } from "@/utils/priceFormatter";

const CRYPTO_SYMBOLS = [
  "BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT"
];

const B3_SYMBOLS = [
  "PETR4", "VALE3", "ITUB4", 
  "BBDC4", "ABEV3", "WEGE3"
];

export const CryptoGrid = () => {
  const { isB3Mode } = useTradingMode();
  const symbols = isB3Mode ? B3_SYMBOLS : CRYPTO_SYMBOLS;
  const { prices, isLoading, error } = useBinancePrices(symbols);

  if (isLoading) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Carregando preços ao vivo...
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8 text-loss">
        {error}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3 md:gap-4">
      {prices.map((crypto) => (
        <div 
          key={crypto.symbol}
          className="bg-card border border-border/50 rounded-lg p-3 sm:p-4 hover:border-primary/50 transition-all"
        >
          <div className="flex justify-between items-start mb-2">
            <span className="font-sans font-semibold text-foreground">
              {isB3Mode ? crypto.symbol : crypto.symbol.replace('USDT', '')}
            </span>
            <span className="font-sans text-xs text-muted-foreground">{isB3Mode ? 'BRL' : 'USDT'}</span>
          </div>
          
          <div className="space-y-1">
            <p className="font-sans text-2xl font-bold text-foreground animate-pulse-subtle">
              {isB3Mode ? formatPrice(crypto.price, 'R$ ') : formatPrice(crypto.price, '$')}
            </p>
            
            <div className={`flex items-center gap-1 ${crypto.change24h >= 0 ? 'text-profit' : 'text-loss'}`}>
              {crypto.change24h >= 0 ? (
                <TrendingUp className="w-4 h-4" />
              ) : (
                <TrendingDown className="w-4 h-4" />
              )}
              <span className="font-sans text-sm font-medium">
                {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h.toFixed(2)}%
              </span>
            </div>

            <div className="flex justify-between text-xs text-muted-foreground pt-1">
              <span className="font-sans">H: {isB3Mode ? formatPrice(crypto.high24h, 'R$ ') : formatPrice(crypto.high24h, '$')}</span>
              <span className="font-sans">L: {isB3Mode ? formatPrice(crypto.low24h, 'R$ ') : formatPrice(crypto.low24h, '$')}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
