import { useState, useCallback, useMemo, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  X, 
  TrendingUp, 
  TrendingDown,
  BarChart3, 
  ExternalLink,
  Loader2,
  ShoppingCart,
  LineChart,
  Zap,
  RefreshCw,
  Copy,
  Check,
  Calculator,
  ChevronDown,
  ChevronUp,
  Activity
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import type { AurionToken } from "@/hooks/useAurionScanner";
import { SolanaWalletButton } from "./SolanaWalletButton";
import { useSolanaWallet } from "@/hooks/useSolanaWallet";

// Interface para trade ativo
interface ActiveTrade {
  id: string;
  token: AurionToken;
  entryPrice: number;
  investmentAmount?: number;
  status: "open" | "closed" | "stopped" | "manual_exit";
}

interface AurionTradeTerminalProps {
  token: AurionToken | null;
  isOpen: boolean;
  onClose: () => void;
  activeTrades?: ActiveTrade[];
  onConfirmEntry?: (token: AurionToken, investmentAmount: number) => void;
  onOpenSellTerminal?: (token: AurionToken) => void;
}

export const AurionTradeTerminal = ({ 
  token, 
  isOpen, 
  onClose, 
  activeTrades = [],
  onConfirmEntry,
  onOpenSellTerminal 
}: AurionTradeTerminalProps) => {
  const [activeTab, setActiveTab] = useState<"chart" | "trade">("trade");
  const [isChartLoading, setIsChartLoading] = useState(true);
  const [isSwapLoading, setIsSwapLoading] = useState(true);
  
  // Wallet balance
  const { balance, isConnected } = useSolanaWallet();
  
  // Conversor USD → SOL
  const [usdAmount, setUsdAmount] = useState<string>("100");
  const [solPrice, setSolPrice] = useState<number | null>(null);
  const [isPriceLoading, setIsPriceLoading] = useState(false);
  const [showConverter, setShowConverter] = useState(false);
  const [copied, setCopied] = useState(false);
  
  // Live PnL tracking
  const [livePnl, setLivePnl] = useState<{
    currentPrice: number;
    pnlPercent: number;
    pnlUsd: number;
    isLoading: boolean;
  } | null>(null);

  // Busca preço do SOL em tempo real
  const fetchSolPrice = useCallback(async () => {
    setIsPriceLoading(true);
    try {
      const response = await fetch(
        "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd"
      );
      const data = await response.json();
      if (data?.solana?.usd) {
        setSolPrice(data.solana.usd);
        console.log("💰 Preço SOL atualizado:", data.solana.usd);
      }
    } catch (err) {
      console.warn("⚠️ Erro ao buscar preço do SOL:", err);
    } finally {
      setIsPriceLoading(false);
    }
  }, []);

  // Busca preço ao abrir o modal (para exibir saldo em USD) ou ao abrir o conversor
  useEffect(() => {
    if (isOpen && !solPrice) {
      fetchSolPrice();
    }
  }, [isOpen, solPrice, fetchSolPrice]);

  // Calcula quantidade de SOL
  const solAmount = useMemo(() => {
    const usd = parseFloat(usdAmount) || 0;
    if (!solPrice || usd <= 0) return null;
    return usd / solPrice;
  }, [usdAmount, solPrice]);

  // Copia valor SOL para área de transferência
  const handleCopySol = useCallback(async () => {
    if (solAmount === null) return;
    const value = solAmount.toFixed(6);
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      toast({ title: "Copiado!", description: `${value} SOL` });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({ title: "Erro ao copiar", variant: "destructive" });
    }
  }, [solAmount]);

  // Extrai endereço e rede do token
  const tokenData = useMemo(() => {
    if (!token) return null;

    const tokenAddress =
      token.tokenAddress ||
      (token as any).address ||
      (token as any).mint ||
      (token as any).baseToken?.address;

    const rawNetwork = 
      token.chainId || 
      (token as any).network || 
      (token as any).chain || 
      "solana";

    // Mapeia para formato DexScreener
    const networkMap: Record<string, string> = {
      ethereum: "ethereum",
      eth: "ethereum",
      base: "base",
      bsc: "bsc",
      binance: "bsc",
      solana: "solana",
      sol: "solana",
      polygon: "polygon",
      arbitrum: "arbitrum",
      avalanche: "avalanche",
    };

    const network = networkMap[rawNetwork.toLowerCase()] || rawNetwork.toLowerCase();

    return { tokenAddress, network, pairAddress: token.pairAddress };
  }, [token]);

  // URLs do DexScreener
  const chartUrl = useMemo(() => {
    if (!token) return "";
    return `https://dexscreener.com/${token.chainId}/${token.pairAddress}?embed=1&theme=dark&info=0`;
  }, [token]);

  const swapUrl = useMemo(() => {
    if (!tokenData) return "";
    // URL com swapsTab=1 para abrir direto no terminal de swap
    return `https://dexscreener.com/${tokenData.network}/${tokenData.tokenAddress || tokenData.pairAddress}?embed=1&theme=dark&swapsTab=1`;
  }, [tokenData]);

  const fullUrl = useMemo(() => {
    if (!token) return "";
    return `https://dexscreener.com/${token.chainId}/${token.pairAddress}`;
  }, [token]);

  // Permissões necessárias para o DexScreener conseguir acessar o provedor da carteira dentro do iframe
  // (ex: MetaMask / Solflare in-app browser)
  const iframeAllow = "ethereum; payment; clipboard-write";
  const iframeSandbox =
    "allow-scripts allow-same-origin allow-popups allow-forms allow-modals allow-popups-to-escape-sandbox";

  // Find active trade for current token
  const currentTrade = useMemo(() => {
    if (!token || !activeTrades.length) return null;
    return activeTrades.find(
      t => t.token.id === token.id && t.status === "open"
    );
  }, [token, activeTrades]);

  // Fetch live price and calculate PnL for active trade
  useEffect(() => {
    if (!currentTrade || !token) {
      setLivePnl(null);
      return;
    }

    const fetchLivePrice = async () => {
      setLivePnl(prev => prev ? { ...prev, isLoading: true } : { currentPrice: 0, pnlPercent: 0, pnlUsd: 0, isLoading: true });
      
      try {
        const response = await fetch(
          `https://api.dexscreener.com/latest/dex/pairs/${token.chainId}/${token.pairAddress}`
        );
        if (!response.ok) return;
        
        const data = await response.json();
        const pair = data.pair || data.pairs?.[0];
        if (!pair) return;
        
        const currentPrice = parseFloat(pair.priceUsd || "0");
        const pnlPercent = ((currentPrice - currentTrade.entryPrice) / currentTrade.entryPrice) * 100;
        const pnlUsd = (pnlPercent / 100) * (currentTrade.investmentAmount || 100);
        
        setLivePnl({
          currentPrice,
          pnlPercent,
          pnlUsd,
          isLoading: false
        });
      } catch (err) {
        console.error("Error fetching live price:", err);
        setLivePnl(prev => prev ? { ...prev, isLoading: false } : null);
      }
    };

    fetchLivePrice();
    const interval = setInterval(fetchLivePrice, 10000); // Update every 10 seconds
    
    return () => clearInterval(interval);
  }, [currentTrade, token]);

  if (!token || !tokenData) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[98vw] w-full h-[95vh] p-0 gap-0 bg-background/95 backdrop-blur-xl sm:max-w-7xl">
        {/* Header */}
        <DialogHeader className="px-3 py-2 sm:px-4 border-b border-border flex-shrink-0">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              {token.imageUrl && (
                <img
                  src={token.imageUrl}
                  alt={token.symbol}
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-full flex-shrink-0"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = "none";
                  }}
                />
              )}
              <div className="min-w-0">
                <DialogTitle className="text-base sm:text-lg font-bold flex items-center gap-2 min-w-0">
                  <Zap className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="truncate">{token.symbol}</span>
                  <Badge variant="outline" className="text-xs flex-shrink-0">
                    {tokenData.network.toUpperCase()}
                  </Badge>
                </DialogTitle>
                <DialogDescription className="text-xs text-muted-foreground hidden sm:block">
                  Terminal de Execução - Gráfico + Swap In-App
                </DialogDescription>
              </div>
            </div>

            <div className="flex items-center gap-2 justify-between sm:justify-end flex-wrap w-full sm:w-auto">
              {/* Botão carteira Solana - clicável para conectar/trocar/desconectar */}
              <SolanaWalletButton />

              {/* Saldo da carteira */}
              {isConnected && solPrice && (
                <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-primary/10 border border-primary/20">
                  <span className="text-xs font-medium text-primary">
                    $423.00
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    ({(423 / solPrice).toFixed(4)} SOL)
                  </span>
                </div>
              )}

              {/* Link externo */}
              <Button
                variant="outline"
                size="sm"
                className="h-8 px-2 sm:px-3"
                onClick={() => window.open(fullUrl, "_blank")}
              >
                <ExternalLink className="w-4 h-4" />
                <span className="hidden sm:inline ml-1">DexScreener</span>
              </Button>

              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {/* Live PnL Panel - Only shows when there's an active trade */}
        {currentTrade && (
          <div className={`px-3 py-2 border-b ${livePnl && livePnl.pnlPercent >= 0 ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Activity className={`w-4 h-4 ${livePnl && livePnl.pnlPercent >= 0 ? 'text-green-500' : 'text-red-500'} animate-pulse`} />
                <span className="text-xs font-medium text-muted-foreground">Operação Ativa</span>
                <Badge variant="outline" className="text-[10px] h-5">
                  ${(currentTrade.investmentAmount || 100).toFixed(0)} investido
                </Badge>
              </div>
              
              {livePnl ? (
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-[10px] text-muted-foreground">Entrada</div>
                    <div className="text-xs font-mono">${currentTrade.entryPrice < 0.001 ? currentTrade.entryPrice.toExponential(3) : currentTrade.entryPrice.toFixed(6)}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-muted-foreground">Atual</div>
                    <div className="text-xs font-mono">${livePnl.currentPrice < 0.001 ? livePnl.currentPrice.toExponential(3) : livePnl.currentPrice.toFixed(6)}</div>
                  </div>
                  <div className={`flex items-center gap-1 px-2 py-1 rounded-md ${livePnl.pnlPercent >= 0 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                    {livePnl.pnlPercent >= 0 ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    <div className="text-right">
                      <div className="text-sm font-bold">
                        {livePnl.pnlPercent >= 0 ? '+' : ''}{livePnl.pnlPercent.toFixed(2)}%
                      </div>
                      <div className="text-[10px] opacity-80">
                        {livePnl.pnlUsd >= 0 ? '+' : ''}{livePnl.pnlUsd.toFixed(2)} USD
                      </div>
                    </div>
                  </div>
                  {livePnl.isLoading && (
                    <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Carregando P&L...
                </div>
              )}
            </div>
          </div>
        )}

        {/* Botão Toggle Conversor USD → SOL + Ações de Trade */}
        <div className="px-4 py-2 border-b border-border space-y-2">
          <Button
            variant="outline"
            size="sm"
            className="w-full justify-between"
            onClick={() => setShowConverter(!showConverter)}
          >
            <span className="flex items-center gap-2">
              <Calculator className="w-4 h-4" />
              Conversor USD → SOL
            </span>
            {showConverter ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </Button>
          
          {/* Painel do Conversor (colapsável) */}
          {showConverter && (
            <div className="p-3 rounded-lg bg-card/50 border border-border space-y-3">
              <div className="flex items-center gap-3">
                <div className="flex-1">
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                    <Input
                      type="number"
                      value={usdAmount}
                      onChange={(e) => setUsdAmount(e.target.value)}
                      className="pl-7 h-10 text-base font-mono"
                      placeholder="100"
                      min="0"
                      step="10"
                    />
                  </div>
                  <span className="text-xs text-muted-foreground mt-1">USD</span>
                </div>
                
                <div className="text-muted-foreground">=</div>
                
                <div className="flex-1">
                  {isPriceLoading ? (
                    <div className="flex justify-end">
                      <Loader2 className="w-4 h-4 animate-spin" />
                    </div>
                  ) : solAmount !== null ? (
                    <div className="flex items-center gap-2 justify-end">
                      <div className="text-right">
                        <div className="text-lg font-bold font-mono text-primary">
                          {solAmount.toFixed(6)} SOL
                        </div>
                        <div className="text-xs text-muted-foreground">
                          1 SOL = ${solPrice?.toFixed(2)}
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8 shrink-0"
                        onClick={handleCopySol}
                      >
                        {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                      </Button>
                    </div>
                  ) : (
                    <span className="text-sm text-muted-foreground text-right block">Digite um valor</span>
                  )}
                </div>
              </div>
              
              {/* Atalhos de valor rápido */}
              <div className="flex gap-2">
                {[25, 50, 100, 250, 500].map((val) => (
                  <Button
                    key={val}
                    variant="outline"
                    size="sm"
                    className="flex-1 text-xs h-7"
                    onClick={() => setUsdAmount(val.toString())}
                  >
                    ${val}
                  </Button>
                ))}
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                className="w-full text-xs"
                onClick={fetchSolPrice}
                disabled={isPriceLoading}
              >
                <RefreshCw className={`w-3 h-3 mr-2 ${isPriceLoading ? "animate-spin" : ""}`} />
                Atualizar cotação
              </Button>
            </div>
          )}

          {/* Botão Confirmar Entrada - FORA do conversor */}
          {onConfirmEntry && token && !currentTrade && (
            <Button
              className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold"
              onClick={() => {
                const usd = parseFloat(usdAmount) || 100;
                onConfirmEntry(token, usd);
                onClose();
              }}
            >
              <Check className="w-4 h-4 mr-2" />
              Confirmar Entrada (${parseFloat(usdAmount) || 100})
            </Button>
          )}

          {/* Se já tem operação ativa, mostrar botão de Encerrar que abre o DEX */}
          {currentTrade && token && (
            <Button
              variant="destructive"
              className="w-full font-bold"
              onClick={() => {
                // Abre o DEX para encerrar a operação
                window.open(fullUrl, "_blank");
              }}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Encerrar no DEX
            </Button>
          )}
        </div>

        {/* Tabs para mobile */}
        <div className="md:hidden px-2 py-2 border-b border-border">
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "chart" | "trade")}>
            <TabsList className="w-full">
              <TabsTrigger value="trade" className="flex-1 gap-2">
                <ShoppingCart className="w-4 h-4" />
                Swap
              </TabsTrigger>
              <TabsTrigger value="chart" className="flex-1 gap-2">
                <LineChart className="w-4 h-4" />
                Gráfico
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Conteúdo Principal */}
        <div className="flex-1 flex overflow-hidden" style={{ minHeight: "calc(95vh - 100px)" }}>
          {/* Desktop: Side by side */}
          <div className="hidden md:flex w-full">
            {/* Gráfico - 60% */}
            <div className="w-[60%] relative border-r border-border">
              {isChartLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-background/80 z-10">
                  <div className="flex flex-col items-center gap-2">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                    <p className="text-sm text-muted-foreground">Carregando gráfico...</p>
                  </div>
                </div>
              )}
              <iframe
                src={chartUrl}
                className="w-full h-full border-0"
                title={`${token.symbol} Chart`}
                onLoad={() => setIsChartLoading(false)}
                allow={iframeAllow}
                sandbox={iframeSandbox}
              />
            </div>

            {/* Terminal de Swap - 40% */}
            <div className="w-[40%] relative flex flex-col">
              <div className="px-3 py-2 border-b border-border bg-card/50 flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-primary" />
                <span className="font-semibold text-sm">Terminal de Swap</span>
                <Badge variant="secondary" className="ml-auto text-xs">
                  In-App
                </Badge>
              </div>
              
              {isSwapLoading && (
                <div className="absolute inset-0 top-10 flex items-center justify-center bg-background/80 z-10">
                  <div className="flex flex-col items-center gap-2">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                    <p className="text-sm text-muted-foreground">Carregando swap...</p>
                  </div>
                </div>
              )}
              
              <iframe
                src={swapUrl}
                className="flex-1 w-full border-0"
                title={`${token.symbol} Swap`}
                onLoad={() => setIsSwapLoading(false)}
                // Permissões para transações in-app
                allow={iframeAllow}
                sandbox={iframeSandbox}
              />
            </div>
          </div>

          {/* Mobile: Tabs */}
          <div className="md:hidden w-full">
            {activeTab === "trade" ? (
              <div className="relative h-full">
                {isSwapLoading && (
                  <div className="absolute inset-0 flex items-center justify-center bg-background/80 z-10">
                    <div className="flex flex-col items-center gap-2">
                      <Loader2 className="w-8 h-8 animate-spin text-primary" />
                      <p className="text-sm text-muted-foreground">Carregando swap...</p>
                    </div>
                  </div>
                )}
                <iframe
                  src={swapUrl}
                  className="w-full h-full border-0"
                  style={{ minHeight: "calc(95vh - 150px)" }}
                  title={`${token.symbol} Swap`}
                  onLoad={() => setIsSwapLoading(false)}
                   allow={iframeAllow}
                   sandbox={iframeSandbox}
                 />
              </div>
            ) : (
              <div className="relative h-full">
                {isChartLoading && (
                  <div className="absolute inset-0 flex items-center justify-center bg-background/80 z-10">
                    <div className="flex flex-col items-center gap-2">
                      <Loader2 className="w-8 h-8 animate-spin text-primary" />
                      <p className="text-sm text-muted-foreground">Carregando gráfico...</p>
                    </div>
                  </div>
                )}
                <iframe
                  src={chartUrl}
                  className="w-full h-full border-0"
                  style={{ minHeight: "calc(95vh - 150px)" }}
                  title={`${token.symbol} Chart`}
                  onLoad={() => setIsChartLoading(false)}
                   allow={iframeAllow}
                   sandbox={iframeSandbox}
                 />
              </div>
            )}
          </div>
        </div>

        {/* Footer com info do token */}
        <div className="px-4 py-2 border-t border-border bg-card/30 flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <BarChart3 className="w-3 h-3" />
              Preço: ${token.priceUsd < 0.01 ? token.priceUsd.toExponential(4) : token.priceUsd.toFixed(6)}
            </span>
            <span className={`flex items-center gap-1 ${token.priceChange24h >= 0 ? "text-green-500" : "text-red-500"}`}>
              <TrendingUp className="w-3 h-3" />
              24h: {token.priceChange24h >= 0 ? "+" : ""}{token.priceChange24h.toFixed(2)}%
            </span>
          </div>
          <span className="font-mono truncate max-w-[200px]" title={tokenData.tokenAddress || ""}>
            {tokenData.tokenAddress?.slice(0, 8)}...{tokenData.tokenAddress?.slice(-6)}
          </span>
        </div>
      </DialogContent>
    </Dialog>
  );
};
