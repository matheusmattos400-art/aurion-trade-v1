import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useBinanceWebSocket } from "@/hooks/useBinanceWebSocket";
import { useState } from "react";
import { Wifi, WifiOff, RefreshCw } from "lucide-react";

export const WebSocketTest = () => {
  const [enabled, setEnabled] = useState(false);
  const { isConnected, error, accountData, orderUpdate, reconnect } = useBinanceWebSocket(enabled);

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {isConnected ? (
            <Wifi className="w-5 h-5 text-green-500" />
          ) : (
            <WifiOff className="w-5 h-5 text-red-500" />
          )}
          Teste WebSocket Binance
        </CardTitle>
        <CardDescription>
          Teste de conexão com o User Data Stream via proxy WebSocket
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4">
          <Button
            onClick={() => setEnabled(!enabled)}
            variant={enabled ? "destructive" : "default"}
          >
            {enabled ? "Desconectar" : "Conectar"}
          </Button>
          
          {enabled && (
            <Button
              onClick={reconnect}
              variant="outline"
              size="icon"
            >
              <RefreshCw className="w-4 h-4" />
            </Button>
          )}

          <Badge variant={isConnected ? "default" : "secondary"}>
            {isConnected ? "Conectado" : "Desconectado"}
          </Badge>
        </div>

        {error && (
          <div className="p-4 bg-destructive/10 border border-destructive rounded-lg space-y-2">
            <p className="text-sm text-destructive font-medium">Erro:</p>
            <p className="text-sm text-destructive/80">{error}</p>
            
            {error.includes('insegura') && (
              <div className="mt-3 p-3 bg-background/50 rounded border border-primary/20">
                <p className="text-xs font-medium mb-2">💡 Solução:</p>
                <p className="text-xs text-muted-foreground mb-2">
                  Configure SSL/TLS no seu VPS para usar WebSocket Seguro (wss://)
                </p>
                <div className="text-xs space-y-1 text-muted-foreground">
                  <p><strong>Opção 1 (Rápida):</strong> Cloudflare Tunnel - 5 min, grátis</p>
                  <p><strong>Opção 2:</strong> Nginx + Let's Encrypt - requer domínio</p>
                  <p className="mt-2 text-primary">Veja: vps-setup/QUICK_FIX_WSS.md</p>
                </div>
              </div>
            )}
          </div>
        )}

        {accountData && (
          <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
            <p className="text-sm font-medium mb-2">Account Update Recebido:</p>
            <pre className="text-xs overflow-auto max-h-40 bg-background/50 p-2 rounded">
              {JSON.stringify(accountData, null, 2)}
            </pre>
          </div>
        )}

        {orderUpdate && (
          <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
            <p className="text-sm font-medium mb-2">Order Update Recebido:</p>
            <pre className="text-xs overflow-auto max-h-40 bg-background/50 p-2 rounded">
              {JSON.stringify(orderUpdate, null, 2)}
            </pre>
          </div>
        )}

        <div className="text-xs text-muted-foreground space-y-1">
          <p>• Porta WebSocket: 3001</p>
          <p>• Porta REST API: 3000</p>
          <p>• Proxy: SOCKS5 → Binance</p>
        </div>
      </CardContent>
    </Card>
  );
};
