import { useState, useEffect, useRef } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";

interface ADXIndicatorChartProps {
  symbol: string;
  settings: {
    adxPeriod: number;
    adxSmoothing: number;
  };
}

interface ADXData {
  time: string;
  timestamp: number;
  adx: number;
  plusDI: number;
  minusDI: number;
}

export const ADXIndicatorChart = ({ symbol, settings }: ADXIndicatorChartProps) => {
  const [data, setData] = useState<ADXData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<NodeJS.Timeout>();

  // Wilder's Smoothing Method (RMA - Running Moving Average)
  const wilderSmooth = (values: number[], period: number): number[] => {
    const result: number[] = [];
    let prevSmoothed = 0;

    for (let i = 0; i < values.length; i++) {
      if (i < period - 1) {
        // Accumulate for initial SMA
        result.push(0);
      } else if (i === period - 1) {
        // First value is SMA
        let sum = 0;
        for (let j = 0; j < period; j++) {
          sum += values[i - j];
        }
        prevSmoothed = sum / period;
        result.push(prevSmoothed);
      } else {
        // Wilder's smoothing: prev * (period-1)/period + current * 1/period
        prevSmoothed = (prevSmoothed * (period - 1) + values[i]) / period;
        result.push(prevSmoothed);
      }
    }
    return result;
  };

  useEffect(() => {
    if (!symbol) {
      setIsLoading(false);
      return;
    }

    const fetchADXData = async () => {
      try {
        setIsLoading(true);
        setError(null);

        const period = settings.adxPeriod; // 14
        const limit = 150; // Need enough data for proper calculation

        const response = await fetch(
          `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=5m&limit=${limit}`
        );

        if (!response.ok) {
          throw new Error("Erro ao buscar dados da Binance");
        }

        const klines = await response.json();

        if (klines.length < period * 2) {
          throw new Error("Dados insuficientes");
        }

        // Arrays for calculations
        const trValues: number[] = [];
        const plusDMValues: number[] = [];
        const minusDMValues: number[] = [];

        // Calculate TR, +DM, -DM for each candle (starting from index 1)
        for (let i = 1; i < klines.length; i++) {
          const high = parseFloat(klines[i][2]);
          const low = parseFloat(klines[i][3]);
          const close = parseFloat(klines[i][4]);
          const prevHigh = parseFloat(klines[i - 1][2]);
          const prevLow = parseFloat(klines[i - 1][3]);
          const prevClose = parseFloat(klines[i - 1][4]);

          // True Range (Wilder's definition)
          const tr = Math.max(
            high - low,
            Math.abs(high - prevClose),
            Math.abs(low - prevClose)
          );
          trValues.push(tr);

          // Directional Movement
          const upMove = high - prevHigh;
          const downMove = prevLow - low;

          // +DM: upMove if upMove > downMove AND upMove > 0, else 0
          const plusDM = upMove > downMove && upMove > 0 ? upMove : 0;
          // -DM: downMove if downMove > upMove AND downMove > 0, else 0
          const minusDM = downMove > upMove && downMove > 0 ? downMove : 0;

          plusDMValues.push(plusDM);
          minusDMValues.push(minusDM);
        }

        // Apply Wilder's smoothing to TR, +DM, -DM
        const smoothedTR = wilderSmooth(trValues, period);
        const smoothedPlusDM = wilderSmooth(plusDMValues, period);
        const smoothedMinusDM = wilderSmooth(minusDMValues, period);

        // Calculate +DI, -DI, and DX
        const plusDI: number[] = [];
        const minusDI: number[] = [];
        const dx: number[] = [];

        for (let i = 0; i < smoothedTR.length; i++) {
          if (smoothedTR[i] === 0 || i < period - 1) {
            plusDI.push(0);
            minusDI.push(0);
            dx.push(0);
          } else {
            // +DI = 100 * Smoothed +DM / Smoothed TR
            const pdi = (smoothedPlusDM[i] / smoothedTR[i]) * 100;
            // -DI = 100 * Smoothed -DM / Smoothed TR
            const mdi = (smoothedMinusDM[i] / smoothedTR[i]) * 100;

            plusDI.push(pdi);
            minusDI.push(mdi);

            // DX = 100 * |+DI - -DI| / (+DI + -DI)
            const diSum = pdi + mdi;
            const dxValue = diSum === 0 ? 0 : (Math.abs(pdi - mdi) / diSum) * 100;
            dx.push(dxValue);
          }
        }

        // Apply Wilder's smoothing to DX to get ADX
        const adx = wilderSmooth(dx, period);

        // Prepare chart data (last 50 candles)
        const chartData: ADXData[] = [];
        const displayCount = 50;
        const startIndex = Math.max(period * 2, klines.length - displayCount - 1);

        for (let i = startIndex; i < klines.length - 1; i++) {
          const dataIndex = i - 1; // Offset because TR/DM arrays start from index 1
          if (dataIndex < 0 || dataIndex >= adx.length) continue;

          const timestamp = new Date(klines[i][0]);
          const timeKey = timestamp.toLocaleTimeString('pt-BR', { 
            hour: '2-digit', 
            minute: '2-digit' 
          });

          const currentADX = adx[dataIndex];
          const currentPlusDI = plusDI[dataIndex];
          const currentMinusDI = minusDI[dataIndex];

          // Only include data points with valid calculations
          if (currentADX > 0 || currentPlusDI > 0 || currentMinusDI > 0) {
            chartData.push({
              time: timeKey,
              timestamp: klines[i][0],
              adx: parseFloat(currentADX.toFixed(2)),
              plusDI: parseFloat(currentPlusDI.toFixed(2)),
              minusDI: parseFloat(currentMinusDI.toFixed(2))
            });
          }
        }

        setData(chartData);
        setIsLoading(false);
      } catch (err) {
        console.error('Erro ao calcular ADX:', err);
        setError(err instanceof Error ? err.message : 'Erro desconhecido');
        setIsLoading(false);
      }
    };

    fetchADXData();
    intervalRef.current = setInterval(fetchADXData, 30000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [symbol, settings.adxPeriod, settings.adxSmoothing]);

  // Custom tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataPoint = payload[0]?.payload as ADXData;
      const trend = dataPoint.plusDI > dataPoint.minusDI ? 'Alta' : 'Baixa';
      const trendColor = dataPoint.plusDI > dataPoint.minusDI ? 'text-green-500' : 'text-red-500';
      const strength = dataPoint.adx > 25 ? 'Forte' : dataPoint.adx > 20 ? 'Moderada' : 'Fraca';

      return (
        <div className="bg-background/95 border border-border rounded-lg p-3 shadow-lg">
          <p className="text-xs text-muted-foreground mb-2">{label}</p>
          <div className="space-y-1">
            <p className="text-sm font-medium text-white">
              ADX: {dataPoint.adx.toFixed(2)} <span className="text-xs text-muted-foreground">({strength})</span>
            </p>
            <p className="text-sm font-medium text-green-500">
              +DI: {dataPoint.plusDI.toFixed(2)}
            </p>
            <p className="text-sm font-medium text-red-500">
              -DI: {dataPoint.minusDI.toFixed(2)}
            </p>
            <p className={`text-xs font-medium mt-1 ${trendColor}`}>
              Tendência: {trend}
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  if (isLoading) {
    return (
      <div className="h-[180px] flex items-center justify-center text-muted-foreground">
        <div className="animate-pulse">Calculando ADX/DI...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-[180px] flex items-center justify-center text-red-400 text-sm">
        {error}
      </div>
    );
  }

  // Get current values for status display
  const currentData = data[data.length - 1];
  const trend = currentData ? (currentData.plusDI > currentData.minusDI ? 'ALTA' : 'BAIXA') : '-';
  const trendStrength = currentData ? (currentData.adx > 25 ? 'Forte' : currentData.adx > 20 ? 'Moderada' : 'Lateral') : '-';

  return (
    <div className="space-y-4">
      {/* Header com status atual */}
      <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-muted/30 to-transparent rounded-lg">
        <div className="flex items-center gap-4">
          <div>
            <h4 className="text-sm font-bold text-foreground">
              📊 Indicador ADX/DMI
            </h4>
            <p className="text-xs text-muted-foreground">Período: {settings.adxPeriod}</p>
          </div>
          {currentData && (
            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                trend === 'ALTA' ? 'bg-green-500/20 text-green-400 border border-green-500/40' : 'bg-red-500/20 text-red-400 border border-red-500/40'
              }`}>
                {trend === 'ALTA' ? '↗ ALTA' : '↘ BAIXA'}
              </span>
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                trendStrength === 'Forte' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 
                trendStrength === 'Moderada' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/40' : 
                'bg-gray-500/20 text-gray-400 border border-gray-500/40'
              }`}>
                {trendStrength}
              </span>
            </div>
          )}
        </div>
        <div className="flex gap-4 text-xs">
          <span className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-white shadow-sm shadow-white/30"></span>
            <span className="text-muted-foreground">ADX</span>
          </span>
          <span className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-green-500 shadow-sm shadow-green-500/30"></span>
            <span className="text-muted-foreground">+DI</span>
          </span>
          <span className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-500 shadow-sm shadow-red-500/30"></span>
            <span className="text-muted-foreground">-DI</span>
          </span>
        </div>
      </div>

      {/* Gráfico maior */}
      <div className="h-[280px] bg-gradient-to-b from-muted/10 to-transparent rounded-lg p-2">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 15, left: 5, bottom: 40 }}>
            <XAxis 
              dataKey="time" 
              tick={{ fill: '#888', fontSize: 10 }}
              interval={Math.floor(data.length / 10)}
              angle={-45}
              textAnchor="end"
              height={55}
            />
            <YAxis 
              tick={{ fill: '#888', fontSize: 11 }}
              domain={[0, 100]}
              ticks={[0, 20, 40, 60, 80, 100]}
              width={35}
            />
            <Tooltip content={<CustomTooltip />} />
            
            {/* Threshold line at 20 (lateralization limit) */}
            <ReferenceLine 
              y={20} 
              stroke="#666" 
              strokeDasharray="5 5" 
              label={{ 
                value: 'Lateral', 
                position: 'right', 
                fill: '#888', 
                fontSize: 11 
              }}
            />

            {/* ADX Line (White) */}
            <Line 
              type="monotone" 
              dataKey="adx" 
              stroke="#ffffff" 
              strokeWidth={2.5}
              dot={false}
              name="ADX"
              isAnimationActive={false}
            />
            
            {/* +DI Line (Green) */}
            <Line 
              type="monotone" 
              dataKey="plusDI" 
              stroke="#22c55e" 
              strokeWidth={2}
              dot={false}
              name="+DI"
              isAnimationActive={false}
            />
            
            {/* -DI Line (Red) */}
            <Line 
              type="monotone" 
              dataKey="minusDI" 
              stroke="#ef4444" 
              strokeWidth={2}
              dot={false}
              name="-DI"
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Current values display - mais destacado */}
      {currentData && (
        <div className="flex justify-center gap-8 py-3 px-4 bg-muted/20 rounded-lg">
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">ADX</p>
            <p className="text-lg font-bold text-white">{currentData.adx.toFixed(1)}</p>
          </div>
          <div className="h-10 w-px bg-border/50"></div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">+DI (Alta)</p>
            <p className="text-lg font-bold text-green-500">{currentData.plusDI.toFixed(1)}</p>
          </div>
          <div className="h-10 w-px bg-border/50"></div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">-DI (Baixa)</p>
            <p className="text-lg font-bold text-red-500">{currentData.minusDI.toFixed(1)}</p>
          </div>
        </div>
      )}
    </div>
  );
};
