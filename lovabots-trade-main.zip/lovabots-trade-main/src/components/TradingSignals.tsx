import { useState, useEffect, useRef, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  RefreshCw, 
  Scan, 
  AlertCircle,
  TrendingUp,
  Clock,
  Zap,
  Search,
  X
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { usePairScanner } from "@/hooks/usePairScanner";
import { useBinancePrices } from "@/hooks/useBinancePrices";
import { TradingSignal } from "@/utils/pairScanner";
import { TradingConfig } from "./TradingConfig";
import { SignalCard } from "./SignalCard";
import { SignalDetailsModal } from "./SignalDetailsModal";

interface ActiveOperation {
  id?: string;
  longSymbol: string;
  shortSymbol: string;
  leverageLong: number;
  leverageShort: number;
  amount: number;
  entryPriceLong: number;
  entryPriceShort: number;
  startTime: Date;
  profitTarget?: number;
  autoCloseEnabled?: boolean;
  isTest?: boolean;
  entryMomentum?: number;
}

interface TradingSignalsProps {
  onOperationStart: (data: {
    id?: string;
    longSymbol: string;
    shortSymbol: string;
    leverageLong: number;
    leverageShort: number;
    amount: number;
    entryPriceLong: number;
    entryPriceShort: number;
    startTime: Date;
    profitTarget: number;
    autoCloseEnabled: boolean;
    isTest?: boolean;
  }) => void;
  binanceBalance: number;
  activeOperation?: ActiveOperation | null;
  onPnlUpdate?: (pnl: number) => void;
  onOperationClose?: () => void;
  onTargetReached?: () => void;
}

export const TradingSignals = ({ 
  onOperationStart, 
  binanceBalance,
  activeOperation,
  onPnlUpdate,
  onOperationClose,
  onTargetReached,
}: TradingSignalsProps) => {
  const [investment, setInvestment] = useState(100);
  const [leverage, setLeverage] = useState(50);
  const [profitTarget, setProfitTarget] = useState(3);
  const [autoCloseEnabled, setAutoCloseEnabled] = useState(true);
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [selectedSignal, setSelectedSignal] = useState<TradingSignal | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [loadingSignalId, setLoadingSignalId] = useState<string | null>(null);
  const [swappedSignals, setSwappedSignals] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");
  
  // Estados locais para edição da operação ativa
  const [activeAutoClose, setActiveAutoClose] = useState(activeOperation?.autoCloseEnabled ?? true);
  const [activeProfitTarget, setActiveProfitTarget] = useState(activeOperation?.profitTarget ?? 0);

  // Carregar configurações salvas do banco de dados
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const { data: settings } = await supabase
          .from('user_trading_settings')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        if (settings) {
          setInvestment(Number(settings.investment_amount));
          setLeverage(settings.leverage);
          setProfitTarget(settings.profit_target);
          setAutoCloseEnabled(settings.auto_close_enabled);
        }
        setSettingsLoaded(true);
      } catch (error) {
        console.error('Erro ao carregar configurações:', error);
        setSettingsLoaded(true);
      }
    };

    loadSettings();
  }, []);

  // Salvar configurações no banco de dados quando mudarem
  const saveSettings = async (newInvestment: number, newLeverage: number, newProfitTarget: number, newAutoClose: boolean) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('user_trading_settings')
        .upsert({
          user_id: user.id,
          investment_amount: newInvestment,
          leverage: newLeverage,
          profit_target: newProfitTarget,
          auto_close_enabled: newAutoClose,
        }, {
          onConflict: 'user_id'
        });

      if (error) throw error;
    } catch (error) {
      console.error('Erro ao salvar configurações:', error);
    }
  };

  // Handlers que salvam no banco
  const handleInvestmentChange = (value: number) => {
    setInvestment(value);
    saveSettings(value, leverage, profitTarget, autoCloseEnabled);
  };

  const handleLeverageChange = (value: number) => {
    setLeverage(value);
    saveSettings(investment, value, profitTarget, autoCloseEnabled);
  };

  const handleProfitTargetChange = (value: number) => {
    setProfitTarget(value);
    saveSettings(investment, leverage, value, autoCloseEnabled);
  };

  const handleAutoCloseChange = (value: boolean) => {
    setAutoCloseEnabled(value);
    saveSettings(investment, leverage, profitTarget, value);
  };
  
  // Sincronizar estados com a operação ativa quando ela muda
  useEffect(() => {
    if (activeOperation) {
      setActiveAutoClose(activeOperation.autoCloseEnabled ?? true);
      setActiveProfitTarget(activeOperation.profitTarget ?? 0);
    }
  }, [activeOperation?.id, activeOperation?.autoCloseEnabled, activeOperation?.profitTarget]);
  
  const { toast } = useToast();
  const { signals, isScanning, lastScanTime, error, rescan } = usePairScanner(true, 60000);

  const hasActiveOperation = !!activeOperation;
  const activeSymbols = activeOperation ? [activeOperation.longSymbol, activeOperation.shortSymbol] : [];
  const { prices } = useBinancePrices(activeSymbols);
  const targetReachedCalledRef = useRef(false);

  useEffect(() => {
    targetReachedCalledRef.current = false;
  }, [activeOperation?.id]);

  let activePnl: number | null = null;
  let liveMomentum: number | null = null;
  const [lastClosedPrices, setLastClosedPrices] = useState<{ long: number; short: number } | null>(null);

  // Fetch last closed candle prices for momentum calculation (every 30 seconds)
  useEffect(() => {
    if (!activeOperation) {
      setLastClosedPrices(null);
      return;
    }

    const fetchLastClosedPrices = async () => {
      try {
        const [longRes, shortRes] = await Promise.all([
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${activeOperation.longSymbol}&interval=30m&limit=2`),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${activeOperation.shortSymbol}&interval=30m&limit=2`)
        ]);

        if (longRes.ok && shortRes.ok) {
          const longKlines = await longRes.json();
          const shortKlines = await shortRes.json();
          
          // Get the last CLOSED candle (index 0, since index 1 is current)
          if (longKlines.length >= 2 && shortKlines.length >= 2) {
            setLastClosedPrices({
              long: parseFloat(longKlines[0][4]), // Close price of last closed candle
              short: parseFloat(shortKlines[0][4])
            });
          }
        }
      } catch (error) {
        console.error("Error fetching last closed prices:", error);
      }
    };

    fetchLastClosedPrices();
    const interval = setInterval(fetchLastClosedPrices, 30000);
    return () => clearInterval(interval);
  }, [activeOperation?.longSymbol, activeOperation?.shortSymbol]);

  if (activeOperation && activeSymbols.length === 2) {
    const entryPriceLong = activeOperation.entryPriceLong;
    const entryPriceShort = activeOperation.entryPriceShort;

    const currentLongPrice = prices.find(p => p.symbol === activeOperation.longSymbol)?.price || 0;
    const currentShortPrice = prices.find(p => p.symbol === activeOperation.shortSymbol)?.price || 0;

    if (entryPriceLong > 0 && entryPriceShort > 0) {
      const longMargin = activeOperation.amount / 2;
      const shortMargin = activeOperation.amount / 2;
      const longNotional = longMargin * activeOperation.leverageLong;
      const shortNotional = shortMargin * activeOperation.leverageShort;

      const longPnl = ((currentLongPrice - entryPriceLong) / entryPriceLong) * longNotional;
      const shortPnl = ((entryPriceShort - currentShortPrice) / entryPriceShort) * shortNotional;

      activePnl = longPnl + shortPnl;
    }

    // Calculate live momentum using the SAME formula as MomentumIndicator
    // Momentum = ((currentRatio - prevRatio) / prevRatio) * 100
    // Where prevRatio is from the last CLOSED candle
    if (currentLongPrice > 0 && currentShortPrice > 0 && lastClosedPrices) {
      const prevRatio = lastClosedPrices.long / lastClosedPrices.short;
      const currentRatio = currentLongPrice / currentShortPrice;
      liveMomentum = ((currentRatio - prevRatio) / prevRatio) * 100;
    }
  }

  useEffect(() => {
    if (!activeOperation || activePnl === null) return;

    onPnlUpdate?.(activePnl);

    // Usar estados locais para verificação de auto-close (atualizados em tempo real)
    if (activeAutoClose && activeProfitTarget && onTargetReached) {
      const bufferAmount = activeOperation.amount * 0.002;
      const targetWithBuffer = activeProfitTarget + bufferAmount;

      if (activePnl >= targetWithBuffer && !targetReachedCalledRef.current) {
        targetReachedCalledRef.current = true;
        onTargetReached();
      }
    }
  }, [activePnl, activeOperation, onPnlUpdate, onTargetReached, activeAutoClose, activeProfitTarget]);
  const handleOpenTrade = async (signal: TradingSignal, isTest: boolean = false) => {
    if (hasActiveOperation) {
      toast({
        title: "Operação já ativa",
        description: "Encerre a operação atual antes de abrir uma nova.",
        variant: "destructive",
      });
      return;
    }

    setLoadingSignalId(signal.id);
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Erro de autenticação",
          description: "Faça login para continuar",
          variant: "destructive",
        });
        return;
      }

      // Validações
      if (investment < 10) {
        toast({
          title: "Investimento inválido",
          description: "O valor mínimo é $10",
          variant: "destructive",
        });
        return;
      }

      // Só validar saldo para operações reais
      if (!isTest && investment > binanceBalance) {
        toast({
          title: "Saldo insuficiente",
          description: `Seu saldo é $${binanceBalance.toFixed(2)}`,
          variant: "destructive",
        });
        return;
      }

      // Buscar preços atuais
      const [longPriceRes, shortPriceRes] = await Promise.all([
        fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${signal.longSymbol}`),
        fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${signal.shortSymbol}`),
      ]);

      const longPriceData = await longPriceRes.json();
      const shortPriceData = await shortPriceRes.json();

      const entryPriceLong = parseFloat(longPriceData.price);
      const entryPriceShort = parseFloat(shortPriceData.price);

      // Calcular meta em USDT baseado na porcentagem do investimento (sem alavancagem)
      const profitTargetUSDT = (investment * profitTarget) / 100;

      // Só executar ordens reais se não for teste
      if (!isTest) {
        // Configurar alavancagem na Binance
        await Promise.all([
          supabase.functions.invoke('binance-trading', {
            body: { action: 'set_leverage', symbol: signal.longSymbol, leverage }
          }),
          supabase.functions.invoke('binance-trading', {
            body: { action: 'set_leverage', symbol: signal.shortSymbol, leverage }
          }),
        ]);

        // Criar ordens
        const halfAmount = investment / 2;

        const [longOrder, shortOrder] = await Promise.all([
          supabase.functions.invoke('binance-trading', {
            body: {
              action: 'create_order',
              symbol: signal.longSymbol,
              side: 'BUY',
              quantity: (halfAmount * leverage) / entryPriceLong,
            }
          }),
          supabase.functions.invoke('binance-trading', {
            body: {
              action: 'create_order',
              symbol: signal.shortSymbol,
              side: 'SELL',
              quantity: (halfAmount * leverage) / entryPriceShort,
            }
          }),
        ]);

        if (longOrder.error || shortOrder.error) {
          throw new Error(longOrder.error?.message || shortOrder.error?.message || 'Erro ao criar ordens');
        }
      }

      // Salvar operação no banco
      const { data: newOp, error: dbError } = await supabase
        .from('active_operations')
        .insert({
          user_id: user.id,
          long_symbol: signal.longSymbol,
          short_symbol: signal.shortSymbol,
          leverage: leverage,
          leverage_long: leverage,
          leverage_short: leverage,
          investment_amount: investment,
          entry_price_long: entryPriceLong,
          entry_price_short: entryPriceShort,
          profit_target: profitTargetUSDT,
          auto_close_enabled: autoCloseEnabled,
          is_test: isTest,
          trading_mode: 'crypto',
          status: 'active',
          long_order_id: isTest ? null : null,
          short_order_id: isTest ? null : null,
        })
        .select()
        .single();

      if (dbError) throw dbError;

      // Notificar componente pai
      onOperationStart({
        id: newOp.id,
        longSymbol: signal.longSymbol,
        shortSymbol: signal.shortSymbol,
        leverageLong: leverage,
        leverageShort: leverage,
        amount: investment,
        entryPriceLong,
        entryPriceShort,
        startTime: new Date(),
        profitTarget: profitTargetUSDT,
        autoCloseEnabled: autoCloseEnabled,
        isTest: isTest,
      });

      toast({
        title: isTest ? "🧪 Operação TESTE iniciada!" : "✅ Operação iniciada!",
        description: `${signal.longSymbol.replace("USDT", "")}/${signal.shortSymbol.replace("USDT", "")} | Meta: $${profitTargetUSDT.toFixed(2)}`,
      });

    } catch (error) {
      console.error("Erro ao abrir operação:", error);
      toast({
        title: "Erro ao abrir operação",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setLoadingSignalId(null);
    }
  };

  const handleShowDetails = (signal: TradingSignal) => {
    setSelectedSignal(signal);
    setIsDetailsOpen(true);
  };

  // Handler para inverter os símbolos long/short de um sinal
  const handleSwapSymbols = (signal: TradingSignal) => {
    setSwappedSignals(prev => {
      const newSet = new Set(prev);
      if (newSet.has(signal.id)) {
        newSet.delete(signal.id);
      } else {
        newSet.add(signal.id);
      }
      return newSet;
    });
  };

  // Função para obter o sinal com símbolos possivelmente invertidos
  const getDisplaySignal = (signal: TradingSignal): TradingSignal => {
    if (swappedSignals.has(signal.id)) {
      return {
        ...signal,
        longSymbol: signal.shortSymbol,
        shortSymbol: signal.longSymbol,
        currentMomentum: -signal.currentMomentum, // Inverter momentum
      };
    }
    return signal;
  };

  // Filtrar sinais com base na busca
  const filteredSignals = useMemo(() => {
    if (!searchQuery.trim()) return signals;
    
    const query = searchQuery.toUpperCase().trim();
    return signals.filter(signal => 
      signal.longSymbol.includes(query) || 
      signal.shortSymbol.includes(query) ||
      signal.longSymbol.replace("USDT", "").includes(query) ||
      signal.shortSymbol.replace("USDT", "").includes(query)
    );
  }, [signals, searchQuery]);

  const handleActiveAutoCloseChange = async (enabled: boolean) => {
    if (!activeOperation?.id) return;
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({ title: "Erro", description: "Usuário não autenticado", variant: "destructive" });
        return;
      }

      const { error } = await supabase
        .from('active_operations')
        .update({ auto_close_enabled: enabled })
        .eq('id', activeOperation.id)
        .eq('user_id', user.id);

      if (error) throw error;

      setActiveAutoClose(enabled);
      toast({ title: enabled ? "Saída automática ativada" : "Saída automática desativada" });
    } catch (error) {
      console.error('Erro ao atualizar auto-close:', error);
      toast({ title: "Erro ao atualizar", variant: "destructive" });
    }
  };

  const handleActiveProfitTargetChange = async (target: number) => {
    if (!activeOperation?.id) return;
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({ title: "Erro", description: "Usuário não autenticado", variant: "destructive" });
        return;
      }

      const { error } = await supabase
        .from('active_operations')
        .update({ profit_target: target })
        .eq('id', activeOperation.id)
        .eq('user_id', user.id);

      if (error) throw error;

      setActiveProfitTarget(target);
      toast({ title: `Meta atualizada para $${target.toFixed(2)}` });
    } catch (error) {
      console.error('Erro ao atualizar meta:', error);
      toast({ title: "Erro ao atualizar meta", variant: "destructive" });
    }
  };

  

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Zap className="h-6 w-6 text-primary" />
            {hasActiveOperation ? "Operação em Andamento" : "Sinais de Entrada"}
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            {hasActiveOperation 
              ? "Acompanhe sua operação ativa em tempo real"
              : "Pares com correlação e momentum dentro do operacional"
            }
          </p>
        </div>
        
        {!hasActiveOperation && (
          <div className="flex items-center gap-3">
            {/* Barra de Busca */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Buscar moeda..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-8 h-9 w-[160px] sm:w-[200px] bg-card/50 border-border/50 focus:border-primary"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1 hover:bg-muted rounded-full transition-colors"
                >
                  <X className="h-3 w-3 text-muted-foreground" />
                </button>
              )}
            </div>
            
            {lastScanTime && (
              <div className="hidden sm:flex items-center gap-2 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                <span>Atualizado: {lastScanTime.toLocaleTimeString()}</span>
              </div>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={rescan}
              disabled={isScanning}
              className="gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${isScanning ? 'animate-spin' : ''}`} />
              {isScanning ? 'Escaneando...' : 'Atualizar'}
            </Button>
          </div>
        )}
      </div>

      {/* Operação em Aberto - card separado no topo */}
      {hasActiveOperation && activeOperation && (() => {
        // Encontrar o sinal correspondente à operação ativa
        const activeSignal = signals.find(
          s => s.longSymbol === activeOperation.longSymbol && s.shortSymbol === activeOperation.shortSymbol
        );

        // Se não encontrar nos sinais, criar um sinal "virtual" baseado na operação
        const signalToShow: TradingSignal = activeSignal || {
          id: `active-${activeOperation.id}`,
          longSymbol: activeOperation.longSymbol,
          shortSymbol: activeOperation.shortSymbol,
          strategy: "micro_distortion" as const,
          zScore: 0,
          correlation: 0,
          correlation5d: 0,
          correlation25d: 0,
          correlation2m: 0,
          momentumAge: 0,
          currentMomentum: 0,
          avgBullish: 0,
          avgBearish: 0,
          liquidityRatio: 0,
          message: "Operação em andamento",
          timestamp: activeOperation.startTime,
          status: "ready" as const,
        };

        return (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <h3 className="text-lg font-semibold text-emerald-400">Operação em Aberto</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <SignalCard
                key={signalToShow.id}
                signal={signalToShow}
                onOpenTrade={handleOpenTrade}
                onShowDetails={handleShowDetails}
                isLoading={false}
                isActive={true}
                pnl={activePnl !== null ? activePnl : undefined}
                profitTarget={activeProfitTarget}
                onCloseTrade={onOperationClose}
                liveMomentum={liveMomentum !== null ? liveMomentum : undefined}
                autoCloseEnabled={activeAutoClose}
                onAutoCloseChange={handleActiveAutoCloseChange}
                onProfitTargetChange={handleActiveProfitTargetChange}
                operationId={activeOperation.id}
              />
            </div>
          </div>
        );
      })()}

      {/* Configurações */}
      <TradingConfig
        investment={investment}
        leverage={leverage}
        profitTarget={profitTarget}
        autoCloseEnabled={autoCloseEnabled}
        onInvestmentChange={handleInvestmentChange}
        onLeverageChange={handleLeverageChange}
        onProfitTargetChange={handleProfitTargetChange}
        onAutoCloseChange={handleAutoCloseChange}
      />

      {/* Status do Scanner */}
      {isScanning && signals.length === 0 && (
        <Card className="p-8 bg-card/50 border-border/50">
          <div className="flex flex-col items-center justify-center gap-4">
            <div className="relative">
              <Scan className="h-12 w-12 text-primary animate-pulse" />
              <div className="absolute inset-0 h-12 w-12 border-2 border-primary/30 rounded-full animate-ping" />
            </div>
            <div className="text-center">
              <h3 className="text-lg font-semibold text-foreground">Escaneando o mercado...</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Analisando correlação e momentum de 190 combinações de pares
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Erro */}
      {error && (
        <Card className="p-4 bg-destructive/10 border-destructive/30">
          <div className="flex items-center gap-3">
            <AlertCircle className="h-5 w-5 text-destructive" />
            <div>
              <p className="font-medium text-destructive">Erro no escaneamento</p>
              <p className="text-sm text-muted-foreground">{error}</p>
            </div>
          </div>
        </Card>
      )}

      {/* Sem sinais */}
      {!isScanning && signals.length === 0 && !error && !hasActiveOperation && (
        <Card className="p-8 bg-card/50 border-border/50">
          <div className="flex flex-col items-center justify-center gap-4 text-center">
            <TrendingUp className="h-12 w-12 text-muted-foreground/50" />
            <div>
              <h3 className="text-lg font-semibold text-foreground">Nenhum sinal disponível</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Aguardando oportunidades com correlação alta e momentum recente
              </p>
            </div>
            <Button variant="outline" onClick={rescan} className="mt-2">
              <RefreshCw className="h-4 w-4 mr-2" />
              Escanear novamente
            </Button>
          </div>
        </Card>
      )}

      {/* Sinais Prontos para Entrada (excluindo o sinal ativo) */}
      {filteredSignals.filter(s => {
        if (s.status !== "ready") return false;
        // Excluir o sinal que está ativo (já aparece no topo)
        if (hasActiveOperation && activeOperation && 
            s.longSymbol === activeOperation.longSymbol && 
            s.shortSymbol === activeOperation.shortSymbol) {
          return false;
        }
        return true;
      }).length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            <h3 className="text-lg font-semibold text-foreground">Prontos para Entrada</h3>
            <Badge variant="secondary" className="bg-green-500/20 text-green-500">
              {filteredSignals.filter(s => {
                if (s.status !== "ready") return false;
                if (hasActiveOperation && activeOperation && 
                    s.longSymbol === activeOperation.longSymbol && 
                    s.shortSymbol === activeOperation.shortSymbol) {
                  return false;
                }
                return true;
              }).length}
            </Badge>
            {searchQuery && (
              <span className="text-xs text-muted-foreground ml-2">
                buscando "{searchQuery}"
              </span>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSignals.filter(s => {
              if (s.status !== "ready") return false;
              if (hasActiveOperation && activeOperation && 
                  s.longSymbol === activeOperation.longSymbol && 
                  s.shortSymbol === activeOperation.shortSymbol) {
                return false;
              }
              return true;
            }).map((signal) => {
              const displaySignal = getDisplaySignal(signal);
              return (
                <SignalCard
                  key={signal.id}
                  signal={displaySignal}
                  onOpenTrade={handleOpenTrade}
                  onShowDetails={handleShowDetails}
                  isLoading={loadingSignalId === signal.id}
                  onSwapSymbols={() => handleSwapSymbols(signal)}
                />
              );
            })}
          </div>
        </div>
      )}

      {/* Sinais Próximos de Entrada */}
      {filteredSignals.filter(s => s.status === "pending").length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <div className="h-2 w-2 rounded-full bg-yellow-500" />
            <h3 className="text-lg font-semibold text-foreground">Próximos de Entrada</h3>
            <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-500">
              {filteredSignals.filter(s => s.status === "pending").length}
            </Badge>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSignals.filter(s => s.status === "pending").map((signal) => {
              const displaySignal = getDisplaySignal(signal);
              return (
                <SignalCard
                  key={signal.id}
                  signal={displaySignal}
                  onOpenTrade={handleOpenTrade}
                  onShowDetails={handleShowDetails}
                  isLoading={loadingSignalId === signal.id}
                  isPending
                  onSwapSymbols={() => handleSwapSymbols(signal)}
                />
              );
            })}
          </div>
        </div>
      )}

      {/* Nenhum resultado de busca */}
      {searchQuery && filteredSignals.length === 0 && signals.length > 0 && (
        <Card className="p-6 bg-card/50 border-border/50">
          <div className="flex flex-col items-center justify-center gap-3 text-center">
            <Search className="h-10 w-10 text-muted-foreground/50" />
            <div>
              <h3 className="text-base font-semibold text-foreground">Nenhuma moeda encontrada</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Não encontramos sinais para "{searchQuery}"
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={() => setSearchQuery("")}>
              Limpar busca
            </Button>
          </div>
        </Card>
      )}

      {/* Modal de Detalhes */}
      <SignalDetailsModal
        signal={selectedSignal}
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        onOpenTrade={handleOpenTrade}
      />
    </div>
  );
};
