import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Check, X, AlertTriangle, Zap, DollarSign } from "lucide-react";

interface CloseOperationModalProps {
  isOpen: boolean;
  onClose: () => void;
  operation: {
    id?: string;
    longSymbol: string;
    shortSymbol: string;
    isTest?: boolean;
  } | null;
  onSuccess: () => void;
}

interface OrderStatus {
  symbol: string;
  orderId: number | null;
  status: "pending" | "placed" | "filled" | "failed" | "cancelled";
  message: string;
}

interface PositionBalance {
  symbol: string;
  pnl: number;
  frozen: boolean;
}

export const CloseOperationModal = ({ isOpen, onClose, operation, onSuccess }: CloseOperationModalProps) => {
  const { toast } = useToast();
  const [longOrderStatus, setLongOrderStatus] = useState<OrderStatus | null>(null);
  const [shortOrderStatus, setShortOrderStatus] = useState<OrderStatus | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showForceMarketButton, setShowForceMarketButton] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);

  // Saldos das posições
  const [longBalance, setLongBalance] = useState<PositionBalance | null>(null);
  const [shortBalance, setShortBalance] = useState<PositionBalance | null>(null);

  const checkIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startTimeRef = useRef<number>(0);

  // Refs para evitar "stale state" dentro do setInterval
  const operationRef = useRef<CloseOperationModalProps["operation"] | null>(null);
  const longOrderStatusRef = useRef<OrderStatus | null>(null);
  const shortOrderStatusRef = useRef<OrderStatus | null>(null);
  const longBalanceRef = useRef<PositionBalance | null>(null);
  const shortBalanceRef = useRef<PositionBalance | null>(null);

  useEffect(() => {
    operationRef.current = operation;
  }, [operation]);

  useEffect(() => {
    longOrderStatusRef.current = longOrderStatus;
  }, [longOrderStatus]);

  useEffect(() => {
    shortOrderStatusRef.current = shortOrderStatus;
  }, [shortOrderStatus]);

  useEffect(() => {
    longBalanceRef.current = longBalance;
  }, [longBalance]);

  useEffect(() => {
    shortBalanceRef.current = shortBalance;
  }, [shortBalance]);

  const stopChecking = () => {
    if (checkIntervalRef.current) {
      clearInterval(checkIntervalRef.current);
      checkIntervalRef.current = null;
    }
  };

  // Buscar saldos das posições
  const fetchPositionBalances = async () => {
    const op = operationRef.current;
    if (!op) return;

    try {
      const { data, error } = await supabase.functions.invoke('binance-trading', {
        body: { action: 'get_positions' }
      });

      if (error || !data?.success) return;

      const positions = data.data?.positions || [];
      
      // Atualizar saldo LONG apenas se não estiver congelado
      const longPos = positions.find((p: any) => p.symbol === op.longSymbol);
      if (longPos && !longBalanceRef.current?.frozen) {
        setLongBalance({
          symbol: op.longSymbol,
          pnl: parseFloat(longPos.unrealizedProfit) || 0,
          frozen: false
        });
      }

      // Atualizar saldo SHORT apenas se não estiver congelado
      const shortPos = positions.find((p: any) => p.symbol === op.shortSymbol);
      if (shortPos && !shortBalanceRef.current?.frozen) {
        setShortBalance({
          symbol: op.shortSymbol,
          pnl: parseFloat(shortPos.unrealizedProfit) || 0,
          frozen: false
        });
      }
    } catch (err) {
      console.error("Erro ao buscar saldos:", err);
    }
  };

  // Iniciar processo de fechamento quando modal abrir
  useEffect(() => {
    if (isOpen && operation && !operation.isTest) {
      void startClosingProcess();
    }

    return () => {
      stopChecking();
    };
  }, [isOpen, operation]);

  const startClosingProcess = async () => {
    if (!operation) return;

    stopChecking();
    setShowForceMarketButton(false);
    setIsCancelling(false);
    setLongBalance(null);
    setShortBalance(null);

    setIsProcessing(true);
    startTimeRef.current = Date.now();
    
    // Inicializar status
    setLongOrderStatus({
      symbol: operation.longSymbol,
      orderId: null,
      status: "pending",
      message: "Enviando ordem..."
    });
    
    setShortOrderStatus({
      symbol: operation.shortSymbol,
      orderId: null,
      status: "pending",
      message: "Enviando ordem..."
    });

    // Buscar saldos iniciais
    await fetchPositionBalances();

    // Enviar ordens LIMIT em paralelo
    const [longResult, shortResult] = await Promise.all([
      sendLimitOrder(operation.longSymbol),
      sendLimitOrder(operation.shortSymbol)
    ]);

    // Atualizar status com resultados
    if (longResult.success) {
      setLongOrderStatus({
        symbol: operation.longSymbol,
        orderId: longResult.orderId,
        status: "placed",
        message: "Apregoado - aguardando..."
      });
    } else {
      setLongOrderStatus({
        symbol: operation.longSymbol,
        orderId: null,
        status: "failed",
        message: longResult.error || "Erro ao enviar"
      });
    }

    if (shortResult.success) {
      setShortOrderStatus({
        symbol: operation.shortSymbol,
        orderId: shortResult.orderId,
        status: "placed",
        message: "Apregoado - aguardando..."
      });
    } else {
      setShortOrderStatus({
        symbol: operation.shortSymbol,
        orderId: null,
        status: "failed",
        message: shortResult.error || "Erro ao enviar"
      });
    }

    // Iniciar verificação de status das ordens
    checkIntervalRef.current = setInterval(() => {
      void checkOrdersStatus();
    }, 1000);
  };

  const sendLimitOrder = async (symbol: string): Promise<{ success: boolean; orderId?: number; error?: string }> => {
    try {
      const { data, error } = await supabase.functions.invoke('binance-trading', {
        body: { action: 'close_position_limit', symbol }
      });

      if (error || !data?.success) {
        return { success: false, error: data?.error || error?.message || "Erro desconhecido" };
      }

      return { success: true, orderId: data.data.orderId };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : "Erro ao enviar ordem" };
    }
  };

  const checkOrdersStatus = async () => {
    const op = operationRef.current;
    if (!op) return;

    // Atualizar saldos
    await fetchPositionBalances();

    // Após 30 segundos, mostrar botão para forçar saída a mercado
    const elapsed = Date.now() - startTimeRef.current;
    if (elapsed > 30000) {
      setShowForceMarketButton(true);
    }

    const checkOne = async (
      current: OrderStatus | null,
      symbol: string,
      label: string,
      setStatus: (next: OrderStatus | null) => void,
      setBalance: React.Dispatch<React.SetStateAction<PositionBalance | null>>
    ): Promise<OrderStatus | null> => {
      if (!current) return null;

      if (!current.orderId || current.status !== "placed") {
        return current;
      }

      try {
        const { data, error } = await supabase.functions.invoke("binance-trading", {
          body: {
            action: "check_order_status",
            symbol,
            orderId: current.orderId,
          },
        });

        if (error || !data?.success) {
          return current;
        }

        const status = String(data.data?.status || "");

        if (status === "FILLED") {
          // Congelar o saldo quando a ordem for executada
          setBalance(prev => prev ? { ...prev, frozen: true } : null);
          
          const updated: OrderStatus = {
            ...current,
            status: "filled",
            message: `${label} encerrada ✓`,
          };
          setStatus(updated);
          return updated;
        }

        if (status === "PARTIALLY_FILLED") {
          const updated: OrderStatus = {
            ...current,
            status: "placed",
            message: "Parcialmente executada...",
          };
          setStatus(updated);
          return updated;
        }

        if (status === "CANCELED" || status === "EXPIRED" || status === "REJECTED") {
          const updated: OrderStatus = {
            ...current,
            status: "cancelled",
            message: "Ordem cancelada",
          };
          setStatus(updated);
          return updated;
        }

        return current;
      } catch (err) {
        console.error("Erro ao verificar status da ordem:", err);
        return current;
      }
    };

    const currentLong = longOrderStatusRef.current;
    const currentShort = shortOrderStatusRef.current;

    const [nextLong, nextShort] = await Promise.all([
      checkOne(currentLong, op.longSymbol, "1ª", setLongOrderStatus, setLongBalance),
      checkOne(currentShort, op.shortSymbol, "2ª", setShortOrderStatus, setShortBalance),
    ]);

    // ✅ Sucesso apenas quando AMBAS forem executadas
    const bothFilled = nextLong?.status === "filled" && nextShort?.status === "filled";
    if (bothFilled) {
      stopChecking();
      setIsProcessing(false);

      toast({
        title: "✅ Ordens encerradas com sucesso!",
        description: "As duas posições foram encerradas na Binance.",
      });

      setTimeout(() => {
        onSuccess();
        onClose();
      }, 1200);
    }
  };

  const cancelLimitOrders = async () => {
    const op = operationRef.current;
    const long = longOrderStatusRef.current;
    const short = shortOrderStatusRef.current;

    if (!op || isCancelling) return;

    setIsCancelling(true);

    try {
      await Promise.all([
        long?.orderId && long.status === "placed"
          ? supabase.functions.invoke("binance-trading", {
              body: { action: "cancel_order", symbol: op.longSymbol, orderId: long.orderId },
            })
          : Promise.resolve(null),
        short?.orderId && short.status === "placed"
          ? supabase.functions.invoke("binance-trading", {
              body: { action: "cancel_order", symbol: op.shortSymbol, orderId: short.orderId },
            })
          : Promise.resolve(null),
      ]);

      setLongOrderStatus((prev) =>
        prev && prev.status === "placed"
          ? { ...prev, status: "cancelled", message: "Cancelada pelo usuário" }
          : prev
      );

      setShortOrderStatus((prev) =>
        prev && prev.status === "placed"
          ? { ...prev, status: "cancelled", message: "Cancelada pelo usuário" }
          : prev
      );

      toast({
        title: "Ordens canceladas",
        description: "Envio de ordens LIMIT cancelado.",
      });
    } catch (err) {
      console.error("Erro ao cancelar ordens:", err);
      toast({
        title: "Erro ao cancelar ordens",
        description: "Tente novamente.",
        variant: "destructive",
      });
    } finally {
      stopChecking();
      setIsProcessing(false);
      setIsCancelling(false);
    }
  };

  const forceMarketClose = async (symbol: string, orderStatus: OrderStatus | null, isLong: boolean) => {
    if (!operation) return;

    // Primeiro, cancelar a ordem limit se existir
    if (orderStatus?.orderId && orderStatus.status === "placed") {
      try {
        await supabase.functions.invoke('binance-trading', {
          body: { 
            action: 'cancel_order', 
            symbol,
            orderId: orderStatus.orderId
          }
        });
      } catch (err) {
        console.error("Erro ao cancelar ordem:", err);
      }
    }

    // Fechar a mercado
    const setStatus = isLong ? setLongOrderStatus : setShortOrderStatus;
    const setBalance = isLong ? setLongBalance : setShortBalance;
    setStatus(prev => prev ? { ...prev, status: "pending", message: "Fechando a mercado..." } : null);

    try {
      const { data, error } = await supabase.functions.invoke('binance-trading', {
        body: { action: 'close_position', symbol }
      });

      if (data?.success) {
        // Congelar saldo quando fechado a mercado
        setBalance(prev => prev ? { ...prev, frozen: true } : null);
        
        setStatus(prev => prev ? { 
          ...prev, 
          status: "filled", 
          message: isLong ? "1° Encerrada (mercado) ✓" : "2° Encerrada (mercado) ✓" 
        } : null);
        
        toast({
          title: "✅ Posição fechada a mercado",
          description: `${symbol.replace('USDT', '')} encerrado com sucesso`,
        });
      } else {
        setStatus(prev => prev ? { ...prev, status: "failed", message: error?.message || "Erro ao fechar" } : null);
        toast({
          title: "❌ Erro ao fechar posição",
          description: data?.error || "Tente novamente",
          variant: "destructive"
        });
      }
    } catch (err) {
      setStatus(prev => prev ? { ...prev, status: "failed", message: "Erro de conexão" } : null);
    }
  };

  const forceMarketCloseAll = async () => {
    if (!operation) return;

    toast({
      title: "⚡ Forçando saída a mercado",
      description: "Fechando ambas posições...",
    });

    await Promise.all([
      forceMarketClose(operation.longSymbol, longOrderStatus, true),
      forceMarketClose(operation.shortSymbol, shortOrderStatus, false)
    ]);
  };

  const getStatusIcon = (status: OrderStatus["status"]) => {
    switch (status) {
      case "pending":
        return <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />;
      case "placed":
        return <Loader2 className="h-5 w-5 animate-spin text-yellow-500" />;
      case "filled":
        return <Check className="h-5 w-5 text-green-500" />;
      case "failed":
      case "cancelled":
        return <X className="h-5 w-5 text-red-500" />;
    }
  };

  const getStatusColor = (status: OrderStatus["status"]) => {
    switch (status) {
      case "pending":
        return "border-muted-foreground/30";
      case "placed":
        return "border-yellow-500/50 bg-yellow-500/5";
      case "filled":
        return "border-green-500/50 bg-green-500/5";
      case "failed":
      case "cancelled":
        return "border-red-500/50 bg-red-500/5";
    }
  };

  const formatPnl = (pnl: number | undefined) => {
    if (pnl === undefined) return "---";
    const prefix = pnl >= 0 ? "+" : "";
    return `${prefix}$${pnl.toFixed(2)}`;
  };

  const getPnlColor = (pnl: number | undefined, frozen: boolean) => {
    if (pnl === undefined) return "text-muted-foreground";
    if (frozen) return pnl >= 0 ? "text-green-500" : "text-red-500";
    return pnl >= 0 ? "text-green-400" : "text-red-400";
  };

  const totalPnl = (longBalance?.pnl || 0) + (shortBalance?.pnl || 0);

  // Se for operação de teste, apenas fechar
  if (operation?.isTest) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Encerrar Operação Teste</DialogTitle>
            <DialogDescription>
              Esta é uma operação de teste. Clique para encerrar.
            </DialogDescription>
          </DialogHeader>
          <Button onClick={() => { onSuccess(); onClose(); }} className="w-full">
            Encerrar Operação Teste
          </Button>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!isProcessing) onClose(); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            Encerrando Posições
          </DialogTitle>
          <DialogDescription>
            Ordens LIMIT apregoadas para menor taxa
          </DialogDescription>
        </DialogHeader>

        {/* Saldo Total da Operação */}
        {(longBalance || shortBalance) && (
          <Card className="p-3 border-2 border-primary/30 bg-primary/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-primary" />
                <span className="font-medium text-sm">Saldo da Operação</span>
              </div>
              <span className={`font-bold text-lg ${totalPnl >= 0 ? "text-green-500" : "text-red-500"}`}>
                {formatPnl(totalPnl)}
              </span>
            </div>
          </Card>
        )}

        <div className="space-y-3 my-4">
          {/* Status LONG */}
          {longOrderStatus && (
            <Card className={`p-4 border-2 ${getStatusColor(longOrderStatus.status)}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {getStatusIcon(longOrderStatus.status)}
                  <div>
                    <p className="font-medium text-sm">
                      LONG {longOrderStatus.symbol.replace('USDT', '')}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {longOrderStatus.message}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {/* Saldo da posição LONG */}
                  {longBalance && (
                    <span className={`text-sm font-semibold ${getPnlColor(longBalance.pnl, longBalance.frozen)} ${longBalance.frozen ? 'opacity-70' : ''}`}>
                      {formatPnl(longBalance.pnl)}
                      {longBalance.frozen && <span className="ml-1 text-xs">(fixo)</span>}
                    </span>
                  )}
                  {(longOrderStatus.status === "placed" || longOrderStatus.status === "cancelled") && showForceMarketButton && (
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => forceMarketClose(operation!.longSymbol, longOrderStatus, true)}
                      className="text-xs"
                    >
                      <Zap className="h-3 w-3 mr-1" />
                      Mercado
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          )}

          {/* Status SHORT */}
          {shortOrderStatus && (
            <Card className={`p-4 border-2 ${getStatusColor(shortOrderStatus.status)}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {getStatusIcon(shortOrderStatus.status)}
                  <div>
                    <p className="font-medium text-sm">
                      SHORT {shortOrderStatus.symbol.replace('USDT', '')}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {shortOrderStatus.message}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {/* Saldo da posição SHORT */}
                  {shortBalance && (
                    <span className={`text-sm font-semibold ${getPnlColor(shortBalance.pnl, shortBalance.frozen)} ${shortBalance.frozen ? 'opacity-70' : ''}`}>
                      {formatPnl(shortBalance.pnl)}
                      {shortBalance.frozen && <span className="ml-1 text-xs">(fixo)</span>}
                    </span>
                  )}
                  {(shortOrderStatus.status === "placed" || shortOrderStatus.status === "cancelled") && showForceMarketButton && (
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => forceMarketClose(operation!.shortSymbol, shortOrderStatus, false)}
                      className="text-xs"
                    >
                      <Zap className="h-3 w-3 mr-1" />
                      Mercado
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          )}
        </div>

        {/* Mostrar botão de forçar todas após 30 segundos */}
        {showForceMarketButton && (
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <AlertTriangle className="h-4 w-4 text-yellow-500" />
              <span>Ordens demorando? Force saída a mercado.</span>
            </div>
            <Button 
              variant="destructive" 
              onClick={forceMarketCloseAll}
              className="w-full"
            >
              <Zap className="h-4 w-4 mr-2" />
              Forçar Saída a Mercado
            </Button>
          </div>
        )}

        <div className="flex flex-col gap-2 mt-4">
          {isProcessing ? (
            <Button
              variant="outline"
              onClick={cancelLimitOrders}
              disabled={isCancelling}
              className="w-full"
            >
              {isCancelling ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Cancelando...
                </>
              ) : (
                <>
                  <X className="h-4 w-4 mr-2" />
                  Cancelar ordens LIMIT
                </>
              )}
            </Button>
          ) : (
            <Button variant="outline" onClick={onClose} className="w-full">
              Fechar
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
