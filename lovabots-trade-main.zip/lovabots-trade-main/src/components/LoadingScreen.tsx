import { Loader2 } from "lucide-react";
import aurionLogo from "@/assets/aurion-logo.png";

export const LoadingScreen = () => {
  return (
    <div className="fixed inset-0 bg-background flex items-center justify-center z-50">
      <div className="flex flex-col items-center gap-4">
        <img src={aurionLogo} alt="AURION" className="w-24 h-24 animate-pulse" />
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
        <p className="text-muted-foreground text-sm">Carregando...</p>
      </div>
    </div>
  );
};
