import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Sparkles, 
  RefreshCw, 
  Clock, 
  Calendar,
  TrendingUp,
  TrendingDown,
  Rocket,
  AlertCircle
} from "lucide-react";
import { useNewCryptoScanner, NewCryptoSignal } from "@/hooks/useNewCryptoScanner";
import { HoldingSignalDetailsModal } from "@/components/HoldingSignalDetailsModal";
import { HoldingSignal } from "@/hooks/useHoldingScanner";
import { TradingConfig } from "@/components/TradingConfig";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface NewCryptoPositionProps {
  binanceBalance: number;
  hasActiveOperation: boolean;
  onOperationStart: (data: any) => void;
}

const NewCryptoCard = ({ 
  signal, 
  onClick 
}: { 
  signal: NewCryptoSignal; 
  onClick: () => void;
}) => {
  const qualityColors = {
    "Excelente": "bg-green-500/20 text-green-400 border-green-500/50",
    "Bom": "bg-blue-500/20 text-blue-400 border-blue-500/50",
    "Moderado": "bg-yellow-500/20 text-yellow-400 border-yellow-500/50",
  };

  const formatPrice = (price: number) => {
    if (price >= 1000) return price.toFixed(2);
    if (price >= 1) return price.toFixed(4);
    return price.toFixed(6);
  };

  return (
    <Card 
      className="cursor-pointer hover:border-primary/50 transition-all hover:scale-[1.02] bg-card/60"
      onClick={onClick}
    >
      <CardContent className="p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-foreground">{signal.symbol.replace("USDT", "")}</span>
            <Badge 
              variant="outline" 
              className={signal.direction === "LONG" 
                ? "bg-green-500/20 text-green-400 border-green-500/50" 
                : "bg-red-500/20 text-red-400 border-red-500/50"
              }
            >
              {signal.direction === "LONG" ? (
                <TrendingUp className="h-3 w-3 mr-1" />
              ) : (
                <TrendingDown className="h-3 w-3 mr-1" />
              )}
              {signal.direction}
            </Badge>
          </div>
          <Badge variant="outline" className={qualityColors[signal.quality]}>
            {signal.quality}
          </Badge>
        </div>
        
        <div className="text-sm text-muted-foreground">
          ${formatPrice(signal.currentPrice)}
        </div>
        
        <p className="text-xs text-muted-foreground mt-2 line-clamp-1">
          {signal.signalReason}
        </p>
      </CardContent>
    </Card>
  );
};

const SignalGrid = ({ 
  signals, 
  emptyMessage,
  onSignalClick,
}: { 
  signals: NewCryptoSignal[];
  emptyMessage: string;
  onSignalClick: (signal: NewCryptoSignal) => void;
}) => {
  if (signals.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <AlertCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
      {signals.map(signal => (
        <NewCryptoCard 
          key={signal.id} 
          signal={signal} 
          onClick={() => onSignalClick(signal)}
        />
      ))}
    </div>
  );
};

export const NewCryptoPosition = ({
  binanceBalance,
  hasActiveOperation,
  onOperationStart,
}: NewCryptoPositionProps) => {
  const { toast } = useToast();
  const { data, isScanning, lastScanTime, rescan } = useNewCryptoScanner(true, 120000);
  const [selectedSignal, setSelectedSignal] = useState<NewCryptoSignal | null>(null);
  const [periodTab, setPeriodTab] = useState<"1_day" | "5_days" | "3_weeks">("1_day");
  const [isOpeningTrade, setIsOpeningTrade] = useState(false);

  // Config state
  const [investment, setInvestment] = useState(100);
  const [leverage, setLeverage] = useState(10);
  const [profitTarget, setProfitTarget] = useState(10);
  const [autoCloseEnabled, setAutoCloseEnabled] = useState(true);

  const handleSignalClick = (signal: NewCryptoSignal) => {
    setSelectedSignal(signal);
  };

  const handleOpenTrade = async (signal: HoldingSignal, isTest: boolean) => {
    setIsOpeningTrade(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Erro",
          description: "Usuário não autenticado",
          variant: "destructive",
        });
        return;
      }

      if (!isTest) {
        const { data: result, error } = await supabase.functions.invoke("binance-trading", {
          body: {
            action: "open_single_position",
            symbol: signal.symbol,
            side: signal.direction === "LONG" ? "BUY" : "SELL",
            amount: investment,
            leverage: leverage,
          },
        });

        if (error || !result?.success) {
          throw new Error(result?.error || "Erro ao abrir posição");
        }
      }

      const { data: newOp, error: dbError } = await supabase
        .from("active_operations")
        .insert({
          user_id: user.id,
          long_symbol: signal.direction === "LONG" ? signal.symbol : "",
          short_symbol: signal.direction === "SHORT" ? signal.symbol : "",
          leverage_long: signal.direction === "LONG" ? leverage : 1,
          leverage_short: signal.direction === "SHORT" ? leverage : 1,
          leverage: leverage,
          investment_amount: investment,
          entry_price_long: signal.direction === "LONG" ? signal.currentPrice : 0,
          entry_price_short: signal.direction === "SHORT" ? signal.currentPrice : 0,
          profit_target: profitTarget,
          auto_close_enabled: autoCloseEnabled,
          status: "active",
          is_test: isTest,
          trading_mode: "holding",
        })
        .select()
        .single();

      if (dbError) throw dbError;

      toast({
        title: isTest ? "Operação de teste aberta" : "Operação aberta",
        description: `${signal.direction} ${signal.symbol}`,
      });

      onOperationStart({
        id: newOp.id,
        longSymbol: signal.direction === "LONG" ? signal.symbol : "",
        shortSymbol: signal.direction === "SHORT" ? signal.symbol : "",
        leverageLong: signal.direction === "LONG" ? leverage : 1,
        leverageShort: signal.direction === "SHORT" ? leverage : 1,
        amount: investment,
        entryPriceLong: signal.direction === "LONG" ? signal.currentPrice : 0,
        entryPriceShort: signal.direction === "SHORT" ? signal.currentPrice : 0,
        startTime: new Date(),
        profitTarget,
        autoCloseEnabled,
        isTest,
      });

      setSelectedSignal(null);
    } catch (error) {
      console.error("Erro ao abrir operação:", error);
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setIsOpeningTrade(false);
    }
  };

  const adaptedSignal: HoldingSignal | null = selectedSignal ? {
    id: selectedSignal.id,
    symbol: selectedSignal.symbol,
    direction: selectedSignal.direction,
    quality: selectedSignal.quality,
    currentPrice: selectedSignal.currentPrice,
    chandelierTrend: selectedSignal.chandelierTrend,
    adxMomentum: selectedSignal.adxMomentum,
    diAlignment: selectedSignal.diAlignment,
    rsiCondition: selectedSignal.rsiCondition,
    signalReason: selectedSignal.signalReason,
    timestamp: selectedSignal.timestamp,
  } : null;

  const totalSignals = data.oneDayCoins.length + data.fiveDaysCoins.length + data.threeWeeksCoins.length;

  return (
    <div className="space-y-4">
      {/* Config */}
      <TradingConfig
        investment={investment}
        leverage={leverage}
        profitTarget={profitTarget}
        autoCloseEnabled={autoCloseEnabled}
        onInvestmentChange={setInvestment}
        onLeverageChange={setLeverage}
        onProfitTargetChange={setProfitTarget}
        onAutoCloseChange={setAutoCloseEnabled}
      />

      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-purple-400" />
              <CardTitle className="text-lg">New Crypto</CardTitle>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={rescan}
              disabled={isScanning}
              className="gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${isScanning ? "animate-spin" : ""}`} />
              {isScanning ? "Analisando..." : "Atualizar"}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <Rocket className="h-4 w-4" />
              {totalSignals} sinais encontrados
            </span>
            {lastScanTime && (
              <span className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {lastScanTime.toLocaleTimeString()}
              </span>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Tabs por período */}
      <Tabs value={periodTab} onValueChange={(v) => setPeriodTab(v as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="1_day" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span className="hidden sm:inline">1 Dia</span>
            <Badge variant="secondary" className="ml-1">{data.oneDayCoins.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="5_days" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            <span className="hidden sm:inline">5 Dias</span>
            <Badge variant="secondary" className="ml-1">{data.fiveDaysCoins.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="3_weeks" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            <span className="hidden sm:inline">3 Semanas</span>
            <Badge variant="secondary" className="ml-1">{data.threeWeeksCoins.length}</Badge>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="1_day">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-yellow-400" />
                Moedas listadas nas últimas 24h
              </CardTitle>
            </CardHeader>
            <CardContent>
              <SignalGrid 
                signals={data.oneDayCoins}
                emptyMessage="Nenhuma moeda nova com sinal forte nas últimas 24h"
                onSignalClick={handleSignalClick}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="5_days">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Calendar className="h-4 w-4 text-blue-400" />
                Moedas listadas nos últimos 5 dias
              </CardTitle>
            </CardHeader>
            <CardContent>
              <SignalGrid 
                signals={data.fiveDaysCoins}
                emptyMessage="Nenhuma moeda com sinal forte nos últimos 5 dias"
                onSignalClick={handleSignalClick}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="3_weeks">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Calendar className="h-4 w-4 text-purple-400" />
                Moedas listadas nas últimas 3 semanas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <SignalGrid 
                signals={data.threeWeeksCoins}
                emptyMessage="Nenhuma moeda com sinal forte nas últimas 3 semanas"
                onSignalClick={handleSignalClick}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Próximos lançamentos */}
      <Card className="border-primary/30 bg-gradient-to-r from-orange-500/5 to-yellow-500/5">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Rocket className="h-4 w-4 text-orange-400" />
            Próximos Lançamentos
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.upcomingListings.length === 0 ? (
            <div className="text-sm text-muted-foreground text-center py-4">
              <p>Carregando anúncios...</p>
            </div>
          ) : data.upcomingListings[0].symbol === "—" ? (
            <div className="text-sm text-muted-foreground text-center py-4">
              <p>Não foi possível carregar os anúncios automaticamente.</p>
              <a 
                href={data.upcomingListings[0].announcementUrl}
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                Ver anúncios oficiais da Binance
              </a>
            </div>
          ) : (
            <div className="space-y-2">
              {data.upcomingListings.map((listing, index) => (
                <a
                  key={index}
                  href={listing.announcementUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3 rounded-lg bg-card/60 hover:bg-card/80 transition-colors border border-border/30 hover:border-primary/40 group"
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="flex-shrink-0">
                      <Badge 
                        variant="outline" 
                        className="bg-orange-500/20 text-orange-400 border-orange-500/50"
                      >
                        {listing.symbol}
                      </Badge>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">
                        {listing.name}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-xs">
                          {listing.type}
                        </Badge>
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {listing.expectedDate}
                        </span>
                      </div>
                    </div>
                  </div>
                  <TrendingUp className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
                </a>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de detalhes */}
      <HoldingSignalDetailsModal
        signal={adaptedSignal}
        isOpen={!!selectedSignal}
        onClose={() => setSelectedSignal(null)}
        onOpenTrade={handleOpenTrade}
        isLoading={isOpeningTrade}
        disabled={hasActiveOperation}
      />
    </div>
  );
};
