import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Coins, Sparkles, QrCode, Copy, Check } from "lucide-react";
interface CreditPackage {
  value: number;
  credits: number;
  promotion?: string;
}
const packages: CreditPackage[] = [{
  value: 5,
  credits: 1
}, {
  value: 25,
  credits: 15
}, {
  value: 30,
  credits: 10
}, {
  value: 50,
  credits: 50,
  promotion: "🎉 Super Promoção!"
}];
export const Credits = () => {
  const [userCredits, setUserCredits] = useState(0);
  const [loading, setLoading] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<CreditPackage | null>(null);
  const [qrCode, setQrCode] = useState<string>("");
  const [pixCode, setPixCode] = useState<string>("");
  const [orderId, setOrderId] = useState<string>("");
  const [copied, setCopied] = useState(false);
  const [checkingPayment, setCheckingPayment] = useState(false);
  const {
    toast
  } = useToast();
  useEffect(() => {
    fetchCredits();

    // Escutar atualizações em tempo real
    const channel = supabase.channel("user_credits_updates").on("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "user_credits"
    }, payload => {
      console.log("Créditos atualizados:", payload);
      if (payload.new) {
        setUserCredits(payload.new.credits);
        toast({
          title: "✅ Pagamento confirmado!",
          description: `${payload.new.credits} créditos adicionados à sua conta.`
        });
        // Limpar estado do pagamento
        setSelectedPackage(null);
        setQrCode("");
        setPixCode("");
        setOrderId("");
        setCheckingPayment(false);
      }
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);
  const fetchCredits = async () => {
    const {
      data: {
        user
      }
    } = await supabase.auth.getUser();
    if (!user) return;
    const {
      data,
      error
    } = await supabase.from("user_credits").select("credits").eq("user_id", user.id).maybeSingle();
    if (error) {
      console.error("Erro ao buscar créditos:", error);
      return;
    }
    if (data) {
      setUserCredits(data.credits);
    } else {
      // Criar registro inicial
      const {
        data: newData
      } = await supabase.from("user_credits").insert({
        user_id: user.id,
        credits: 0
      }).select().single();
      if (newData) {
        setUserCredits(newData.credits);
      }
    }
  };
  const generatePixPayment = async (pkg: CreditPackage) => {
    setLoading(true);
    setSelectedPackage(pkg);
    try {
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (!user) throw new Error("Usuário não autenticado");
      const {
        data,
        error
      } = await supabase.functions.invoke("create-pix-payment", {
        body: {
          amount: pkg.value,
          credits: pkg.credits,
          userEmail: user.email
        }
      });
      if (error) throw error;
      setQrCode(data.qrCodeUrl);
      setPixCode(data.pixCode);
      setOrderId(data.orderId);
      toast({
        title: "QR Code gerado!",
        description: "Escaneie o QR Code ou copie o código Pix para pagar."
      });

      // Iniciar verificação de pagamento
      startPaymentCheck(data.orderId);
    } catch (error) {
      console.error("Erro ao gerar pagamento:", error);
      toast({
        title: "Erro",
        description: "Não foi possível gerar o pagamento. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const startPaymentCheck = (orderId: string) => {
    setCheckingPayment(true);
    const interval = setInterval(async () => {
      try {
        const {
          data,
          error
        } = await supabase.functions.invoke("check-payment-status", {
          body: {
            orderId
          }
        });
        if (error) throw error;
        if (data.status === "PAID") {
          clearInterval(interval);
          setCheckingPayment(false);
          // Os créditos serão atualizados via realtime
        }
      } catch (error) {
        console.error("Erro ao verificar pagamento:", error);
      }
    }, 60000); // Verificar a cada 60 segundos

    // Limpar após 30 minutos
    setTimeout(() => {
      clearInterval(interval);
      setCheckingPayment(false);
    }, 1800000);
  };
  const copyPixCode = () => {
    navigator.clipboard.writeText(pixCode);
    setCopied(true);
    toast({
      title: "Código copiado!",
      description: "Cole no seu app de pagamentos."
    });
    setTimeout(() => setCopied(false), 2000);
  };
  return <div className="space-y-4">
      {/* Saldo Atual */}
      <Card className="glass-card premium-border p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Saldo Atual</p>
            <div className="flex items-center gap-2">
              <Coins className="w-6 h-6 text-primary" />
              <p className="text-3xl font-bold text-primary">{userCredits}</p>
              <span className="text-lg text-muted-foreground">créditos</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Banner de créditos zerados */}
      {userCredits === 0 && <Card className="bg-destructive/10 border-destructive/50 p-4">
          <p className="text-destructive font-medium">
            ⚠️ Seus créditos acabaram! Adquira mais para continuar operando.
          </p>
        </Card>}

      {/* Área de Compra */}
      <Card className="glass-card premium-border p-6">
        <h3 className="text-xl font-bold mb-2 gradient-primary bg-clip-text text-transparent">
          💰 Adquirir Créditos Aurion
        </h3>
        <p className="text-sm text-muted-foreground mb-6">
          Escolha um pacote, gere o QR Pix e receba seus créditos automaticamente após o pagamento.
        </p>

        {/* QR Code Display */}
        {qrCode && selectedPackage && <Card className="bg-card/50 p-6 mb-6 space-y-4">
            <div className="text-center">
              <h4 className="font-bold text-lg mb-2">
                Pagamento: R$ {selectedPackage.value.toFixed(2)}
              </h4>
              <p className="text-sm text-muted-foreground mb-4">
                {selectedPackage.credits} créditos
              </p>

              {/* QR Code */}
              <div className="bg-white p-4 rounded-lg inline-block mb-4">
                <img src={qrCode} alt="QR Code Pix" className="w-64 h-64" />
              </div>

              {/* Código Pix Copia e Cola */}
              <div className="space-y-2">
                <p className="text-sm font-medium">Código Pix Copia e Cola:</p>
                <div className="flex gap-2">
                  <input type="text" value={pixCode} readOnly className="flex-1 px-3 py-2 bg-background border rounded-md text-sm font-mono" />
                  <Button onClick={copyPixCode} variant="outline" size="icon">
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              {checkingPayment && <p className="text-sm text-muted-foreground mt-4 animate-pulse">
                  Aguardando confirmação do pagamento...
                </p>}

              <p className="text-xs text-muted-foreground mt-4">
                Após o pagamento ser confirmado, seus créditos serão liberados automaticamente.
              </p>

              <Button onClick={() => {
            setSelectedPackage(null);
            setQrCode("");
            setPixCode("");
            setOrderId("");
          }} variant="outline" className="mt-4">
                Cancelar
              </Button>
            </div>
          </Card>}

        {/* Pacotes */}
        {!qrCode && <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {packages.map((pkg, index) => <Card key={index} className={`p-4 cursor-pointer transition-all hover:scale-105 ${pkg.promotion ? "bg-gradient-to-br from-primary/20 to-accent/20 border-primary" : "bg-card/50"}`}>
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-2xl font-bold text-primary">
                        R$ {pkg.value.toFixed(2)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {pkg.credits} créditos
                      </p>
                    </div>
                    {pkg.promotion && <div className="flex items-center gap-1 text-xs font-medium text-primary">
                        <Sparkles className="w-4 h-4" />
                        <span>{pkg.promotion}</span>
                      </div>}
                  </div>

                  <Button onClick={() => generatePixPayment(pkg)} disabled={loading} className="w-full">
                    <QrCode className="w-4 h-4 mr-2" />
                    Gerar QR Pix
                  </Button>
                </div>
              </Card>)}
          </div>}
      </Card>

      {/* Sistema em Produção */}
      <Card className="bg-green-500/10 border-green-500/50 p-4">
        <p className="text-green-600 dark:text-green-400 font-medium mb-2">
          ✅ Sistema de Pagamento Ativo
        </p>
        <p className="text-sm text-muted-foreground">
          Os pagamentos PIX estão configurados e funcionando. Escaneie o QR code ou copie o código PIX para efetuar o pagamento.
        </p>
      </Card>
    </div>;
};