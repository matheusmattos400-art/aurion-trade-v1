import { memo, useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Loader2, Send, X, Calculator, DollarSign } from "lucide-react";

interface ProfitTargetExitInputProps {
  onSubmit: (price: string) => Promise<void>;
  onCancel: () => Promise<void>;
  isCreating: boolean;
  orderCreated: boolean;
  isCancelling: boolean;
  formatPrice: (price: number) => string;
  // Dados necessários para o cálculo
  entryPrice: number;
  positionAmt: number;
  side: "LONG" | "SHORT";
  currentPnl: number;
}

export const ProfitTargetExitInput = memo(({
  onSubmit,
  onCancel,
  isCreating,
  orderCreated,
  isCancelling,
  formatPrice,
  entryPrice,
  positionAmt,
  side,
  currentPnl,
}: ProfitTargetExitInputProps) => {
  const [desiredProfit, setDesiredProfit] = useState("");
  const [calculatedPrice, setCalculatedPrice] = useState<number | null>(null);

  // Calcula o preço de saída necessário para atingir o lucro desejado
  useEffect(() => {
    const profitValue = parseFloat(desiredProfit.replace(",", "."));
    
    if (!isFinite(profitValue) || profitValue <= 0 || entryPrice <= 0 || Math.abs(positionAmt) === 0) {
      setCalculatedPrice(null);
      return;
    }

    // Fórmula: PnL = (exitPrice - entryPrice) * positionAmt (para LONG)
    // Fórmula: PnL = (entryPrice - exitPrice) * |positionAmt| (para SHORT)
    // 
    // Resolvendo para exitPrice:
    // LONG: exitPrice = entryPrice + (desiredProfit / positionAmt)
    // SHORT: exitPrice = entryPrice - (desiredProfit / |positionAmt|)

    let exitPrice: number;
    
    if (side === "LONG") {
      exitPrice = entryPrice + (profitValue / positionAmt);
    } else {
      // Para SHORT, positionAmt é negativo, então usamos o absoluto
      exitPrice = entryPrice - (profitValue / Math.abs(positionAmt));
    }

    if (exitPrice > 0 && isFinite(exitPrice)) {
      setCalculatedPrice(exitPrice);
    } else {
      setCalculatedPrice(null);
    }
  }, [desiredProfit, entryPrice, positionAmt, side]);

  const handleSubmit = async () => {
    if (calculatedPrice && calculatedPrice > 0) {
      await onSubmit(calculatedPrice.toString());
    }
  };

  if (orderCreated) {
    return (
      <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-green-500">
            <CheckCircle2 className="h-4 w-4" />
            <span>Ordem de lucro enviada!</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onCancel}
            disabled={isCancelling}
            className="h-7 px-2 text-red-400 hover:text-red-500 hover:bg-red-500/10"
          >
            {isCancelling ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <>
                <X className="h-3.5 w-3.5 mr-1" />
                Cancelar
              </>
            )}
          </Button>
        </div>
        {calculatedPrice && (
          <p className="text-[10px] text-muted-foreground mt-1">
            Take Profit @ ${formatPrice(calculatedPrice)}
          </p>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-3 p-3 rounded-lg bg-primary/5 border border-primary/20">
      <div className="flex items-center gap-2 text-sm font-medium text-primary">
        <Calculator className="h-4 w-4" />
        <span>Definir lucro desejado</span>
      </div>
      
      <div className="flex gap-2">
        <div className="relative flex-1">
          <DollarSign className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            inputMode="decimal"
            placeholder="Quanto quer ganhar?"
            value={desiredProfit}
            onChange={(e) => setDesiredProfit(e.target.value)}
            className="pl-8 bg-background/50 border-border/50 text-sm"
          />
        </div>
        <Button
          variant="default"
          size="sm"
          onClick={handleSubmit}
          disabled={isCreating || !calculatedPrice}
          className="gap-1.5"
        >
          {isCreating ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <>
              <Send className="h-4 w-4" />
              Criar
            </>
          )}
        </Button>
      </div>

      {/* Preview do cálculo */}
      {desiredProfit && (
        <div className="text-xs space-y-1">
          {calculatedPrice ? (
            <>
              <div className="flex items-center justify-between text-muted-foreground">
                <span>PnL atual:</span>
                <span className={currentPnl >= 0 ? "text-green-500" : "text-red-500"}>
                  {currentPnl >= 0 ? "+" : ""}${currentPnl.toFixed(2)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Preço de saída calculado:</span>
                <span className="font-mono font-bold text-primary">
                  ${formatPrice(calculatedPrice)}
                </span>
              </div>
              <div className="flex items-center justify-between text-muted-foreground">
                <span>Variação do preço:</span>
                <span className={side === "LONG" 
                  ? (calculatedPrice > entryPrice ? "text-green-500" : "text-red-500")
                  : (calculatedPrice < entryPrice ? "text-green-500" : "text-red-500")
                }>
                  {((Math.abs(calculatedPrice - entryPrice) / entryPrice) * 100).toFixed(2)}%
                </span>
              </div>
            </>
          ) : (
            <p className="text-muted-foreground">
              Digite um valor válido para calcular o preço
            </p>
          )}
        </div>
      )}

      <p className="text-[10px] text-muted-foreground">
        O preço de saída será calculado automaticamente para atingir o lucro desejado
      </p>
    </div>
  );
});

ProfitTargetExitInput.displayName = "ProfitTargetExitInput";
