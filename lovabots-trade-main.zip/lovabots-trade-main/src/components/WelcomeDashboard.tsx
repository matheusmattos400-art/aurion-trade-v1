import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CryptoNews } from "./CryptoNews";
import { CryptoTicker } from "./CryptoTicker";

import { TopMoverCarousel } from "./TopMoverCarousel";
import { 
  Wallet, 
  Coins, 
  TrendingUp, 
  Zap,
  ArrowRight,
  Plus,
  Sparkles,
  Activity,
  AlertTriangle
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface ActiveOperationInfo {
  longSymbol: string;
  shortSymbol: string;
  currentPnl: number;
  isTest: boolean;
  entryPriceLong: number;
  entryPriceShort: number;
  leverageLong: number;
  leverageShort: number;
  longClosed: boolean;
  shortClosed: boolean;
  longClosePnl: number;
  shortClosePnl: number;
}

interface OrphanPositionInfo {
  symbol: string;
  positionAmt: string;
  entryPrice?: string;
  leverage?: string;
  unrealizedProfit?: string;
}

interface WelcomeDashboardProps {
  binanceBalance: number;
  userCredits: number;
  userName?: string;
  orphanPositions?: OrphanPositionInfo[];
  onAddCredits?: () => void;
}

export const WelcomeDashboard = ({ 
  binanceBalance, 
  userCredits,
  userName,
  orphanPositions = [],
  onAddCredits
}: WelcomeDashboardProps) => {
  const navigate = useNavigate();
  const [activeOperation, setActiveOperation] = useState<ActiveOperationInfo | null>(null);
  const [calculatedPnl, setCalculatedPnl] = useState<number>(0);
  const [usdBrlRate, setUsdBrlRate] = useState<number>(0);

  // Fetch USD/BRL exchange rate
  useEffect(() => {
    const fetchExchangeRate = async () => {
      try {
        const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
        if (!response.ok) return;
        const data = await response.json();
        if (data?.rates?.BRL) {
          setUsdBrlRate(data.rates.BRL);
        }
      } catch (error) {
        console.error('Erro ao buscar cotação USD/BRL:', error);
      }
    };

    fetchExchangeRate();
    // Atualiza a cada 5 minutos
    const interval = setInterval(fetchExchangeRate, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  // Fetch operation data
  useEffect(() => {
    const fetchActiveOperation = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('active_operations')
        .select('long_symbol, short_symbol, current_pnl, is_test, entry_price_long, entry_price_short, leverage_long, leverage_short, long_closed, short_closed, long_close_pnl, short_close_pnl')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .maybeSingle();

      // Evita "piscar" para null/0 em erros temporários de rede/back-end
      if (error) {
        console.error('Erro ao buscar operação ativa:', error);
        return;
      }

      if (data) {
        setActiveOperation({
          longSymbol: data.long_symbol,
          shortSymbol: data.short_symbol,
          currentPnl: data.current_pnl || 0,
          isTest: data.is_test || false,
          entryPriceLong: data.entry_price_long || 0,
          entryPriceShort: data.entry_price_short || 0,
          leverageLong: data.leverage_long || 1,
          leverageShort: data.leverage_short || 1,
          longClosed: data.long_closed || false,
          shortClosed: data.short_closed || false,
          longClosePnl: data.long_close_pnl || 0,
          shortClosePnl: data.short_close_pnl || 0
        });
      } else {
        setActiveOperation(null);
      }
    };

    fetchActiveOperation();
    const interval = setInterval(fetchActiveOperation, 30000);
    return () => clearInterval(interval);
  }, []);

  // Fetch real PnL from Binance
  useEffect(() => {
    if (!activeOperation) {
      setCalculatedPnl(0);
      return;
    }

    const fetchRealPnl = async () => {
      try {
        let longPnl = 0;
        let shortPnl = 0;

        // Se long já foi fechado, usa o PnL salvo
        if (activeOperation.longClosed) {
          longPnl = activeOperation.longClosePnl;
        }

        // Se short já foi fechado, usa o PnL salvo
        if (activeOperation.shortClosed) {
          shortPnl = activeOperation.shortClosePnl;
        }

        // Se for operação de teste, calcular baseado nos preços
        if (activeOperation.isTest) {
          if (!activeOperation.longClosed && activeOperation.entryPriceLong > 0) {
            const longRes = await fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${activeOperation.longSymbol}`);
            const longData = await longRes.json();
            const currentLongPrice = parseFloat(longData.price);
            // Calcular PnL em valor financeiro (simulado)
            const longNotional = 25 * activeOperation.leverageLong; // Metade do investimento padrão
            const longChange = (currentLongPrice - activeOperation.entryPriceLong) / activeOperation.entryPriceLong;
            longPnl = longChange * longNotional;
          }

          if (!activeOperation.shortClosed && activeOperation.entryPriceShort > 0) {
            const shortRes = await fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${activeOperation.shortSymbol}`);
            const shortData = await shortRes.json();
            const currentShortPrice = parseFloat(shortData.price);
            // Calcular PnL em valor financeiro (simulado)
            const shortNotional = 25 * activeOperation.leverageShort;
            const shortChange = (activeOperation.entryPriceShort - currentShortPrice) / activeOperation.entryPriceShort;
            shortPnl = shortChange * shortNotional;
          }
        } else {
          // Operação REAL: buscar PnL diretamente da Binance
          // Se ambas já foram fechadas, não precisa consultar e evita "piscar"
          if (activeOperation.longClosed && activeOperation.shortClosed) {
            setCalculatedPnl(longPnl + shortPnl);
            return;
          }

          const { data, error } = await supabase.functions.invoke('binance-trading', {
            body: { action: 'get_positions' }
          });

          // Em falhas temporárias, mantenha o último PnL exibido (não zera)
          if (error || !data?.success) {
            return;
          }

          const positions = Array.isArray(data.data?.positions) ? data.data.positions : [];
          if (!positions.length) {
            return;
          }
          
          if (!activeOperation.longClosed) {
            const longPos = positions.find((p: any) => 
              p.symbol === activeOperation.longSymbol && parseFloat(p.positionAmt) !== 0
            );
            if (longPos) {
              longPnl = parseFloat(longPos.unrealizedProfit || '0');
            }
          }

          if (!activeOperation.shortClosed) {
            const shortPos = positions.find((p: any) => 
              p.symbol === activeOperation.shortSymbol && parseFloat(p.positionAmt) !== 0
            );
            if (shortPos) {
              shortPnl = parseFloat(shortPos.unrealizedProfit || '0');
            }
          }
        }

        const totalPnl = longPnl + shortPnl;
        setCalculatedPnl(totalPnl);
      } catch (error) {
        console.error('Erro ao buscar PnL:', error);
      }
    };

    fetchRealPnl();
    const interval = setInterval(fetchRealPnl, 5000);
    return () => clearInterval(interval);
  }, [activeOperation]);

  const formatDate = () => {
    return new Date().toLocaleDateString('pt-BR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };


  return (
    <div className="space-y-4">
      {/* Header com data e botão de créditos */}
      <Card className="p-4 sm:p-5 bg-gradient-to-br from-primary/10 via-card/50 to-accent/10 border-primary/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-accent/5 rounded-full blur-2xl" />
        
        <div className="relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              <span className="text-lg font-semibold text-foreground">
                Seja Bem-vindo, <span className="text-primary">{userName || "Trader"}</span>
              </span>
            </div>
            <span className="text-sm text-muted-foreground capitalize ml-7">{formatDate()}</span>
          </div>
          
          <Button 
            onClick={onAddCredits}
            variant="outline"
            size="sm"
            className="border-primary/30 hover:bg-primary/10"
          >
            <Plus className="h-4 w-4 mr-1.5" />
            Adicionar Créditos
          </Button>
        </div>
      </Card>


      {/* Operação Ativa */}
      {activeOperation && (
        <Card className="p-4 bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-500/30">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/30">
                <Activity className="h-5 w-5 text-amber-400 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-foreground">Operação Ativa</h3>
                  {activeOperation.isTest && (
                    <Badge variant="outline" className="text-[10px] border-blue-500/30 text-blue-400">
                      TESTE
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {activeOperation.longSymbol} / {activeOperation.shortSymbol}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-4 w-full sm:w-auto">
              <div className="text-center">
                <p className="text-[10px] text-muted-foreground uppercase">PnL</p>
                <p className={`text-xl font-bold font-mono ${
                  calculatedPnl >= 0 ? 'text-profit' : 'text-loss'
                }`}>
                  {calculatedPnl >= 0 ? '+' : ''}${calculatedPnl.toFixed(2)}
                </p>
              </div>
              
              <Button 
                onClick={() => navigate('/aurion-strategy')}
                size="sm"
                className="gradient-button"
              >
                <Zap className="h-4 w-4 mr-1.5" />
                Ver Operação
                <ArrowRight className="h-4 w-4 ml-1.5" />
              </Button>
            </div>
          </div>
        </Card>
      )}


      {/* Saldo Card */}
      <Card className="p-4 bg-card/50 border-border/30">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-profit/10">
            <Wallet className="h-5 w-5 text-profit" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Saldo Binance</p>
            <p className={`text-lg font-bold font-mono ${binanceBalance >= 0 ? 'text-profit' : 'text-loss'}`}>
              ${binanceBalance.toFixed(2)}
            </p>
            {usdBrlRate > 0 && (
              <p className="text-xs text-muted-foreground font-mono">
                R$ {(binanceBalance * usdBrlRate).toFixed(2)}
              </p>
            )}
          </div>
        </div>
      </Card>

      {/* Top Movers Carousel */}
      <TopMoverCarousel />

      {/* Crypto Ticker */}
      <CryptoTicker />

      {/* News Section */}
      <CryptoNews />
    </div>
  );
};
