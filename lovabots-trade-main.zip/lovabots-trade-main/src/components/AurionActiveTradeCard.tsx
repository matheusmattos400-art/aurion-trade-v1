import { memo } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Zap } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import type { AurionToken, SimulatedTrade } from "@/hooks/useAurionScanner";

interface AurionActiveTradeCardProps {
  trade: SimulatedTrade;
  liveData?: { price: number; pnlPercent: number; pnlUsd: number };
  onViewChart: (token: AurionToken) => void;
  onExitTrade: (tradeId: string) => void;
}

export const AurionActiveTradeCard = memo(({
  trade,
  liveData,
  onViewChart,
  onExitTrade,
}: AurionActiveTradeCardProps) => {
  const currentPrice = liveData?.price || trade.entryPrice;
  const pnlPercent = liveData?.pnlPercent || 0;
  const pnlUsd = liveData?.pnlUsd || 0;
  const investment = trade.investmentAmount || 100;
  const currentBalance = investment + pnlUsd;

  const formatPrice = (price: number) => {
    if (price === 0) return "-";
    if (price >= 1) return price.toFixed(4);
    if (price >= 0.0001) return price.toFixed(6);
    return price.toFixed(8);
  };

  return (
    <Card className={`glass-card p-4 ${pnlPercent >= 0 ? 'border-green-500/30' : 'border-red-500/30'}`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          {trade.token.imageUrl && (
            <img 
              src={trade.token.imageUrl} 
              alt={trade.token.symbol} 
              className="w-8 h-8 rounded-full"
              onError={(e) => { e.currentTarget.style.display = 'none'; }}
            />
          )}
          <div>
            <h3 className="font-bold text-sm">{trade.token.symbol}</h3>
            <p className="text-xs text-muted-foreground">{trade.token.name}</p>
          </div>
        </div>
        <div className={`text-right px-2 py-1 rounded-lg ${pnlPercent >= 0 ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
          <p className={`text-sm font-bold ${pnlPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {pnlPercent >= 0 ? '+' : ''}{pnlPercent.toFixed(2)}%
          </p>
          <p className={`text-xs ${pnlPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {pnlUsd >= 0 ? '+' : ''}${pnlUsd.toFixed(2)}
          </p>
        </div>
      </div>

      {/* Balance Highlight */}
      <div className={`rounded-lg p-3 mb-3 ${pnlPercent >= 0 ? 'bg-green-500/10 border border-green-500/20' : 'bg-red-500/10 border border-red-500/20'}`}>
        <p className="text-xs text-muted-foreground text-center mb-1">Saldo da Operação</p>
        <p className={`text-xl font-bold text-center ${pnlPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
          ${currentBalance.toFixed(2)}
        </p>
      </div>

      {/* Price Info */}
      <div className="space-y-1.5 text-sm mb-4">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Entrada:</span>
          <span className="font-mono text-xs">${formatPrice(trade.entryPrice)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Atual:</span>
          <span className="font-mono text-xs">${formatPrice(currentPrice)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Investido:</span>
          <span className="font-bold">${investment.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Tempo:</span>
          <span className="text-xs">
            {formatDistanceToNow(new Date(trade.entryTime), { addSuffix: true, locale: ptBR })}
          </span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-2">
        <Button
          variant="outline"
          size="sm"
          className="flex-1"
          onClick={() => onViewChart(trade.token)}
        >
          <Zap className="w-3 h-3 mr-1" />
          Gráfico
        </Button>
        <Button
          variant="destructive"
          size="sm"
          className="flex-1"
          onClick={() => onExitTrade(trade.id)}
        >
          <X className="w-3 h-3 mr-1" />
          Encerrar
        </Button>
      </div>
    </Card>
  );
});

AurionActiveTradeCard.displayName = "AurionActiveTradeCard";
