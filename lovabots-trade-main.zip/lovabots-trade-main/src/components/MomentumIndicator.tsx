import { useState, useEffect, useRef, useCallback } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine, Legend } from "recharts";
import { useTradingMode } from "@/contexts/TradingModeContext";
import { supabase } from "@/integrations/supabase/client";


interface MomentumIndicatorProps {
  longSymbol: string;
  shortSymbol: string;
  entryTime?: Date;
  entryMomentum?: number; // Momentum congelado no momento da entrada (do banco)
}

interface MomentumData {
  time: string;
  timestamp: number; // Unix timestamp para identificação única
  correlation: number;
  periodsFromEntry: number;
  fromDatabase: boolean; // Indica se veio do banco (congelado) ou foi recalculado
}

interface LiquidityData {
  time: string;
  longLiquidity: number;
  shortLiquidity: number;
  longLiquidityChange: number;
  shortLiquidityChange: number;
  hoursFromEntry: number;
}

interface MomentumHistoryRecord {
  timestamp: string;
  momentum: number;
}

/**
 * Momentum Indicator (30min)
 * 
 * REGRAS IMPORTANTES:
 * 1. A cada 30 minutos, calcular momentum usando SOMENTE dados até o candle atual
 * 2. Salvar valor no banco (timestamp -> momentum) - NUNCA RECALCULAR
 * 3. Quando abre operação, salvar momentum_da_entrada fixo no banco
 * 4. Dados históricos vêm do banco, dados novos são calculados e salvos
 */
export const MomentumIndicator = ({ longSymbol, shortSymbol, entryTime, entryMomentum }: MomentumIndicatorProps) => {
  const { isB3Mode } = useTradingMode();
  const [data, setData] = useState<MomentumData[]>([]);
  const [liquidityData, setLiquidityData] = useState<LiquidityData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<NodeJS.Timeout>();
  const realtimeIntervalRef = useRef<NodeJS.Timeout>();
  const lastKlinesRef = useRef<{ longSymbol: string, shortSymbol: string, longPrices: number[], shortPrices: number[], entryIndex: number } | null>(null);
  const lastSavedTimestampRef = useRef<number>(0);
  
  // CRÍTICO: Congelar valores de entrada para evitar recálculos
  const frozenEntryTimeRef = useRef<Date | undefined>(undefined);
  const frozenEntryMomentumRef = useRef<number | undefined>(undefined);
  const hasOperationRef = useRef<boolean>(false);
  
  // Congelar entryTime e entryMomentum na primeira vez que aparecem
  if (entryTime && !hasOperationRef.current) {
    frozenEntryTimeRef.current = entryTime;
    frozenEntryMomentumRef.current = entryMomentum;
    hasOperationRef.current = true;
  }
  
  // Liberar quando operação termina
  if (!entryTime && hasOperationRef.current) {
    frozenEntryTimeRef.current = undefined;
    frozenEntryMomentumRef.current = undefined;
    hasOperationRef.current = false;
  }

  // Calcular correlação entre dois arrays
  const calculateCorrelation = (x: number[], y: number[]): number => {
    const n = x.length;
    if (n < 2) return 0;

    const meanX = x.reduce((a, b) => a + b, 0) / n;
    const meanY = y.reduce((a, b) => a + b, 0) / n;

    let numerator = 0;
    let sumSqX = 0;
    let sumSqY = 0;

    for (let i = 0; i < n; i++) {
      const diffX = x[i] - meanX;
      const diffY = y[i] - meanY;
      numerator += diffX * diffY;
      sumSqX += diffX * diffX;
      sumSqY += diffY * diffY;
    }

    const denominator = Math.sqrt(sumSqX * sumSqY);
    return denominator === 0 ? 0 : numerator / denominator;
  };

  // Salvar momentum no banco de dados (nunca recalcular)
  const saveMomentumToDatabase = useCallback(async (
    timestamp: Date, 
    momentum: number
  ) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Arredondar timestamp para o início do período de 30min
      const roundedTimestamp = new Date(Math.floor(timestamp.getTime() / 1800000) * 1800000);
      
      // Evitar salvar o mesmo timestamp novamente
      if (roundedTimestamp.getTime() <= lastSavedTimestampRef.current) {
        return;
      }

      const { error } = await supabase
        .from("momentum_history")
        .upsert({
          user_id: user.id,
          long_symbol: longSymbol,
          short_symbol: shortSymbol,
          timestamp: roundedTimestamp.toISOString(),
          momentum: momentum,
        }, {
          onConflict: 'user_id,long_symbol,short_symbol,timestamp'
        });

      if (!error) {
        lastSavedTimestampRef.current = roundedTimestamp.getTime();
        console.log("💾 Momentum salvo no banco:", roundedTimestamp.toISOString(), momentum.toFixed(4) + "%");
      }
    } catch (err) {
      console.error("Erro ao salvar momentum:", err);
    }
  }, [longSymbol, shortSymbol]);

  // Buscar histórico de momentum do banco de dados
  const fetchMomentumHistory = useCallback(async (): Promise<Map<number, number>> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return new Map();

      const { data: history, error } = await supabase
        .from("momentum_history")
        .select("timestamp, momentum")
        .eq("user_id", user.id)
        .eq("long_symbol", longSymbol)
        .eq("short_symbol", shortSymbol)
        .order("timestamp", { ascending: true });

      if (error) {
        console.error("Erro ao buscar histórico:", error);
        return new Map();
      }

      const historyMap = new Map<number, number>();
      history?.forEach((record: MomentumHistoryRecord) => {
        const ts = new Date(record.timestamp).getTime();
        historyMap.set(ts, Number(record.momentum));
      });

      console.log(`📚 ${historyMap.size} registros de momentum carregados do banco`);
      return historyMap;
    } catch (err) {
      console.error("Erro ao buscar histórico:", err);
      return new Map();
    }
  }, [longSymbol, shortSymbol]);

  useEffect(() => {
    if (!longSymbol || !shortSymbol) {
      setIsLoading(false);
      return;
    }

    // CRÍTICO: Limpar ref quando par muda para evitar dados misturados
    if (lastKlinesRef.current && 
        (lastKlinesRef.current.longSymbol !== longSymbol || lastKlinesRef.current.shortSymbol !== shortSymbol)) {
      console.log('[MOMENTUM] Par mudou, limpando cache...');
      lastKlinesRef.current = null;
      setData([]); // Limpar dados do par anterior
    }

    // Usar valores congelados para evitar recálculos durante a operação
    const activeEntryTime = frozenEntryTimeRef.current;
    const activeEntryMomentum = frozenEntryMomentumRef.current;

    const fetchMomentumData = async () => {
      try {
        // Não setar isLoading=true para evitar piscar o componente inteiro
        // setIsLoading(true);
        setError(null);
        // Modo B3: gerar dados mockados
        if (isB3Mode) {
          const mockCorrelationData: MomentumData[] = [];
          const mockLiquidityData: LiquidityData[] = [];
          const entryPeriod = activeEntryTime ? Math.floor((Date.now() - activeEntryTime.getTime()) / 1800000) : 0;
          const entryHour = activeEntryTime ? Math.floor((Date.now() - activeEntryTime.getTime()) / 3600000) : 0;
          const baseLongLiquidity = 1000000 + Math.random() * 500000;
          const baseShortLiquidity = 800000 + Math.random() * 400000;
          
          for (let i = 0; i <= 48; i++) {
            const periodsFromEntry = i - entryPeriod;
            const momentum = (Math.sin(i / 10) * 2 + (Math.random() - 0.5) * 0.5);
            
            mockCorrelationData.push({
              time: `${i}`,
              timestamp: Date.now() - (48 - i) * 1800000,
              correlation: momentum,
              periodsFromEntry,
              fromDatabase: false
            });
          }

          for (let i = 0; i <= 24; i++) {
            const hoursFromEntry = i - entryHour;
            const longLiquidity = baseLongLiquidity * (1 + Math.sin(i / 6) * 0.2 + (Math.random() - 0.5) * 0.1);
            const shortLiquidity = baseShortLiquidity * (1 + Math.cos(i / 5) * 0.15 + (Math.random() - 0.5) * 0.08);
            
            mockLiquidityData.push({
              time: `${i}h`,
              longLiquidity,
              shortLiquidity,
              longLiquidityChange: ((longLiquidity - baseLongLiquidity) / baseLongLiquidity) * 100,
              shortLiquidityChange: ((shortLiquidity - baseShortLiquidity) / baseShortLiquidity) * 100,
              hoursFromEntry
            });
          }

          setData(mockCorrelationData);
          setLiquidityData(mockLiquidityData);
          setIsLoading(false);
          return;
        }

        // Buscar histórico do banco de dados PRIMEIRO
        const historyMap = await fetchMomentumHistory();

        // Buscar dados de momentum 30min (48 períodos = 24h)
        const [longResponseMomentum, shortResponseMomentum] = await Promise.all([
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${longSymbol}&interval=30m&limit=48`),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${shortSymbol}&interval=30m&limit=48`)
        ]);

        // Buscar dados de 1 hora para liquidez (últimas 24 velas)
        const [longResponse1h, shortResponse1h] = await Promise.all([
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${longSymbol}&interval=1h&limit=24`),
          fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${shortSymbol}&interval=1h&limit=24`)
        ]);

        if (!longResponseMomentum.ok || !shortResponseMomentum.ok || !longResponse1h.ok || !shortResponse1h.ok) {
          throw new Error("Erro ao buscar dados da Binance");
        }

        const longKlinesMomentum = await longResponseMomentum.json();
        const shortKlinesMomentum = await shortResponseMomentum.json();
        const longKlines1h = await longResponse1h.json();
        const shortKlines1h = await shortResponse1h.json();

        if (longKlinesMomentum.length < 10 || shortKlinesMomentum.length < 10) {
          throw new Error("Dados insuficientes");
        }

        // ===== PROCESSAMENTO DE CORRELAÇÃO =====
        // CRÍTICO: Filtrar apenas candles FECHADOS (igual ao sinal de entrada)
        const now = Date.now();
        const closedLongKlines = longKlinesMomentum.filter((k: number[]) => k[6] < now);
        const closedShortKlines = shortKlinesMomentum.filter((k: number[]) => k[6] < now);
        
        const longPrices = closedLongKlines.map((k: number[]) => parseFloat(String(k[4])));
        const shortPrices = closedShortKlines.map((k: number[]) => parseFloat(String(k[4])));
        
        // Encontrar o índice correspondente ao entryTime (se houver)
        let entryIndexMomentum = 0;
        if (activeEntryTime) {
          const entryTimestamp = activeEntryTime.getTime();
          entryIndexMomentum = closedLongKlines.findIndex((k: number[]) => k[0] >= entryTimestamp);
          if (entryIndexMomentum === -1) entryIndexMomentum = closedLongKlines.length - 1;
        } else {
          entryIndexMomentum = closedLongKlines.length - 1;
        }

        // Salvar dados para atualização em tempo real (APENAS candles fechados)
        lastKlinesRef.current = { longSymbol, shortSymbol, longPrices, shortPrices, entryIndex: entryIndexMomentum };

        const ratios = longPrices.map((p: number, i: number) => p / shortPrices[i]);

        // Calcular momentum simples: variação % do ratio entre candles consecutivos
        const momentumValues = ratios.map((ratio: number, i: number) => {
          if (i === 0) return 0;
          const prevRatio = ratios[i - 1];
          return ((ratio - prevRatio) / prevRatio) * 100;
        });

        const momentumData: MomentumData[] = [];

        // Criar dados do gráfico - APENAS com candles fechados
        for (let i = 0; i < ratios.length; i++) {
          const periodsFromEntry = i - entryIndexMomentum;
          const candleTimestamp = longKlinesMomentum[i][0];
          const candleCloseTimestamp = longKlinesMomentum[i][6];
          const timestamp = new Date(candleTimestamp);
          const timeKey = timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
          
          // PULAR candle atual (não fechado) - evita mudanças em tempo real
          if (candleCloseTimestamp >= now) {
            continue;
          }
          
          // Arredondar para o início do período de 30min
          const roundedTimestamp = Math.floor(candleTimestamp / 1800000) * 1800000;
          
          // Usar momentum simples (variação entre candles)
          let momentum = momentumValues[i];
          let fromDatabase = false;
          
          // REGRA PRINCIPAL: Se temos operação ativa, congelar dados históricos
          if (activeEntryTime) {
            // Verificar se temos valor no banco
            if (historyMap.has(roundedTimestamp)) {
              momentum = historyMap.get(roundedTimestamp)!;
              fromDatabase = true;
            } else {
              // Não temos no banco, salvar o valor calculado APENAS UMA VEZ
              await saveMomentumToDatabase(timestamp, momentum);
              fromDatabase = true; // Marcar como congelado
            }
            
            // Se é o ponto de entrada e temos entryMomentum, usar ele
            if (periodsFromEntry === 0 && activeEntryMomentum !== undefined) {
              momentum = activeEntryMomentum;
              fromDatabase = true;
            }
          }
          
          momentumData.push({
            time: timeKey,
            timestamp: roundedTimestamp,
            correlation: momentum,
            periodsFromEntry,
            fromDatabase
          });
        }

        // ===== PROCESSAMENTO DE LIQUIDEZ (1h) =====
        const longVolumes1h = longKlines1h.map((k: number[]) => parseFloat(String(k[7])));
        const shortVolumes1h = shortKlines1h.map((k: number[]) => parseFloat(String(k[7])));

        let entryIndex1h = 0;
        if (activeEntryTime) {
          const entryTimestamp = activeEntryTime.getTime();
          entryIndex1h = longKlines1h.findIndex((k: number[]) => k[0] >= entryTimestamp);
          if (entryIndex1h === -1) entryIndex1h = longKlines1h.length - 1;
        } else {
          entryIndex1h = 0;
        }

        const initialLongLiquidity = longVolumes1h[entryIndex1h] || longVolumes1h[0];
        const initialShortLiquidity = shortVolumes1h[entryIndex1h] || shortVolumes1h[0];

        const liquidityDataArray: LiquidityData[] = longKlines1h.map((k: number[], i: number) => {
          const timestamp = new Date(k[0]);
          const currentLongLiquidity = longVolumes1h[i];
          const currentShortLiquidity = shortVolumes1h[i];
          const hoursFromEntry = i - entryIndex1h;

          return {
            time: timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
            longLiquidity: currentLongLiquidity,
            shortLiquidity: currentShortLiquidity,
            longLiquidityChange: ((currentLongLiquidity - initialLongLiquidity) / initialLongLiquidity) * 100,
            shortLiquidityChange: ((currentShortLiquidity - initialShortLiquidity) / initialShortLiquidity) * 100,
            hoursFromEntry
          };
        });

        setData(momentumData);
        setLiquidityData(liquidityDataArray);
        setIsLoading(false);
      } catch (err) {
        console.error('Erro ao calcular momentum:', err);
        setError(err instanceof Error ? err.message : 'Erro desconhecido');
        setIsLoading(false);
      }
    };

    // Buscar dados inicialmente
    fetchMomentumData();

    // Atualizar dados completos a cada 30 segundos para manter sincronizado com o sinal
    intervalRef.current = setInterval(fetchMomentumData, 30000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  // CRÍTICO: Remover entryTime e entryMomentum das dependências para evitar recálculos
  // Os valores são congelados via refs
  }, [longSymbol, shortSymbol, isB3Mode, fetchMomentumHistory, saveMomentumToDatabase]);

  // Atualização em tempo real da última ponta (a cada 3 segundos)
  // Mostra o momentum do candle ATUAL (não fechado) como visualização em tempo real
  useEffect(() => {
    if (!longSymbol || !shortSymbol || isB3Mode) return;

    const updateLastPoint = async () => {
      try {
        if (!lastKlinesRef.current || data.length === 0) return;
        
        // CRÍTICO: Verificar se os símbolos na ref correspondem aos símbolos atuais
        // Isso evita usar dados do par antigo quando troca de par
        if (lastKlinesRef.current.longSymbol !== longSymbol || lastKlinesRef.current.shortSymbol !== shortSymbol) {
          return;
        }

        // Buscar preços atuais
        const [longRes, shortRes] = await Promise.all([
          fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${longSymbol}`),
          fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${shortSymbol}`)
        ]);

        // Em caso de falha, manter dados anteriores (não piscar)
        if (!longRes.ok || !shortRes.ok) return;

        const longData = await longRes.json();
        const shortData = await shortRes.json();

        const currentLongPrice = parseFloat(longData.price);
        const currentShortPrice = parseFloat(shortData.price);

        // Validar preços - se inválidos, manter dados anteriores
        if (!currentLongPrice || !currentShortPrice || isNaN(currentLongPrice) || isNaN(currentShortPrice)) {
          return;
        }

        // Calcular momentum em tempo real
        const { longPrices, shortPrices } = lastKlinesRef.current;
        const prevLongPrice = longPrices[longPrices.length - 1];
        const prevShortPrice = shortPrices[shortPrices.length - 1];
        
        if (!prevLongPrice || !prevShortPrice) return;
        
        const prevRatio = prevLongPrice / prevShortPrice;
        const currentRatio = currentLongPrice / currentShortPrice;
        const currentMomentum = ((currentRatio - prevRatio) / prevRatio) * 100;

        // Adicionar ou atualizar o ponto em tempo real (último ponto do gráfico)
        setData(prevData => {
          if (prevData.length === 0) return prevData;
          
          const now = Date.now();
          const currentCandleStart = Math.floor(now / 1800000) * 1800000;
          const lastPoint = prevData[prevData.length - 1];
          
          // Se o último ponto é do candle atual (tempo real), atualizar
          if (lastPoint.timestamp === currentCandleStart) {
            const newData = [...prevData];
            newData[newData.length - 1] = {
              ...lastPoint,
              correlation: currentMomentum
            };
            return newData;
          }
          
          // Senão, adicionar novo ponto para o candle atual
          const timeKey = new Date(currentCandleStart).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
          return [...prevData, {
            time: timeKey,
            timestamp: currentCandleStart,
            correlation: currentMomentum,
            periodsFromEntry: prevData.length - (lastKlinesRef.current?.entryIndex || 0),
            fromDatabase: false
          }];
        });
      } catch (err) {
        // Silenciosamente ignorar erros - manter dados anteriores
      }
    };

    // Atualizar a cada 3 segundos
    realtimeIntervalRef.current = setInterval(updateLastPoint, 1000);
    updateLastPoint(); // Executar imediatamente

    return () => {
      if (realtimeIntervalRef.current) {
        clearInterval(realtimeIntervalRef.current);
      }
    };
  }, [longSymbol, shortSymbol, isB3Mode, data.length]);

  if (!longSymbol || !shortSymbol) {
    return (
      <div className="text-center py-4 text-muted-foreground text-xs">
        Selecione os pares para visualizar momentum e liquidez
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="text-center py-4 text-muted-foreground text-xs">
        Calculando momentum...
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-4 text-destructive text-xs">
        {error}
      </div>
    );
  }

  const lastData = data.length > 0 ? data[data.length - 1] : null;
  const lastLiquidityData = liquidityData.length > 0 ? liquidityData[liquidityData.length - 1] : null;

  return (
    <div className="space-y-2">
      <h3 className="text-xs font-light text-[#a6a6ff]">
        Momentum & Liquidez (30min) {entryTime && <span className="text-green-400">● Valores Congelados</span>}
      </h3>

      {/* Gráfico de Momentum */}
      <div className="h-[120px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <XAxis 
              dataKey="time" 
              stroke="hsl(var(--muted-foreground))"
              style={{ fontSize: '10px' }}
              tickLine={false}
            />
            <YAxis 
              stroke="hsl(var(--muted-foreground))"
              style={{ fontSize: '10px' }}
              tickLine={false}
              tickFormatter={(value) => value.toFixed(1) + '%'}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
                fontSize: '11px'
              }}
              formatter={(value: number, name: string) => {
                if (name === 'Momentum Ratio') return [value.toFixed(2) + '%', name];
                return [value.toFixed(1) + '%', name];
              }}
            />
            <Legend 
              wrapperStyle={{ fontSize: '10px' }}
              iconSize={8}
            />
            
            {/* Linha zero (referência) */}
            <ReferenceLine 
              y={0} 
              stroke="hsl(var(--muted-foreground))" 
              strokeDasharray="3 3"
              opacity={0.5}
            />
            
            {/* Linha vertical no marco zero (entrada) */}
            {entryTime && (
              <ReferenceLine 
                x={data.find(d => d.periodsFromEntry === 0)?.time || ''} 
                stroke="#ef4444"
                strokeWidth={2}
                label={{ value: `Entrada${entryMomentum !== undefined ? ` (${entryMomentum >= 0 ? '+' : ''}${entryMomentum.toFixed(2)}%)` : ''}`, position: 'top', fill: '#ef4444', fontSize: 10 }}
              />
            )}
            
            {/* Linha de momentum do ratio */}
            <Line 
              type="monotone" 
              dataKey="correlation" 
              stroke="#60a5fa"
              strokeWidth={2}
              dot={{ r: 1 }}
              name="Momentum Ratio"
              yAxisId={0}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Gráfico de Variação de Liquidez (1h) */}
      <div className="h-[120px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={liquidityData}>
            <XAxis 
              dataKey="time" 
              stroke="hsl(var(--muted-foreground))"
              style={{ fontSize: '10px' }}
              tickLine={false}
            />
            <YAxis 
              stroke="hsl(var(--muted-foreground))"
              style={{ fontSize: '10px' }}
              tickLine={false}
              tickFormatter={(value) => value.toFixed(0) + '%'}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
                fontSize: '11px'
              }}
              formatter={(value: number, name: string) => [value.toFixed(1) + '%', name]}
            />
            <Legend 
              wrapperStyle={{ fontSize: '10px' }}
              iconSize={8}
            />
            
            {/* Linha zero (referência) */}
            <ReferenceLine 
              y={0} 
              stroke="hsl(var(--muted-foreground))" 
              strokeDasharray="3 3"
              opacity={0.5}
            />
            
            {/* Linha vertical no marco zero (entrada) */}
            {entryTime && (
              <ReferenceLine 
                x={liquidityData.find(d => d.hoursFromEntry === 0)?.time || ''} 
                stroke="#ef4444"
                strokeWidth={1.5}
                strokeDasharray="3 3"
              />
            )}
            
            {/* Linhas de variação de liquidez */}
            <Line 
              type="monotone" 
              dataKey="longLiquidityChange" 
              stroke="#22c55e"
              strokeWidth={2}
              dot={{ r: 1 }}
              name="Δ Liquidez LONG"
            />
            <Line 
              type="monotone" 
              dataKey="shortLiquidityChange" 
              stroke="#ef4444"
              strokeWidth={2}
              dot={{ r: 1 }}
              name="Δ Liquidez SHORT"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-2 gap-3 text-xs pt-2 border-t border-border/50">
        {/* Coluna Momentum */}
        <div className="space-y-2">
          <div className="text-center text-muted-foreground font-semibold">Momentum Ratio (30min)</div>
          <div className="flex justify-around">
            <div className="text-center">
              <div className="text-muted-foreground text-[10px]">Atual</div>
              <div className={`font-semibold ${lastData && lastData.correlation >= 0 ? 'text-profit' : 'text-loss'}`}>
                {lastData ? (lastData.correlation >= 0 ? '+' : '') + lastData.correlation.toFixed(2) + '%' : '-'}
              </div>
            </div>
            <div className="text-center">
              <div className="text-muted-foreground text-[10px]">Máx</div>
              <div className="text-profit font-semibold">
                {data.length > 0 ? '+' + Math.max(...data.map(d => d.correlation)).toFixed(2) + '%' : '-'}
              </div>
            </div>
            <div className="text-center">
              <div className="text-muted-foreground text-[10px]">Mín</div>
              <div className="text-loss font-semibold">
                {data.length > 0 ? Math.min(...data.map(d => d.correlation)).toFixed(2) + '%' : '-'}
              </div>
            </div>
          </div>
        </div>

        {/* Coluna Liquidez */}
        <div className="space-y-2">
          <div className="text-center text-muted-foreground font-semibold">Liquidez vs Entrada (1h)</div>
          <div className="flex justify-around">
            <div className="text-center">
              <div className="text-muted-foreground text-[10px]">LONG</div>
              <div className={`font-semibold ${lastLiquidityData && lastLiquidityData.longLiquidityChange >= 0 ? 'text-profit' : 'text-loss'}`}>
                {lastLiquidityData ? (lastLiquidityData.longLiquidityChange >= 0 ? '+' : '') + lastLiquidityData.longLiquidityChange.toFixed(1) + '%' : '-'}
              </div>
            </div>
            <div className="text-center">
              <div className="text-muted-foreground text-[10px]">SHORT</div>
              <div className={`font-semibold ${lastLiquidityData && lastLiquidityData.shortLiquidityChange >= 0 ? 'text-profit' : 'text-loss'}`}>
                {lastLiquidityData ? (lastLiquidityData.shortLiquidityChange >= 0 ? '+' : '') + lastLiquidityData.shortLiquidityChange.toFixed(1) + '%' : '-'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
