import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { User, Mail, Calendar, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const UserProfile = () => {
  const [userEmail, setUserEmail] = useState("");
  const [createdAt, setCreatedAt] = useState("");
  const [isUpdating, setIsUpdating] = useState(false);

  const handleClearCache = async () => {
    setIsUpdating(true);
    try {
      // Limpar cache do service worker
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map(name => caches.delete(name)));
      }

      // Forçar atualização do service worker
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map(reg => reg.unregister()));
      }

      toast.success("Cache limpo! Recarregando página...");
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (error) {
      console.error("Erro ao limpar cache:", error);
      toast.error("Erro ao limpar cache");
    } finally {
      setIsUpdating(false);
    }
  };

  useEffect(() => {
    const fetchUserInfo = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setUserEmail(user.email || "");
        setCreatedAt(new Date(user.created_at).toLocaleDateString('pt-BR', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }));
      }
    };

    fetchUserInfo();
  }, []);

  return (
    <div className="space-y-4">
      <Card className="glass-card p-4 space-y-4">
        <div className="flex items-center gap-3 pb-3 border-b border-border">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
            <User className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="font-bold text-lg">Informações da Conta</h3>
            <p className="text-xs text-muted-foreground">Dados do seu perfil</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="flex items-center gap-2 text-muted-foreground">
              <Mail className="w-4 h-4" />
              Email
            </Label>
            <div className="p-3 bg-muted/50 rounded-lg">
              <p className="font-medium">{userEmail}</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="w-4 h-4" />
              Membro desde
            </Label>
            <div className="p-3 bg-muted/50 rounded-lg">
              <p className="font-medium">{createdAt}</p>
            </div>
          </div>
        </div>
      </Card>

      <Card className="glass-card p-4">
        <div className="space-y-3">
          <div>
            <h3 className="font-bold text-lg">Atualizar App</h3>
            <p className="text-xs text-muted-foreground">Limpar cache e ver novos ícones do PWA</p>
          </div>
          <Button 
            onClick={handleClearCache}
            disabled={isUpdating}
            className="w-full"
            variant="outline"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isUpdating ? 'animate-spin' : ''}`} />
            {isUpdating ? "Limpando..." : "Limpar Cache e Recarregar"}
          </Button>
        </div>
      </Card>
    </div>
  );
};