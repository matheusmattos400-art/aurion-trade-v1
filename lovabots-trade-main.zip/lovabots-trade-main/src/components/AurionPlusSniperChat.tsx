import { useState, useEffect, useRef, useCallback } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useUserControlledAutoScroll } from "@/hooks/useUserControlledAutoScroll";
import { 
  Send, 
  RefreshCw, 
  Sparkles,
  TrendingUp,
  AlertTriangle,
  Shield,
  Clock,
  Target,
  Loader2
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  isAIGatewayTemporarilyDisabled,
  disableAIGatewayForMinutes,
  getAIGatewayUserMessage,
  shouldToastPaymentRequiredOnce,
} from "@/utils/aiCreditsGuard";
import type { AurionToken } from "@/hooks/useAurionScanner";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface HeliusRawData {
  tokenMint: string;
  collectedAt: string;
  block0: {
    creationSlot: number | null;
    creationTime: string | null;
    wallets: string[];
    transactionCount: number;
    totalTransactionsAnalyzed: number;
  };
  holders: {
    count: number;
    topAccounts: { address: string; balance: number }[];
  };
  devWallet: null | {
    address: string;
    inferred?: boolean;
    transactionCount: number;
    transactions: any[];
  };
  _meta?: Record<string, any>;
}

interface AurionPlusSniperChatProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  token: AurionToken | null;
}

export function AurionPlusSniperChat({
  open,
  onOpenChange,
  token
}: AurionPlusSniperChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const [heliusData, setHeliusData] = useState<HeliusRawData | null>(null);
  const { scrollContainerRef, lastItemRef, onScroll } = useUserControlledAutoScroll<HTMLDivElement>([
    messages,
  ]);
  const hasInitialized = useRef(false);

  // Auto-scroll behavior is user-controlled (see hook).

  // Collect Helius data and start initial analysis when chat opens
  useEffect(() => {
    if (open && token && !hasInitialized.current) {
      hasInitialized.current = true;
      initializeSniperChat();
    }
  }, [open, token]);

  // Reset when closed
  useEffect(() => {
    if (!open) {
      hasInitialized.current = false;
      setMessages([]);
      setHeliusData(null);
    }
  }, [open]);

  const collectHeliusData = async (): Promise<HeliusRawData | null> => {
    if (!token?.tokenAddress) return null;

    try {
      console.log("[SniperChat] Collecting Helius data for:", token.tokenAddress);

      const { data, error } = await supabase.functions.invoke("pump-fun-data-collector", {
        body: {
          tokenMint: token.tokenAddress,
          includeHolders: true,
          includeDevHistory: true,
        },
      });

      if (error) {
        console.error("[SniperChat] Error collecting Helius data:", error);
        return null;
      }

      const raw = data as HeliusRawData | undefined;
      if (!raw?.block0?.wallets || !raw?.holders?.topAccounts) {
        console.warn("[SniperChat] Unexpected collector payload:", data);
        return null;
      }

      console.log("[SniperChat] Helius data received:", {
        block0Wallets: raw.block0.wallets.length,
        topHolders: raw.holders.topAccounts.length,
        devWallet: raw.devWallet?.address || null,
        devInferred: !!raw.devWallet?.inferred,
      });

      return raw;
    } catch (err) {
      console.error("[SniperChat] Error calling pump-fun-data-collector:", err);
      return null;
    }
  };

  const initializeSniperChat = async () => {
    if (!token) return;

    // Check circuit breaker first
    if (isAIGatewayTemporarilyDisabled()) {
      setMessages([{
        role: "assistant",
        content: `⚠️ ${getAIGatewayUserMessage(402)}`,
        timestamp: new Date()
      }]);
      return;
    }

    setIsInitializing(true);
    
    // Add initial loading message
    const loadingMsg: Message = {
      role: "assistant",
      content: `🎯 Preparando análise Sniper 2000% para **${token.symbol}**...\n\n⏳ Coletando dados do Bloco 0, Bundle e histórico do Dev via Helius...`,
      timestamp: new Date()
    };
    setMessages([loadingMsg]);

    try {
      // Collect raw data from Helius
      const rawData = await collectHeliusData();
      setHeliusData(rawData);

      // Send to AI for initial analysis
      const ageMinutes = token.ageHours * 60;
      
      const block0Wallets = rawData?.block0?.wallets || [];
      const topHolders = rawData?.holders?.topAccounts || [];
      const topHolderWallets = topHolders.map((h) => h.address);
      const devWalletAddress = rawData?.devWallet?.address || null;

      const systemContext = `
Você é a Aurion AI, especialista na Estratégia Sniper 2000% para tokens Pump.fun na Solana.

TOKEN SENDO ANALISADO:
- Nome: ${token.name}
- Símbolo: ${token.symbol}
- Contrato (CA): ${token.tokenAddress}
- Preço: $${token.priceUsd}
- Market Cap: $${token.marketCap?.toLocaleString()}
- Liquidez: $${token.liquidity?.toLocaleString()}
- Idade: ${ageMinutes.toFixed(0)} minutos
- Security Score: ${token.securityScore}

DADOS BRUTOS DA HELIUS (SEM ANÁLISE/SEM HEURÍSTICA):
- Block0.wallets (signers do bloco 0): ${block0Wallets.length}
- Holders.topAccounts (top 20): ${topHolders.length}
- Dev wallet: ${devWalletAddress || "N/D"}

LISTAS PARA COMPARAÇÃO (endereços completos):
BLOCK0_WALLETS:
${JSON.stringify(block0Wallets, null, 2)}

TOP_HOLDER_WALLETS:
${JSON.stringify(topHolderWallets, null, 2)}

TOP_HOLDERS (com balance):
${JSON.stringify(topHolders, null, 2)}

DEV_WALLET (se disponível):
${JSON.stringify(rawData?.devWallet, null, 2)}

META:
${JSON.stringify(rawData?._meta, null, 2)}

ESTRATÉGIA SNIPER 2000% (VOCÊ APLICA):
1) Bundle Retention: compare BLOCK0_WALLETS vs TOP_HOLDER_WALLETS e estime % de retenção
2) DNA do Dev: use DEV_WALLET (se houver). Se não houver, diga explicitamente que não é possível calcular DNA do Dev com os dados atuais.
3) Timing: janela ideal 30-90 min
4) Veredito: Borda Verde / Amarela / Sem cor

Obrigatório: nunca diga "dados insuficientes" se BLOCK0_WALLETS e TOP_HOLDER_WALLETS estão presentes; faça uma estimativa com base nessas listas.
`;

      const initialPrompt = `${systemContext}\n\nFaça a análise inicial completa do token no formato Sniper 2000%.`;

      const { data: aiResponse, error: aiError } = await supabase.functions.invoke("aurion-ai-chat", {
        body: {
          messages: [{ role: "user", content: initialPrompt }],
        },
      });

      if (aiError) {
        // Check for 402/429 in error message
        const errMsg = aiError.message || "";
        if (errMsg.includes("402") || errMsg.toLowerCase().includes("payment")) {
          disableAIGatewayForMinutes(10);
          if (shouldToastPaymentRequiredOnce()) {
            toast.error(getAIGatewayUserMessage(402));
          }
          throw new Error(getAIGatewayUserMessage(402));
        }
        throw new Error(aiError.message);
      }

      // Update with AI response
      setMessages([{
        role: "assistant",
        content: aiResponse?.response || "Erro ao gerar análise inicial.",
        timestamp: new Date()
      }]);

    } catch (err) {
      console.error("Error initializing sniper chat:", err);
      const errMsg = err instanceof Error ? err.message : "Erro desconhecido";
      setMessages([{
        role: "assistant",
        content: errMsg.includes("credits") || errMsg.includes("Payment") 
          ? `⚠️ ${errMsg}`
          : `❌ Erro ao inicializar análise para ${token.symbol}. Por favor, tente novamente.`,
        timestamp: new Date()
      }]);
    } finally {
      setIsInitializing(false);
    }
  };

  const sendMessage = useCallback(async () => {
    if (!userInput.trim() || isLoading || !token) return;

    const userMessage: Message = {
      role: "user",
      content: userInput.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setUserInput("");
    setIsLoading(true);

    try {
      // Check if user wants to refresh data
      const isRefreshRequest = userInput.toLowerCase().includes("atualizar") || 
                               userInput.toLowerCase().includes("refresh") ||
                               userInput.toLowerCase().includes("novos dados");

      let currentHeliusData = heliusData;
      
      if (isRefreshRequest) {
        // Fetch fresh data
        const freshData = await collectHeliusData();
        if (freshData) {
          currentHeliusData = freshData;
          setHeliusData(freshData);
        }
      }

      const ageMinutes = token.ageHours * 60;

      const block0Wallets = currentHeliusData?.block0?.wallets || [];
      const topHolders = currentHeliusData?.holders?.topAccounts || [];
      const topHolderWallets = topHolders.map((h) => h.address);
      const devWalletAddress = currentHeliusData?.devWallet?.address || null;

      const systemContext = `
Você é a Aurion AI, especialista na Estratégia Sniper 2000% para tokens Pump.fun.

TOKEN:
- ${token.symbol} (${token.name})
- CA: ${token.tokenAddress}
- Preço: $${token.priceUsd}
- MC: $${token.marketCap?.toLocaleString()}
- Liquidez: $${token.liquidity?.toLocaleString()}
- Idade: ${ageMinutes.toFixed(0)} minutos
- Score: ${token.securityScore}

DADOS BRUTOS HELIUS (${isRefreshRequest ? "ATUALIZADOS AGORA" : "CACHE"}):
- BLOCK0_WALLETS: ${block0Wallets.length}
- TOP_HOLDERS: ${topHolders.length}
- DEV_WALLET: ${devWalletAddress || "N/D"}

BLOCK0_WALLETS:
${JSON.stringify(block0Wallets, null, 2)}

TOP_HOLDER_WALLETS:
${JSON.stringify(topHolderWallets, null, 2)}

TOP_HOLDERS (com balance):
${JSON.stringify(topHolders, null, 2)}

DEV_WALLET:
${JSON.stringify(currentHeliusData?.devWallet, null, 2)}

META:
${JSON.stringify(currentHeliusData?._meta, null, 2)}

REGRAS:
- Para Bundle Retention, compare BLOCK0_WALLETS vs TOP_HOLDER_WALLETS.
- Se listas existirem, responda com estimativa (não diga "dados insuficientes").
`;

      // Build conversation history
      const conversationHistory = messages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const { data: aiResponse, error: aiError } = await supabase.functions.invoke("aurion-ai-chat", {
        body: {
          messages: [{ role: "user", content: userInput.trim() }],
          conversationHistory: [{ role: "user", content: systemContext }, ...conversationHistory],
        },
      });

      if (aiError) {
        throw new Error(aiError.message);
      }

      const assistantMessage: Message = {
        role: "assistant",
        content: aiResponse?.response || "Erro ao processar sua pergunta.",
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);

    } catch (err) {
      console.error("Error sending message:", err);
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "❌ Erro ao processar sua pergunta. Tente novamente.",
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  }, [userInput, isLoading, token, messages, heliusData]);

  const handleRefreshData = async () => {
    if (!token || isLoading) return;
    
    setIsLoading(true);
    
    try {
      const freshData = await collectHeliusData();
      if (freshData) {
        setHeliusData(freshData);
        
        const ageMinutes = token.ageHours * 60;
        
        setMessages(prev => [...prev, {
          role: "assistant",
          content: `🔄 **Dados atualizados!**\n\n⏱️ Idade atual: ${ageMinutes.toFixed(0)} minutos\n📊 Preço: $${token.priceUsd}\n💰 MC: $${token.marketCap?.toLocaleString()}\n\n*Pergunte-me sobre o status atual do Bundle ou Dev.*`,
          timestamp: new Date()
        }]);
        
        toast.success("Dados Helius atualizados!");
      }
    } catch (err) {
      toast.error("Erro ao atualizar dados");
    } finally {
      setIsLoading(false);
    }
  };

  const quickQuestions = [
    "O bundle começou a vender?",
    "Qual o risco de rug agora?",
    "Dev está lucrando muito?",
    "Devo entrar ou esperar?"
  ];

  if (!token) return null;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent 
        side="bottom" 
        className="h-[90vh] sm:h-auto sm:max-h-[90vh] p-0 flex flex-col rounded-t-2xl sm:rounded-none"
      >
        {/* Header */}
        <SheetHeader className="p-3 sm:p-4 border-b bg-gradient-to-r from-amber-500/10 to-yellow-500/10 shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 sm:gap-3">
              {token.imageUrl && (
                <img 
                  src={token.imageUrl} 
                  alt={token.symbol} 
                  className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-card"
                  onError={(e) => (e.currentTarget.style.display = 'none')}
                />
              )}
              <div className="min-w-0">
                <SheetTitle className="flex items-center gap-1.5 sm:gap-2 text-sm sm:text-base">
                  <Target className="w-4 h-4 sm:w-5 sm:h-5 text-amber-500 shrink-0" />
                  <span className="truncate">Sniper 2000% - {token.symbol}</span>
                </SheetTitle>
                <p className="text-[10px] sm:text-xs text-muted-foreground">
                  MC: ${token.marketCap?.toLocaleString()} • {(token.ageHours * 60).toFixed(0)}min
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleRefreshData}
              disabled={isLoading || isInitializing}
              className="h-8 w-8 sm:h-9 sm:w-9"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
          
          {/* Token Stats Bar */}
          <div className="flex gap-1.5 sm:gap-2 mt-2 flex-wrap">
            <Badge variant="outline" className="text-[10px] sm:text-xs">
              <Shield className="w-3 h-3 mr-1" />
              Score: {token.securityScore}
            </Badge>
            <Badge variant="outline" className="text-[10px] sm:text-xs">
              <Clock className="w-3 h-3 mr-1" />
              {(token.ageHours * 60).toFixed(0)}min
            </Badge>
            {heliusData && (
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-[10px] sm:text-xs">
                <Sparkles className="w-3 h-3 mr-1" />
                Helius OK
              </Badge>
            )}
          </div>
        </SheetHeader>

        {/* Messages */}
        <div
          ref={scrollContainerRef}
          onScroll={onScroll}
          className="flex-1 min-h-0 p-3 sm:p-4 overflow-y-auto"
        >
          <div className="space-y-3 sm:space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] rounded-lg p-2 sm:p-3 ${
                    msg.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  <div className="text-xs sm:text-sm whitespace-pre-wrap leading-relaxed">
                    {msg.content.split('\n').map((line, i) => (
                      <span key={i}>
                        {line.includes('**') ? (
                          <span dangerouslySetInnerHTML={{
                            __html: line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                          }} />
                        ) : line}
                        {i < msg.content.split('\n').length - 1 && <br />}
                      </span>
                    ))}
                  </div>
                  <p className="text-[10px] sm:text-xs opacity-50 mt-1">
                    {msg.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
            
            {(isLoading || isInitializing) && (
              <div className="flex justify-start">
                <div className="bg-muted rounded-lg p-2 sm:p-3 flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-xs sm:text-sm text-muted-foreground">
                    {isInitializing ? "Analisando token..." : "Pensando..."}
                  </span>
                </div>
              </div>
            )}
            
            <div ref={lastItemRef} />
          </div>
        </div>

        {/* Quick Questions */}
        {messages.length > 0 && !isInitializing && (
          <div className="px-3 sm:px-4 py-2 border-t shrink-0">
            <p className="text-[10px] sm:text-xs text-muted-foreground mb-1.5 sm:mb-2">Perguntas rápidas:</p>
            <div className="flex flex-wrap gap-1">
              {quickQuestions.map((q, i) => (
                <Button
                  key={i}
                  variant="outline"
                  size="sm"
                  className="text-[10px] sm:text-xs h-6 sm:h-7 px-2"
                  onClick={() => {
                    setUserInput(q);
                  }}
                  disabled={isLoading}
                >
                  {q}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="p-3 sm:p-4 border-t shrink-0">
          <div className="flex gap-2">
            <Input
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Pergunte sobre o token..."
              className="flex-1 h-9 sm:h-10 text-sm"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              disabled={isLoading || isInitializing}
            />
            <Button 
              onClick={sendMessage} 
              disabled={!userInput.trim() || isLoading || isInitializing}
              className="gradient-button h-9 sm:h-10 w-9 sm:w-10 p-0"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

export default AurionPlusSniperChat;
