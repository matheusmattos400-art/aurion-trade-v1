import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Copy, Check, Database, AlertCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const DatabaseConnectionInfo = () => {
  const [copied, setCopied] = useState(false);
  const [copiedIpv4, setCopiedIpv4] = useState(false);
  const [databaseUrl, setDatabaseUrl] = useState<string>("");
  const [ipv4ConnectionUrl, setIpv4ConnectionUrl] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [components, setComponents] = useState<any>(null);

  const fetchDatabaseUrl = async () => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        toast.error("Você precisa estar autenticado");
        return;
      }

      const response = await supabase.functions.invoke('get-database-url', {
        headers: {
          Authorization: `Bearer ${session.access_token}`
        }
      });

      if (response.error) {
        toast.error("Erro ao obter DATABASE_URL");
        console.error(response.error);
        return;
      }

      if (response.data?.database_url) {
        setDatabaseUrl(response.data.database_url);
        setIpv4ConnectionUrl(response.data.ipv4_connection_url || "");
        setComponents(response.data.components);
        toast.success("DATABASE_URL obtido com sucesso!");
      }
    } catch (error) {
      console.error("Error fetching database URL:", error);
      toast.error("Erro ao buscar informações do banco");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(databaseUrl);
    setCopied(true);
    toast.success("DATABASE_URL copiado!");
    setTimeout(() => setCopied(false), 2000);
  };

  const copyIpv4ToClipboard = () => {
    navigator.clipboard.writeText(ipv4ConnectionUrl);
    setCopiedIpv4(true);
    toast.success("URL IPv4 copiada!");
    setTimeout(() => setCopiedIpv4(false), 2000);
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="w-5 h-5" />
          Informações de Conexão do Banco de Dados
        </CardTitle>
        <CardDescription>
          Obtenha o DATABASE_URL completo para configurar o monitor no VPS
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {!databaseUrl ? (
          <div className="text-center py-8">
            <Button onClick={fetchDatabaseUrl} disabled={loading} size="lg">
              {loading ? "Carregando..." : "Obter DATABASE_URL"}
            </Button>
            <p className="text-sm text-muted-foreground mt-4">
              Clique para revelar as credenciais de conexão do banco
            </p>
          </div>
        ) : (
          <>
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium mb-2">URL de Conexão (Hostname):</p>
                <div className="bg-muted p-4 rounded-lg">
                  <div className="flex items-start justify-between gap-2">
                    <code className="text-sm break-all flex-1 font-mono">
                      {databaseUrl}
                    </code>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={copyToClipboard}
                      className="flex-shrink-0"
                    >
                      {copied ? (
                        <Check className="w-4 h-4 text-green-500" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>

              {ipv4ConnectionUrl && (
                <div className="border-t pt-4">
                  <p className="text-sm font-semibold mb-2 text-primary flex items-center gap-2">
                    🔧 URL de Conexão IPv4 (Recomendada para VPS)
                  </p>
                  <p className="text-xs text-muted-foreground mb-2">
                    Use esta URL se enfrentar erros ENETUNREACH ou problemas IPv6
                  </p>
                  <div className="bg-primary/10 p-4 rounded-lg border border-primary/20">
                    <div className="flex items-start justify-between gap-2">
                      <code className="text-sm break-all flex-1 font-mono">
                        {ipv4ConnectionUrl}
                      </code>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={copyIpv4ToClipboard}
                        className="flex-shrink-0"
                      >
                        {copiedIpv4 ? (
                          <Check className="w-4 h-4 text-green-500" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {components && (
              <div className="grid grid-cols-2 gap-4 text-sm border-t pt-4">
                <div>
                  <span className="font-semibold">Host:</span> {components.host}
                </div>
                <div>
                  <span className="font-semibold">Porta:</span> {components.port}
                </div>
                <div>
                  <span className="font-semibold">Database:</span> {components.database}
                </div>
                <div>
                  <span className="font-semibold">Usuário:</span> {components.username}
                </div>
                {components.ipv4 && (
                  <div className="col-span-2 border-t pt-2 mt-2">
                    <span className="font-semibold text-primary">IPv4 Estático:</span>
                    <code className="ml-2 text-primary bg-primary/10 px-2 py-1 rounded">{components.ipv4}</code>
                  </div>
                )}
              </div>
            )}

            <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 p-4 rounded-lg">
              <div className="flex gap-2">
                <AlertCircle className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-semibold text-blue-900 dark:text-blue-100 mb-1">
                    Próximos passos:
                  </p>
                  <ol className="list-decimal list-inside space-y-1 text-blue-800 dark:text-blue-200">
                    <li>Copie o DATABASE_URL acima</li>
                    <li>Conecte no VPS: <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">ssh root@104.248.136.155</code></li>
                    <li>Edite o arquivo: <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">nano /opt/binance-proxy/.env.monitor</code></li>
                    <li>Cole o DATABASE_URL na primeira linha</li>
                    <li>Salve (Ctrl+O, Enter, Ctrl+X)</li>
                    <li>Reinicie o monitor: <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">pm2 restart auto-close-monitor</code></li>
                  </ol>
                </div>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};
