import { Card } from "@/components/ui/card";
import { Activity, TrendingUp, CheckCircle, XCircle } from "lucide-react";

interface StatusDisplayProps {
  status: "idle" | "running" | "profit" | "closed";
  pnl: number;
}

export const StatusDisplay = ({ status, pnl }: StatusDisplayProps) => {
  const getStatusConfig = () => {
    switch (status) {
      case "idle":
        return {
          icon: XCircle,
          text: "Aguardando",
          color: "text-muted-foreground",
          bgColor: "bg-muted/20",
        };
      case "running":
        return {
          icon: Activity,
          text: "Operando",
          color: "text-accent",
          bgColor: "bg-accent/20",
        };
      case "profit":
        return {
          icon: TrendingUp,
          text: "Lucro Atingido",
          color: "text-profit",
          bgColor: "bg-profit/20",
        };
      case "closed":
        return {
          icon: CheckCircle,
          text: "Encerrada",
          color: "text-primary",
          bgColor: "bg-primary/20",
        };
    }
  };

  const config = getStatusConfig();
  const Icon = config.icon;

  return (
    <Card className="glass-card premium-border p-3 sm:p-4 md:p-6 relative overflow-hidden">
      {/* Premium background overlay */}
      <div className="absolute inset-0 gradient-premium opacity-30 pointer-events-none"></div>
      
      <div className="relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
        <div className="flex items-center gap-2 sm:gap-3 md:gap-4 min-w-0">
          <div className={`${config.bgColor} p-2 sm:p-3 rounded-xl sm:rounded-2xl shadow-glow-accent backdrop-blur-sm shrink-0`}>
            <Icon className={`w-6 h-6 sm:w-8 sm:h-8 md:w-10 md:h-10 ${config.color} ${status === 'running' ? 'animate-pulse-subtle' : ''}`} />
          </div>
          <div className="min-w-0">
            <p className="text-[10px] sm:text-xs uppercase tracking-wider text-muted-foreground font-medium">Status da Operação</p>
            <p className={`text-lg sm:text-2xl md:text-3xl font-bold ${config.color} mt-0.5 truncate`}>{config.text}</p>
          </div>
        </div>
        
        <div className="text-left sm:text-right glass-card p-2 sm:p-3 md:p-4 rounded-lg sm:rounded-xl w-full sm:w-auto">
          <p className="text-[10px] sm:text-xs uppercase tracking-wider text-muted-foreground font-medium mb-0.5 sm:mb-1">Lucro/Prejuízo</p>
          <p className={`text-xl sm:text-3xl md:text-4xl font-bold ${pnl >= 0 ? 'text-profit' : 'text-loss'} ${status === 'running' ? 'animate-pulse-subtle' : ''} ${pnl >= 0 ? 'shadow-glow' : ''}`}>
            ${pnl.toFixed(2)}
          </p>
        </div>
      </div>
    </Card>
  );
};
