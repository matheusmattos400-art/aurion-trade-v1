import { Home, Key, LogOut, Target } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface AppSidebarProps {
  currentView: "dashboard" | "api" | "aurion-strategy";
  onViewChange: (view: "dashboard" | "api" | "aurion-strategy") => void;
}

export function AppSidebar({ currentView, onViewChange }: AppSidebarProps) {
  const { toast } = useToast();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast({
      title: "Logout realizado",
      description: "Até logo!",
    });
  };

  const menuItems = [
    { 
      title: "Dashboard", 
      icon: Home, 
      action: () => onViewChange("dashboard"),
      isActive: currentView === "dashboard"
    },
    { 
      title: "Estratégia Aurion", 
      icon: Target, 
      action: () => onViewChange("aurion-strategy"),
      isActive: currentView === "aurion-strategy"
    },
    { 
      title: "API Binance", 
      icon: Key, 
      action: () => onViewChange("api"),
      isActive: currentView === "api"
    },
  ];

  return (
    <Sidebar>
      <SidebarTrigger className="m-2 self-end" />

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    onClick={item.action}
                    className={item.isActive ? "bg-muted text-primary font-medium border-l-2 border-blue-500" : "hover:bg-muted/50"}
                  >
                    <item.icon className="h-4 w-4 mr-2" />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
              
              <SidebarMenuItem>
                <SidebarMenuButton 
                  onClick={handleLogout}
                  className="hover:bg-destructive/10 hover:text-destructive"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  <span>Sair</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
