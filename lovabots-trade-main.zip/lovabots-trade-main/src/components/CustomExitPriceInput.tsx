import { memo, useRef, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Loader2, Send, X } from "lucide-react";

interface CustomExitPriceInputProps {
  onSubmit: (price: string) => Promise<void>;
  onCancel: () => Promise<void>;
  isCreating: boolean;
  orderCreated: boolean;
  isCancelling: boolean;
  formatPrice: (price: number) => string;
  onEditingChange?: (editing: boolean) => void;
}

export const CustomExitPriceInput = memo(({
  onSubmit,
  onCancel,
  isCreating,
  orderCreated,
  isCancelling,
  formatPrice,
  onEditingChange,
}: CustomExitPriceInputProps) => {
  const [localPrice, setLocalPrice] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = async () => {
    const normalized = localPrice.replace(/\s+/g, "").replace(/,/g, ".");
    if (normalized) await onSubmit(normalized);
  };

  if (orderCreated) {
    return (
      <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-yellow-500">
            <CheckCircle2 className="h-4 w-4" />
            <span>Ordem enviada com sucesso!</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onCancel}
            disabled={isCancelling}
            className="h-7 px-2 text-red-400 hover:text-red-500 hover:bg-red-500/10"
          >
            {isCancelling ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <>
                <X className="h-3.5 w-3.5 mr-1" />
                Cancelar
              </>
            )}
          </Button>
        </div>
        <p className="text-[10px] text-muted-foreground mt-1">
          Ordem customizada @ ${formatPrice(parseFloat(localPrice) || 0)}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex gap-2">
        <Input
          ref={inputRef}
          type="text"
          inputMode="decimal"
          placeholder="Preço de saída"
          value={localPrice}
          onChange={(e) => setLocalPrice(e.target.value)}
          onFocus={() => onEditingChange?.(true)}
          onBlur={() => onEditingChange?.(false)}
          className="flex-1 bg-background/50 border-border/50 text-sm"
        />
        <Button
          variant="outline"
          size="sm"
          onClick={handleSubmit}
          disabled={isCreating || !localPrice}
          className="border-yellow-500/30 text-yellow-500 hover:bg-yellow-500/10 hover:border-yellow-500/50 gap-1.5"
        >
          {isCreating ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Send className="h-4 w-4" />
          )}
        </Button>
      </div>
      <p className="text-[10px] text-muted-foreground text-center">
        Ou defina um preço de saída customizado
      </p>
    </div>
  );
});

CustomExitPriceInput.displayName = "CustomExitPriceInput";
