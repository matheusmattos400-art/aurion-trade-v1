import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { 
  Newspaper, 
  ExternalLink, 
  RefreshCw, 
  Clock,
  TrendingUp,
  AlertCircle,
  Languages
} from "lucide-react";

interface NewsItem {
  id: string;
  title: string;
  body: string;
  url: string;
  imageUrl: string;
  source: string;
  publishedAt: string;
  categories: string;
  originalTitle?: string;
  originalBody?: string;
}

export const CryptoNews = () => {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isTranslating, setIsTranslating] = useState(false);
  const [isTranslated, setIsTranslated] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastFetched, setLastFetched] = useState<Date | null>(null);

  const fetchNews = async () => {
    setIsLoading(true);
    setError(null);
    setIsTranslated(false);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('crypto-news', {
        body: { translate: false }
      });
      
      if (fnError) {
        throw new Error(fnError.message);
      }
      
      if (data?.success && data?.data) {
        setNews(data.data);
        setLastFetched(new Date());
      } else {
        throw new Error(data?.error || 'Erro ao carregar notícias');
      }
    } catch (err) {
      console.error('Erro ao buscar notícias:', err);
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
    } finally {
      setIsLoading(false);
    }
  };

  const translateNews = async () => {
    if (isTranslated) {
      // Revert to original
      setNews(prev => prev.map(item => ({
        ...item,
        title: item.originalTitle || item.title,
        body: item.originalBody || item.body,
      })));
      setIsTranslated(false);
      return;
    }

    setIsTranslating(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('crypto-news', {
        body: { translate: true }
      });
      
      if (fnError) throw new Error(fnError.message);
      
      if (data?.success && data?.data) {
        // Store originals and update with translations
        setNews(prev => data.data.map((translatedItem: NewsItem, index: number) => ({
          ...translatedItem,
          originalTitle: prev[index]?.title,
          originalBody: prev[index]?.body,
        })));
        setIsTranslated(true);
      }
    } catch (err) {
      console.error('Erro ao traduzir notícias:', err);
    } finally {
      setIsTranslating(false);
    }
  };

  useEffect(() => {
    fetchNews();
    
    // Atualizar a cada 2 minutos para manter as notícias frescas
    const interval = setInterval(fetchNews, 2 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    
    if (diffMins < 60) {
      return `${diffMins}min atrás`;
    } else if (diffHours < 24) {
      return `${diffHours}h atrás`;
    } else {
      return date.toLocaleDateString('pt-BR');
    }
  };

  const getCategoryColor = (categories: string) => {
    if (categories.toLowerCase().includes('btc') || categories.toLowerCase().includes('bitcoin')) {
      return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
    }
    if (categories.toLowerCase().includes('eth') || categories.toLowerCase().includes('ethereum')) {
      return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
    }
    if (categories.toLowerCase().includes('trading')) {
      return 'bg-green-500/20 text-green-400 border-green-500/30';
    }
    return 'bg-primary/20 text-primary border-primary/30';
  };

  if (isLoading && news.length === 0) {
    return (
      <Card className="p-4 bg-card/50 border-border/30">
        <div className="flex items-center gap-2 mb-4">
          <Newspaper className="h-5 w-5 text-primary" />
          <h3 className="font-bold text-foreground">Notícias do Dia</h3>
        </div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex gap-3">
              <Skeleton className="w-16 h-16 rounded-lg flex-shrink-0" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-3 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            </div>
          ))}
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-4 bg-card/50 border-border/30">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Newspaper className="h-5 w-5 text-primary" />
            <h3 className="font-bold text-foreground">Notícias do Dia</h3>
          </div>
          <Button variant="ghost" size="sm" onClick={fetchNews}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
        <div className="text-center py-6">
          <AlertCircle className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">{error}</p>
          <Button variant="outline" size="sm" className="mt-3" onClick={fetchNews}>
            Tentar novamente
          </Button>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-4 bg-card/50 border-border/30">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Newspaper className="h-5 w-5 text-primary" />
          <h3 className="font-bold text-foreground">Notícias do Dia</h3>
          {lastFetched && (
            <span className="text-[10px] text-muted-foreground">
              {lastFetched.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={translateNews}
            disabled={isLoading || isTranslating}
            className={`h-8 px-2 text-xs gap-1 ${isTranslated ? 'bg-primary/20 text-primary' : ''}`}
            title={isTranslated ? 'Ver original' : 'Traduzir para PT'}
          >
            <Languages className={`h-4 w-4 ${isTranslating ? 'animate-pulse' : ''}`} />
            {isTranslating ? '...' : isTranslated ? 'PT' : 'EN'}
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={fetchNews}
            disabled={isLoading}
            className="h-8 w-8 p-0"
          >
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
        {news.length === 0 ? (
          <div className="text-center py-6">
            <TrendingUp className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Nenhuma notícia disponível</p>
          </div>
        ) : (
          news.map((item) => (
            <a
              key={item.id}
              href={item.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex gap-3 p-2 rounded-lg hover:bg-card/80 transition-colors group"
            >
              {item.imageUrl && (
                <div className="w-16 h-16 flex-shrink-0 rounded-lg overflow-hidden bg-muted">
                  <img 
                    src={item.imageUrl} 
                    alt=""
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-medium text-foreground line-clamp-2 group-hover:text-primary transition-colors">
                  {item.title}
                </h4>
                <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                  <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {formatTimeAgo(item.publishedAt)}
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    {item.source}
                  </span>
                  {item.categories && (
                    <Badge 
                      variant="outline" 
                      className={`text-[8px] px-1.5 py-0 h-4 ${getCategoryColor(item.categories)}`}
                    >
                      {item.categories.split('|')[0]}
                    </Badge>
                  )}
                </div>
              </div>
              <ExternalLink className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
            </a>
          ))
        )}
      </div>
    </Card>
  );
};
