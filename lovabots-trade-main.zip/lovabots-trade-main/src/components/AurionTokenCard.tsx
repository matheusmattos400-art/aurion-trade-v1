import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Shield, 
  ShieldCheck, 
  ShieldX, 
  TrendingUp, 
  TrendingDown,
  ExternalLink,
  Clock,
  Droplets,
  BarChart3,
  Globe,
  Twitter,
  Zap,
  Star,
  AlertTriangle,
  X,
  DollarSign,
  Award,
  Lock,
  CheckCircle
} from "lucide-react";
import type { AurionToken, SimulatedTrade } from "@/hooks/useAurionScanner";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

interface AurionTokenCardProps {
  token: AurionToken;
  onSimulateEntry: (token: AurionToken) => void;
  onViewChart: (token: AurionToken) => void;
  onAurionAI?: (token: AurionToken) => void;
  onExitTrade?: (tradeId: string) => void;
  isSimulating?: boolean;
  isAnalyzingAI?: boolean;
  activeTrades?: SimulatedTrade[];
  showAurionCertificate?: boolean;
  showSecurityBadge?: boolean;
}

export const AurionTokenCard = ({ 
  token, 
  onSimulateEntry, 
  onViewChart,
  onAurionAI,
  onExitTrade,
  isSimulating = false,
  isAnalyzingAI = false,
  activeTrades = [],
  showAurionCertificate = false,
  showSecurityBadge = false
}: AurionTokenCardProps) => {
  const isPositiveChange = token.priceChange24h >= 0;
  const isAurionGold = token.aurionConfirmed;
  const hasActiveTrades = activeTrades.length > 0;
  
  // Live prices state for PnL calculation - store for each trade
  const [livePrices, setLivePrices] = useState<{ [tradeId: string]: { price: number; pnlPercent: number; pnlUsd: number } }>({});

  // Fetch live prices for all active trades
  useEffect(() => {
    if (!hasActiveTrades) return;

    const fetchPrice = async () => {
      try {
        const response = await fetch(
          `https://api.dexscreener.com/latest/dex/pairs/${token.chainId}/${token.pairAddress}`
        );
        if (!response.ok) return;
        
        const data = await response.json();
        const pair = data.pair || data.pairs?.[0];
        if (!pair) return;
        
        const currentPrice = parseFloat(pair.priceUsd || "0");
        
        const newPrices: { [tradeId: string]: { price: number; pnlPercent: number; pnlUsd: number } } = {};
        activeTrades.forEach(trade => {
          const pnl = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100;
          newPrices[trade.id] = {
            price: currentPrice,
            pnlPercent: pnl,
            pnlUsd: (pnl / 100) * (trade.investmentAmount || 100)
          };
        });
        
        setLivePrices(newPrices);
      } catch (error) {
        console.error("Error fetching live price:", error);
      }
    };

    fetchPrice();
    const interval = setInterval(fetchPrice, 5000);
    
    return () => clearInterval(interval);
  }, [hasActiveTrades, activeTrades, token.chainId, token.pairAddress]);

  // Calculate total PnL across all trades
  const totalPnlUsd = Object.values(livePrices).reduce((sum, p) => sum + p.pnlUsd, 0);
  const totalPnlPercent = activeTrades.length > 0 
    ? Object.values(livePrices).reduce((sum, p) => sum + p.pnlPercent, 0) / activeTrades.length
    : 0;

  const getSecurityBadge = () => {
    if (token.securityScore >= 90) {
      return <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30"><ShieldCheck className="w-3 h-3 mr-1" />Excelente</Badge>;
    }
    if (token.securityScore >= 75) {
      return <Badge className="bg-green-500/20 text-green-400 border-green-500/30"><Shield className="w-3 h-3 mr-1" />Seguro</Badge>;
    }
    return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30"><ShieldX className="w-3 h-3 mr-1" />Atenção</Badge>;
  };

  const getTechnicalBadge = () => {
    if (token.technicalStatus === "pending") {
      return <Badge variant="outline" className="text-muted-foreground"><Clock className="w-3 h-3 mr-1" />Analisando...</Badge>;
    }
    if (token.aurionConfirmed) {
      return <Badge className="bg-primary/20 text-primary border-primary/30 animate-pulse"><Star className="w-3 h-3 mr-1" />AURION GOLD</Badge>;
    }
    return <Badge variant="outline" className="text-muted-foreground">Aguardando Confluência</Badge>;
  };

  const formatPrice = (price: number) => {
    if (price < 0.00001) return price.toExponential(4);
    if (price < 0.01) return price.toFixed(8);
    if (price < 1) return price.toFixed(6);
    return price.toFixed(4);
  };

  const formatNumber = (num: number) => {
    if (num >= 1_000_000) return `$${(num / 1_000_000).toFixed(2)}M`;
    if (num >= 1_000) return `$${(num / 1_000).toFixed(2)}K`;
    return `$${num.toFixed(2)}`;
  };

  return (
    <Card className={`glass-card p-3 sm:p-4 space-y-3 transition-all duration-300 hover:scale-[1.01] sm:hover:scale-[1.02] ${
      showAurionCertificate
        ? 'ring-2 ring-amber-400 border-amber-400/50 shadow-[0_0_25px_rgba(245,158,11,0.4)]'
        : hasActiveTrades 
          ? 'ring-2 ring-green-500 border-green-500/50 shadow-[0_0_20px_rgba(34,197,94,0.3)]' 
          : isAurionGold 
            ? 'premium-border shadow-glow ring-2 ring-primary/50' 
            : 'border-border/50'
    }`}>
      {/* Aurion Certificate Banner */}
      {showAurionCertificate && (
        <div className="flex items-center justify-center gap-2 py-1.5 px-3 -mx-3 sm:-mx-4 -mt-3 sm:-mt-4 mb-2 bg-gradient-to-r from-amber-500/30 via-yellow-500/30 to-amber-500/30 border-b border-amber-400/30">
          <Award className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-bold text-amber-400">🏅 CERTIFICADO AURION</span>
          <ShieldCheck className="w-4 h-4 text-green-400" />
        </div>
      )}

      {/* Header */}
      <div className="flex items-start justify-between gap-2 min-w-0">
        <div className="flex items-center gap-3">
          {token.imageUrl ? (
            <img 
              src={token.imageUrl} 
              alt={token.symbol} 
              className="w-10 h-10 rounded-full bg-muted"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = 'none';
              }}
            />
          ) : (
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-primary font-bold text-sm">{token.symbol.slice(0, 2)}</span>
            </div>
          )}
          <div>
            <div className="flex items-center gap-1.5 min-w-0">
              <h3 className="font-bold text-foreground truncate">{token.symbol}</h3>
              {/* Selo dourado de verificação quando tem algum pilar de segurança */}
              {showSecurityBadge && (
                <CheckCircle className="w-4 h-4 text-amber-400 shrink-0" />
              )}
              {isAurionGold && !showSecurityBadge && <Star className="w-4 h-4 text-primary fill-primary shrink-0" />}
            </div>
            <p className="text-xs text-muted-foreground truncate max-w-[120px] sm:max-w-[150px]">{token.name}</p>
          </div>
        </div>

        <div className="text-right shrink-0">
          <p className="font-mono font-bold text-foreground text-sm sm:text-base">${formatPrice(token.priceUsd)}</p>
          <div className={`flex items-center justify-end gap-1 text-xs sm:text-sm ${isPositiveChange ? 'text-profit' : 'text-loss'}`}>
            {isPositiveChange ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            <span className="font-mono">{token.priceChange24h.toFixed(2)}%</span>
          </div>
        </div>
      </div>

      {/* Badges */}
      <div className="flex flex-wrap gap-2">
        {getSecurityBadge()}
        {getTechnicalBadge()}
        <Badge variant="outline" className="text-xs">
          <Clock className="w-3 h-3 mr-1" />
          {token.ageHours < 1 
            ? `${Math.round(token.ageHours * 60)}m`
            : token.ageHours < 24 
              ? `${Math.round(token.ageHours)}h`
              : `${Math.round(token.ageHours / 24)}d`
          }
        </Badge>
      </div>

      {/* Security Pillars - Mostrar quando tem certificado ou selo de segurança */}
      {(showAurionCertificate || showSecurityBadge) && (
        <div className="grid grid-cols-3 gap-1.5 text-[10px]">
          <div className={`flex items-center justify-center gap-1 px-2 py-1.5 rounded-md ${
            !token.isMintable 
              ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
              : 'bg-red-500/10 text-red-400/60 border border-red-500/20'
          }`}>
            <Lock className="w-3 h-3" />
            <span className="truncate">Mint {!token.isMintable ? '✓' : '✗'}</span>
          </div>
          <div className={`flex items-center justify-center gap-1 px-2 py-1.5 rounded-md ${
            !token.hasBlacklist 
              ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
              : 'bg-red-500/10 text-red-400/60 border border-red-500/20'
          }`}>
            <ShieldCheck className="w-3 h-3" />
            <span className="truncate">Freeze {!token.hasBlacklist ? '✓' : '✗'}</span>
          </div>
          <div className={`flex items-center justify-center gap-1 px-2 py-1.5 rounded-md ${
            token.lpLocked 
              ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
              : 'bg-red-500/10 text-red-400/60 border border-red-500/20'
          }`}>
            <Lock className="w-3 h-3" />
            <span className="truncate">LP {token.lpLocked ? '✓' : '✗'}</span>
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-1.5 sm:gap-2 text-xs">
        <div className="flex items-center gap-1 text-muted-foreground min-w-0">
          <Droplets className="w-3 h-3 shrink-0" />
          <span className="shrink-0">Liq:</span>
          <span className="text-foreground font-medium truncate">{formatNumber(token.liquidity)}</span>
        </div>
        <div className="flex items-center gap-1 text-muted-foreground min-w-0">
          <BarChart3 className="w-3 h-3 shrink-0" />
          <span className="shrink-0">Vol:</span>
          <span className="text-foreground font-medium truncate">{formatNumber(token.volume24h)}</span>
        </div>
        <div className="flex items-center gap-1 text-muted-foreground min-w-0">
          <span className="shrink-0">Compras:</span>
          <span className="text-profit font-medium">{token.buys1h}</span>
        </div>
        <div className="flex items-center gap-1 text-muted-foreground min-w-0">
          <span className="shrink-0">Vendas:</span>
          <span className="text-loss font-medium">{token.sells1h}</span>
        </div>
      </div>

      {/* Technical Indicators */}
      {token.technicalStatus !== "pending" && (
        <div className="p-2 bg-muted/30 rounded-lg space-y-1 text-xs">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Chandelier Exit:</span>
            <span className={token.chandelierSignal === "LONG" ? "text-profit" : "text-loss"}>
              {token.chandelierSignal || "—"}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">ADX:</span>
            <span className={token.adxSignal && token.adxSignal.adx >= 25 ? "text-profit" : "text-muted-foreground"}>
              {token.adxSignal ? `${token.adxSignal.adx.toFixed(1)} (DI+: ${token.adxSignal.plusDI.toFixed(1)})` : "—"}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">RSI:</span>
            <span className={
              token.rsiSignal && token.rsiSignal < 40 ? "text-profit" :
              token.rsiSignal && token.rsiSignal > 60 ? "text-loss" :
              "text-muted-foreground"
            }>
              {token.rsiSignal ? token.rsiSignal.toFixed(1) : "—"}
            </span>
          </div>
        </div>
      )}

      {/* Social Links */}
      <div className="flex items-center gap-2">
        {token.hasWebsite && token.websites?.length > 0 && token.websites[0] && (
          <a 
            href={token.websites[0].url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="p-1.5 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
          >
            <Globe className="w-3.5 h-3.5 text-muted-foreground" />
          </a>
        )}
        {token.socials?.find(s => s.type === "twitter") && (
          <a 
            href={token.socials.find(s => s.type === "twitter")?.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="p-1.5 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
          >
            <Twitter className="w-3.5 h-3.5 text-muted-foreground" />
          </a>
        )}
        <a 
          href={token.url} 
          target="_blank" 
          rel="noopener noreferrer"
          className="p-1.5 rounded-lg bg-muted/50 hover:bg-muted transition-colors ml-auto"
        >
          <ExternalLink className="w-3.5 h-3.5 text-muted-foreground" />
        </a>
      </div>

      {/* Active Trades PnL Display */}
      {hasActiveTrades && activeTrades.map((trade) => {
        const tradeData = livePrices[trade.id] || { price: trade.entryPrice, pnlPercent: 0, pnlUsd: 0 };
        return (
          <div key={trade.id} className={`p-3 rounded-lg border ${tradeData.pnlPercent >= 0 ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                  <Zap className="w-3 h-3 mr-1" />
                  Operação #{activeTrades.indexOf(trade) + 1}
                </Badge>
              </div>
              <span className="text-xs text-muted-foreground">
                {formatDistanceToNow(trade.entryTime, { addSuffix: true, locale: ptBR })}
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-2 text-xs mb-2">
              <div>
                <span className="text-muted-foreground">Entrada:</span>
                <span className="ml-1 font-mono">${formatPrice(trade.entryPrice)}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Atual:</span>
                <span className="ml-1 font-mono">${formatPrice(tradeData.price)}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Investido:</span>
                <span className="ml-1 font-mono">${trade.investmentAmount?.toFixed(2)}</span>
              </div>
              <div className={`font-bold ${tradeData.pnlPercent >= 0 ? 'text-profit' : 'text-loss'}`}>
                <DollarSign className="w-3 h-3 inline" />
                {tradeData.pnlUsd >= 0 ? '+' : ''}{tradeData.pnlUsd.toFixed(2)} ({tradeData.pnlPercent >= 0 ? '+' : ''}{tradeData.pnlPercent.toFixed(2)}%)
              </div>
            </div>
            
            <Button 
              size="sm" 
              variant="destructive"
              className="w-full"
              onClick={() => onExitTrade?.(trade.id)}
            >
              <X className="w-4 h-4 mr-1" />
              Encerrar Operação #{activeTrades.indexOf(trade) + 1}
            </Button>
          </div>
        );
      })}

      {/* Actions - Always show buy button */}
      <div className="flex flex-col gap-2">
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1"
            onClick={() => onViewChart(token)}
          >
            <BarChart3 className="w-4 h-4 mr-1" />
            Gráfico
          </Button>
          
          <Button 
            size="sm" 
            className={`flex-1 ${token.securityScore >= 80 ? 'gradient-button' : ''}`}
            onClick={() => onSimulateEntry(token)}
            disabled={isSimulating || token.securityScore < 80}
          >
            <Zap className="w-4 h-4 mr-1" />
            {isSimulating ? "Simulando..." : token.securityScore >= 80 ? (hasActiveTrades ? "Nova Entrada" : "Simular Entrada") : "Score < 80"}
          </Button>
        </div>
        
        {/* Aurion AI Button */}
        {onAurionAI && (
          <Button
            size="sm"
            variant="outline"
            className="w-full relative overflow-hidden bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/50 hover:border-purple-400 hover:from-purple-500/20 hover:to-blue-500/20 text-purple-300 hover:text-purple-200"
            onClick={() => onAurionAI(token)}
            disabled={isAnalyzingAI}
          >
            <span className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-blue-500/20 animate-pulse" style={{ opacity: isAnalyzingAI ? 1 : 0 }} />
            <Star className="w-4 h-4 mr-2 fill-purple-400 text-purple-400" />
            {isAnalyzingAI ? "Analisando..." : "Aurion AI"}
            {isAnalyzingAI && <span className="ml-2 w-3 h-3 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />}
          </Button>
        )}
      </div>

      {/* Security Warning if applicable */}
      {token.securityReasons && token.securityReasons.length > 0 && (
        <div className="p-2 bg-destructive/10 rounded-lg border border-destructive/20">
          <div className="flex items-center gap-1 text-destructive text-xs">
            <AlertTriangle className="w-3 h-3" />
            <span className="font-medium">Alertas:</span>
          </div>
          <ul className="text-xs text-muted-foreground mt-1 space-y-0.5">
            {token.securityReasons.slice(0, 3).map((reason, i) => (
              <li key={i}>• {reason}</li>
            ))}
          </ul>
        </div>
      )}
    </Card>
  );
};
