import { useEffect, useState, useMemo, useCallback, memo } from "react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { RefreshCw, Trash2, Calendar as CalendarIcon, Clock, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface Trade {
  id: string;
  date: Date;
  startedAt?: Date;
  longPair: string;
  shortPair: string;
  profit: number;
  isTest: boolean;
  durationSeconds: number;
}

interface TradeHistoryProps {
  mode: "real" | "test";
}

const TradeHistoryComponent = ({ mode }: TradeHistoryProps) => {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [calendarOpen, setCalendarOpen] = useState(false);
  const { toast } = useToast();

  const fetchTradeHistory = useCallback(async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setTrades([]);
        return;
      }

      const isTestMode = mode === "test";

      // 1) trade_history (fonte oficial quando disponível)
      let historyQuery = supabase
        .from("trade_history")
        .select("id, started_at, ended_at, long_symbol, short_symbol, profit, is_test, duration_seconds")
        .eq("user_id", user.id)
        .eq("is_test", isTestMode);

      // 2) fallback: operações fechadas que ainda estão em active_operations
      let closedOpsQuery = supabase
        .from("active_operations")
        .select("id, started_at, updated_at, long_symbol, short_symbol, long_close_pnl, short_close_pnl, is_test")
        .eq("user_id", user.id)
        .eq("status", "closed")
        .eq("is_test", isTestMode);

      if (selectedDate) {
        const dayStart = new Date(selectedDate);
        dayStart.setHours(0, 0, 0, 0);

        const dayEnd = new Date(selectedDate);
        dayEnd.setHours(23, 59, 59, 999);

        historyQuery = historyQuery
          .gte("ended_at", dayStart.toISOString())
          .lte("ended_at", dayEnd.toISOString());

        // Para operações fechadas, usamos updated_at como "data de encerramento".
        closedOpsQuery = closedOpsQuery
          .gte("updated_at", dayStart.toISOString())
          .lte("updated_at", dayEnd.toISOString());
      }

      const [{ data: historyRows, error: historyError }, { data: closedRows, error: closedError }] = await Promise.all([
        historyQuery.order("ended_at", { ascending: false }),
        closedOpsQuery.order("updated_at", { ascending: false }),
      ]);

      if (historyError) throw historyError;
      if (closedError) throw closedError;

      const historyTrades: Trade[] = (historyRows ?? [])
        .filter((t) => !!t.ended_at)
        .map((trade) => ({
          id: `history_${trade.id}`,
          startedAt: trade.started_at ? new Date(trade.started_at) : undefined,
          date: new Date(trade.ended_at),
          longPair: trade.long_symbol,
          shortPair: trade.short_symbol,
          profit: Number(trade.profit),
          isTest: trade.is_test || false,
          durationSeconds: trade.duration_seconds || 0,
        }));

      const historyKey = new Set(
        (historyRows ?? [])
          .filter((t) => t.started_at)
          .map((t) => `${t.long_symbol}|${t.short_symbol}|${t.started_at}`)
      );

      const closedOpsTrades: Trade[] = (closedRows ?? [])
        .filter((op) => !!op.updated_at)
        .filter((op) => {
          // Evitar duplicar se já existe no trade_history
          if (!op.started_at) return true;
          const key = `${op.long_symbol}|${op.short_symbol}|${op.started_at}`;
          return !historyKey.has(key);
        })
        .map((op) => {
          const endedAt = new Date(op.updated_at);
          const startedAt = op.started_at ? new Date(op.started_at) : undefined;
          const durationSeconds = startedAt
            ? Math.max(0, Math.floor((endedAt.getTime() - startedAt.getTime()) / 1000))
            : 0;

          const totalProfit = Number(op.long_close_pnl || 0) + Number(op.short_close_pnl || 0);

          return {
            id: `op_${op.id}`,
            startedAt,
            date: endedAt,
            longPair: op.long_symbol,
            shortPair: op.short_symbol,
            profit: totalProfit,
            isTest: op.is_test || false,
            durationSeconds,
          };
        });

      const merged = [...historyTrades, ...closedOpsTrades].sort(
        (a, b) => b.date.getTime() - a.date.getTime()
      );

      setTrades(merged);
    } catch (error) {
      console.error("Error fetching trade history:", error);
      toast({
        title: "Erro ao carregar histórico",
        description: "Não foi possível carregar o histórico de operações",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [mode, selectedDate, toast]);

  useEffect(() => {
    let channel: ReturnType<typeof supabase.channel> | null = null;

    (async () => {
      setLoading(true);
      await fetchTradeHistory();

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      channel = supabase
        .channel(`history_${mode}_${user.id}`)
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "trade_history",
            filter: `user_id=eq.${user.id}`,
          },
          () => {
            fetchTradeHistory();
          }
        )
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "active_operations",
            filter: `user_id=eq.${user.id}`,
          },
          () => {
            fetchTradeHistory();
          }
        )
        .subscribe();
    })();

    return () => {
      if (channel) supabase.removeChannel(channel);
    };
  }, [mode, selectedDate, fetchTradeHistory]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchTradeHistory();
    setRefreshing(false);
    toast({
      title: "Atualizado",
      description: "Histórico atualizado com sucesso",
    });
  };

  const handleCleanupOldOperations = async () => {
    const confirmed = window.confirm(
      "⚠️ Isso vai encerrar operações abertas há mais de 2 horas.\n\nDeseja continuar?"
    );

    if (!confirmed) return;

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const twoHoursAgo = new Date();
      twoHoursAgo.setHours(twoHoursAgo.getHours() - 2);

      const { data: oldOps, error: fetchError } = await supabase
        .from('active_operations')
        .select('id')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .lt('started_at', twoHoursAgo.toISOString());

      if (fetchError) throw fetchError;

      if (!oldOps || oldOps.length === 0) {
        toast({
          title: "Nenhuma operação antiga",
          description: "Não há operações antigas para limpar",
        });
        setLoading(false);
        return;
      }

      const { error: deleteError } = await supabase
        .from('active_operations')
        .delete()
        .eq('user_id', user.id)
        .eq('status', 'active')
        .lt('started_at', twoHoursAgo.toISOString());

      if (deleteError) throw deleteError;

      toast({
        title: "Operações limpas",
        description: `${oldOps.length} operação(ões) antiga(s) removida(s)`,
      });

      setTimeout(() => window.location.reload(), 1500);
    } catch (error) {
      console.error('Error cleaning operations:', error);
      toast({
        title: "Erro ao limpar",
        description: "Não foi possível limpar as operações",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const tradesWithBalance = useMemo(() => {
    const totalBalance = trades.reduce((sum, trade) => sum + trade.profit, 0);
    let runningBalance = totalBalance;
    
    return trades.map((trade) => {
      const currentBalance = runningBalance;
      runningBalance -= trade.profit;
      return { ...trade, balance: currentBalance };
    });
  }, [trades]);

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hours > 0) return `${hours}h ${minutes}m`;
    if (minutes > 0) return `${minutes}m ${secs}s`;
    return `${secs}s`;
  };

  const totalProfit = trades.reduce((sum, t) => sum + t.profit, 0);
  const winningTrades = trades.filter(t => t.profit > 0).length;
  const winRate = trades.length > 0 ? (winningTrades / trades.length * 100).toFixed(0) : 0;

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className={cn(
                  "h-9 px-3 bg-background/50 border-border/50 hover:bg-background hover:border-border",
                  selectedDate && "border-primary/50 bg-primary/5"
                )}
              >
                <CalendarIcon className="w-4 h-4 mr-2" />
                {selectedDate ? format(selectedDate, "dd/MM/yyyy", { locale: ptBR }) : "Filtrar por data"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={(date) => {
                  setSelectedDate(date);
                  setCalendarOpen(false);
                }}
                disabled={(date) => date > new Date()}
                initialFocus
                locale={ptBR}
              />
              {selectedDate && (
                <div className="p-3 border-t">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full"
                    onClick={() => {
                      setSelectedDate(undefined);
                      setCalendarOpen(false);
                    }}
                  >
                    Limpar filtro
                  </Button>
                </div>
              )}
            </PopoverContent>
          </Popover>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={handleRefresh}
            disabled={refreshing || loading}
            size="sm"
            variant="outline"
            className="h-9 bg-background/50 border-border/50 hover:bg-background"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
          <Button
            onClick={handleCleanupOldOperations}
            disabled={loading}
            size="sm"
            variant="ghost"
            className="h-9 text-muted-foreground hover:text-destructive"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Limpar antigas
          </Button>
        </div>
      </div>

      {/* Summary Stats */}
      {trades.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-background/50 border border-border/30 text-center">
            <p className="text-xs text-muted-foreground mb-1">Total</p>
            <p className={`text-lg font-bold ${totalProfit >= 0 ? 'text-profit' : 'text-loss'}`}>
              ${totalProfit.toFixed(2)}
            </p>
          </div>
          <div className="p-3 rounded-lg bg-background/50 border border-border/30 text-center">
            <p className="text-xs text-muted-foreground mb-1">Win Rate</p>
            <p className="text-lg font-bold text-foreground">{winRate}%</p>
          </div>
          <div className="p-3 rounded-lg bg-background/50 border border-border/30 text-center">
            <p className="text-xs text-muted-foreground mb-1">Operações</p>
            <p className="text-lg font-bold text-foreground">{trades.length}</p>
          </div>
        </div>
      )}

      {/* Trade List */}
      <div className="space-y-2">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="flex flex-col items-center gap-3">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              <span className="text-sm text-muted-foreground">Carregando histórico...</span>
            </div>
          </div>
        ) : trades.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-16 h-16 rounded-full bg-muted/30 flex items-center justify-center mb-4">
              <Clock className="w-8 h-8 text-muted-foreground/50" />
            </div>
            <p className="text-muted-foreground font-medium">Nenhuma operação encontrada</p>
            <p className="text-xs text-muted-foreground/70 mt-1">
              {selectedDate 
                ? `Sem operações em ${format(selectedDate, "dd/MM/yyyy", { locale: ptBR })}`
                : "Realize operações para ver o histórico"
              }
            </p>
          </div>
        ) : (
          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {tradesWithBalance.map((trade) => (
              <div 
                key={trade.id}
                className={cn(
                  "p-4 rounded-xl border transition-all hover:shadow-md",
                  trade.profit >= 0 
                    ? "bg-profit/5 border-profit/20 hover:border-profit/40" 
                    : "bg-loss/5 border-loss/20 hover:border-loss/40"
                )}
              >
                <div className="flex items-start justify-between gap-4">
                  {/* Left side - Pairs and Time */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline" className="bg-profit/10 text-profit border-profit/30 text-xs">
                        <ArrowUpRight className="w-3 h-3 mr-1" />
                        {trade.longPair}
                      </Badge>
                      <Badge variant="outline" className="bg-loss/10 text-loss border-loss/30 text-xs">
                        <ArrowDownRight className="w-3 h-3 mr-1" />
                        {trade.shortPair}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{format(trade.date, "dd/MM/yyyy HH:mm")}</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatDuration(trade.durationSeconds)}
                      </span>
                    </div>
                  </div>

                  {/* Right side - Profit and Balance */}
                  <div className="text-right flex-shrink-0">
                    <div className={cn(
                      "flex items-center justify-end gap-1 text-lg font-bold",
                      trade.profit >= 0 ? "text-profit" : "text-loss"
                    )}>
                      {trade.profit >= 0 ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : (
                        <TrendingDown className="w-4 h-4" />
                      )}
                      ${trade.profit.toFixed(2)}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Saldo: <span className={cn(
                        "font-medium",
                        trade.balance >= 0 ? "text-profit" : "text-loss"
                      )}>${trade.balance.toFixed(2)}</span>
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export const TradeHistory = memo(TradeHistoryComponent);