import { memo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CustomExitPriceInput } from "./CustomExitPriceInput";
import { ProfitTargetExitInput } from "./ProfitTargetExitInput";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Square,
  Loader2,
  CheckCircle2,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Target,
  X,
} from "lucide-react";
interface PositionBalance {
  symbol: string;
  pnl: number;
  frozen: boolean;
  closed: boolean;
  markPrice: number;
  entryPrice: number;
  positionAmt: number;
}

interface AurionPositionCardProps {
  balance: PositionBalance;
  otherBalance: PositionBalance;
  side: "LONG" | "SHORT";
  leverage: number;
  isClosing: boolean;
  onClose: () => void;

  showLimitOrderButton: boolean;
  formatPrice: (price: number) => string;

  // Ordem no preço de entrada
  limitOrderCreated: boolean;
  isCreatingLimitOrder: boolean;
  isCancellingLimitOrder: boolean;
  onCreateLimitOrderAtEntry: () => Promise<void> | void;
  onCancelLimitOrder: () => Promise<void> | void;

  // Ordem customizada
  isCreatingCustomOrder: boolean;
  customOrderCreated: boolean;
  isCancellingCustomOrder: boolean;
  onSubmitCustomExitPrice: (price: string) => Promise<void>;
  onCancelCustomExitOrder: () => Promise<void>;
  onExitPriceEditingChange?: (editing: boolean) => void;
}

export const AurionPositionCard = memo(({
  balance,
  otherBalance,
  side,
  leverage,
  isClosing,
  onClose,
  showLimitOrderButton,
  formatPrice,
  limitOrderCreated,
  isCreatingLimitOrder,
  isCancellingLimitOrder,
  onCreateLimitOrderAtEntry,
  onCancelLimitOrder,
  isCreatingCustomOrder,
  customOrderCreated,
  isCancellingCustomOrder,
  onSubmitCustomExitPrice,
  onCancelCustomExitOrder,
  onExitPriceEditingChange,
}: AurionPositionCardProps) => {
  const [showCloseConfirm, setShowCloseConfirm] = useState(false);
  const [showLimitOrderConfirm, setShowLimitOrderConfirm] = useState(false);
  
  const isLong = side === "LONG";
  const isProfitable = balance.pnl >= 0;
  const priceChange = balance.entryPrice > 0
    ? ((balance.markPrice - balance.entryPrice) / balance.entryPrice) * 100
    : 0;

  return (
    <Card
      className={`relative overflow-hidden transition-all duration-300 ${
        balance.closed
          ? "bg-card/30 border-border/20"
          : "bg-card/60 border-border/40 hover:border-primary/30"
      }`}
    >
      {/* Gradient Accent */}
      <div
        className={`absolute top-0 left-0 right-0 h-1 ${
          isLong
            ? "bg-gradient-to-r from-green-500 to-emerald-400"
            : "bg-gradient-to-r from-red-500 to-rose-400"
        }`}
      />

      <div className="p-5">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div
              className={`p-2 rounded-lg ${
                isLong
                  ? "bg-green-500/10 border border-green-500/20"
                  : "bg-red-500/10 border border-red-500/20"
              }`}
            >
              {isLong ? (
                <TrendingUp className="h-5 w-5 text-green-500" />
              ) : (
                <TrendingDown className="h-5 w-5 text-red-500" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-foreground">{balance.symbol}</span>
                <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                  {leverage}x
                </Badge>
              </div>
              <span
                className={`text-xs font-medium ${
                  isLong ? "text-green-500" : "text-red-500"
                }`}
              >
                {side}
              </span>
            </div>
          </div>

          {balance.closed ? (
            <Badge className="bg-muted/50 text-muted-foreground border-border/50 gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5" />
              Fechado
            </Badge>
          ) : (
            <AlertDialog open={showCloseConfirm} onOpenChange={setShowCloseConfirm}>
              <AlertDialogTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={isClosing}
                  className="border-red-500/30 text-red-400 hover:bg-red-500/10 hover:border-red-500/50 gap-1.5"
                >
                  {isClosing ? (
                    <>
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      Fechando...
                    </>
                  ) : (
                    <>
                      <Square className="h-3.5 w-3.5" />
                      Encerrar
                    </>
                  )}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Confirmar Encerramento</AlertDialogTitle>
                  <AlertDialogDescription>
                    Tem certeza que deseja encerrar a posição {side} de {balance.symbol}?
                    Esta ação irá fechar a posição a mercado.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => {
                      setShowCloseConfirm(false);
                      onClose();
                    }}
                    className="bg-red-500 hover:bg-red-600"
                  >
                    Encerrar Posição
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

        {/* Price Info */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="space-y-1">
            <span className="text-xs text-muted-foreground uppercase tracking-wider">
              Entrada
            </span>
            <p className="font-mono font-semibold text-foreground">
              ${formatPrice(balance.entryPrice)}
            </p>
          </div>
          <div className="space-y-1">
            <span className="text-xs text-muted-foreground uppercase tracking-wider">
              Atual
            </span>
            <div className="flex items-center gap-2">
              <p className="font-mono font-semibold text-foreground">
                ${formatPrice(balance.markPrice)}
              </p>
              {!balance.closed && balance.markPrice > 0 && (
                <span
                  className={`text-xs font-medium ${
                    priceChange >= 0 ? "text-green-500" : "text-red-500"
                  }`}
                >
                  {priceChange >= 0 ? "+" : ""}
                  {priceChange.toFixed(2)}%
                </span>
              )}
            </div>
          </div>
        </div>

        {/* PnL Display */}
        <div
          className={`p-3 rounded-lg ${
            balance.frozen
              ? "bg-muted/30"
              : isProfitable
                ? "bg-green-500/10 border border-green-500/20"
                : "bg-red-500/10 border border-red-500/20"
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground flex items-center gap-1.5">
              <DollarSign className="h-4 w-4" />
              PnL
            </span>
            <div className="flex items-center gap-2">
              <span
                className={`text-xl font-bold font-mono ${
                  balance.frozen
                    ? "text-muted-foreground"
                    : isProfitable
                      ? "text-green-500"
                      : "text-red-500"
                }`}
              >
                {isProfitable ? "+" : ""}${balance.pnl.toFixed(2)}
              </span>
              {balance.frozen && (
                <Badge variant="secondary" className="text-[10px]">
                  Fixo
                </Badge>
              )}
            </div>
          </div>
        </div>
        {/* Input de lucro desejado - mostrar sempre que posição estiver ABERTA */}
        {!balance.closed && (
          <div className="mt-4 pt-4 border-t border-border/20 space-y-4">
            <ProfitTargetExitInput
              onSubmit={onSubmitCustomExitPrice}
              onCancel={onCancelCustomExitOrder}
              isCreating={isCreatingCustomOrder}
              orderCreated={customOrderCreated}
              isCancelling={isCancellingCustomOrder}
              formatPrice={formatPrice}
              entryPrice={balance.entryPrice}
              positionAmt={balance.positionAmt}
              side={side}
              currentPnl={balance.pnl}
            />
          </div>
        )}

        {/* Controles adicionais - mostrar quando a outra posição foi fechada */}
        {showLimitOrderButton && !balance.closed && otherBalance.closed && (
          <div className="mt-4 pt-4 border-t border-border/20 space-y-4">
            {/* Botão para fechar no preço de entrada */}
            {!limitOrderCreated && (
              <div>
                <AlertDialog open={showLimitOrderConfirm} onOpenChange={setShowLimitOrderConfirm}>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={isCreatingLimitOrder}
                      className="w-full border-primary/30 text-primary hover:bg-primary/10 hover:border-primary/50 gap-2"
                    >
                      {isCreatingLimitOrder ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Criando ordem...
                        </>
                      ) : (
                        <>
                          <Target className="h-4 w-4" />
                          Encerrar no preço de entrada?
                        </>
                      )}
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Criar Ordem Limite</AlertDialogTitle>
                      <AlertDialogDescription>
                        Tem certeza que deseja criar uma ordem limite para encerrar a posição {side} no preço de entrada (${formatPrice(balance.entryPrice)})?
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => {
                          setShowLimitOrderConfirm(false);
                          onCreateLimitOrderAtEntry();
                        }}
                      >
                        Criar Ordem
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <p className="text-[10px] text-muted-foreground text-center mt-2">
                  Ordem limite @ ${formatPrice(balance.entryPrice)}
                </p>
              </div>
            )}

            {/* Mostrar se ordem no preço de entrada foi criada */}
            {limitOrderCreated && (
              <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-green-500">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>Ordem enviada com sucesso!</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onCancelLimitOrder}
                    disabled={isCancellingLimitOrder}
                    className="h-7 px-2 text-red-400 hover:text-red-500 hover:bg-red-500/10"
                  >
                    {isCancellingLimitOrder ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <>
                        <X className="h-3.5 w-3.5 mr-1" />
                        Cancelar
                      </>
                    )}
                  </Button>
                </div>
                <p className="text-[10px] text-muted-foreground mt-1">
                  Ordem limite @ ${formatPrice(balance.entryPrice)}
                </p>
              </div>
            )}

            {/* Input de preço manual (alternativa) */}
            <CustomExitPriceInput
              onSubmit={onSubmitCustomExitPrice}
              onCancel={onCancelCustomExitOrder}
              isCreating={isCreatingCustomOrder}
              orderCreated={customOrderCreated}
              isCancelling={isCancellingCustomOrder}
              formatPrice={formatPrice}
              onEditingChange={onExitPriceEditingChange}
            />
          </div>
        )}
      </div>
    </Card>
  );
});

AurionPositionCard.displayName = "AurionPositionCard";
