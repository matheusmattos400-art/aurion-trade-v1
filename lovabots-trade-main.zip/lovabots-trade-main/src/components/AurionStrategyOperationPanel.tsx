import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { TradingViewChart } from "./TradingViewChart";
import { MomentumIndicator } from "./MomentumIndicator";
import { ExhaustionIndicator } from "./ExhaustionIndicator";
import { LiquidityAnomalyIndicator } from "./LiquidityAnomalyIndicator";
import { AurionPositionCard } from "./AurionPositionCard";
import { ADXIndicatorChart } from "./ADXIndicatorChart";
import { ChandelierExitChart } from "./ChandelierExitChart";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Square, Loader2, Activity, Clock, Zap } from "lucide-react";

interface PositionBalance {
  symbol: string;
  pnl: number;
  frozen: boolean;
  closed: boolean;
  markPrice: number;
  entryPrice: number;
  positionAmt: number;
}

interface AurionStrategyOperationPanelProps {
  operation: {
    id: string;
    longSymbol: string;
    shortSymbol: string;
    leverageLong: number;
    leverageShort: number;
    amount: number;
    entryPriceLong: number;
    entryPriceShort: number;
    startTime: Date;
    isTest?: boolean;
    longClosed?: boolean;
    shortClosed?: boolean;
    longClosePnl?: number;
    shortClosePnl?: number;
    // Novos campos para persistência de ordens
    limitOrderId?: string | null;
    limitOrderCreated?: boolean;
    customOrderId?: string | null;
    customOrderPrice?: number | null;
    customOrderCreated?: boolean;
  };
  onOperationClosed: () => void;
}

export const AurionStrategyOperationPanel = ({
  operation,
  onOperationClosed,
}: AurionStrategyOperationPanelProps) => {
  const { toast } = useToast();
  
  const [longBalance, setLongBalance] = useState<PositionBalance>({
    symbol: operation.longSymbol,
    pnl: operation.longClosePnl || 0,
    frozen: operation.longClosed || false,
    closed: operation.longClosed || false,
    markPrice: 0,
    entryPrice: operation.entryPriceLong,
    positionAmt: 0,
  });
  
  const [shortBalance, setShortBalance] = useState<PositionBalance>({
    symbol: operation.shortSymbol,
    pnl: operation.shortClosePnl || 0,
    frozen: operation.shortClosed || false,
    closed: operation.shortClosed || false,
    markPrice: 0,
    entryPrice: operation.entryPriceShort,
    positionAmt: 0,
  });

  const [isClosingLong, setIsClosingLong] = useState(false);
  const [isClosingShort, setIsClosingShort] = useState(false);
  const [chartSymbol, setChartSymbol] = useState<string | null>(
    operation.longClosed && !operation.shortClosed ? operation.shortSymbol :
    operation.shortClosed && !operation.longClosed ? operation.longSymbol : null
  );
  const [elapsedTime, setElapsedTime] = useState("00:00:00");
  
  const wsRef = useRef<WebSocket | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Refs para guardar últimos PnLs válidos (usados quando posição é fechada externamente)
  const lastValidLongPnlRef = useRef<number>(operation.longClosePnl || 0);
  const lastValidShortPnlRef = useRef<number>(operation.shortClosePnl || 0);

  // Timer para tempo decorrido
  useEffect(() => {
    const updateTimer = () => {
      const now = new Date();
      const diff = Math.floor((now.getTime() - operation.startTime.getTime()) / 1000);
      const hours = Math.floor(diff / 3600);
      const minutes = Math.floor((diff % 3600) / 60);
      const seconds = diff % 60;
      setElapsedTime(
        `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
      );
    };

    updateTimer();
    timerRef.current = setInterval(updateTimer, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [operation.startTime]);

  // WebSocket para preços em tempo real
  useEffect(() => {
    const symbols = [operation.longSymbol, operation.shortSymbol].filter(Boolean);
    if (symbols.length === 0) return;

    const streams = symbols.map(s => `${s.toLowerCase()}@markPrice`).join("/");
    const wsUrl = `wss://fstream.binance.com/stream?streams=${streams}`;

    console.log("📡 Conectando WebSocket para preços:", wsUrl);
    
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        const payload = data.data;
        
        if (!payload?.s || !payload?.p) return;

        const symbol = payload.s;
        const markPrice = parseFloat(payload.p);

        if (symbol === operation.longSymbol && !longBalance.frozen) {
          setLongBalance(prev => {
            if (prev.frozen) return prev;
            const pnl = prev.positionAmt !== 0 
              ? (markPrice - prev.entryPrice) * prev.positionAmt
              : 0;
            // Salvar último PnL válido no ref
            if (pnl !== 0) {
              lastValidLongPnlRef.current = pnl;
            }
            return { ...prev, markPrice, pnl };
          });
        }
        
        if (symbol === operation.shortSymbol && !shortBalance.frozen) {
          setShortBalance(prev => {
            if (prev.frozen) return prev;
            const pnl = prev.positionAmt !== 0
              ? (prev.entryPrice - markPrice) * Math.abs(prev.positionAmt)
              : 0;
            // Salvar último PnL válido no ref
            if (pnl !== 0) {
              lastValidShortPnlRef.current = pnl;
            }
            return { ...prev, markPrice, pnl };
          });
        }
      } catch (error) {
        console.error("Erro ao processar WebSocket:", error);
      }
    };

    ws.onerror = (error) => {
      console.error("Erro WebSocket:", error);
    };

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [operation.longSymbol, operation.shortSymbol]);

  // Buscar posições iniciais e atualizar periodicamente
  // Para operações TESTE: usar preços do WebSocket diretamente
  // Para operações REAIS: buscar posições da Binance
  useEffect(() => {
    // Se for operação de teste, simular PnL baseado nos preços do WebSocket
    if (operation.isTest) {
      console.log("📊 Operação TESTE - usando simulação de PnL via WebSocket");
      
      // Inicializar com valores simulados
      const halfAmount = operation.amount / 2;
      const longNotional = halfAmount * operation.leverageLong;
      const shortNotional = halfAmount * operation.leverageShort;
      
      // Simular quantidade baseada no preço de entrada
      const simulatedLongQty = operation.entryPriceLong > 0 
        ? longNotional / operation.entryPriceLong 
        : 0;
      const simulatedShortQty = operation.entryPriceShort > 0 
        ? shortNotional / operation.entryPriceShort 
        : 0;
      
      setLongBalance(prev => ({
        ...prev,
        positionAmt: simulatedLongQty,
        entryPrice: operation.entryPriceLong || prev.entryPrice,
      }));
      
      setShortBalance(prev => ({
        ...prev,
        positionAmt: -simulatedShortQty, // Negativo para short
        entryPrice: operation.entryPriceShort || prev.entryPrice,
      }));
      
      return;
    }

    // Operação REAL - buscar posições da Binance

    const fetchPositions = async () => {
      try {
        const { data, error } = await supabase.functions.invoke("binance-trading", {
          body: { action: "get_positions" },
        });

        if (error || !data?.success) {
          console.error("Erro ao buscar posições:", error);
          return;
        }

        const positions = data.data?.positions || [];
        
        const longPos = positions.find((p: any) => p.symbol === operation.longSymbol);
        const shortPos = positions.find((p: any) => p.symbol === operation.shortSymbol);

        // === LONG ===
        const longPositionAmt = longPos ? parseFloat(longPos.positionAmt || '0') : 0;
        
        if (longPos && !longBalance.frozen && Math.abs(longPositionAmt) > 0.0001) {
          // Posição LONG ainda aberta - atualizar estado e guardar PnL válido
          const positionAmt = parseFloat(longPos.positionAmt || '0');
          const entryPrice = parseFloat(longPos.entryPrice || '0');
          const apiUnrealizedProfit = parseFloat(longPos.unrealizedProfit || '0');
          const fallbackMarkPrice = parseFloat(longPos.markPrice || '0');

          setLongBalance(prev => {
            if (prev.frozen) return prev;

            const markPrice = prev.markPrice > 0 ? prev.markPrice : fallbackMarkPrice;
            // Usar PnL da API da Binance (mais preciso) ou calcular manualmente
            const pnl = apiUnrealizedProfit !== 0 
              ? apiUnrealizedProfit
              : (positionAmt !== 0 && entryPrice > 0 && markPrice > 0
                ? (markPrice - entryPrice) * positionAmt
                : prev.pnl);

            // Salvar último PnL válido
            if (pnl !== 0) {
              lastValidLongPnlRef.current = pnl;
            }

            return {
              ...prev,
              positionAmt,
              entryPrice: entryPrice > 0 ? entryPrice : prev.entryPrice,
              markPrice: markPrice > 0 ? markPrice : prev.markPrice,
              pnl,
            };
          });
        } else if (!longBalance.closed && Math.abs(longPositionAmt) < 0.0001) {
          // Posição LONG fechada externamente
          console.log("🔍 Posição LONG detectada como fechada externamente");
          
          // Usar o último PnL válido salvo, não o estado atual (que pode estar zerado)
          const pnlToSave = lastValidLongPnlRef.current !== 0 
            ? lastValidLongPnlRef.current 
            : longBalance.pnl;
          
          console.log(`💰 PnL LONG a salvar: ${pnlToSave} (ref: ${lastValidLongPnlRef.current}, state: ${longBalance.pnl})`);

          setLongBalance(prev => ({
            ...prev,
            frozen: true,
            closed: true,
            positionAmt: 0,
            pnl: pnlToSave, // Manter o PnL correto no estado
          }));
          
          await supabase
            .from("active_operations")
            .update({ long_closed: true, long_close_pnl: pnlToSave })
            .eq("id", operation.id);
        }

        // === SHORT ===
        const shortPositionAmt = shortPos ? parseFloat(shortPos.positionAmt || '0') : 0;
        
        if (shortPos && !shortBalance.frozen && Math.abs(shortPositionAmt) > 0.0001) {
          // Posição SHORT ainda aberta - atualizar estado e guardar PnL válido
          const positionAmt = parseFloat(shortPos.positionAmt || '0');
          const entryPrice = parseFloat(shortPos.entryPrice || '0');
          const apiUnrealizedProfit = parseFloat(shortPos.unrealizedProfit || '0');
          const fallbackMarkPrice = parseFloat(shortPos.markPrice || '0');

          setShortBalance(prev => {
            if (prev.frozen) return prev;

            const markPrice = prev.markPrice > 0 ? prev.markPrice : fallbackMarkPrice;
            // Usar PnL da API da Binance (mais preciso)
            const pnl = apiUnrealizedProfit !== 0 
              ? apiUnrealizedProfit
              : (positionAmt !== 0 && entryPrice > 0 && markPrice > 0
                ? (entryPrice - markPrice) * Math.abs(positionAmt)
                : prev.pnl);

            // Salvar último PnL válido
            if (pnl !== 0) {
              lastValidShortPnlRef.current = pnl;
            }

            return {
              ...prev,
              positionAmt,
              entryPrice: entryPrice > 0 ? entryPrice : prev.entryPrice,
              markPrice: markPrice > 0 ? markPrice : prev.markPrice,
              pnl,
            };
          });
        } else if (!shortBalance.closed && Math.abs(shortPositionAmt) < 0.0001) {
          // Posição SHORT fechada externamente
          console.log("🔍 Posição SHORT detectada como fechada externamente");
          
          // Usar o último PnL válido salvo
          const pnlToSave = lastValidShortPnlRef.current !== 0 
            ? lastValidShortPnlRef.current 
            : shortBalance.pnl;
          
          console.log(`💰 PnL SHORT a salvar: ${pnlToSave} (ref: ${lastValidShortPnlRef.current}, state: ${shortBalance.pnl})`);

          setShortBalance(prev => ({
            ...prev,
            frozen: true,
            closed: true,
            positionAmt: 0,
            pnl: pnlToSave, // Manter o PnL correto no estado
          }));
          
          await supabase
            .from("active_operations")
            .update({ short_closed: true, short_close_pnl: pnlToSave })
            .eq("id", operation.id);
        }
      } catch (error) {
        console.error("Erro ao buscar posições:", error);
      }
    };

    fetchPositions();
    intervalRef.current = setInterval(fetchPositions, 5000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [operation.longSymbol, operation.shortSymbol, longBalance.frozen, shortBalance.frozen, longBalance.closed, shortBalance.closed, operation.isTest, operation.amount, operation.leverageLong, operation.leverageShort, operation.entryPriceLong, operation.entryPriceShort, operation.id, longBalance.pnl, shortBalance.pnl]);

  // Verificar se ambas posições foram fechadas e salvar PnL total no banco
  useEffect(() => {
    const saveAndClose = async () => {
      if (longBalance.closed && shortBalance.closed) {
        // Usar os PnLs congelados de cada posição
        const finalLongPnl = longBalance.pnl;
        const finalShortPnl = shortBalance.pnl;
        const finalTotalPnl = finalLongPnl + finalShortPnl;
        
        console.log(`💰 Salvando PnL final - Long: ${finalLongPnl}, Short: ${finalShortPnl}, Total: ${finalTotalPnl}`);
        
        // Garantir que os PnLs estão salvos corretamente antes de chamar onOperationClosed
        await supabase
          .from("active_operations")
          .update({ 
            long_close_pnl: finalLongPnl,
            short_close_pnl: finalShortPnl,
            current_pnl: finalTotalPnl
          })
          .eq("id", operation.id);
        
        toast({
          title: "✅ Operação Encerrada",
          description: `Lucro total: $${finalTotalPnl.toFixed(2)}`,
        });
        onOperationClosed();
      }
    };
    
    saveAndClose();
  }, [longBalance.closed, shortBalance.closed, longBalance.pnl, shortBalance.pnl]);

  const handleClosePosition = async (side: "long" | "short") => {
    const symbol = side === "long" ? operation.longSymbol : operation.shortSymbol;
    const setClosing = side === "long" ? setIsClosingLong : setIsClosingShort;
    const setBalance = side === "long" ? setLongBalance : setShortBalance;
    const balance = side === "long" ? longBalance : shortBalance;
    const otherBalance = side === "long" ? shortBalance : longBalance;

    setClosing(true);

    try {
      // Para operações TESTE, apenas simular o fechamento
      if (operation.isTest) {
        console.log(`📤 [TESTE] Simulando fechamento ${side.toUpperCase()}: ${symbol}`);
        
        // Salvar o estado no banco de dados
        const updateData = side === "long" 
          ? { long_closed: true, long_close_pnl: balance.pnl }
          : { short_closed: true, short_close_pnl: balance.pnl };
        
        await supabase
          .from("active_operations")
          .update(updateData)
          .eq("id", operation.id);
        
        toast({
          title: `✅ ${symbol} Encerrado (Teste)`,
          description: `Posição ${side.toUpperCase()} fechada - PnL: $${balance.pnl.toFixed(2)}`,
        });

        // Congelar o saldo desta posição
        setBalance(prev => ({
          ...prev,
          frozen: true,
          closed: true,
        }));

        // Se a outra posição ainda está aberta, mostrar o gráfico dela
        if (!otherBalance.closed) {
          const remainingSymbol = side === "long" ? operation.shortSymbol : operation.longSymbol;
          setChartSymbol(remainingSymbol);
        }

        return;
      }

      // Para operações REAIS, chamar a API da Binance
      console.log(`📤 Fechando posição ${side.toUpperCase()}: ${symbol}`);

      const { data, error } = await supabase.functions.invoke("binance-trading", {
        body: { action: "close_position", symbol },
      });

      if (error || !data?.success) {
        throw new Error(data?.error || "Erro ao fechar posição");
      }

      // Salvar o estado no banco de dados
      const updateData = side === "long" 
        ? { long_closed: true, long_close_pnl: balance.pnl }
        : { short_closed: true, short_close_pnl: balance.pnl };
      
      await supabase
        .from("active_operations")
        .update(updateData)
        .eq("id", operation.id);

      toast({
        title: `✅ ${symbol} Encerrado`,
        description: `Posição ${side.toUpperCase()} fechada com sucesso`,
      });

      // Congelar o saldo desta posição
      setBalance(prev => ({
        ...prev,
        frozen: true,
        closed: true,
      }));

      // Se a outra posição ainda está aberta, mostrar o gráfico dela
      if (!otherBalance.closed) {
        const remainingSymbol = side === "long" ? operation.shortSymbol : operation.longSymbol;
        setChartSymbol(remainingSymbol);
      }

    } catch (error: any) {
      console.error(`Erro ao fechar ${side}:`, error);
      toast({
        title: "Erro ao fechar posição",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setClosing(false);
    }
  };

  const [isClosingAll, setIsClosingAll] = useState(false);
  const [isCreatingLimitOrder, setIsCreatingLimitOrder] = useState(false);
  const [limitOrderCreated, setLimitOrderCreated] = useState(operation.limitOrderCreated || false);
  const [limitOrderId, setLimitOrderId] = useState<string | null>(operation.limitOrderId || null);
  const [isCancellingLimitOrder, setIsCancellingLimitOrder] = useState(false);
  const [customExitPrice, setCustomExitPrice] = useState<string>(
    operation.customOrderPrice ? operation.customOrderPrice.toString() : ""
  );
  const [isCreatingCustomOrder, setIsCreatingCustomOrder] = useState(false);
  const [customOrderCreated, setCustomOrderCreated] = useState(operation.customOrderCreated || false);
  const [customOrderId, setCustomOrderId] = useState<string | null>(operation.customOrderId || null);
  const [isCancellingCustomOrder, setIsCancellingCustomOrder] = useState(false);

  // Salvar estado das ordens no banco
  const saveOrderState = async (updates: {
    limit_order_id?: string | null;
    limit_order_created?: boolean;
    custom_order_id?: string | null;
    custom_order_price?: number | null;
    custom_order_created?: boolean;
  }) => {
    try {
      await supabase
        .from("active_operations")
        .update(updates)
        .eq("id", operation.id);
    } catch (error) {
      console.error("Erro ao salvar estado da ordem:", error);
    }
  };

  const handleCloseAll = async () => {
    if (longBalance.closed && shortBalance.closed) return;
    
    setIsClosingAll(true);
    
    try {
      // Fechar ambas em paralelo
      const closeLong = !longBalance.closed ? handleClosePosition("long") : Promise.resolve();
      const closeShort = !shortBalance.closed ? handleClosePosition("short") : Promise.resolve();
      
      await Promise.all([closeLong, closeShort]);
    } catch (error) {
      console.error("Erro ao encerrar todas as posições:", error);
    } finally {
      setIsClosingAll(false);
    }
  };

  // Criar ordem limite no preço de entrada para a posição aberta (no negativo)
  const handleCreateLimitOrderAtEntry = async () => {
    // Determinar qual posição está aberta (a que está no negativo)
    const openPosition = !longBalance.closed ? "long" : !shortBalance.closed ? "short" : null;
    
    if (!openPosition) {
      toast({
        title: "Nenhuma posição aberta",
        description: "Não há posição aberta para criar ordem limite.",
        variant: "destructive",
      });
      return;
    }

    const openBalance = openPosition === "long" ? longBalance : shortBalance;
    const symbol = openBalance.symbol;
    const entryPrice = openBalance.entryPrice;
    const positionAmt = Math.abs(openBalance.positionAmt);

    if (entryPrice <= 0 || positionAmt <= 0) {
      toast({
        title: "Dados insuficientes",
        description: "Preço de entrada ou quantidade não disponíveis.",
        variant: "destructive",
      });
      return;
    }

    // Proteção: impedir ordem LIMIT que executaria imediatamente (vira 'a mercado')
    if (!operation.isTest && openBalance.markPrice > 0) {
      const sideToSend = openPosition === "long" ? "SELL" : "BUY";
      const mark = openBalance.markPrice;
      const wouldFillImmediately = sideToSend === "SELL" ? entryPrice <= mark : entryPrice >= mark;

      if (wouldFillImmediately) {
        toast({
          title: "⚠️ Ordem executaria imediatamente",
          description: `Preço escolhido (${formatPrice(entryPrice)}) cruza o preço atual (${formatPrice(mark)}). Ajuste o preço para não executar na hora.`,
          variant: "destructive",
        });
        return;
      }
    }

    setIsCreatingLimitOrder(true);

    try {
      if (operation.isTest) {
        // Para operações de teste, apenas simular
        console.log(`📤 [TESTE] Simulando ordem limite em ${symbol} @ ${entryPrice}`);
        
        toast({
          title: "✅ Ordem enviada com sucesso!",
          description: `Ordem de saída em ${symbol} @ $${formatPrice(entryPrice)}`,
        });
        
        const orderId = "TEST_ORDER_" + Date.now();
        setLimitOrderId(orderId);
        setLimitOrderCreated(true);
        await saveOrderState({ limit_order_id: orderId, limit_order_created: true });
        return;
      }

      // Para operações reais, enviar ordem limite para Binance
      console.log(`📤 Criando ordem limite: ${symbol} @ ${entryPrice}, qty: ${positionAmt}`);

      const { data, error } = await supabase.functions.invoke("binance-trading", {
        body: { 
          action: "create_limit_order",
          symbol,
          side: openPosition === "long" ? "SELL" : "BUY", // Oposto para fechar
          price: entryPrice,
          quantity: positionAmt,
        },
      });

      if (error || !data?.success) {
        throw new Error(data?.error || "Erro ao criar ordem limite");
      }

      toast({
        title: "✅ Ordem enviada com sucesso!",
        description: `Ordem de saída em ${symbol} @ $${formatPrice(entryPrice)} enviada para Binance`,
      });

      const orderId = data.data?.orderId?.toString() || null;
      setLimitOrderId(orderId);
      setLimitOrderCreated(true);
      await saveOrderState({ limit_order_id: orderId, limit_order_created: true });

    } catch (error: any) {
      console.error("Erro ao criar ordem limite:", error);
      toast({
        title: "Erro ao criar ordem",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsCreatingLimitOrder(false);
    }
  };

  // Cancelar ordem limite no preço de entrada
  const handleCancelLimitOrder = async () => {
    // Determinar qual posição está aberta
    let openPosition: "long" | "short" | null = null;
    if (!longBalance.closed) openPosition = "long";
    else if (!shortBalance.closed) openPosition = "short";
    
    const openBalance = openPosition === "long" ? longBalance : 
                        openPosition === "short" ? shortBalance : null;
    const symbol = openBalance?.symbol;

    setIsCancellingLimitOrder(true);

    try {
      if (operation.isTest) {
        console.log(`📤 [TESTE] Simulando cancelamento de ordem limite`);
        
        toast({
          title: "✅ Ordem cancelada com sucesso!",
          description: "A ordem limite foi cancelada.",
        });
        
        setLimitOrderCreated(false);
        setLimitOrderId(null);
        await saveOrderState({ limit_order_id: null, limit_order_created: false });
        return;
      }

      if (!limitOrderId) {
        throw new Error("ID da ordem não disponível. Tente novamente.");
      }

      if (!symbol) {
        throw new Error("Símbolo não disponível. Tente novamente.");
      }

      // Garantir que orderId é enviado como número
      const orderIdNumber = parseInt(limitOrderId, 10);
      if (isNaN(orderIdNumber)) {
        throw new Error("ID da ordem inválido.");
      }

      console.log(`❌ Cancelando ordem limite: ${symbol}, orderId: ${orderIdNumber}`);

      const { data, error } = await supabase.functions.invoke("binance-trading", {
        body: { 
          action: "cancel_order",
          symbol,
          orderId: orderIdNumber,
        },
      });

      if (error) {
        console.error("Erro na invocação:", error);
        throw new Error(error.message || "Erro ao cancelar ordem");
      }

      if (!data?.success) {
        console.error("Resposta de erro:", data);
        throw new Error(data?.error || "Erro ao cancelar ordem na Binance");
      }

      toast({
        title: "✅ Ordem cancelada com sucesso!",
        description: "A ordem limite foi cancelada na Binance.",
      });

      setLimitOrderCreated(false);
      setLimitOrderId(null);
      await saveOrderState({ limit_order_id: null, limit_order_created: false });

    } catch (error: any) {
      console.error("Erro ao cancelar ordem limite:", error);
      toast({
        title: "Erro ao cancelar ordem",
        description: error.message || "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setIsCancellingLimitOrder(false);
    }
  };

  // Criar ordem limite com preço customizado
  const handleCreateCustomLimitOrder = async (priceStr?: string) => {
    const openPosition = !longBalance.closed ? "long" : !shortBalance.closed ? "short" : null;
    
    if (!openPosition) {
      toast({
        title: "Nenhuma posição aberta",
        description: "Não há posição aberta para criar ordem limite.",
        variant: "destructive",
      });
      return;
    }

    const priceToUse = priceStr || customExitPrice;
    const normalized = priceToUse.replace(/\s+/g, "").replace(/,/g, ".");
    const price = Number(normalized);
    if (!Number.isFinite(price) || price <= 0) {
      toast({
        title: "Preço inválido",
        description: "Digite um preço válido para a ordem.",
        variant: "destructive",
      });
      return;
    }

    const openBalance = openPosition === "long" ? longBalance : shortBalance;
    const symbol = openBalance.symbol;
    const positionAmt = Math.abs(openBalance.positionAmt);

    if (positionAmt <= 0) {
      toast({
        title: "Dados insuficientes",
        description: "Quantidade não disponível.",
        variant: "destructive",
      });
      return;
    }

    // Proteção: impedir ordem LIMIT que executaria imediatamente (vira 'a mercado')
    if (!operation.isTest && openBalance.markPrice > 0) {
      const sideToSend = openPosition === "long" ? "SELL" : "BUY";
      const mark = openBalance.markPrice;
      const wouldFillImmediately = sideToSend === "SELL" ? price <= mark : price >= mark;

      if (wouldFillImmediately) {
        toast({
          title: "⚠️ Ordem executaria imediatamente",
          description: `Preço escolhido (${formatPrice(price)}) cruza o preço atual (${formatPrice(mark)}). Ajuste o preço para não executar na hora.`,
          variant: "destructive",
        });
        return;
      }
    }

    setIsCreatingCustomOrder(true);

    try {
      if (operation.isTest) {
        console.log(`📤 [TESTE] Simulando ordem limite customizada em ${symbol} @ ${price}`);
        
        toast({
          title: "✅ Ordem enviada com sucesso!",
          description: `Ordem de saída em ${symbol} @ $${formatPrice(price)}`,
        });
        
        const orderId = "TEST_CUSTOM_" + Date.now();
        setCustomOrderId(orderId);
        setCustomOrderCreated(true);
        await saveOrderState({ 
          custom_order_id: orderId, 
          custom_order_price: price, 
          custom_order_created: true 
        });
        return;
      }

      console.log(`📤 Criando ordem limite customizada: ${symbol} @ ${price}, qty: ${positionAmt}`);

      const { data, error } = await supabase.functions.invoke("binance-trading", {
        body: { 
          action: "create_limit_order",
          symbol,
          side: openPosition === "long" ? "SELL" : "BUY",
          price,
          quantity: positionAmt,
        },
      });

      if (error || !data?.success) {
        throw new Error(data?.error || "Erro ao criar ordem limite");
      }

      toast({
        title: "✅ Ordem enviada com sucesso!",
        description: `Ordem de saída em ${symbol} @ $${formatPrice(price)} enviada para Binance`,
      });

      const orderId = data.data?.orderId?.toString() || null;
      setCustomOrderId(orderId);
      setCustomOrderCreated(true);
      await saveOrderState({ 
        custom_order_id: orderId, 
        custom_order_price: price, 
        custom_order_created: true 
      });

    } catch (error: any) {
      console.error("Erro ao criar ordem limite customizada:", error);
      toast({
        title: "Erro ao criar ordem",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsCreatingCustomOrder(false);
    }
  };

  // Cancelar ordem limite customizada
  const handleCancelCustomOrder = async () => {
    // Determinar qual posição está aberta
    let openPosition: "long" | "short" | null = null;
    if (!longBalance.closed) openPosition = "long";
    else if (!shortBalance.closed) openPosition = "short";
    
    const openBalance = openPosition === "long" ? longBalance : 
                        openPosition === "short" ? shortBalance : null;
    const symbol = openBalance?.symbol;

    setIsCancellingCustomOrder(true);

    try {
      if (operation.isTest) {
        console.log(`📤 [TESTE] Simulando cancelamento de ordem customizada`);
        
        toast({
          title: "✅ Ordem cancelada com sucesso!",
          description: "A ordem limite customizada foi cancelada.",
        });
        
        setCustomOrderCreated(false);
        setCustomOrderId(null);
        await saveOrderState({ 
          custom_order_id: null, 
          custom_order_price: null, 
          custom_order_created: false 
        });
        return;
      }

      if (!customOrderId) {
        throw new Error("ID da ordem não disponível. Tente novamente.");
      }

      if (!symbol) {
        throw new Error("Símbolo não disponível. Tente novamente.");
      }

      // Garantir que orderId é enviado como número
      const orderIdNumber = parseInt(customOrderId, 10);
      if (isNaN(orderIdNumber)) {
        throw new Error("ID da ordem inválido.");
      }

      console.log(`❌ Cancelando ordem customizada: ${symbol}, orderId: ${orderIdNumber}`);

      const { data, error } = await supabase.functions.invoke("binance-trading", {
        body: { 
          action: "cancel_order",
          symbol,
          orderId: orderIdNumber,
        },
      });

      if (error) {
        console.error("Erro na invocação:", error);
        throw new Error(error.message || "Erro ao cancelar ordem");
      }

      if (!data?.success) {
        console.error("Resposta de erro:", data);
        throw new Error(data?.error || "Erro ao cancelar ordem na Binance");
      }

      toast({
        title: "✅ Ordem cancelada com sucesso!",
        description: "A ordem limite customizada foi cancelada na Binance.",
      });

      setCustomOrderCreated(false);
      setCustomOrderId(null);
      await saveOrderState({ 
        custom_order_id: null, 
        custom_order_price: null, 
        custom_order_created: false 
      });

    } catch (error: any) {
      console.error("Erro ao cancelar ordem customizada:", error);
      toast({
        title: "Erro ao cancelar ordem",
        description: error.message || "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setIsCancellingCustomOrder(false);
    }
  };

  const totalPnl = longBalance.pnl + shortBalance.pnl;

  const formatPrice = (price: number) => {
    if (price === 0) return "-";
    if (price >= 1000) return price.toFixed(2);
    if (price >= 1) return price.toFixed(4);
    return price.toFixed(6);
  };


  return (
    <div className="space-y-5">
      {/* Total PnL Card */}
      <Card className="relative overflow-hidden bg-gradient-to-br from-card/80 via-card/60 to-card/40 border-border/30">
        {/* Ambient glow based on profit/loss */}
        <div className={`absolute inset-0 opacity-20 ${
          totalPnl >= 0 
            ? "bg-gradient-to-br from-green-500/20 to-transparent" 
            : "bg-gradient-to-br from-red-500/20 to-transparent"
        }`} />
        
        <div className="relative p-5">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                  PnL Total da Operação
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className={`text-4xl font-bold font-mono ${
                  totalPnl >= 0 ? "text-green-500" : "text-red-500"
                }`}>
                  {totalPnl >= 0 ? "+" : ""}${totalPnl.toFixed(2)}
                </span>
                {operation.isTest && (
                  <Badge variant="outline" className="border-yellow-500/30 text-yellow-500">
                    <Zap className="h-3 w-3 mr-1" />
                    Teste
                  </Badge>
                )}
              </div>
            </div>

            <div className="text-right space-y-1">
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <Clock className="h-4 w-4" />
                <span className="text-xs uppercase tracking-wider">Tempo</span>
              </div>
              <span className="text-2xl font-mono font-bold text-foreground">{elapsedTime}</span>
            </div>
          </div>

          {/* Botão Encerrar Tudo */}
          {!longBalance.closed || !shortBalance.closed ? (
            <div className="mt-4 pt-4 border-t border-border/30">
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="destructive"
                    size="lg"
                    disabled={isClosingAll || isClosingLong || isClosingShort || (longBalance.closed && shortBalance.closed)}
                    className="w-full gap-2 bg-red-500/80 hover:bg-red-500"
                  >
                    {isClosingAll ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Encerrando Posições...
                      </>
                    ) : (
                      <>
                        <Square className="h-4 w-4" />
                        Encerrar Todas as Posições
                      </>
                    )}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirmar Encerramento</AlertDialogTitle>
                    <AlertDialogDescription>
                      Tem certeza que deseja encerrar TODAS as posições abertas?
                      Esta ação irá fechar as posições {!longBalance.closed && operation.longSymbol} {!longBalance.closed && !shortBalance.closed && "e"} {!shortBalance.closed && operation.shortSymbol} a mercado.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleCloseAll}
                      className="bg-red-500 hover:bg-red-600"
                    >
                      Encerrar Todas
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          ) : null}
        </div>
      </Card>

      {/* Position Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <AurionPositionCard
          balance={longBalance}
          side="LONG"
          leverage={operation.leverageLong}
          isClosing={isClosingLong}
          onClose={() => handleClosePosition("long")}
          showLimitOrderButton={!longBalance.closed && shortBalance.closed}
          otherBalance={shortBalance}
          formatPrice={formatPrice}
          limitOrderCreated={limitOrderCreated}
          isCreatingLimitOrder={isCreatingLimitOrder}
          isCancellingLimitOrder={isCancellingLimitOrder}
          onCreateLimitOrderAtEntry={handleCreateLimitOrderAtEntry}
          onCancelLimitOrder={handleCancelLimitOrder}
          isCreatingCustomOrder={isCreatingCustomOrder}
          customOrderCreated={customOrderCreated}
          isCancellingCustomOrder={isCancellingCustomOrder}
          onSubmitCustomExitPrice={async (price) => {
            setCustomExitPrice(price);
            await handleCreateCustomLimitOrder(price);
          }}
          onCancelCustomExitOrder={handleCancelCustomOrder}
        />
        <AurionPositionCard
          balance={shortBalance}
          side="SHORT"
          leverage={operation.leverageShort}
          isClosing={isClosingShort}
          onClose={() => handleClosePosition("short")}
          showLimitOrderButton={!shortBalance.closed && longBalance.closed}
          otherBalance={longBalance}
          formatPrice={formatPrice}
          limitOrderCreated={limitOrderCreated}
          isCreatingLimitOrder={isCreatingLimitOrder}
          isCancellingLimitOrder={isCancellingLimitOrder}
          onCreateLimitOrderAtEntry={handleCreateLimitOrderAtEntry}
          onCancelLimitOrder={handleCancelLimitOrder}
          isCreatingCustomOrder={isCreatingCustomOrder}
          customOrderCreated={customOrderCreated}
          isCancellingCustomOrder={isCancellingCustomOrder}
          onSubmitCustomExitPrice={async (price) => {
            setCustomExitPrice(price);
            await handleCreateCustomLimitOrder(price);
          }}
          onCancelCustomExitOrder={handleCancelCustomOrder}
        />
      </div>

      {/* Momentum - Mostrar quando ambas posições estão abertas */}
      {!longBalance.closed && !shortBalance.closed && (
        <MomentumIndicator
          longSymbol={operation.longSymbol}
          shortSymbol={operation.shortSymbol}
          entryTime={operation.startTime}
          entryMomentum={undefined}
        />
      )}

      {/* RSI Exaustão - Sempre visível (mesmo após encerrar posições) */}
      <ExhaustionIndicator
        longSymbol={operation.longSymbol}
        shortSymbol={operation.shortSymbol}
        longPnl={longBalance.pnl}
        shortPnl={shortBalance.pnl}
        longClosed={longBalance.closed}
        shortClosed={shortBalance.closed}
      />

      {/* Indicador de Anomalia de Liquidez */}
      <LiquidityAnomalyIndicator
        longSymbol={operation.longSymbol}
        shortSymbol={operation.shortSymbol}
      />

      {/* TradingView Chart com Chandelier Exit - Mostrar apenas quando UMA posição for encerrada (não ambas) */}
      {(longBalance.closed !== shortBalance.closed) && (
        <>
          <Card className="p-4 bg-card/40 border-border/30">
            <div className="flex items-center gap-2 mb-3">
              <div className={`h-2 w-2 rounded-full ${longBalance.closed ? 'bg-red-500' : 'bg-green-500'} animate-pulse`} />
              <span className="text-sm font-medium text-foreground">
                {longBalance.closed ? `SHORT: ${operation.shortSymbol}` : `LONG: ${operation.longSymbol}`}
              </span>
              <Badge variant="outline" className={`text-xs ${longBalance.closed ? 'border-red-500/30 text-red-500' : 'border-green-500/30 text-green-500'}`}>
                Ao Vivo
              </Badge>
            </div>
            <TradingViewChart 
              symbol={longBalance.closed ? operation.shortSymbol : operation.longSymbol} 
              className="h-[500px]" 
            />
          </Card>

          {/* ADX Chart */}
          <Card className="p-5 border-border/40 bg-card/80">
            <ADXIndicatorChart 
              symbol={longBalance.closed ? operation.shortSymbol : operation.longSymbol} 
              settings={{ adxPeriod: 14, adxSmoothing: 14 }} 
            />
          </Card>

          {/* Chandelier Exit */}
          <Card className="p-5 border-border/40 bg-card/80">
            <ChandelierExitChart 
              symbol={longBalance.closed ? operation.shortSymbol : operation.longSymbol} 
              settings={{ chandelierPeriod: 22, chandelierMultiplier: 3 }} 
            />
          </Card>
        </>
      )}

    </div>
  );
};