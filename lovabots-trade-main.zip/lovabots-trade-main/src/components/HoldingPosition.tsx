import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Scan, Clock, TrendingUp, TrendingDown, AlertCircle, Loader2, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useHoldingScanner, HoldingSignal } from "@/hooks/useHoldingScanner";
import { HoldingSignalCard } from "./HoldingSignalCard";
import { HoldingSignalDetailsModal } from "./HoldingSignalDetailsModal";
import { TradingConfig } from "./TradingConfig";

interface HoldingPositionProps {
  binanceBalance: number;
  hasActiveOperation: boolean;
  onOperationStart: (data: any) => void;
}

export const HoldingPosition = ({
  binanceBalance,
  hasActiveOperation,
  onOperationStart,
}: HoldingPositionProps) => {
  const { toast } = useToast();
  const { signals, isScanning, lastScanTime, error, rescan } = useHoldingScanner(true, 60000);
  
  const [selectedSignal, setSelectedSignal] = useState<HoldingSignal | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [loadingSignalId, setLoadingSignalId] = useState<string | null>(null);
  
  // Configurações de trading
  const [investment, setInvestment] = useState(100);
  const [leverage, setLeverage] = useState(10); // Leverage menor para holding
  const [profitTarget, setProfitTarget] = useState(5);
  const [autoCloseEnabled, setAutoCloseEnabled] = useState(true);
  const [settingsLoaded, setSettingsLoaded] = useState(false);

  // Carregar configurações
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const { data: settings } = await supabase
          .from('user_trading_settings')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        if (settings) {
          setInvestment(Number(settings.investment_amount));
          setLeverage(settings.leverage);
          setProfitTarget(settings.profit_target);
          setAutoCloseEnabled(settings.auto_close_enabled);
        }
        setSettingsLoaded(true);
      } catch (error) {
        console.error('Erro ao carregar configurações:', error);
        setSettingsLoaded(true);
      }
    };

    loadSettings();
  }, []);

  // Separar sinais por direção
  const longSignals = signals.filter(s => s.direction === "LONG");
  const shortSignals = signals.filter(s => s.direction === "SHORT");

  const handleShowDetails = (signal: HoldingSignal) => {
    setSelectedSignal(signal);
    setIsDetailsOpen(true);
  };

  const handleOpenTrade = async (signal: HoldingSignal, isTest: boolean = false) => {
    if (hasActiveOperation) {
      toast({
        title: "Operação já ativa",
        description: "Você já tem uma operação ativa. Pode abrir outra se desejar.",
      });
    }

    setLoadingSignalId(signal.id);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Erro de autenticação",
          description: "Faça login para continuar",
          variant: "destructive",
        });
        return;
      }

      if (investment < 10) {
        toast({
          title: "Investimento inválido",
          description: "O valor mínimo é $10",
          variant: "destructive",
        });
        return;
      }

      if (!isTest && investment > binanceBalance) {
        toast({
          title: "Saldo insuficiente",
          description: `Seu saldo é $${binanceBalance.toFixed(2)}`,
          variant: "destructive",
        });
        return;
      }

      // Calcular meta em USDT
      const profitTargetUSDT = (investment * profitTarget) / 100;
      const isLong = signal.direction === "LONG";
      const side = isLong ? "BUY" : "SELL";

      // Configurar alavancagem e criar ordem
      if (!isTest) {
        await supabase.functions.invoke('binance-trading', {
          body: { action: 'set_leverage', symbol: signal.symbol, leverage }
        });

        const orderResult = await supabase.functions.invoke('binance-trading', {
          body: {
            action: 'create_order',
            symbol: signal.symbol,
            side: side,
            quantity: (investment * leverage) / signal.currentPrice,
          }
        });

        if (orderResult.error) {
          throw new Error(orderResult.error.message || 'Erro ao criar ordem');
        }
      }

      // Salvar operação - usando o mesmo schema mas como holding
      // Para holding, usamos apenas um lado (long ou short)
      const { data: newOp, error: dbError } = await supabase
        .from('active_operations')
        .insert({
          user_id: user.id,
          long_symbol: isLong ? signal.symbol : 'NONE',
          short_symbol: isLong ? 'NONE' : signal.symbol,
          leverage: leverage,
          leverage_long: isLong ? leverage : 0,
          leverage_short: isLong ? 0 : leverage,
          investment_amount: investment,
          entry_price_long: isLong ? signal.currentPrice : 0,
          entry_price_short: isLong ? 0 : signal.currentPrice,
          profit_target: profitTargetUSDT,
          auto_close_enabled: autoCloseEnabled,
          is_test: isTest,
          trading_mode: 'holding',
          status: 'active',
          long_closed: !isLong,
          short_closed: isLong,
        })
        .select()
        .single();

      if (dbError) throw dbError;

      onOperationStart({
        id: newOp.id,
        longSymbol: isLong ? signal.symbol : 'NONE',
        shortSymbol: isLong ? 'NONE' : signal.symbol,
        leverageLong: isLong ? leverage : 0,
        leverageShort: isLong ? 0 : leverage,
        amount: investment,
        entryPriceLong: isLong ? signal.currentPrice : 0,
        entryPriceShort: isLong ? 0 : signal.currentPrice,
        startTime: new Date(),
        profitTarget: profitTargetUSDT,
        autoCloseEnabled: autoCloseEnabled,
        isTest: isTest,
        longClosed: !isLong,
        shortClosed: isLong,
      });

      setIsDetailsOpen(false);

      toast({
        title: isTest ? "🧪 Operação TESTE iniciada!" : "✅ Operação iniciada!",
        description: `${signal.symbol.replace("USDT", "")} ${isLong ? "LONG" : "SHORT"} | Meta: $${profitTargetUSDT.toFixed(2)}`,
      });

    } catch (error) {
      console.error("Erro ao abrir operação:", error);
      toast({
        title: "Erro ao abrir operação",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setLoadingSignalId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Zap className="h-6 w-6 text-primary" />
            Holding Position
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Sinais baseados em Chandelier Exit, ADX/DI e RSI
          </p>
        </div>

        <div className="flex items-center gap-3">
          {lastScanTime && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" />
              <span>Atualizado: {lastScanTime.toLocaleTimeString()}</span>
            </div>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={rescan}
            disabled={isScanning}
          >
            {isScanning ? (
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
            ) : (
              <RefreshCw className="h-4 w-4 mr-2" />
            )}
            {isScanning ? "Escaneando..." : "Atualizar"}
          </Button>
        </div>
      </div>

      {/* Configurações */}
      <TradingConfig
        investment={investment}
        leverage={leverage}
        profitTarget={profitTarget}
        autoCloseEnabled={autoCloseEnabled}
        onInvestmentChange={setInvestment}
        onLeverageChange={setLeverage}
        onProfitTargetChange={setProfitTarget}
        onAutoCloseChange={setAutoCloseEnabled}
      />

      {/* Erro */}
      {error && (
        <Card className="p-4 bg-red-500/10 border-red-500/30">
          <div className="flex items-center gap-2 text-red-400">
            <AlertCircle className="h-5 w-5" />
            <span>{error}</span>
          </div>
        </Card>
      )}

      {/* Scanning state */}
      {isScanning && signals.length === 0 && (
        <Card className="p-8 text-center">
          <Scan className="h-12 w-12 mx-auto mb-4 text-primary animate-pulse" />
          <p className="text-muted-foreground">Analisando moedas com os indicadores...</p>
        </Card>
      )}

      {/* Sinais LONG */}
      {longSignals.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-green-500" />
            <h3 className="font-semibold text-green-400">Oportunidades de Compra ({longSignals.length})</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {longSignals.slice(0, 6).map(signal => (
              <HoldingSignalCard
                key={signal.id}
                signal={signal}
                onShowDetails={handleShowDetails}
                onOpenTrade={handleOpenTrade}
                isLoading={loadingSignalId === signal.id}
                disabled={false}
              />
            ))}
          </div>
        </div>
      )}

      {/* Sinais SHORT */}
      {shortSignals.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <TrendingDown className="h-5 w-5 text-red-500" />
            <h3 className="font-semibold text-red-400">Oportunidades de Venda ({shortSignals.length})</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {shortSignals.slice(0, 6).map(signal => (
              <HoldingSignalCard
                key={signal.id}
                signal={signal}
                onShowDetails={handleShowDetails}
                onOpenTrade={handleOpenTrade}
                isLoading={loadingSignalId === signal.id}
                disabled={false}
              />
            ))}
          </div>
        </div>
      )}

      {/* Sem sinais */}
      {!isScanning && signals.length === 0 && (
        <Card className="p-8 text-center">
          <AlertCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Nenhum sinal encontrado no momento.</p>
          <p className="text-sm text-muted-foreground mt-2">Os indicadores não identificaram oportunidades claras.</p>
        </Card>
      )}

      {/* Modal de detalhes */}
      <HoldingSignalDetailsModal
        signal={selectedSignal}
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        onOpenTrade={handleOpenTrade}
        isLoading={loadingSignalId === selectedSignal?.id}
        disabled={false}
      />
    </div>
  );
};
