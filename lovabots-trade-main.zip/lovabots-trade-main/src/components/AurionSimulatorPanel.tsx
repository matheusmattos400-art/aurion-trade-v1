import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, Trash2, History, DollarSign } from "lucide-react";
import type { SimulatedTrade, DailyPerformance } from "@/hooks/useAurionScanner";
import { formatDistanceToNow, format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface AurionSimulatorPanelProps {
  trades: SimulatedTrade[];
  performance: DailyPerformance[];
  onExitTrade: (tradeId: string) => void;
  onClearHistory: () => void;
}

export const AurionSimulatorPanel = ({
  trades,
  performance,
  onExitTrade,
  onClearHistory
}: AurionSimulatorPanelProps) => {
  const closedTrades = trades.filter(t => t.status !== "open").sort((a, b) => (b.exitTime || 0) - (a.exitTime || 0));

  const totalPnl = closedTrades.reduce((sum, t) => sum + (t.pnlPercent || 0), 0);
  const totalPnlUsd = closedTrades.reduce((sum, t) => sum + (t.pnlUsd || 0), 0);
  const winRate = closedTrades.length > 0 
    ? (closedTrades.filter(t => (t.pnlPercent || 0) > 0).length / closedTrades.length) * 100
    : 0;
  const winners = closedTrades.filter(t => (t.pnlPercent || 0) > 0).length;
  const losers = closedTrades.filter(t => (t.pnlPercent || 0) < 0).length;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-primary" />
          <h2 className="text-lg font-bold">Histórico de Operações</h2>
          <Badge variant="outline">{closedTrades.length} trades</Badge>
        </div>
        {closedTrades.length > 0 && (
          <Button variant="ghost" size="sm" onClick={onClearHistory} className="text-muted-foreground hover:text-destructive">
            <Trash2 className="w-4 h-4 mr-1" />
            Limpar
          </Button>
        )}
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <Card className="glass-card p-3 text-center">
          <p className="text-xs text-muted-foreground">Total Trades</p>
          <p className="text-xl font-bold text-foreground">{closedTrades.length}</p>
        </Card>
        <Card className="glass-card p-3 text-center">
          <p className="text-xs text-muted-foreground">Vitórias</p>
          <p className="text-xl font-bold text-profit">{winners}</p>
        </Card>
        <Card className="glass-card p-3 text-center">
          <p className="text-xs text-muted-foreground">Derrotas</p>
          <p className="text-xl font-bold text-loss">{losers}</p>
        </Card>
        <Card className="glass-card p-3 text-center">
          <p className="text-xs text-muted-foreground">Taxa de Acerto</p>
          <p className={`text-xl font-bold ${winRate >= 50 ? 'text-profit' : 'text-loss'}`}>
            {winRate.toFixed(1)}%
          </p>
        </Card>
        <Card className="glass-card p-3 text-center col-span-2 sm:col-span-1">
          <p className="text-xs text-muted-foreground">PnL Total</p>
          <p className={`text-xl font-bold font-mono ${totalPnlUsd >= 0 ? 'text-profit' : 'text-loss'}`}>
            {totalPnlUsd >= 0 ? '+' : ''}${totalPnlUsd.toFixed(2)}
          </p>
        </Card>
      </div>

      {/* Trade History List */}
      {closedTrades.length > 0 ? (
        <Card className="glass-card p-4">
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {closedTrades.map(trade => {
              const isPositive = (trade.pnlPercent || 0) >= 0;
              const investment = trade.investmentAmount || 100;
              const pnlUsd = trade.pnlUsd || ((trade.pnlPercent || 0) / 100) * investment;
              const duration = trade.exitTime && trade.entryTime 
                ? Math.round((trade.exitTime - trade.entryTime) / 1000 / 60) 
                : 0;
              
              return (
                <div 
                  key={trade.id} 
                  className={`flex items-center justify-between p-3 rounded-lg border ${
                    isPositive 
                      ? 'bg-profit/5 border-profit/20' 
                      : 'bg-loss/5 border-loss/20'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      isPositive ? 'bg-profit/20' : 'bg-loss/20'
                    }`}>
                      {isPositive 
                        ? <TrendingUp className="w-5 h-5 text-profit" />
                        : <TrendingDown className="w-5 h-5 text-loss" />
                      }
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-bold">{trade.token.symbol}</p>
                        <Badge variant="outline" className="text-xs">
                          {trade.status === "stopped" ? "Stop Loss" : "Manual"}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                        <span>
                          {trade.exitTime 
                            ? format(new Date(trade.exitTime), "dd/MM HH:mm", { locale: ptBR })
                            : "—"
                          }
                        </span>
                        <span>•</span>
                        <span>{duration}min</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <DollarSign className="w-3 h-3" />
                          {investment.toFixed(0)} investido
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                        <span>Entrada: ${trade.entryPrice.toFixed(8)}</span>
                        <span>→</span>
                        <span>Saída: ${trade.exitPrice?.toFixed(8) || "—"}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className={`font-mono font-bold text-lg ${isPositive ? 'text-profit' : 'text-loss'}`}>
                      {isPositive ? '+' : ''}{(trade.pnlPercent || 0).toFixed(2)}%
                    </p>
                    <p className={`font-mono text-sm ${isPositive ? 'text-profit' : 'text-loss'}`}>
                      {isPositive ? '+' : ''}${pnlUsd.toFixed(2)}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      ) : (
        <Card className="glass-card p-8 text-center">
          <History className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
          <p className="text-muted-foreground">
            Nenhuma operação encerrada ainda.
          </p>
          <p className="text-sm text-muted-foreground mt-1">
            Abra operações nos tokens e encerre para ver o histórico aqui.
          </p>
        </Card>
      )}

      {/* Daily Performance */}
      {performance.length > 0 && (
        <Card className="glass-card p-4">
          <h3 className="text-sm font-bold text-muted-foreground mb-3">
            Performance Diária
          </h3>
          <div className="space-y-2">
            {performance.slice(-7).reverse().map(day => (
              <div 
                key={day.date} 
                className="flex items-center justify-between p-2 bg-muted/20 rounded-lg text-sm"
              >
                <span className="text-muted-foreground">{day.date}</span>
                <div className="flex items-center gap-4">
                  <span className="text-muted-foreground">
                    {day.totalTrades} trades
                  </span>
                  <Badge variant="outline" className={day.winRate >= 50 ? 'text-profit' : 'text-loss'}>
                    {day.winRate.toFixed(0)}% acerto
                  </Badge>
                  <span className={`font-mono font-bold ${day.totalPnlPercent >= 0 ? 'text-profit' : 'text-loss'}`}>
                    {day.totalPnlPercent >= 0 ? '+' : ''}{day.totalPnlPercent.toFixed(2)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};
