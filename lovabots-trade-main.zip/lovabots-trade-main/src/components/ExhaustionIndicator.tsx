import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Gauge, TrendingUp, TrendingDown, AlertTriangle } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ExhaustionIndicatorProps {
  longSymbol: string;
  shortSymbol: string;
  longPnl: number;
  shortPnl: number;
  longClosed: boolean;
  shortClosed: boolean;
}

interface RSIData {
  symbol: string;
  rsi: number;
  status: "overbought" | "oversold" | "neutral";
  direction: "long" | "short";
}

type AnalysisMode = "auto" | "long" | "short";

export const ExhaustionIndicator = ({
  longSymbol,
  shortSymbol,
  longPnl,
  shortPnl,
  longClosed,
  shortClosed,
}: ExhaustionIndicatorProps) => {
  const [rsiData, setRsiData] = useState<RSIData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [analysisMode, setAnalysisMode] = useState<AnalysisMode>("auto");
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Determinar qual posição está perdendo (para modo automático)
  const losingPosition = longPnl < shortPnl && !longClosed 
    ? { symbol: longSymbol, direction: "long" as const, pnl: longPnl }
    : shortPnl < longPnl && !shortClosed
    ? { symbol: shortSymbol, direction: "short" as const, pnl: shortPnl }
    : null;

  // Determinar posição a analisar baseado no modo selecionado
  const getSelectedPosition = () => {
    if (analysisMode === "long" && !longClosed) {
      return { symbol: longSymbol, direction: "long" as const, pnl: longPnl };
    }
    if (analysisMode === "short" && !shortClosed) {
      return { symbol: shortSymbol, direction: "short" as const, pnl: shortPnl };
    }
    return losingPosition;
  };

  const selectedPosition = getSelectedPosition();

  // Calcular RSI com base em dados de klines
  const calculateRSI = (closes: number[], period: number = 14): number => {
    if (closes.length < period + 1) return 50;

    let gains = 0;
    let losses = 0;

    // Calcular médias iniciais
    for (let i = 1; i <= period; i++) {
      const change = closes[i] - closes[i - 1];
      if (change >= 0) {
        gains += change;
      } else {
        losses += Math.abs(change);
      }
    }

    let avgGain = gains / period;
    let avgLoss = losses / period;

    // Calcular RSI suavizado para o resto dos dados
    for (let i = period + 1; i < closes.length; i++) {
      const change = closes[i] - closes[i - 1];
      
      if (change >= 0) {
        avgGain = (avgGain * (period - 1) + change) / period;
        avgLoss = (avgLoss * (period - 1)) / period;
      } else {
        avgGain = (avgGain * (period - 1)) / period;
        avgLoss = (avgLoss * (period - 1) + Math.abs(change)) / period;
      }
    }

    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  };

  const fetchRSI = async (symbol: string, direction: "long" | "short") => {
    try {
      // Buscar klines de 5 minutos (últimas 50 velas = ~4 horas)
      const response = await fetch(
        `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=5m&limit=50`
      );
      
      // Em caso de falha, manter dados anteriores (não piscar)
      if (!response.ok) return;
      
      const data = await response.json();
      
      // Validar dados
      if (!Array.isArray(data) || data.length === 0) return;
      
      const closes = data.map((k: any[]) => parseFloat(k[4]));
      
      // Validar closes
      if (closes.some((c: number) => isNaN(c))) return;
      
      const rsi = calculateRSI(closes, 14);
      
      // Validar RSI
      if (isNaN(rsi)) return;
      
      let status: "overbought" | "oversold" | "neutral" = "neutral";
      if (rsi >= 70) status = "overbought";
      else if (rsi <= 30) status = "oversold";

      setRsiData({
        symbol,
        rsi,
        status,
        direction,
      });
    } catch (error) {
      // Em caso de erro, manter dados anteriores (não piscar)
      console.error("Erro ao calcular RSI:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!selectedPosition || (longClosed && shortClosed)) {
      setRsiData(null);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    fetchRSI(selectedPosition.symbol, selectedPosition.direction);
    
    // Atualizar a cada 30 segundos
    intervalRef.current = setInterval(() => {
      if (selectedPosition) {
        fetchRSI(selectedPosition.symbol, selectedPosition.direction);
      }
    }, 30000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [selectedPosition?.symbol, selectedPosition?.direction, longClosed, shortClosed, analysisMode]);

  // Continuar mostrando RSI mesmo após encerrar posições (não retorna null)

  const getRSIColor = (rsi: number) => {
    if (rsi >= 70) return "text-red-500";
    if (rsi >= 60) return "text-orange-400";
    if (rsi <= 30) return "text-green-500";
    if (rsi <= 40) return "text-emerald-400";
    return "text-muted-foreground";
  };

  const getRSIBgColor = (status: "overbought" | "oversold" | "neutral") => {
    switch (status) {
      case "overbought": return "bg-red-500/10 border-red-500/30";
      case "oversold": return "bg-green-500/10 border-green-500/30";
      default: return "bg-muted/20 border-border/30";
    }
  };

  const getSignalMessage = () => {
    if (!rsiData) return null;

    const { status, direction, rsi } = rsiData;

    // Para LONG perdendo: sobrevendido = bom (pode subir), sobrecomprado = ruim
    // Para SHORT perdendo: sobrecomprado = bom (pode cair), sobrevendido = ruim
    if (direction === "long") {
      if (status === "oversold") {
        return {
          message: "RSI indica exaustão vendedora - preço pode recuperar",
          icon: TrendingUp,
          color: "text-green-500",
          bgColor: "bg-green-500/10",
        };
      } else if (status === "overbought") {
        return {
          message: "RSI indica sobrecompra - cautela ao manter posição",
          icon: AlertTriangle,
          color: "text-yellow-500",
          bgColor: "bg-yellow-500/10",
        };
      }
    } else {
      if (status === "overbought") {
        return {
          message: "RSI indica exaustão compradora - preço pode recuar",
          icon: TrendingDown,
          color: "text-green-500",
          bgColor: "bg-green-500/10",
        };
      } else if (status === "oversold") {
        return {
          message: "RSI indica sobrevenda - cautela ao manter posição",
          icon: AlertTriangle,
          color: "text-yellow-500",
          bgColor: "bg-yellow-500/10",
        };
      }
    }

    return {
      message: "Mercado em zona neutra - sem sinal de exaustão",
      icon: Gauge,
      color: "text-muted-foreground",
      bgColor: "bg-muted/10",
    };
  };

  const signal = getSignalMessage();

  return (
    <Card className="relative overflow-hidden bg-card/40 border-border/30">
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary/50 via-primary to-primary/50" />
      
      <div className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <Gauge className="h-5 w-5 text-primary" />
          <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
            Indicador de Exaustão (RSI)
          </span>
          <div className="ml-auto">
            <Select value={analysisMode} onValueChange={(value: AnalysisMode) => setAnalysisMode(value)}>
              <SelectTrigger className="h-8 w-[140px] text-xs">
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto">
                  <span className="flex items-center gap-1.5">
                    Automático
                  </span>
                </SelectItem>
                <SelectItem value="long" disabled={longClosed}>
                  <span className="flex items-center gap-1.5">
                    <TrendingUp className="h-3 w-3 text-profit" />
                    {longSymbol}
                  </span>
                </SelectItem>
                <SelectItem value="short" disabled={shortClosed}>
                  <span className="flex items-center gap-1.5">
                    <TrendingDown className="h-3 w-3 text-loss" />
                    {shortSymbol}
                  </span>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-6">
            <div className="animate-pulse flex items-center gap-2 text-muted-foreground">
              <Gauge className="h-4 w-4 animate-spin" />
              <span className="text-sm">Calculando RSI...</span>
            </div>
          </div>
        ) : rsiData ? (
          <div className="space-y-4">
            {/* RSI Value Display */}
            <div className={`p-4 rounded-lg border ${getRSIBgColor(rsiData.status)}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex flex-col">
                    <span className="text-xs text-muted-foreground">
                      {rsiData.direction === "long" ? "LONG" : "SHORT"} - {rsiData.symbol}
                    </span>
                    <span className={`text-3xl font-bold font-mono ${getRSIColor(rsiData.rsi)}`}>
                      {rsiData.rsi.toFixed(1)}
                    </span>
                  </div>
                </div>
                
                <div className="text-right">
                  <Badge 
                    variant="outline" 
                    className={`${
                      rsiData.status === "overbought" 
                        ? "border-red-500/50 text-red-500 bg-red-500/10" 
                        : rsiData.status === "oversold"
                        ? "border-green-500/50 text-green-500 bg-green-500/10"
                        : "border-border text-muted-foreground"
                    }`}
                  >
                    {rsiData.status === "overbought" 
                      ? "Sobrecomprado" 
                      : rsiData.status === "oversold" 
                      ? "Sobrevendido" 
                      : "Neutro"}
                  </Badge>
                </div>
              </div>

              {/* RSI Bar */}
              <div className="mt-4">
                <div className="relative h-3 rounded-full bg-gradient-to-r from-green-500 via-muted to-red-500 overflow-hidden">
                  <div 
                    className="absolute top-0 h-full w-1 bg-foreground shadow-lg transition-all duration-500"
                    style={{ left: `calc(${rsiData.rsi}% - 2px)` }}
                  />
                </div>
                <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                  <span>0 (Sobrevendido)</span>
                  <span>50</span>
                  <span>100 (Sobrecomprado)</span>
                </div>
              </div>
            </div>

            {/* Signal Message */}
            {signal && (
              <div className={`flex items-center gap-3 p-3 rounded-lg ${signal.bgColor} border border-border/20`}>
                <signal.icon className={`h-5 w-5 ${signal.color} flex-shrink-0`} />
                <span className={`text-sm ${signal.color}`}>{signal.message}</span>
              </div>
            )}

            {/* Legend */}
            <div className="flex items-center justify-center gap-6 text-xs text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <div className="h-2 w-2 rounded-full bg-green-500" />
                <span>≤30 Sobrevendido</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="h-2 w-2 rounded-full bg-muted" />
                <span>30-70 Neutro</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="h-2 w-2 rounded-full bg-red-500" />
                <span>≥70 Sobrecomprado</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-4 text-muted-foreground text-sm">
            Aguardando dados da posição perdedora...
          </div>
        )}
      </div>
    </Card>
  );
};
