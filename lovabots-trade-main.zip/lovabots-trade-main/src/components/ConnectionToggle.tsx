import { useBinanceWebSocket } from "@/hooks/useBinanceWebSocket";

export const ConnectionToggle = () => {
  const { isConnected } = useBinanceWebSocket(true);

  return (
    <div className="flex items-center gap-2">
      <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
      <span className="text-xs font-medium">
        {isConnected ? "Ativo" : "Desconectado"}
      </span>
    </div>
  );
};
