import { useAdvancedPairAnalysis } from "@/hooks/useAdvancedPairAnalysis";
import { Card } from "./ui/card";
import { TrendingUp, TrendingDown, Pause } from "lucide-react";
import { useState, useEffect } from "react";

interface PairSignalProps {
  symbol1: string;
  symbol2: string;
}

export const PairSignal = ({ symbol1, symbol2 }: PairSignalProps) => {
  const { analysis, isLoading, error } = useAdvancedPairAnalysis(symbol1, symbol2);

  // Manter sempre a última análise válida em tela para evitar piscar
  const [displayAnalysis, setDisplayAnalysis] = useState<typeof analysis>(null);

  useEffect(() => {
    if (analysis && !error) {
      setDisplayAnalysis(analysis);
    }
  }, [analysis, error]);

  if (!displayAnalysis || error || !symbol1 || !symbol2 || symbol1 === symbol2) {
    return null;
  }

  const pair = `${symbol1.replace('USDT', '')}/${symbol2.replace('USDT', '')}`;

  return (
    <Card className={`p-3 animate-fade-in transition-all ${
      displayAnalysis.isValid 
        ? 'bg-profit/10 border-profit/40 shadow-lg' 
        : 'bg-muted/30 border-border/50'
    }`}>
      <div className="space-y-2">
        {/* Header com título */}
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
            💡 Sinal de Momentum
          </span>
          {displayAnalysis.isValid ? (
            displayAnalysis.signal === "long_first" ? (
              <TrendingUp className="w-4 h-4 text-profit animate-pulse" />
            ) : (
              <TrendingDown className="w-4 h-4 text-profit animate-pulse" />
            )
          ) : (
            <Pause className="w-4 h-4 text-muted-foreground" />
          )}
        </div>

        {/* Mensagem principal */}
        <div className="flex items-start gap-2">
          <div className="flex-1">
            <p className={`text-sm font-bold leading-tight ${
              displayAnalysis.isValid ? 'text-profit' : 'text-muted-foreground'
            }`}>
              {displayAnalysis.message}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Par: {pair}
            </p>
          </div>
        </div>

        {/* Detalhes de Momentum */}
        <div className="pt-2 border-t border-border/30 space-y-2">
          {/* Indicação de Long/Short quando válido */}
          {displayAnalysis.isValid && (
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1">
                <span className="text-profit font-bold">LONG:</span>
                <span className="text-foreground font-medium">{displayAnalysis.longSymbol}</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-loss font-bold">SHORT:</span>
                <span className="text-foreground font-medium">{displayAnalysis.shortSymbol}</span>
              </div>
            </div>
          )}

          {/* Métricas de Momentum */}
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div>
              <span className="text-muted-foreground">Momentum:</span>
              <span className={`ml-1 font-bold ${
                displayAnalysis.currentMomentum > 0 ? 'text-profit' : 'text-loss'
              }`}>
                {displayAnalysis.currentMomentum > 0 ? '+' : ''}{displayAnalysis.currentMomentum.toFixed(3)}%
              </span>
            </div>
            <div>
              <span className="text-muted-foreground">Média Alta:</span>
              <span className="ml-1 font-medium text-profit">+{displayAnalysis.avgBullishMomentum.toFixed(3)}%</span>
            </div>
            <div>
              <span className="text-muted-foreground">Média Baixa:</span>
              <span className="ml-1 font-medium text-loss">{displayAnalysis.avgBearishMomentum.toFixed(3)}%</span>
            </div>
          </div>

          {/* Distorção */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-muted-foreground">Distorção:</span>
            <span className={`font-bold ${
              Math.abs(displayAnalysis.momentumDistortion) > 0.1 
                ? displayAnalysis.momentumDistortion > 0 ? 'text-profit' : 'text-loss'
                : 'text-muted-foreground'
            }`}>
              {displayAnalysis.momentumDistortion > 0 ? '+' : ''}{displayAnalysis.momentumDistortion.toFixed(4)}%
            </span>
          </div>
        </div>

        {/* Correlação */}
        {!displayAnalysis.correlationValid && (
          <div className="text-xs text-loss">
            ⚠️ Correlação baixa - par não recomendado
          </div>
        )}
      </div>
    </Card>
  );
};
