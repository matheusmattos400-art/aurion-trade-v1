import { useAdvancedPairAnalysis } from "@/hooks/useAdvancedPairAnalysis";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle2 } from "lucide-react";

interface AdvancedPairAnalysisProps {
  symbol1: string;
  symbol2: string;
}

export const AdvancedPairAnalysis = ({ symbol1, symbol2 }: AdvancedPairAnalysisProps) => {
  const { analysis, isLoading, error } = useAdvancedPairAnalysis(symbol1, symbol2);

  if (!symbol1 || !symbol2) {
    return (
      <Card className="p-4 bg-card/50 border-border/50">
        <p className="text-xs text-muted-foreground text-center">
          Selecione os pares para análise de momentum
        </p>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="p-4 bg-card/50 border-border/50">
        <p className="text-xs text-muted-foreground text-center">
          Analisando momentum {symbol1.replace('USDT', '')}/{symbol2.replace('USDT', '')}...
        </p>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-4 bg-card/50 border-border/50">
        <p className="text-xs text-destructive text-center">{error}</p>
      </Card>
    );
  }

  if (!analysis) return null;

  const pair = `${symbol1.replace('USDT', '')}/${symbol2.replace('USDT', '')}`;

  return (
    <Card className="p-4 bg-card/50 border-border/50">
      <div className="space-y-3">
        {/* Título */}
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-foreground">
            Análise Momentum: {pair}
          </h3>
          {analysis.isValid ? (
            <CheckCircle2 className="w-4 h-4 text-profit" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-muted-foreground" />
          )}
        </div>

        {/* Primeiro Filtro: Correlação */}
        <div className="p-3 bg-primary/5 rounded-lg border border-primary/20">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold">🔍 Filtro de Correlação</span>
            <Badge variant={analysis.correlationValid ? "default" : "destructive"}>
              {analysis.correlationValid ? '✓ PASSOU' : '✗ REJEITADO'}
            </Badge>
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="flex flex-col">
              <span className="text-muted-foreground">1h:</span>
              <span className={`font-medium ${
                analysis.correlations.period1h >= 0.90 
                  ? 'text-green-500' 
                  : analysis.correlations.period1h >= 0.80 
                    ? 'text-yellow-500' 
                    : 'text-red-500'
              }`}>
                {analysis.correlations.period1h.toFixed(2)}
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-muted-foreground">10d:</span>
              <span className={`font-medium ${
                analysis.correlations.period10d >= 0.90 
                  ? 'text-green-500' 
                  : analysis.correlations.period10d >= 0.80 
                    ? 'text-yellow-500' 
                    : 'text-red-500'
              }`}>
                {analysis.correlations.period10d.toFixed(2)}
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-muted-foreground">30d:</span>
              <span className={`font-medium ${
                analysis.correlations.period30d >= 0.90 
                  ? 'text-green-500' 
                  : analysis.correlations.period30d >= 0.80 
                    ? 'text-yellow-500' 
                    : 'text-red-500'
              }`}>
                {analysis.correlations.period30d.toFixed(2)}
              </span>
            </div>
          </div>
          <p className="text-[10px] text-muted-foreground mt-2">
            Necessário: média de correlação ≥ 0.70
          </p>
        </div>

        {/* Resultado Final */}
        <div className={`p-3 rounded-lg border ${
          analysis.isValid 
            ? 'bg-profit/10 border-profit/30' 
            : 'bg-muted/50 border-border/50'
        }`}>
          <div className="flex items-center gap-2 mb-2">
            {analysis.signal === "long_first" && (
              <TrendingUp className="w-4 h-4 text-profit" />
            )}
            {analysis.signal === "short_first" && (
              <TrendingDown className="w-4 h-4 text-profit" />
            )}
            {analysis.signal === "none" && (
              <AlertTriangle className="w-4 h-4 text-muted-foreground" />
            )}
            <span className={`text-sm font-semibold ${
              analysis.isValid ? 'text-profit' : 'text-muted-foreground'
            }`}>
              {analysis.message}
            </span>
          </div>
          
          {/* Indicação de posição quando válido */}
          {analysis.isValid && (
            <div className="flex items-center gap-4 mt-2 text-sm">
              <div className="flex items-center gap-1 bg-profit/20 px-2 py-1 rounded">
                <span className="text-profit font-bold">LONG:</span>
                <span className="text-foreground font-medium">{analysis.longSymbol}</span>
              </div>
              <div className="flex items-center gap-1 bg-loss/20 px-2 py-1 rounded">
                <span className="text-loss font-bold">SHORT:</span>
                <span className="text-foreground font-medium">{analysis.shortSymbol}</span>
              </div>
            </div>
          )}
        </div>

        {/* Detalhes do Momentum */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="space-y-1">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Momentum Atual:</span>
              <span className={`font-bold ${
                analysis.currentMomentum > 0 ? 'text-profit' : 'text-loss'
              }`}>
                {analysis.currentMomentum > 0 ? '+' : ''}{analysis.currentMomentum.toFixed(4)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Média Alta:</span>
              <span className="text-profit font-medium">+{analysis.avgBullishMomentum.toFixed(4)}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Média Baixa:</span>
              <span className="text-loss font-medium">{analysis.avgBearishMomentum.toFixed(4)}%</span>
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Distorção:</span>
              <span className={`font-bold ${
                Math.abs(analysis.momentumDistortion) > 0.05
                  ? analysis.momentumDistortion > 0 ? 'text-profit' : 'text-loss'
                  : 'text-muted-foreground'
              }`}>
                {analysis.momentumDistortion > 0 ? '+' : ''}{analysis.momentumDistortion.toFixed(4)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Liquidez Ratio:</span>
              <span className="text-foreground font-medium">{analysis.liquidityRatio.toFixed(2)}x</span>
            </div>
          </div>
        </div>

        {/* Interpretação */}
        <div className="pt-2 border-t border-border/50">
          <p className="text-[10px] text-muted-foreground">
            {analysis.isValid 
              ? `Sinal ativo: ${analysis.longSymbol} com momentum favorável para LONG, ${analysis.shortSymbol} para SHORT`
              : "Momentum entre as médias - aguardando extremo para entrada"}
          </p>
        </div>
      </div>
    </Card>
  );
};
