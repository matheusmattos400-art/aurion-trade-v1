import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import {
  TrendingUp,
  TrendingDown,
  Zap,
  RotateCcw,
  ArrowRight,
  Info,
  Clock,
  Activity,
  Square,
  DollarSign,
  Edit2,
  Check,
  ArrowLeftRight,
} from "lucide-react";
import { TradingSignal } from "@/utils/pairScanner";
import { useMemo, useState } from "react";

interface SignalCardProps {
  signal: TradingSignal;
  onOpenTrade: (signal: TradingSignal) => void;
  onShowDetails: (signal: TradingSignal) => void;
  isLoading?: boolean;
  isPending?: boolean;
  isActive?: boolean;
  pnl?: number;
  profitTarget?: number;
  onCloseTrade?: () => void;
  liveMomentum?: number;
  autoCloseEnabled?: boolean;
  onAutoCloseChange?: (enabled: boolean) => void;
  onProfitTargetChange?: (target: number) => void;
  operationId?: string;
  onSwapSymbols?: (signal: TradingSignal) => void;
}

const strategyConfig = {
  micro_distortion: {
    label: "Micro Distorção",
    color: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    icon: Zap,
  },
  partial_reversal: {
    label: "Reversão",
    color: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    icon: RotateCcw,
  },
  trend_follow: {
    label: "Trend Follow",
    color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
    icon: TrendingUp,
  },
} as const;

export const SignalCard = ({
  signal,
  onOpenTrade,
  onShowDetails,
  isLoading,
  isPending,
  isActive,
  pnl,
  profitTarget,
  onCloseTrade,
  liveMomentum,
  autoCloseEnabled,
  onAutoCloseChange,
  onProfitTargetChange,
  operationId,
  onSwapSymbols,
}: SignalCardProps) => {
  const strategy = strategyConfig[signal.strategy];
  const StrategyIcon = strategy.icon;
  const pnlValue = typeof pnl === "number" ? pnl : null;
  
  const [isEditingTarget, setIsEditingTarget] = useState(false);
  const [editedTarget, setEditedTarget] = useState(profitTarget?.toString() || "");
  const [isTogglingAutoClose, setIsTogglingAutoClose] = useState(false);
  
  // Use live momentum if available (for active operations), otherwise use signal's static momentum
  const displayMomentum = typeof liveMomentum === "number" ? liveMomentum : signal.currentMomentum;
  const liquidityLabel = useMemo(() => {
    const ratio = signal.liquidityRatio;
    if (ratio >= 0.8) return "Alta";
    if (ratio >= 0.5) return "Média";
    return "Baixa";
  }, [signal.liquidityRatio]);

  const handleToggleAutoClose = async () => {
    if (!onAutoCloseChange || isTogglingAutoClose) return;
    setIsTogglingAutoClose(true);
    await onAutoCloseChange(!autoCloseEnabled);
    setIsTogglingAutoClose(false);
  };

  const handleSaveTarget = () => {
    const newTarget = parseFloat(editedTarget);
    if (!isNaN(newTarget) && newTarget > 0 && onProfitTargetChange) {
      onProfitTargetChange(newTarget);
    }
    setIsEditingTarget(false);
  };

  const handleTargetKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSaveTarget();
    } else if (e.key === 'Escape') {
      setEditedTarget(profitTarget?.toString() || "");
      setIsEditingTarget(false);
    }
  };

  return (
    <Card
      className={`group relative overflow-hidden bg-gradient-to-br from-card/80 to-card/40 backdrop-blur-sm border-border/50 transition-all duration-300 hover:shadow-lg ${
        isPending
          ? "opacity-80 hover:border-yellow-500/50 hover:shadow-yellow-500/5"
          : "hover:border-primary/50 hover:shadow-primary/5"
      } ${
        isActive
          ? "border-emerald-500/70 shadow-emerald-500/20 ring-2 ring-emerald-500/40"
          : ""
      }`}
    >
      {/* Glow effect on hover */}
      <div
        className={`absolute inset-0 bg-gradient-to-br ${
          isPending ? "from-yellow-500/5" : "from-primary/5"
        } to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300`}
      />

      {/* Pending indicator */}
      {isPending && signal.pendingReason && (
        <div className="absolute top-0 left-0 right-0 bg-yellow-500/20 border-b border-yellow-500/30 px-3 py-1.5">
          <p className="text-xs text-yellow-400 text-center truncate">
            {signal.pendingReason}
          </p>
        </div>
      )}

      <div className={`relative p-4 ${isPending && signal.pendingReason ? "pt-10" : ""}`}>
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge
              variant="outline"
              className={`${strategy.color} px-2 py-0.5 text-xs`}
            >
              <StrategyIcon className="h-3 w-3 mr-1" />
              {strategy.label}
            </Badge>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" />
              <span>{signal.momentumAge}min</span>
            </div>
            {isActive && (
              <Badge
                variant="outline"
                className="text-[10px] bg-emerald-500/20 text-emerald-400 border-emerald-500/40 uppercase tracking-wide"
              >
                Operação ativa
              </Badge>
            )}
          </div>
          <Badge
            variant="outline"
            className={`text-xs ${
              Math.abs(signal.zScore) >= 2
                ? "bg-red-500/20 text-red-400 border-red-500/30"
                : "bg-muted/50"
            }`}
          >
            Z: {signal.zScore.toFixed(2)}
          </Badge>
        </div>

        {/* Par */}
        <div className="flex items-center justify-center gap-2 sm:gap-3 mb-3 py-2 rounded-lg bg-background/50 relative">
          <div className="flex flex-col items-center">
            <span className="text-xs text-muted-foreground mb-0.5">
              SHORT (Venda)
            </span>
            <div className="flex items-center gap-1">
              <TrendingDown className="h-3.5 w-3.5 text-red-400" />
              <span className="text-base sm:text-lg font-bold text-red-400">
                {signal.shortSymbol.replace("USDT", "")}
              </span>
            </div>
          </div>

          {/* Botão de Inverter - só aparece quando não está em operação ativa */}
          {!isActive && onSwapSymbols ? (
            <button
              onClick={() => onSwapSymbols(signal)}
              className="p-1.5 rounded-full bg-primary/10 hover:bg-primary/20 border border-primary/30 transition-all hover:scale-110"
              title="Inverter Long/Short"
            >
              <ArrowLeftRight className="h-4 w-4 text-primary" />
            </button>
          ) : (
            <ArrowRight className="h-4 w-4 text-muted-foreground" />
          )}

          <div className="flex flex-col items-center">
            <span className="text-xs text-muted-foreground mb-0.5">
              LONG (Compra)
            </span>
            <div className="flex items-center gap-1">
              <TrendingUp className="h-3.5 w-3.5 text-emerald-400" />
              <span className="text-base sm:text-lg font-bold text-emerald-400">
                {signal.longSymbol.replace("USDT", "")}
              </span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2 mb-3 text-xs">
          <div className="flex items-center gap-1.5 p-2 rounded bg-muted/30">
            <Activity className="h-3 w-3 text-primary flex-shrink-0" />
            <span className="text-muted-foreground">Corr:</span>
            <span className="font-medium text-foreground">
              {(signal.correlation * 100).toFixed(0)}%
            </span>
          </div>
          <div className="flex items-center gap-1.5 p-2 rounded bg-muted/30">
            <TrendingUp className="h-3 w-3 text-primary flex-shrink-0" />
            <span className="text-muted-foreground">Mom:</span>
            <span
              className={`font-medium ${
                displayMomentum >= 0
                  ? "text-emerald-400"
                  : "text-red-400"
              } ${isActive ? "animate-pulse" : ""}`}
            >
              {displayMomentum >= 0 ? "+" : ""}
              {displayMomentum.toFixed(3)}%
              {isActive && <span className="ml-1 text-[9px] text-muted-foreground">(ao vivo)</span>}
            </span>
          </div>
          <div className="flex items-center gap-1.5 p-2 rounded bg-muted/30">
            <TrendingUp className="h-3 w-3 text-primary flex-shrink-0 rotate-90" />
            <span className="text-muted-foreground">Liq.:</span>
            <span className="font-medium text-foreground">
              {liquidityLabel} ({(signal.liquidityRatio * 100).toFixed(0)}%)
            </span>
          </div>
        </div>

        {/* PnL when active */}
        {isActive && pnlValue !== null && (
          <div className="mb-3 text-center">
            <p className="text-[11px] text-muted-foreground uppercase tracking-wider mb-0.5">
              PnL da operação
            </p>
            <div className="flex items-baseline justify-center gap-1.5">
              <DollarSign
                className={`h-3 w-3 ${
                  pnlValue >= 0 ? "text-emerald-400" : "text-red-400"
                }`}
              />
              <span
                className={`text-lg font-bold font-mono ${
                  pnlValue >= 0 ? "text-emerald-400" : "text-red-400"
                }`}
              >
                {pnlValue.toFixed(2)}
              </span>
              {typeof profitTarget === "number" && (
                <>
                  <span className="text-[11px] text-muted-foreground">/ Meta</span>
                  {isEditingTarget ? (
                    <div className="flex items-center gap-1 ml-1">
                      <Input
                        type="number"
                        value={editedTarget}
                        onChange={(e) => setEditedTarget(e.target.value)}
                        onKeyDown={handleTargetKeyDown}
                        onBlur={handleSaveTarget}
                        className="w-16 h-6 text-xs font-mono px-1"
                        autoFocus
                      />
                      <button
                        onClick={handleSaveTarget}
                        className="p-1 rounded bg-primary/10 hover:bg-primary/20"
                      >
                        <Check className="w-3 h-3 text-primary" />
                      </button>
                    </div>
                  ) : (
                    <span 
                      onClick={() => {
                        setEditedTarget(profitTarget.toString());
                        setIsEditingTarget(true);
                      }}
                      className="text-[11px] text-primary font-mono cursor-pointer hover:underline flex items-center gap-0.5"
                    >
                      ${profitTarget.toFixed(2)}
                      <Edit2 className="w-2.5 h-2.5 text-muted-foreground" />
                    </span>
                  )}
                </>
              )}
            </div>
          </div>
        )}

        {/* Auto-close toggle when active */}
        {isActive && typeof autoCloseEnabled === "boolean" && onAutoCloseChange && (
          <div className="mb-3 flex items-center justify-center gap-3 p-2 rounded bg-muted/30">
            <span className="text-xs text-muted-foreground">Saída automática:</span>
            <Switch
              checked={autoCloseEnabled}
              onCheckedChange={handleToggleAutoClose}
              disabled={isTogglingAutoClose}
              className="data-[state=checked]:bg-profit scale-90"
            />
            <span className={`text-xs font-medium ${autoCloseEnabled ? "text-profit" : "text-muted-foreground"}`}>
              {autoCloseEnabled ? "Ativada" : "Desativada"}
            </span>
          </div>
        )}

        {/* Message */}
        <p className="text-xs text-muted-foreground mb-3 text-center line-clamp-1">
          {signal.message}
        </p>

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1 h-9 text-xs sm:text-sm"
            onClick={() => onShowDetails(signal)}
          >
            <Info className="h-3.5 w-3.5 mr-1.5" />
            Detalhes
          </Button>
          {!isPending ? (
            isActive ? (
              <Button
                size="sm"
                variant="destructive"
                className="flex-1 h-9 text-xs sm:text-sm bg-red-500/80 hover:bg-red-500 text-destructive-foreground"
                onClick={onCloseTrade}
                disabled={!onCloseTrade}
              >
                <Square className="h-3.5 w-3.5 mr-1.5" />
                Encerrar
              </Button>
            ) : (
              <Button
                size="sm"
                className="flex-1 h-9 text-xs sm:text-sm bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
                onClick={() => onOpenTrade(signal)}
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                ) : (
                  <>
                    <Zap className="h-3.5 w-3.5 mr-1.5" />
                    Entrar
                  </>
                )}
              </Button>
            )
          ) : (
            <Button
              size="sm"
              variant="secondary"
              className="flex-1 h-9 text-xs sm:text-sm opacity-70"
              disabled
            >
              <Clock className="h-3.5 w-3.5 mr-1.5" />
              Aguardando
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
};
