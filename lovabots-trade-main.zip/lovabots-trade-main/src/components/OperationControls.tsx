import { useState, useEffect, useMemo, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Play, Square, Target, ArrowUpDown, Zap, Pause } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useBinancePrices, type CryptoPrice } from "@/hooks/useBinancePrices";
import { useCorrelation } from "@/hooks/useCorrelation";
import { getProfitTarget } from "@/utils/profitTarget";
import { z } from "zod";
import aurionLogo from "@/assets/aurion-triangle-logo.png";
import { useTradingMode } from "@/contexts/TradingModeContext";
import { useIsMobile } from "@/hooks/use-mobile";
import { PairSignal } from "./PairSignal";

const CRYPTO_PAIRS = [
  "BNBUSDT", "SOLUSDT", "ADAUSDT",
  "DOGEUSDT", "XRPUSDT", "DOTUSDT", "MATICUSDT", "AVAXUSDT"
] as const;

const B3_PAIRS = [
  "PETR4", "VALE3", "ITUB4", "BBDC4", "ABEV3", "WEGE3",
  "BBAS3", "MGLU3", "RENT3", "ELET3"
] as const;

// Validation schema for crypto trading parameters
const CryptoTradingSchema = z.object({
  longPair: z.enum(CRYPTO_PAIRS, { 
    errorMap: () => ({ message: "Par de criptomoeda inválido" }) 
  }),
  shortPair: z.enum(CRYPTO_PAIRS, { 
    errorMap: () => ({ message: "Par de criptomoeda inválido" }) 
  }),
  leverageLong: z.number()
    .int({ message: "Alavancagem deve ser um número inteiro" })
    .min(1, { message: "Alavancagem mínima é 1x" })
    .max(125, { message: "Alavancagem máxima é 125x" }),
  leverageShort: z.number()
    .int({ message: "Alavancagem deve ser um número inteiro" })
    .min(1, { message: "Alavancagem mínima é 1x" })
    .max(125, { message: "Alavancagem máxima é 125x" }),
  amount: z.number()
    .positive({ message: "Valor deve ser positivo" })
    .min(10, { message: "Valor mínimo é $10" })
    .max(100000, { message: "Valor máximo é $100,000" }),
  profitTarget: z.number()
    .int({ message: "Meta deve ser um número inteiro" })
    .min(1, { message: "Meta mínima é 1%" })
    .max(100, { message: "Meta máxima é 100%" })
}).refine(data => data.longPair !== data.shortPair, {
  message: "Pares long e short devem ser diferentes",
  path: ["shortPair"]
});

// Validation schema for B3 trading parameters
const B3TradingSchema = z.object({
  longPair: z.enum(B3_PAIRS, { 
    errorMap: () => ({ message: "Par de ação inválido" }) 
  }),
  shortPair: z.enum(B3_PAIRS, { 
    errorMap: () => ({ message: "Par de ação inválido" }) 
  }),
  leverageLong: z.number()
    .int({ message: "Alavancagem deve ser um número inteiro" })
    .min(1, { message: "Alavancagem mínima é 1x" })
    .max(125, { message: "Alavancagem máxima é 125x" }),
  leverageShort: z.number()
    .int({ message: "Alavancagem deve ser um número inteiro" })
    .min(1, { message: "Alavancagem mínima é 1x" })
    .max(125, { message: "Alavancagem máxima é 125x" }),
  amount: z.number()
    .positive({ message: "Valor deve ser positivo" })
    .min(10, { message: "Valor mínimo é R$10" })
    .max(100000, { message: "Valor máximo é R$100,000" }),
  profitTarget: z.number()
    .int({ message: "Meta deve ser um número inteiro" })
    .min(1, { message: "Meta mínima é 1%" })
    .max(100, { message: "Meta máxima é 100%" })
}).refine(data => data.longPair !== data.shortPair, {
  message: "Pares long e short devem ser diferentes",
  path: ["shortPair"]
});

interface OperationControlsProps {
  onStatusChange: (status: "idle" | "running" | "profit" | "closed") => void;
  onPnlChange: (pnl: number) => void;
  currentPnl?: number;
  autoStopAtProfit?: boolean;
  onOperationStart: (data: {
    id?: string;
    longSymbol: string;
    shortSymbol: string;
    leverageLong: number;
    leverageShort: number;
    amount: number;
    entryPriceLong: number;
    entryPriceShort: number;
    startTime: Date;
    profitTarget: number;
    autoCloseEnabled: boolean;
    isTest?: boolean;
    entryMomentum?: number; // Momentum congelado no momento da entrada
  }) => void;
  onOperationStop: () => void;
  onPairChange?: (longPair: string, shortPair: string) => void;
  userCredits: number;
  onNavigateToCredits?: () => void;
}

export const OperationControls = ({ 
  onStatusChange, 
  onPnlChange,
  currentPnl = 0,
  autoStopAtProfit = true,
  onOperationStart,
  onOperationStop,
  onPairChange,
  userCredits,
  onNavigateToCredits
}: OperationControlsProps) => {
  const { isB3Mode } = useTradingMode();
  const isMobile = useIsMobile();
  
  // Estados separados para Cripto (pré-preenchidos no mobile)
  const [cryptoLongPair, setCryptoLongPair] = useState("");
  const [cryptoShortPair, setCryptoShortPair] = useState("");
  const [cryptoLeverageLong, setCryptoLeverageLong] = useState(isMobile ? "50" : "10");
  const [cryptoLeverageShort, setCryptoLeverageShort] = useState(isMobile ? "50" : "10");
  const [cryptoAmount, setCryptoAmount] = useState("100");
  
  // Estados separados para B3 (pré-preenchidos no mobile)
  const [b3LongPair, setB3LongPair] = useState("");
  const [b3ShortPair, setB3ShortPair] = useState("");
  const [b3LeverageLong, setB3LeverageLong] = useState(isMobile ? "50" : "");
  const [b3LeverageShort, setB3LeverageShort] = useState(isMobile ? "50" : "");
  const [b3Amount, setB3Amount] = useState(isMobile ? "100" : "");
  
  // Estados compartilhados
  const [profitTarget, setProfitTarget] = useState(10);
  const [autoCloseEnabled, setAutoCloseEnabled] = useState(false);
  const [isOperating, setIsOperating] = useState(false);
  const [showTargetSection, setShowTargetSection] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const [hedgeRatio, setHedgeRatio] = useState<number | null>(null);
  const [isCalculatingHedge, setIsCalculatingHedge] = useState(false);
  const [operationData, setOperationData] = useState<{
    id: string;
    longPair: string;
    shortPair: string;
    leverageLong: number;
    leverageShort: number;
    amount: number;
    startTime: Date;
    profitTarget: number;
    autoCloseEnabled: boolean;
  } | null>(null);
  
  // Cache de preços para evitar piscar na UI
  const [lastLongPrice, setLastLongPrice] = useState<CryptoPrice | null>(null);
  const [lastShortPrice, setLastShortPrice] = useState<CryptoPrice | null>(null);
  
  // Estados para modo automático (pré-preenchidos no mobile)
  const [showAutoModeDialog, setShowAutoModeDialog] = useState(false);
  const [autoModeEnabled, setAutoModeEnabled] = useState(false);
  const [autoModePaused, setAutoModePaused] = useState(false);
  const [autoModeTarget, setAutoModeTarget] = useState<5 | 10 | 15>(5);
  const [autoModeOperationsCompleted, setAutoModeOperationsCompleted] = useState(0);
  const [isAnalyzingPairs, setIsAnalyzingPairs] = useState(false);
  const [autoModeIsTest, setAutoModeIsTest] = useState(true);
  const [autoModeProfitTarget, setAutoModeProfitTarget] = useState(10);
  const [autoModeLeverageLong, setAutoModeLeverageLong] = useState(isMobile ? 50 : 10);
  const [autoModeLeverageShort, setAutoModeLeverageShort] = useState(isMobile ? 50 : 10);
  const [autoModeAmount, setAutoModeAmount] = useState(100);
  const [operationStartTime, setOperationStartTime] = useState<Date | null>(null);
  
  const { toast } = useToast();
  
  // Selecionar estados baseado no modo atual
  const longPair = isB3Mode ? b3LongPair : cryptoLongPair;
  const shortPair = isB3Mode ? b3ShortPair : cryptoShortPair;
  const leverageLong = isB3Mode ? b3LeverageLong : cryptoLeverageLong;
  const leverageShort = isB3Mode ? b3LeverageShort : cryptoLeverageShort;
  const amount = isB3Mode ? b3Amount : cryptoAmount;
  
  const setLongPair = (value: string) => {
    if (isB3Mode) setB3LongPair(value);
    else setCryptoLongPair(value);
  };
  
  const setShortPair = (value: string) => {
    if (isB3Mode) setB3ShortPair(value);
    else setCryptoShortPair(value);
  };
  
  const setAmount = (value: string) => {
    if (isB3Mode) setB3Amount(value);
    else setCryptoAmount(value);
  };
  
  // Só buscar preços se os pares estiverem definidos
  const shouldFetchPrices = longPair && shortPair;
  const { prices } = useBinancePrices(shouldFetchPrices ? [longPair, shortPair] : []);
  const { correlations, isLoading: isLoadingCorrelations } = useCorrelation(longPair || "");
  
  // Buscar dados de preço para moedas selecionadas
  const longPrice = useMemo(() => prices.find(p => p.symbol === longPair), [prices, longPair]);
  const shortPrice = useMemo(() => prices.find(p => p.symbol === shortPair), [prices, shortPair]);

  // Atualizar cache quando novos preços chegarem
  useEffect(() => {
    if (longPrice) setLastLongPrice(longPrice);
  }, [longPrice]);

  useEffect(() => {
    if (shortPrice) setLastShortPrice(shortPrice);
  }, [shortPrice]);

  // Função para encontrar o melhor par automaticamente
  const findBestPairAutomatically = async () => {
    // REGRA: Apenas pares já filtrados (sem BTCUSDT e ETHUSDT)
    const allPairs = isB3Mode 
      ? B3_PAIRS 
      : CRYPTO_PAIRS;
    
    try {
      console.log("🤖 Robô buscando oportunidades entre:", allPairs.join(", "));
      console.log("🚫 Pares EXCLUÍDOS do robô: BTCUSDT, ETHUSDT");
      
      // Armazenar candidatos válidos com suas análises
      const validCandidates: Array<{
        longPair: string;
        shortPair: string;
        analysis: {
          isValid: boolean;
          strategy: string;
          zScore: number;
          message: string;
        };
      }> = [];
      
      // Importar função de validação
      const { validatePairStrategy } = await import("@/utils/pairValidation");
      
      // Testar todas as combinações de pares
      for (let i = 0; i < allPairs.length; i++) {
        for (let j = i + 1; j < allPairs.length; j++) {
          const pair1 = allPairs[i];
          const pair2 = allPairs[j];
          
          // Validar o par usando a análise avançada
          const analysis = await validatePairStrategy(pair1, pair2);
          
          if (analysis.isValid) {
            console.log(`✅ Par VÁLIDO encontrado: ${pair1}/${pair2} - ${analysis.strategy} - ${analysis.message}`);
            
            // Determinar qual comprar e qual vender baseado no Z-Score
            const longPair = analysis.zScore > 0 ? pair2 : pair1;
            const shortPair = analysis.zScore > 0 ? pair1 : pair2;
            
            validCandidates.push({
              longPair,
              shortPair,
              analysis
            });
          }
        }
      }
      
      if (validCandidates.length === 0) {
        console.log("❌ Nenhum par válido encontrado");
        return null;
      }
      
      // Priorizar por estratégia e Z-Score
      // Ordem de prioridade: partial_reversal > micro_distortion > trend_follow
      const strategyPriority = {
        "partial_reversal": 3,
        "micro_distortion": 2,
        "trend_follow": 1,
        "none": 0
      };
      
      const bestCandidate = validCandidates.sort((a, b) => {
        const priorityDiff = strategyPriority[b.analysis.strategy as keyof typeof strategyPriority] - 
                           strategyPriority[a.analysis.strategy as keyof typeof strategyPriority];
        if (priorityDiff !== 0) return priorityDiff;
        return Math.abs(b.analysis.zScore) - Math.abs(a.analysis.zScore);
      })[0];
      
      console.log(`🎯 MELHOR PAR selecionado: COMPRAR ${bestCandidate.longPair} / VENDER ${bestCandidate.shortPair}`);
      console.log(`📊 Estratégia: ${bestCandidate.analysis.strategy} | Z-Score: ${bestCandidate.analysis.zScore.toFixed(2)}`);
      
      return bestCandidate;
      
    } catch (error) {
      console.error("Erro ao buscar melhor par:", error);
    }
    
    return null;
  };

  // Iniciar modo automático
  const startAutoMode = async () => {
    setShowAutoModeDialog(false);
    setAutoModeEnabled(true);
    setAutoModePaused(false);
    setAutoModeOperationsCompleted(0);
    
    // Aplicar configurações do modo automático
    setProfitTarget(autoModeProfitTarget);
    setAmount(autoModeAmount.toString());
    if (isB3Mode) {
      setB3LeverageLong(autoModeLeverageLong.toString());
      setB3LeverageShort(autoModeLeverageShort.toString());
      setB3Amount(autoModeAmount.toString());
    } else {
      setCryptoLeverageLong(autoModeLeverageLong.toString());
      setCryptoLeverageShort(autoModeLeverageShort.toString());
      setCryptoAmount(autoModeAmount.toString());
    }
    
    // Persistir estado no banco
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const mode = isB3Mode ? "b3" : "crypto";

      // Verificar se já existe configuração de robô ativa para este modo
      const { data: existingConfig } = await supabase
        .from("active_operations")
        .select("id")
        .eq("user_id", user.id)
        .eq("trading_mode", mode)
        .eq("auto_mode_enabled", true)
        .maybeSingle();

      const payload = {
        user_id: user.id,
        trading_mode: mode,
        long_symbol: "",
        short_symbol: "",
        leverage: autoModeLeverageLong,
        leverage_long: autoModeLeverageLong,
        leverage_short: autoModeLeverageShort,
        investment_amount: autoModeAmount,
        auto_mode_enabled: true,
        auto_mode_target: autoModeTarget,
        auto_mode_completed: 0,
        auto_mode_is_test: autoModeIsTest,
        auto_mode_paused: false,
        profit_target: autoModeProfitTarget,
      } as const;

      if (existingConfig) {
        await supabase
          .from("active_operations")
          .update(payload)
          .eq("id", existingConfig.id);
      } else {
        await supabase
          .from("active_operations")
          .insert(payload);
      }
    }
    
    toast({
      title: "🤖 Modo Automático Ativado",
      description: `${autoModeTarget} ops | $${autoModeAmount} | Meta: $${autoModeProfitTarget} | ${autoModeLeverageLong}x/${autoModeLeverageShort}x`,
    });
    
    await executeNextAutoOperation();
  };

  // Executar próxima operação automática
  const executeNextAutoOperation = async () => {
    console.log("🔄 executeNextAutoOperation chamado. Estado:", {
      completed: autoModeOperationsCompleted,
      target: autoModeTarget,
      paused: autoModePaused,
      enabled: autoModeEnabled
    });
    
    if (autoModeOperationsCompleted >= autoModeTarget) {
      toast({
        title: "✅ Meta de Operações Atingida",
        description: `${autoModeTarget} operações completadas!`,
      });
      setAutoModeEnabled(false);
      return;
    }
    
    setIsAnalyzingPairs(true);
    
    toast({
      title: "🔍 Analisando Mercado",
      description: "Buscando melhor oportunidade...",
    });
    
    // Encontrar melhor par
    const bestPair = await findBestPairAutomatically();
    
    if (!bestPair) {
      setIsAnalyzingPairs(false);
      toast({
        title: "⚠️ Nenhuma Oportunidade Encontrada",
        description: "Aguardando melhores condições de mercado...",
        variant: "destructive",
      });
      
      // Tentar novamente em 30 segundos
      setTimeout(() => executeNextAutoOperation(), 30000);
      return;
    }
    
    console.log("🎯 Par encontrado:", bestPair);
    
    toast({
      title: `🎯 Oportunidade ${bestPair.analysis.strategy === 'micro_distortion' ? 'Micro Distorção' : 
              bestPair.analysis.strategy === 'partial_reversal' ? 'Reversão' : 'Trend Follow'}`,
      description: `COMPRAR ${bestPair.longPair.replace('USDT', '')} / VENDER ${bestPair.shortPair.replace('USDT', '')} | Z-Score: ${bestPair.analysis.zScore.toFixed(2)}`,
    });
    
    // Configurar pares encontrados
    setLongPair(bestPair.longPair);
    setShortPair(bestPair.shortPair);
    
    setIsAnalyzingPairs(false);
    
    // Aguardar 1 segundo para os pares serem atualizados
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Iniciar operação
    await handleTestStart();
  };

  // Parar modo automático
  const stopAutoMode = async () => {
    setAutoModeEnabled(false);
    setAutoModePaused(false);
    
    // Atualizar banco
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      await supabase.from("active_operations")
        .update({ 
          auto_mode_enabled: false,
          auto_mode_paused: false,
        })
        .eq('user_id', user.id)
        .eq('trading_mode', isB3Mode ? 'b3' : 'crypto');
    }
    
    toast({
      title: "🛑 Modo Automático Desativado",
      description: `${autoModeOperationsCompleted} de ${autoModeTarget} operações completadas.`,
    });
  };
  
  // Monitorar fechamento de operações para avançar no modo automático
  useEffect(() => {
    if (autoModeEnabled && !autoModePaused && !isOperating && operationData === null && autoModeOperationsCompleted < autoModeTarget) {
      // Operação foi fechada, incrementar contador e iniciar próxima
      const newCount = autoModeOperationsCompleted + 1;
      setAutoModeOperationsCompleted(newCount);
      
      // Atualizar contador no banco
      supabase.auth.getUser().then(({ data: { user } }) => {
        if (user) {
          supabase.from("active_operations")
            .update({ auto_mode_completed: newCount })
            .eq('user_id', user.id)
            .eq('trading_mode', isB3Mode ? 'b3' : 'crypto');
        }
      });
      
      if (newCount < autoModeTarget) {
        // Aguardar 5 segundos antes da próxima operação
        setTimeout(() => executeNextAutoOperation(), 5000);
      } else {
        // Meta atingida
        setAutoModeEnabled(false);
        
        // Desabilitar no banco
        supabase.auth.getUser().then(({ data: { user } }) => {
          if (user) {
            supabase.from("active_operations")
              .update({ auto_mode_enabled: false })
              .eq('user_id', user.id)
              .eq('trading_mode', isB3Mode ? 'b3' : 'crypto');
          }
        });
        
        toast({
          title: "✅ Meta de Operações Atingida",
          description: `${autoModeTarget} operações completadas com sucesso!`,
        });
      }
    }
  }, [isOperating, operationData, autoModeEnabled, autoModePaused]);

  // Timer de 50 minutos para trocar de par automaticamente no robô
  useEffect(() => {
    if (!autoModeEnabled || autoModePaused || !isOperating || !operationStartTime) {
      return;
    }

    const checkTimeout = setInterval(() => {
      const now = new Date();
      const elapsed = (now.getTime() - operationStartTime.getTime()) / 1000 / 60; // minutos
      
      if (elapsed >= 50) {
        console.log("⏰ Timeout de 50 minutos atingido. Trocando de par...");
        
        toast({
          title: "⏰ Timeout Atingido",
          description: "50 minutos sem atingir meta. Buscando novo par...",
        });
        
        // Encerrar operação atual e buscar novo par
        handleStop(true).then(() => {
          // Aguardar 2 segundos e buscar novo par
          setTimeout(() => executeNextAutoOperation(), 2000);
        });
        
        clearInterval(checkTimeout);
      }
    }, 10000); // Verificar a cada 10 segundos

    return () => clearInterval(checkTimeout);
  }, [autoModeEnabled, autoModePaused, isOperating, operationStartTime]);

  // Notificar mudanças nos pares selecionados
  useEffect(() => {
    if (onPairChange) {
      onPairChange(longPair, shortPair);
    }
  }, [longPair, shortPair, onPairChange]);

  // Resetar pares ao mudar de modo
  useEffect(() => {
    if (isB3Mode) {
      // Se estava usando pares cripto, resetar para vazio
      if (longPair && longPair.includes('USDT')) {
        setLongPair("");
      }
      if (shortPair && shortPair.includes('USDT')) {
        setShortPair("");
      }
    } else {
      // Se estava usando pares B3, resetar para vazio
      if (longPair && !longPair.includes('USDT')) {
        setLongPair("");
      }
      if (shortPair && !shortPair.includes('USDT')) {
        setShortPair("");
      }
    }
  }, [isB3Mode]);

  // Carregar estado do modo automático ao montar
  useEffect(() => {
    const loadAutoModeState = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      
       const mode = isB3Mode ? "b3" : "crypto";
       const { data: activeOp } = await supabase
         .from("active_operations")
         .select("*")
         .eq("user_id", user.id)
         .eq("auto_mode_enabled", true)
         .or(`trading_mode.eq.${mode},trading_mode.is.null`)
         .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (activeOp?.auto_mode_enabled) {
        setAutoModeEnabled(true);
        setAutoModePaused(activeOp.auto_mode_paused || false);
        setAutoModeTarget((activeOp.auto_mode_target || 5) as 5 | 10 | 15);
        setAutoModeOperationsCompleted(activeOp.auto_mode_completed || 0);
        setAutoModeIsTest(activeOp.auto_mode_is_test ?? true);
        setAutoModeProfitTarget(activeOp.profit_target || 10);
        setAutoModeLeverageLong(activeOp.leverage_long || 10);
        setAutoModeLeverageShort(activeOp.leverage_short || 10);
        setAutoModeAmount(activeOp.investment_amount || 100);
        
        console.log("🤖 Robô automático restaurado do banco:", {
          enabled: true,
          paused: activeOp.auto_mode_paused,
          completed: activeOp.auto_mode_completed,
          target: activeOp.auto_mode_target,
          hasActiveOp: !!activeOp.long_symbol
        });
        
        toast({
          title: "🤖 Modo Automático Restaurado",
          description: `${activeOp.auto_mode_completed || 0} de ${activeOp.auto_mode_target || 5} operações completadas.`,
        });
        
        // Se o robô está ativo mas não tem operação em andamento, iniciar próxima
        if (!activeOp.long_symbol && !activeOp.auto_mode_paused && (activeOp.auto_mode_completed || 0) < (activeOp.auto_mode_target || 5)) {
          console.log("🔄 Robô sem operação ativa. Iniciando próxima...");
          setTimeout(() => executeNextAutoOperation(), 2000);
        }
      }
    };
    
    loadAutoModeState();
  }, [isB3Mode]);

  // Calcular momentum atual (retorno do ratio no período de 30min)
  const calculateCurrentMomentum = async (long: string, short: string): Promise<number | undefined> => {
    if (isB3Mode) return undefined; // Mock data para B3
    
    try {
      // Buscar últimas 2 velas de 30min para calcular o momentum atual
      const [longRes, shortRes] = await Promise.all([
        fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${long}&interval=30m&limit=2`),
        fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${short}&interval=30m&limit=2`)
      ]);
      
      if (!longRes.ok || !shortRes.ok) return undefined;
      
      const longKlines = await longRes.json();
      const shortKlines = await shortRes.json();
      
      if (longKlines.length < 2 || shortKlines.length < 2) return undefined;
      
      const prevLongPrice = parseFloat(longKlines[0][4]); // Close price anterior
      const prevShortPrice = parseFloat(shortKlines[0][4]);
      const currentLongPrice = parseFloat(longKlines[1][4]); // Close price atual
      const currentShortPrice = parseFloat(shortKlines[1][4]);
      
      const prevRatio = prevLongPrice / prevShortPrice;
      const currentRatio = currentLongPrice / currentShortPrice;
      const momentum = ((currentRatio - prevRatio) / prevRatio) * 100;
      
      console.log("📊 Momentum calculado na entrada:", momentum.toFixed(4) + "%");
      return momentum;
    } catch (err) {
      console.error("Erro ao calcular momentum:", err);
      return undefined;
    }
  };

  // Calcular Hedge Ratio (Beta) para modo B3
  const calcularHedgeRatio = (longSymbol: string, shortSymbol: string): number | null => {
    // Gerar dados mockados de 90 dias para ambas as ações
    const days = 90;
    
    // Simular preços históricos com correlação
    const basePriceLong = Math.random() * 50 + 30; // Entre 30 e 80
    const basePriceShort = Math.random() * 50 + 30;
    
    const longPrices: number[] = [];
    const shortPrices: number[] = [];
    
    // Gerar preços com alguma correlação
    const correlation = 0.6 + Math.random() * 0.3; // 0.6 a 0.9
    
    for (let i = 0; i < days; i++) {
      const commonNoise = (Math.random() - 0.5) * 0.02;
      const longNoise = (Math.random() - 0.5) * 0.01;
      const shortNoise = (Math.random() - 0.5) * 0.01;
      
      const longChange = commonNoise * correlation + longNoise * (1 - correlation);
      const shortChange = commonNoise * correlation + shortNoise * (1 - correlation);
      
      const longPrice = i === 0 ? basePriceLong : longPrices[i - 1] * (1 + longChange);
      const shortPrice = i === 0 ? basePriceShort : shortPrices[i - 1] * (1 + shortChange);
      
      longPrices.push(longPrice);
      shortPrices.push(shortPrice);
    }
    
    // Calcular retornos
    const longReturns: number[] = [];
    const shortReturns: number[] = [];
    
    for (let i = 1; i < days; i++) {
      longReturns.push((longPrices[i] - longPrices[i - 1]) / longPrices[i - 1]);
      shortReturns.push((shortPrices[i] - shortPrices[i - 1]) / shortPrices[i - 1]);
    }
    
    // Calcular média dos retornos
    const meanLong = longReturns.reduce((a, b) => a + b, 0) / longReturns.length;
    const meanShort = shortReturns.reduce((a, b) => a + b, 0) / shortReturns.length;
    
    // Calcular covariância
    let covariance = 0;
    for (let i = 0; i < longReturns.length; i++) {
      covariance += (longReturns[i] - meanLong) * (shortReturns[i] - meanShort);
    }
    covariance /= longReturns.length;
    
    // Calcular variância de X (long)
    let variance = 0;
    for (let i = 0; i < longReturns.length; i++) {
      variance += Math.pow(longReturns[i] - meanLong, 2);
    }
    variance /= longReturns.length;
    
    if (variance === 0) return null;
    
    // Beta = Cov(X,Y) / Var(X)
    const beta = covariance / variance;
    
    return Math.abs(beta); // Retornar valor absoluto
  };

  // Calcular hedge ratio quando ambos pares forem selecionados (apenas B3)
  useEffect(() => {
    if (isB3Mode && longPair && shortPair && !isOperating) {
      setIsCalculatingHedge(true);
      
      // Simular delay de cálculo
      setTimeout(() => {
        const ratio = calcularHedgeRatio(longPair, shortPair);
        setHedgeRatio(ratio);
        setIsCalculatingHedge(false);
        
        if (ratio) {
          toast({
            title: "🎯 Hedge Ratio Calculado",
            description: `β = ${ratio.toFixed(4)} (baseado em 90 dias)`,
          });
        }
      }, 800);
    } else if (!isB3Mode) {
      setHedgeRatio(null);
    }
  }, [longPair, shortPair, isB3Mode, isOperating]);

  // Aplicar hedge ratio automaticamente ao alterar alavancagem LONG
  const handleLeverageLongChange = (value: string) => {
    if (isB3Mode) {
      setB3LeverageLong(value);
      
      // Aplicar hedge ratio se ratio foi calculado
      if (hedgeRatio && !isOperating) {
        const longLev = parseFloat(value);
        if (!isNaN(longLev)) {
          const shortLev = longLev * hedgeRatio;
          setB3LeverageShort(shortLev.toFixed(2));
        }
      }
    } else {
      setCryptoLeverageLong(value);
    }
  };

  // Aplicar hedge ratio inverso ao alterar alavancagem SHORT
  const handleLeverageShortChange = (value: string) => {
    if (isB3Mode) {
      setB3LeverageShort(value);
      
      // Aplicar hedge ratio inverso se ratio foi calculado
      if (hedgeRatio && !isOperating) {
        const shortLev = parseFloat(value);
        if (!isNaN(shortLev) && hedgeRatio > 0) {
          const longLev = shortLev / hedgeRatio;
          setB3LeverageLong(longLev.toFixed(2));
        }
      }
    } else {
      setCryptoLeverageShort(value);
    }
  };

  // Recalcular hedge ratio manualmente
  const recalcularHedgeRatio = () => {
    if (isB3Mode && longPair && shortPair) {
      setIsCalculatingHedge(true);
      setTimeout(() => {
        const ratio = calcularHedgeRatio(longPair, shortPair);
        setHedgeRatio(ratio);
        setIsCalculatingHedge(false);
        
        if (ratio) {
          toast({
            title: "🔄 Hedge Ratio Recalculado",
            description: `β = ${ratio.toFixed(4)}`,
          });
        }
      }, 500);
    }
  };

  // Verificar operação ativa ao carregar e ao mudar de modo
  useEffect(() => {
    const checkActiveOperation = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const mode = isB3Mode ? 'b3' : 'crypto';
      console.log("🔍 OperationControls verificando operação no modo:", mode);

      // Buscar TODAS as operações ativas do usuário para este modo
      const { data: allActiveOps } = await supabase
        .from("active_operations")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "active")
        .neq("long_symbol", "")
        .or(`trading_mode.eq.${mode},trading_mode.is.null`)
        .order("started_at", { ascending: false });

      if (!allActiveOps || allActiveOps.length === 0) {
        console.log("⚠️ Nenhuma operação ativa encontrada no modo:", mode);
        setOperationData(null);
        setIsOperating(false);
        return;
      }

      // Se houver mais de uma operação ativa, limpar as mais antigas
      if (allActiveOps.length > 1) {
        console.log(`⚠️ ${allActiveOps.length} operações ativas encontradas. Limpando antigas...`);
        const oldOperations = allActiveOps.slice(1); // Todas menos a mais recente
        for (const oldOp of oldOperations) {
          await supabase
            .from("active_operations")
            .delete()
            .eq("id", oldOp.id);
          console.log("🗑️ Operação antiga removida:", oldOp.id);
        }
      }

      const activeOp = allActiveOps[0]; // Pegar apenas a mais recente

      // Verificar se a operação é recente (menos de 2 horas)
      const operationAge = new Date().getTime() - new Date(activeOp.started_at).getTime();
      const twoHoursInMs = 2 * 60 * 60 * 1000;

      if (operationAge > twoHoursInMs) {
        console.log("⚠️ Operação muito antiga detectada, removendo:", activeOp.started_at);
        await supabase
          .from("active_operations")
          .delete()
          .eq("id", activeOp.id);
        setOperationData(null);
        setIsOperating(false);
        return;
      }

      console.log("🔄 Restaurando estado da operação ativa...", activeOp);
      const restoredOperation = {
        id: activeOp.id,
        longPair: activeOp.long_symbol,
        shortPair: activeOp.short_symbol,
        leverageLong: activeOp.leverage_long,
        leverageShort: activeOp.leverage_short,
        amount: Number(activeOp.investment_amount),
        startTime: new Date(activeOp.started_at),
        profitTarget: Number(activeOp.profit_target || 10),
        autoCloseEnabled: activeOp.auto_close_enabled ?? false,
      } as const;

      setOperationData(restoredOperation);
      setIsOperating(true);
      setOperationStartTime(new Date(activeOp.started_at)); // Timer de 50min
      
      // Restaurar no modo correto
      if (isB3Mode) {
        setB3LongPair(activeOp.long_symbol);
        setB3ShortPair(activeOp.short_symbol);
        setB3LeverageLong(activeOp.leverage_long.toString());
        setB3LeverageShort(activeOp.leverage_short.toString());
        setB3Amount(activeOp.investment_amount.toString());
      } else {
        setCryptoLongPair(activeOp.long_symbol);
        setCryptoShortPair(activeOp.short_symbol);
        setCryptoLeverageLong(activeOp.leverage_long.toString());
        setCryptoLeverageShort(activeOp.leverage_short.toString());
        setCryptoAmount(activeOp.investment_amount.toString());
      }
      
      setProfitTarget(Number(activeOp.profit_target || 10));
      setAutoCloseEnabled(activeOp.auto_close_enabled ?? true);

      // ✅ Atualizar Dashboard para manter bloco de operação ativa após reload
      onOperationStart({
        id: activeOp.id,
        longSymbol: activeOp.long_symbol,
        shortSymbol: activeOp.short_symbol,
        leverageLong: activeOp.leverage_long,
        leverageShort: activeOp.leverage_short,
        amount: Number(activeOp.investment_amount),
        entryPriceLong: Number(activeOp.entry_price_long || 0),
        entryPriceShort: Number(activeOp.entry_price_short || 0),
        startTime: new Date(activeOp.started_at),
        profitTarget: Number(activeOp.profit_target || 10),
        autoCloseEnabled: activeOp.auto_close_enabled ?? true,
        isTest: activeOp.is_test ?? false,
        entryMomentum: activeOp.entry_momentum ? Number(activeOp.entry_momentum) : undefined,
      });
      onStatusChange("running");
      onPnlChange(Number(activeOp.current_pnl || 0));
    };

    checkActiveOperation();
  }, [isB3Mode]);

  // Auto-encerrar quando atingir a meta de lucro
  useEffect(() => {
    if (autoStopAtProfit && isOperating && operationData && operationData.autoCloseEnabled && !isClosing) {
      const currentTarget = getProfitTarget(operationData.profitTarget);
      
      if (currentPnl >= currentTarget) {
        console.log(`🎯 Meta de $${currentTarget} atingida! Encerrando operação automaticamente...`);
        toast({
          title: "🎉 Meta Atingida!",
          description: `Lucro de $${currentPnl.toFixed(2)} alcançado (meta: $${currentTarget}). Encerrando operação...`,
        });
        handleStop(true); // true = auto-close, sem confirmação
      }
    }
  }, [currentPnl, isOperating, autoStopAtProfit, operationData, isClosing]);

  // Abrir seção de alvo automaticamente ao iniciar operação
  useEffect(() => {
    if (isOperating) {
      setShowTargetSection(true);
    }
  }, [isOperating]);

  const handleTestStart = async () => {
    // 🚫 VALIDAÇÃO CRÍTICA: Bloquear BTCUSDT e ETHUSDT
    if (!isB3Mode && (longPair === "BTCUSDT" || longPair === "ETHUSDT" || shortPair === "BTCUSDT" || shortPair === "ETHUSDT")) {
      toast({
        title: "❌ Par não permitido",
        description: "BTCUSDT e ETHUSDT foram excluídos. O robô opera apenas com análise avançada validada.",
        variant: "destructive",
      });
      return;
    }

    // Validate all inputs usando schema correto
    const TradingSchema = isB3Mode ? B3TradingSchema : CryptoTradingSchema;
    
    try {
      TradingSchema.parse({
        longPair: longPair as any,
        shortPair: shortPair as any,
        leverageLong: parseInt(leverageLong),
        leverageShort: parseInt(leverageShort),
        amount: parseFloat(amount),
        profitTarget
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("🔴 Zod validation error em handleTestStart", {
          issues: error.errors,
          data: { longPair, shortPair, leverageLong, leverageShort, amount, profitTarget, isB3Mode }
        });
        toast({
          title: "Erro de validação",
          description: error.errors[0].message,
          variant: "destructive",
        });
        return;
      }
    }

    // Buscar preços atuais - usar cache como fallback
    let longPrice = prices.find(p => p.symbol === longPair)?.price || lastLongPrice?.price || 0;
    let shortPrice = prices.find(p => p.symbol === shortPair)?.price || lastShortPrice?.price || 0;

    // Se não temos preços em cache, buscar diretamente da Binance
    if (longPrice === 0 || shortPrice === 0) {
      try {
        const [longRes, shortRes] = await Promise.all([
          fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${longPair}`),
          fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${shortPair}`)
        ]);
        const [longData, shortData] = await Promise.all([longRes.json(), shortRes.json()]);
        longPrice = parseFloat(longData.price) || 0;
        shortPrice = parseFloat(shortData.price) || 0;
      } catch (e) {
        console.error("Erro ao buscar preços:", e);
      }
    }

    if (longPrice === 0 || shortPrice === 0) {
      toast({
        title: "Erro",
        description: "Não foi possível obter os preços. Tente novamente.",
        variant: "destructive",
      });
      return;
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    try {
      // Criar operação de teste (apenas no banco, sem Binance)
      // 🎯 Se robô está ativo, usar valores do modo automático
      const effectiveProfitTarget = autoModeEnabled ? autoModeProfitTarget : profitTarget;
      const effectiveAutoClose = autoModeEnabled ? true : autoCloseEnabled;
      
      // Calcular momentum ANTES de salvar no banco
      const entryMomentum = await calculateCurrentMomentum(longPair, shortPair);
      console.log("📊 Momentum calculado na entrada (teste):", entryMomentum);
      
      const { data: operation, error: insertError } = await supabase
        .from("active_operations")
        .insert({
          user_id: user.id,
          long_symbol: longPair,
          short_symbol: shortPair,
          leverage: parseInt(leverageLong),
          leverage_long: parseInt(leverageLong),
          leverage_short: parseInt(leverageShort),
          investment_amount: parseFloat(amount),
          status: "active",
          long_order_id: "TEST_LONG_" + Date.now(),
          short_order_id: "TEST_SHORT_" + Date.now(),
          profit_target: effectiveProfitTarget,
          auto_close_enabled: effectiveAutoClose,
          is_test: autoModeEnabled ? autoModeIsTest : true,
          entry_price_long: longPrice,
          entry_price_short: shortPrice,
          trading_mode: isB3Mode ? 'b3' : 'crypto',
          entry_momentum: entryMomentum,
        })
        .select()
        .single();

      if (insertError) {
        throw new Error("Falha ao criar operação de teste");
      }

      toast({
        title: "🧪 Operação TESTE iniciada!",
        description: "Simulação ativa (sem ordens na Binance)",
      });

      const startTime = new Date();
      
      setOperationData({
        id: operation.id,
        longPair,
        shortPair,
        leverageLong: parseInt(leverageLong),
        leverageShort: parseInt(leverageShort),
        amount: parseFloat(amount),
        startTime,
        profitTarget: effectiveProfitTarget,
        autoCloseEnabled: effectiveAutoClose,
      });
      setIsOperating(true);
      setOperationStartTime(startTime); // Timer de 50min
      onStatusChange("running");
      
      onOperationStart({
        id: operation.id,
        longSymbol: longPair,
        shortSymbol: shortPair,
        leverageLong: parseInt(leverageLong),
        leverageShort: parseInt(leverageShort),
        amount: parseFloat(amount),
        entryPriceLong: longPrice,
        entryPriceShort: shortPrice,
        startTime,
        profitTarget: effectiveProfitTarget,
        autoCloseEnabled: effectiveAutoClose,
        isTest: true,
        entryMomentum,
      });
    } catch (error) {
      console.error('Error starting test operation:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      toast({
        title: "Erro ao iniciar operação teste",
        description: errorMessage,
        variant: "destructive",
      });
      return;
    }
  };

  const handleStart = async () => {
    // 🚫 VALIDAÇÃO CRÍTICA: Bloquear BTCUSDT e ETHUSDT
    if (!isB3Mode && (longPair === "BTCUSDT" || longPair === "ETHUSDT" || shortPair === "BTCUSDT" || shortPair === "ETHUSDT")) {
      toast({
        title: "❌ Par não permitido",
        description: "BTCUSDT e ETHUSDT foram excluídos. O robô opera apenas com análise avançada validada.",
        variant: "destructive",
      });
      return;
    }

    // Verificar créditos antes de permitir operação real
    if (userCredits === 0) {
      toast({
        title: "⚠️ Sem créditos",
        description: "Adquira créditos para operar na Binance ou use operações de teste.",
        variant: "destructive",
      });
      return;
    }

    // Validate all inputs usando schema correto
    const TradingSchema = isB3Mode ? B3TradingSchema : CryptoTradingSchema;
    
    try {
      TradingSchema.parse({
        longPair: longPair as any,
        shortPair: shortPair as any,
        leverageLong: parseInt(leverageLong),
        leverageShort: parseInt(leverageShort),
        amount: parseFloat(amount),
        profitTarget
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("🔴 Zod validation error em handleStart", {
          issues: error.errors,
          data: { longPair, shortPair, leverageLong, leverageShort, amount, profitTarget, isB3Mode }
        });
        toast({
          title: "Erro de validação",
          description: error.errors[0].message,
          variant: "destructive",
        });
        return;
      }
    }

    // Buscar preços atuais - usar cache como fallback
    let entryLongPrice = prices.find(p => p.symbol === longPair)?.price || lastLongPrice?.price || 0;
    let entryShortPrice = prices.find(p => p.symbol === shortPair)?.price || lastShortPrice?.price || 0;

    // Se não temos preços em cache, buscar diretamente da Binance
    if (entryLongPrice === 0 || entryShortPrice === 0) {
      try {
        const [longRes, shortRes] = await Promise.all([
          fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${longPair}`),
          fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${shortPair}`)
        ]);
        const [longData, shortData] = await Promise.all([longRes.json(), shortRes.json()]);
        entryLongPrice = parseFloat(longData.price) || 0;
        entryShortPrice = parseFloat(shortData.price) || 0;
      } catch (e) {
        console.error("Erro ao buscar preços:", e);
      }
    }

    if (entryLongPrice === 0 || entryShortPrice === 0) {
      toast({
        title: "Erro",
        description: "Não foi possível obter os preços. Tente novamente.",
        variant: "destructive",
      });
      return;
    }

    // Confirmação de segurança
    const confirmed = window.confirm(
      `⚠️ ATENÇÃO: Você está prestes a executar operações REAIS na Binance!\n\n` +
      `LONG: ${longPair} com ${leverageLong}x\n` +
      `SHORT: ${shortPair} com ${leverageShort}x\n` +
      `Valor: $${amount}\n\n` +
      `Isso envolve RISCO REAL de perda financeira. Deseja continuar?`
    );

    if (!confirmed) {
      return;
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    try {
      // 1. Configurar alavancagem LONG
      toast({
        title: "Configurando alavancagem LONG...",
        description: `${longPair} - ${leverageLong}x`,
      });

      const { data: leverageLongResult, error: leverageLongError } = await supabase.functions.invoke('binance-trading', {
        body: {
          action: 'set_leverage',
          symbol: longPair,
          leverage: parseInt(leverageLong),
        },
      });

      if (leverageLongError || !leverageLongResult.success) {
        const errorDetails = leverageLongResult?.error || leverageLongError?.message || 'Erro desconhecido';
        console.error('❌ Erro detalhado ao configurar alavancagem LONG:', {
          error: errorDetails,
          leverageLongResult,
          leverageLongError
        });
        throw new Error(`Erro ao configurar alavancagem LONG: ${errorDetails}`);
      }

      // 2. Configurar alavancagem SHORT
      toast({
        title: "Configurando alavancagem SHORT...",
        description: `${shortPair} - ${leverageShort}x`,
      });

      const { data: leverageShortResult, error: leverageShortError } = await supabase.functions.invoke('binance-trading', {
        body: {
          action: 'set_leverage',
          symbol: shortPair,
          leverage: parseInt(leverageShort),
        },
      });

      if (leverageShortError || !leverageShortResult.success) {
        const errorDetails = leverageShortResult?.error || leverageShortError?.message || 'Erro desconhecido';
        console.error('❌ Erro detalhado ao configurar alavancagem SHORT:', {
          error: errorDetails,
          leverageShortResult,
          leverageShortError
        });
        throw new Error(`Erro ao configurar alavancagem SHORT: ${errorDetails}`);
      }

      // 3. Calcular quantidades (50% do valor para cada posição)
      const totalAmount = parseFloat(amount);
      const halfAmount = totalAmount / 2;
      const leverageLongInt = parseInt(leverageLong) || 1;
      const leverageShortInt = parseInt(leverageShort) || 1;
      
      console.log('💰 CÁLCULO DE QUANTIDADES:', {
        amountString: amount,
        totalAmount,
        halfAmount,
        leverageLong: leverageLongInt,
        leverageShort: leverageShortInt,
        longPrice: entryLongPrice,
        shortPrice: entryShortPrice
      });
      
      // Calcular quantidade considerando que o valor digitado é MARGEM desejada
      // Valor notional por perna = margem (halfAmount) × alavancagem
      const longNotionalValue = halfAmount * leverageLongInt;
      const shortNotionalValue = halfAmount * leverageShortInt;
      
      // VALIDAÇÃO BINANCE: Valor nocional mínimo de 100 USDT
      const MIN_NOTIONAL = 100;
      
      if (longNotionalValue < MIN_NOTIONAL) {
        throw new Error(
          `Valor nocional da ordem LONG muito baixo (${longNotionalValue.toFixed(2)} USDT). ` +
          `Mínimo exigido pela Binance: ${MIN_NOTIONAL} USDT. ` +
          `Aumente o valor investido ou a alavancagem. ` +
          `Valor mínimo sugerido: ${((MIN_NOTIONAL / leverageLongInt) * 2).toFixed(2)} USDT`
        );
      }
      
      if (shortNotionalValue < MIN_NOTIONAL) {
        throw new Error(
          `Valor nocional da ordem SHORT muito baixo (${shortNotionalValue.toFixed(2)} USDT). ` +
          `Mínimo exigido pela Binance: ${MIN_NOTIONAL} USDT. ` +
          `Aumente o valor investido ou a alavancagem. ` +
          `Valor mínimo sugerido: ${((MIN_NOTIONAL / leverageShortInt) * 2).toFixed(2)} USDT`
        );
      }
      
      const longQuantity = (longNotionalValue / entryLongPrice).toFixed(3);
      const shortQuantity = (shortNotionalValue / entryShortPrice).toFixed(3);
      
      console.log('📊 QUANTIDADES CALCULADAS:', {
        longQuantity,
        shortQuantity,
        halfAmountMarginPerLeg: halfAmount,
        longNotionalValue,
        shortNotionalValue,
        longValueOnBinance: parseFloat(longQuantity) * entryLongPrice,
        shortValueOnBinance: parseFloat(shortQuantity) * entryShortPrice,
        notionalValuesValid: longNotionalValue >= MIN_NOTIONAL && shortNotionalValue >= MIN_NOTIONAL
      });

      // Verificar se correlação > 90% em todos os 3 períodos
      const selectedCorrelation = correlations.find(c => c.symbol === shortPair);
      const highCorrelation = selectedCorrelation && 
        selectedCorrelation.corr1h > 0.90 && 
        selectedCorrelation.corr10d > 0.90 && 
        selectedCorrelation.corr30d > 0.90;

      // 4. Criar ordem LONG (BUY)
      toast({
        title: "Criando ordem LONG...",
        description: `${longPair} - ${longQuantity}`,
      });

      const { data: longOrderResult, error: longOrderError } = await supabase.functions.invoke('binance-trading', {
        body: {
          action: 'create_order',
          symbol: longPair,
          side: 'BUY',
          quantity: longQuantity,
        },
      });

      if (longOrderError || !longOrderResult.success) {
        const errorDetails = longOrderResult?.error || longOrderError?.message || 'Erro desconhecido';
        console.error('❌ Erro detalhado ao criar ordem LONG:', {
          error: errorDetails,
          longOrderResult,
          longOrderError,
          requestBody: {
            action: 'create_order',
            symbol: longPair,
            side: 'BUY',
            quantity: longQuantity,
          }
        });
        throw new Error(`Erro ao criar ordem LONG: ${errorDetails}`);
      }

      console.log('✅ Resposta completa da ordem LONG:', JSON.stringify(longOrderResult, null, 2));

      const longOrderId = longOrderResult.data.orderId;
      // Capturar preço real de execução da ordem LONG
      let executedLongPrice = longOrderResult.data.avgPrice || longOrderResult.data.price || entryLongPrice;
      
      // Se não vier preço na resposta da ordem, buscar da posição
      if (!longOrderResult.data.avgPrice && !longOrderResult.data.price) {
        console.log('⚠️ Preço LONG não retornado na ordem, buscando da posição...');
        const { data: posData } = await supabase.functions.invoke('binance-trading', {
          body: { action: 'get_position', symbol: longPair }
        });
        if (posData?.success && posData?.data?.entryPrice) {
          executedLongPrice = parseFloat(posData.data.entryPrice);
          console.log('✅ Preço LONG obtido da posição:', executedLongPrice);
        }
      }
      
      console.log('📊 Preço de execução LONG:', { ticker: entryLongPrice, executed: executedLongPrice });

      // Se correlação alta, esperar 15 segundos antes da ordem SHORT
      if (highCorrelation) {
        toast({
          title: "⏳ Correlação alta detectada (>90%)",
          description: "Aguardando 15 segundos antes da ordem SHORT...",
        });
        await new Promise(resolve => setTimeout(resolve, 15000));
      }

      // 5. Criar ordem SHORT (SELL)
      toast({
        title: "Criando ordem SHORT...",
        description: `${shortPair} - ${shortQuantity}`,
      });

      const { data: shortOrderResult, error: shortOrderError } = await supabase.functions.invoke('binance-trading', {
        body: {
          action: 'create_order',
          symbol: shortPair,
          side: 'SELL',
          quantity: shortQuantity,
        },
      });

      if (shortOrderError || !shortOrderResult.success) {
        // Se a ordem SHORT falhar, devemos fechar a posição LONG
        const errorDetails = shortOrderResult?.error || shortOrderError?.message || 'Erro desconhecido';
        console.error('❌ Erro detalhado ao criar ordem SHORT:', {
          error: errorDetails,
          shortOrderResult,
          shortOrderError,
          requestBody: {
            action: 'create_order',
            symbol: shortPair,
            side: 'SELL',
            quantity: shortQuantity,
          }
        });
        
        toast({
          title: "Erro na ordem SHORT",
          description: "Fechando posição LONG...",
          variant: "destructive",
        });
        
        await supabase.functions.invoke('binance-trading', {
          body: {
            action: 'close_position',
            symbol: longPair,
          },
        });

        throw new Error(`Erro ao criar ordem SHORT: ${errorDetails}`);
      }

      console.log('✅ Resposta completa da ordem SHORT:', JSON.stringify(shortOrderResult, null, 2));

      const shortOrderId = shortOrderResult.data.orderId;
      // Capturar preço real de execução da ordem SHORT
      let executedShortPrice = shortOrderResult.data.avgPrice || shortOrderResult.data.price || entryShortPrice;
      
      // Se não vier preço na resposta da ordem, buscar da posição
      if (!shortOrderResult.data.avgPrice && !shortOrderResult.data.price) {
        console.log('⚠️ Preço SHORT não retornado na ordem, buscando da posição...');
        const { data: posData } = await supabase.functions.invoke('binance-trading', {
          body: { action: 'get_position', symbol: shortPair }
        });
        if (posData?.success && posData?.data?.entryPrice) {
          executedShortPrice = parseFloat(posData.data.entryPrice);
          console.log('✅ Preço SHORT obtido da posição:', executedShortPrice);
        }
      }
      
      console.log('📊 Preço de execução SHORT:', { ticker: entryShortPrice, executed: executedShortPrice });

      // 6. Consumir 1 crédito
      const { data: currentCredits } = await supabase
        .from("user_credits")
        .select("credits")
        .eq("user_id", user.id)
        .single();

      if (currentCredits) {
        await supabase
          .from("user_credits")
          .update({ credits: Math.max(0, currentCredits.credits - 1) })
          .eq("user_id", user.id);
      }

      // 7. Salvar operação ativa no banco usando preços reais de execução
      // 🎯 Se robô está ativo, usar valores do modo automático
      const effectiveProfitTargetReal = autoModeEnabled ? autoModeProfitTarget : profitTarget;
      const effectiveAutoCloseReal = autoModeEnabled ? true : autoCloseEnabled;
      
      console.log('💾 Salvando operação no banco:', {
        entry_price_long: executedLongPrice,
        entry_price_short: executedShortPrice,
        long_order_id: longOrderId.toString(),
        short_order_id: shortOrderId.toString(),
      });
      
      // Calcular momentum ANTES de salvar no banco
      const entryMomentum = await calculateCurrentMomentum(longPair, shortPair);
      console.log("📊 Momentum calculado na entrada (real):", entryMomentum);
      
      const { data: operation, error: insertError } = await supabase
        .from("active_operations")
        .insert({
          user_id: user.id,
          long_symbol: longPair,
          short_symbol: shortPair,
          leverage: parseInt(leverageLong),
          leverage_long: parseInt(leverageLong),
          leverage_short: parseInt(leverageShort),
          investment_amount: parseFloat(amount),
          status: "active",
          long_order_id: longOrderId.toString(),
          short_order_id: shortOrderId.toString(),
          profit_target: effectiveProfitTargetReal,
          auto_close_enabled: effectiveAutoCloseReal,
          entry_price_long: executedLongPrice,
          entry_price_short: executedShortPrice,
          trading_mode: isB3Mode ? 'b3' : 'crypto',
          entry_momentum: entryMomentum,
        })
        .select()
        .single();

      if (insertError) {
        toast({
          title: "Erro ao salvar operação",
          description: "Fechando posições...",
          variant: "destructive"
        });

        // Fechar ambas as posições
        await supabase.functions.invoke('binance-trading', {
          body: { action: 'close_position', symbol: longPair },
        });
        await supabase.functions.invoke('binance-trading', {
          body: { action: 'close_position', symbol: shortPair },
        });

        throw new Error("Falha ao salvar operação");
      }

      toast({
        title: "✅ Operação iniciada com sucesso!",
        description: `Orders: ${longOrderId} / ${shortOrderId}`,
      });

      const startTime = new Date();
      
      setOperationData({
        id: operation.id,
        longPair,
        shortPair,
        leverageLong: parseInt(leverageLong),
        leverageShort: parseInt(leverageShort),
        amount: parseFloat(amount),
        startTime,
        profitTarget: effectiveProfitTargetReal,
        autoCloseEnabled: effectiveAutoCloseReal,
      });
      setIsOperating(true);
      setOperationStartTime(startTime); // Timer de 50min
      onStatusChange("running");
      
      onOperationStart({
        id: operation.id,
        longSymbol: longPair,
        shortSymbol: shortPair,
        leverageLong: parseInt(leverageLong),
        leverageShort: parseInt(leverageShort),
        amount: parseFloat(amount),
        entryPriceLong: executedLongPrice,
        entryPriceShort: executedShortPrice,
        startTime,
        profitTarget: effectiveProfitTargetReal,
        autoCloseEnabled: effectiveAutoCloseReal,
        isTest: false,
        entryMomentum,
      });
    } catch (error) {
      console.error('Error starting operation:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      toast({
        title: "Erro ao iniciar operação",
        description: errorMessage,
        variant: "destructive",
      });
      return;
    }
  };

  const handleStop = async (autoClose = false) => {
    // Prevenir múltiplas execuções
    if (isClosing) {
      console.log("⚠️ Já está fechando operação, ignorando chamada duplicada");
      return;
    }

    if (!operationData) {
      toast({
        title: "Erro",
        description: "Dados da operação não encontrados",
        variant: "destructive",
      });
      setIsOperating(false);
      onStatusChange("idle");
      return;
    }

    setIsClosing(true);

    // Verificar se é operação de teste
    const { data: activeOp } = await supabase
      .from("active_operations")
      .select("is_test, status")
      .eq("id", operationData.id)
      .single();

    // Se já foi fechada, não fazer nada
    if (activeOp?.status === "closed") {
      console.log("Operação já foi fechada anteriormente");
      setIsClosing(false);
      setIsOperating(false);
      setOperationData(null);
      onStatusChange("idle");
      onPnlChange(0);
      onOperationStop();
      return;
    }

    const isTestOperation = activeOp?.is_test || false;

    // Pular confirmação se for auto-close
    if (!autoClose) {
      const confirmed = window.confirm(
        isTestOperation 
          ? `⚠️ Confirmar fechamento da operação TESTE?\n\nPnL simulado: $${currentPnl.toFixed(2)}`
          : `⚠️ Confirmar fechamento das posições?\n\n` +
            `Isso irá fechar as ordens REAIS na Binance.\n` +
            `PnL atual: $${currentPnl.toFixed(2)}`
      );

      if (!confirmed) {
        setIsClosing(false);
        return;
      }
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Capturar lucro real da Binance
    let realProfit = currentPnl; // Fallback para operações de teste

    try {
      if (!isTestOperation) {
        // Operação real - capturar saldo antes e depois
        toast({
          title: "💰 Capturando saldo inicial...",
          description: "Preparando para fechar posições",
        });

        // 1. Buscar saldo ANTES de fechar
        const { data: accountBefore, error: accountBeforeError } = await supabase.functions.invoke('binance-trading', {
          body: { action: 'get_account' }
        });

        if (accountBeforeError || !accountBefore?.success) {
          throw new Error('Erro ao buscar saldo inicial da Binance');
        }

        const balanceBefore = parseFloat(accountBefore.data.totalWalletBalance || '0');
        console.log('💰 Saldo ANTES:', balanceBefore, 'USDT');

        // 2. Fechar LONG e SHORT em PARALELO para máxima velocidade
        toast({
          title: "⚡ Fechando posições...",
          description: `${operationData.longPair} / ${operationData.shortPair}`,
        });

        const [closeLongResult, closeShortResult] = await Promise.all([
          supabase.functions.invoke('binance-trading', {
            body: { action: 'close_position', symbol: operationData.longPair },
          }),
          supabase.functions.invoke('binance-trading', {
            body: { action: 'close_position', symbol: operationData.shortPair },
          }),
        ]);

        if (closeLongResult.error || !closeLongResult.data?.success) {
          console.error('❌ Erro ao fechar LONG:', closeLongResult.error || closeLongResult.data?.error);
        }

        if (closeShortResult.error || !closeShortResult.data?.success) {
          console.error('❌ Erro ao fechar SHORT:', closeShortResult.error || closeShortResult.data?.error);
        }

        // 3. Buscar saldo DEPOIS de fechar (sem delay - posições já fechadas)
        const { data: accountAfter, error: accountAfterError } = await supabase.functions.invoke('binance-trading', {
          body: { action: 'get_account' }
        });

        if (accountAfterError || !accountAfter?.success) {
          throw new Error('Erro ao buscar saldo final da Binance');
        }

        const balanceAfter = parseFloat(accountAfter.data.totalWalletBalance || '0');
        console.log('💰 Saldo DEPOIS:', balanceAfter, 'USDT');

        // 4. Calcular lucro real
        realProfit = balanceAfter - balanceBefore;
        console.log('💰 LUCRO REAL:', realProfit, 'USDT');
      } else {
        // Operação teste - apenas simular
        toast({
          title: "🧪 Encerrando operação TESTE",
          description: "Simulação finalizada",
        });
      }

      // Salvar no histórico (tanto para real quanto teste)
      const endTime = new Date();
      const durationSeconds = Math.floor((endTime.getTime() - operationData.startTime.getTime()) / 1000);

      await supabase.from("trade_history").insert({
        user_id: user.id,
        long_symbol: operationData.longPair,
        short_symbol: operationData.shortPair,
        leverage: operationData.leverageLong,
        leverage_long: operationData.leverageLong,
        leverage_short: operationData.leverageShort,
        investment_amount: operationData.amount,
        profit: realProfit,
        started_at: operationData.startTime.toISOString(),
        ended_at: endTime.toISOString(),
        duration_seconds: durationSeconds,
        is_test: isTestOperation,
      });

      // Remover operação ativa da tabela (mesmo comportamento do monitor)
      const { error: activeOpError } = await supabase
        .from("active_operations")
        .delete()
        .eq("id", operationData.id);

      if (activeOpError) {
        console.error("Erro ao remover operação ativa (fallback para update):", activeOpError);
        await supabase
          .from("active_operations")
          .update({ status: "closed" })
          .eq("id", operationData.id);
      }

      setIsOperating(false);
      setOperationData(null);
      setOperationStartTime(null); // Limpar timer
      setIsClosing(false);
      onStatusChange("closed");
      onPnlChange(0);
      onOperationStop();

      // Formatar duração
      const hours = Math.floor(durationSeconds / 3600);
      const minutes = Math.floor((durationSeconds % 3600) / 60);
      const durationText = hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;

      // Determinar se foi lucro ou perda
      const resultEmoji = realProfit >= 0 ? "🎉" : "📉";
      const resultText = realProfit >= 0 ? "Lucro" : "Perda";

      toast({
        title: isTestOperation ? `🧪 Operação TESTE encerrada! ${resultEmoji}` : `✅ Operação encerrada! ${resultEmoji}`,
        description: `${resultText} REAL: $${realProfit.toFixed(2)}\nPares: ${operationData.longPair} (LONG) / ${operationData.shortPair} (SHORT)\nDuração: ${durationText}`,
      });
    } catch (error) {
      console.error('Error stopping operation:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';

      // Se deu erro ao encerrar na Binance, NÃO marcar como closed (senão perde o rastreio e vira "posição órfã")
      // No máximo desativar o auto-close e manter a operação como ativa.
      if (operationData?.id) {
        try {
          await supabase
            .from("active_operations")
            .update({
              status: "active",
              auto_close_enabled: false,
              updated_at: new Date().toISOString(),
            })
            .eq("id", operationData.id);
        } catch (dbError) {
          console.error(
            "Erro ao manter operação ativa após falha no encerramento:",
            dbError
          );
        }
      }

      setIsClosing(false);

      // Mantém a operação em execução para permitir nova tentativa de encerramento
      onStatusChange("running");

      toast({
        title: "Erro ao encerrar operação",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-3 sm:space-y-4">
      <div className="space-y-1.5 sm:space-y-2">
        <Label htmlFor="long-pair" className="text-primary text-xs sm:text-sm">Par de Compra (LONG)</Label>
        <Select value={longPair} onValueChange={setLongPair} disabled={isOperating}>
          <SelectTrigger id="long-pair" className="bg-input border-border">
            <SelectValue placeholder="Selecione..." />
          </SelectTrigger>
          <SelectContent>
            {(isB3Mode ? B3_PAIRS : CRYPTO_PAIRS).map((pair) => (
              <SelectItem key={pair} value={pair}>{pair}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {lastLongPrice && (
          <div className="space-y-0.5">
            <div className="flex items-center justify-between text-xs px-1">
              <span className="text-muted-foreground">
                {isB3Mode ? 'R$' : '$'} {lastLongPrice.price.toFixed(isB3Mode ? 2 : 2)}
              </span>
              <span className={lastLongPrice.change24h >= 0 ? "text-profit" : "text-loss"}>
                {lastLongPrice.change24h >= 0 ? "+" : ""}{lastLongPrice.change24h.toFixed(2)}% (24h)
              </span>
            </div>
            <div className="flex items-center justify-between text-[10px] px-1">
              <span className="text-muted-foreground">Var. 1h:</span>
              <span className={lastLongPrice.change1h >= 0 ? "text-profit" : "text-loss"}>
                {lastLongPrice.change1h >= 0 ? "+" : ""}{lastLongPrice.change1h.toFixed(2)}%
              </span>
            </div>
            <div className="flex items-center justify-between text-[10px] px-1">
              <span className="text-muted-foreground">Liquidez 24h:</span>
              <span className="text-primary font-medium">
                {isB3Mode ? 'R$' : '$'} {(lastLongPrice.volume24h / 1000000).toFixed(2)}M
              </span>
            </div>
            <div className="flex items-center justify-between text-[10px] px-1">
              <span className="text-muted-foreground">Liquidez 1h:</span>
              <span className="text-primary font-medium">
                {isB3Mode ? 'R$' : '$'} {(lastLongPrice.volume1h / 1000000).toFixed(2)}M
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Botão para inverter moedas */}
      <div className="flex justify-center -my-1">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => {
            const tempLong = longPair;
            const tempShort = shortPair;
            if (isB3Mode) {
              setB3LongPair(tempShort);
              setB3ShortPair(tempLong);
            } else {
              setCryptoLongPair(tempShort);
              setCryptoShortPair(tempLong);
            }
          }}
          disabled={isOperating || !longPair || !shortPair}
          className="h-8 w-8 p-0 rounded-full"
          title="Inverter moedas"
        >
          <ArrowUpDown className="h-4 w-4" />
        </Button>
      </div>

      <div className="space-y-1.5 sm:space-y-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="short-pair" className="text-loss text-xs sm:text-sm">Par de Venda (SHORT)</Label>
          {isLoadingCorrelations && longPair && (
            <span className="text-[10px] text-muted-foreground animate-pulse">
              Calculando correlações...
            </span>
          )}
        </div>
        <Select value={shortPair} onValueChange={setShortPair} disabled={isOperating}>
          <SelectTrigger id="short-pair" className="bg-input border-border">
            <SelectValue placeholder="Selecione..." />
          </SelectTrigger>
          <SelectContent className="max-h-[300px]">
            {longPair && correlations.length > 0 ? (
              correlations.map((corr) => (
                <SelectItem key={corr.symbol} value={corr.symbol}>
                  <div className="flex flex-col gap-0.5 py-1">
                    <span className="font-semibold">{corr.symbol}</span>
                    <span className="text-[10px] text-muted-foreground">
                      1h: {(corr.corr1h >= 0 ? '+' : '')}{corr.corr1h.toFixed(2)} | 
                      10d: {(corr.corr10d >= 0 ? '+' : '')}{corr.corr10d.toFixed(2)} | 
                      30d: {(corr.corr30d >= 0 ? '+' : '')}{corr.corr30d.toFixed(2)}
                    </span>
                  </div>
                </SelectItem>
              ))
            ) : (
              (isB3Mode ? B3_PAIRS : CRYPTO_PAIRS).map((pair) => (
                <SelectItem key={pair} value={pair}>{pair}</SelectItem>
              ))
            )}
          </SelectContent>
        </Select>
        {lastShortPrice && (
          <div className="space-y-0.5">
            <div className="flex items-center justify-between text-xs px-1">
              <span className="text-muted-foreground">
                {isB3Mode ? 'R$' : '$'} {lastShortPrice.price.toFixed(isB3Mode ? 2 : 2)}
              </span>
              <span className={lastShortPrice.change24h >= 0 ? "text-profit" : "text-loss"}>
                {lastShortPrice.change24h >= 0 ? "+" : ""}{lastShortPrice.change24h.toFixed(2)}% (24h)
              </span>
            </div>
            <div className="flex items-center justify-between text-[10px] px-1">
              <span className="text-muted-foreground">Var. 1h:</span>
              <span className={lastShortPrice.change1h >= 0 ? "text-profit" : "text-loss"}>
                {lastShortPrice.change1h >= 0 ? "+" : ""}{lastShortPrice.change1h.toFixed(2)}%
              </span>
            </div>
            <div className="flex items-center justify-between text-[10px] px-1">
              <span className="text-muted-foreground">Liquidez 24h:</span>
              <span className="text-primary font-medium">
                {isB3Mode ? 'R$' : '$'} {(lastShortPrice.volume24h / 1000000).toFixed(2)}M
              </span>
            </div>
            <div className="flex items-center justify-between text-[10px] px-1">
              <span className="text-muted-foreground">Liquidez 1h:</span>
              <span className="text-primary font-medium">
                {isB3Mode ? 'R$' : '$'} {(lastShortPrice.volume1h / 1000000).toFixed(2)}M
              </span>
            </div>
          </div>
        )}
        {longPair && correlations.length > 0 && !isLoadingCorrelations && (
          <p className="text-[10px] text-muted-foreground/70 italic">
            ✨ Aurion Correlator — Ordenado por correlação de Pearson
          </p>
        )}
      </div>

      {/* Advanced Pair Analysis - Sugestão de Entrada */}
      {!isB3Mode && longPair && shortPair && longPair !== shortPair && (
        <PairSignal symbol1={longPair} symbol2={shortPair} />
      )}

      <div className="grid grid-cols-2 gap-2 sm:gap-4">
        <div className="space-y-1.5 sm:space-y-2">
          <Label htmlFor="leverage-long" className="text-profit text-xs sm:text-sm">
            {isB3Mode ? "Qtd. Compra" : "Alav. LONG"}
          </Label>
          <Input
            id="leverage-long"
            type="number"
            min="1"
            max="50"
            step={isB3Mode ? "0.01" : "1"}
            value={leverageLong}
            onChange={(e) => handleLeverageLongChange(e.target.value)}
            disabled={isOperating}
            className="bg-input border-border"
          />
        </div>

        <div className="space-y-1.5 sm:space-y-2">
          <Label htmlFor="leverage-short" className="text-loss text-xs sm:text-sm">
            {isB3Mode ? "Qtd. Venda" : "Alav. SHORT"}
          </Label>
          <Input
            id="leverage-short"
            type="number"
            min="1"
            max="50"
            step={isB3Mode ? "0.01" : "1"}
            value={leverageShort}
            onChange={(e) => handleLeverageShortChange(e.target.value)}
            disabled={isOperating}
            className="bg-input border-border"
          />
        </div>
      </div>

      {/* Hedge Ratio Display - Apenas para B3 */}
      {isB3Mode && hedgeRatio && (
        <div className="glass-card border border-primary/30 p-3 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Hedge Ratio (β):</span>
              <span className="text-sm font-bold text-primary">
                {isCalculatingHedge ? "Calculando..." : hedgeRatio.toFixed(4)}
              </span>
            </div>
            <button
              onClick={recalcularHedgeRatio}
              disabled={isCalculatingHedge || isOperating}
              className="text-primary hover:text-primary/80 transition-colors disabled:opacity-50"
              title="Recalcular hedge ratio"
            >
              🔄
            </button>
          </div>
          <p className="text-[10px] text-muted-foreground/70 italic">
            Calculado com base em 90 dias de histórico
          </p>
        </div>
      )}

      {/* Mensagem de cálculo ou falta de dados */}
      {isB3Mode && longPair && shortPair && !hedgeRatio && !isCalculatingHedge && (
        <div className="text-center text-xs text-muted-foreground p-2 bg-muted/20 rounded-lg">
          Dados insuficientes para calcular o hedge ratio.
        </div>
      )}

      <div className="space-y-1.5 sm:space-y-2">
        <Label htmlFor="amount" className="text-xs sm:text-sm">Valor (USDT)</Label>
        <Input
          id="amount"
          type="number"
          min="10"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          disabled={isOperating}
          className="bg-input border-border"
        />
        {!isB3Mode && amount && leverageLong && leverageShort && (() => {
          const MIN_NOTIONAL = 100;
          const totalAmount = parseFloat(amount);
          const halfAmount = totalAmount / 2;
          const leverageLongInt = parseInt(leverageLong);
          const leverageShortInt = parseInt(leverageShort);
          const minLeverage = Math.min(leverageLongInt, leverageShortInt);
          const minRequiredTotal = (MIN_NOTIONAL / minLeverage) * 2;
          const longNotional = halfAmount * leverageLongInt;
          const shortNotional = halfAmount * leverageShortInt;
          const isValid = longNotional >= MIN_NOTIONAL && shortNotional >= MIN_NOTIONAL;
          
          return !isValid ? (
            <p className="text-xs text-warning flex items-center gap-1 mt-1">
              <span>⚠️</span>
              Valor muito baixo. Mínimo: ${minRequiredTotal.toFixed(2)} USDT (com alavancagens atuais)
            </p>
          ) : null;
        })()}
      </div>

      {/* Botão premium para mostrar/ocultar seção do alvo - Oculto em modo B3 */}
      {!isB3Mode && (
        <div className="glass-card border-2 border-primary/20 hover:border-primary/40 transition-all duration-300 p-4 cursor-pointer group relative overflow-hidden"
             onClick={() => setShowTargetSection(!showTargetSection)}>
          <div className="absolute inset-0 gradient-premium opacity-10 group-hover:opacity-20 transition-opacity pointer-events-none"></div>
          
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-card/50 backdrop-blur-sm border-2 border-primary p-2 sm:p-2.5 flex items-center justify-center group-hover:scale-110 transition-all shadow-glow">
                <img src={aurionLogo} alt="AURION" className="w-full h-full object-contain drop-shadow-lg" />
              </div>
              <div className="text-left">
                <p className="text-xs text-muted-foreground uppercase tracking-wider">
                  Meta de Lucro {isOperating && <span className="text-accent ml-1">(editável)</span>}
                </p>
                <p className="text-lg font-bold text-primary">${profitTarget.toFixed(2)}</p>
              </div>
            </div>
            
            <div className={`transform transition-transform duration-300 ${showTargetSection ? 'rotate-180' : ''}`}>
              <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </div>
          </div>
        </div>
      )}

      {/* Profit Target Section - Premium Design - Oculto em modo B3 */}
      {!isB3Mode && showTargetSection && (
        <div className="glass-card border-2 border-primary/30 p-5 space-y-4 relative overflow-hidden backdrop-blur-xl animate-in fade-in-0 slide-in-from-top-2 duration-300">
        <div className="absolute inset-0 gradient-premium opacity-5 pointer-events-none"></div>
        
        <div className="relative space-y-4">
          {/* Target Label */}
          <Label className="text-[10px] sm:text-xs uppercase tracking-widest text-muted-foreground font-semibold text-center block">
            ALVO DE LUCRO
          </Label>

          {/* Input e Display combinados */}
          <div className="space-y-3">
            {/* Input numérico */}
            <div className="flex items-center gap-2">
              <Label htmlFor="profit-target-input" className="text-xs text-muted-foreground whitespace-nowrap">
                Valor:
              </Label>
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-primary font-bold">$</span>
                <Input
                  id="profit-target-input"
                  type="number"
                  min="1"
                  max="100"
                  step="0.5"
                  value={profitTarget}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    if (!isNaN(val) && val >= 1 && val <= 100) {
                      setProfitTarget(val);
                    }
                  }}
                  className="pl-7 bg-input border-primary/30 text-center font-bold text-lg"
                />
              </div>
            </div>

            {/* Slider */}
            <div className="space-y-2">
              <input
                type="range"
                min="1"
                max="100"
                step="0.5"
                value={profitTarget}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  setProfitTarget(val);
                }}
                className="w-full h-2 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-primary [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:transition-all [&::-webkit-slider-thumb]:hover:scale-125 [&::-webkit-slider-thumb]:shadow-glow [&::-moz-range-thumb]:w-5 [&::-moz-range-thumb]:h-5 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-primary [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:cursor-pointer"
                style={{
                  background: `linear-gradient(to right, hsl(var(--primary)) 0%, hsl(var(--primary)) ${((profitTarget - 1) / 99) * 100}%, hsl(var(--border) / 0.3) ${((profitTarget - 1) / 99) * 100}%, hsl(var(--border) / 0.3) 100%)`
                }}
              />
              
              <div className="flex justify-between text-[10px] text-muted-foreground/60">
                <span>$1</span>
                <span>$100</span>
              </div>
            </div>

            {/* Botão de Atualizar (só aparece durante operação) */}
            {isOperating && operationData && (
              <Button
                onClick={async () => {
                  // Atualizar estado local
                  setOperationData({
                    ...operationData,
                    profitTarget: profitTarget
                  });
                  
                  // Atualizar no banco
                  const { error } = await supabase
                    .from("active_operations")
                    .update({ profit_target: profitTarget })
                    .eq("id", operationData.id);
                  
                  if (!error) {
                    toast({
                      title: "✅ Alvo atualizado",
                      description: `Nova meta: $${profitTarget.toFixed(2)}`,
                    });
                  } else {
                    toast({
                      title: "Erro",
                      description: "Não foi possível atualizar o alvo",
                      variant: "destructive",
                    });
                  }
                }}
                variant="outline"
                className="w-full border-2 border-primary text-primary hover:bg-primary/10 font-bold transition-all hover:scale-105"
              >
                Atualizar Meta
              </Button>
            )}
          </div>

          {/* Auto Close Toggle */}
          <div className="flex items-center justify-between pt-3 border-t border-primary/10">
            <div className="space-y-0.5">
              <Label htmlFor="auto-close" className="text-xs font-semibold text-foreground">
                Saída Automática
              </Label>
              <p className="text-[10px] text-muted-foreground leading-tight">
                {autoCloseEnabled 
                  ? "Encerra ao atingir o alvo" 
                  : "Continua após atingir o alvo"}
              </p>
            </div>
            <Switch
              id="auto-close"
              checked={autoCloseEnabled}
              onCheckedChange={(checked) => {
                setAutoCloseEnabled(checked);
                // Atualizar na operação ativa se estiver operando
                if (isOperating && operationData) {
                  setOperationData({
                    ...operationData,
                    autoCloseEnabled: checked
                  });
                  supabase
                    .from("active_operations")
                    .update({ auto_close_enabled: checked })
                    .eq("id", operationData.id);
                }
              }}
            />
          </div>
        </div>
      </div>
      )}

      {/* Modo Automático - Dialog */}
      {showAutoModeDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="max-w-lg w-full max-h-[90vh] overflow-y-auto p-4 space-y-3 animate-in fade-in-0 zoom-in-95 duration-200 shadow-2xl border-2 border-gold">
            {/* Header */}
            <div className="flex items-center gap-3 pb-3 border-b border-border">
              <div className="p-2 rounded-lg bg-primary/10">
                <Zap className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-bold text-base">🤖 Modo Automático</h3>
                <p className="text-[10px] text-muted-foreground">Configure o robô de trading</p>
              </div>
            </div>
            
            {/* Tipo de Operação */}
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold">Tipo de Operação</Label>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  type="button"
                  onClick={() => setAutoModeIsTest(true)}
                  variant={autoModeIsTest ? "default" : "outline"}
                  size="sm"
                  className="h-9"
                >
                  🧪 Teste
                </Button>
                <Button
                  type="button"
                  onClick={() => setAutoModeIsTest(false)}
                  variant={!autoModeIsTest ? "default" : "outline"}
                  size="sm"
                  className="h-9"
                >
                  💰 Real
                </Button>
              </div>
            </div>
            
            {/* Grid Compacto - Quantidade e Meta */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold">Operações</Label>
                <Select value={autoModeTarget.toString()} onValueChange={(val) => setAutoModeTarget(parseInt(val) as 5 | 10 | 15)}>
                  <SelectTrigger className="h-9 border-gold">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5x</SelectItem>
                    <SelectItem value="10">10x</SelectItem>
                    <SelectItem value="15">15x</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-1.5">
                <Label htmlFor="auto-profit" className="text-xs font-semibold">Meta ($)</Label>
                <Input
                  id="auto-profit"
                  type="number"
                  min="1"
                  max="100"
                  step="0.5"
                  value={autoModeProfitTarget}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    if (!isNaN(val) && val >= 1 && val <= 100) {
                      setAutoModeProfitTarget(val);
                    }
                  }}
                  className="h-9 text-center border-gold"
                />
              </div>
            </div>
            
            {/* Valor de Investimento */}
            <div className="space-y-1.5">
              <Label htmlFor="auto-amount" className="text-xs font-semibold">Valor por Operação ($)</Label>
              <Input
                id="auto-amount"
                type="number"
                min="10"
                max="100000"
                step="10"
                value={autoModeAmount}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  if (!isNaN(val) && val >= 10 && val <= 100000) {
                    setAutoModeAmount(val);
                  }
                }}
                className="h-9 text-center border-gold"
              />
            </div>
            
            {/* Alavancagens */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="auto-lev-long" className="text-xs font-semibold text-profit">LONG</Label>
                <Input
                  id="auto-lev-long"
                  type="number"
                  min="1"
                  max="125"
                  value={autoModeLeverageLong}
                  onChange={(e) => {
                    const val = parseInt(e.target.value);
                    if (!isNaN(val) && val >= 1 && val <= 125) {
                      setAutoModeLeverageLong(val);
                    }
                  }}
                  className="h-9 text-center border-gold"
                />
              </div>
              
              <div className="space-y-1.5">
                <Label htmlFor="auto-lev-short" className="text-xs font-semibold text-loss">SHORT</Label>
                <Input
                  id="auto-lev-short"
                  type="number"
                  min="1"
                  max="125"
                  value={autoModeLeverageShort}
                  onChange={(e) => {
                    const val = parseInt(e.target.value);
                    if (!isNaN(val) && val >= 1 && val <= 125) {
                      setAutoModeLeverageShort(val);
                    }
                  }}
                  className="h-9 text-center border-gold"
                />
              </div>
            </div>
            
            {/* Botões de Ação */}
            <div className="flex gap-2 pt-2">
              <Button 
                onClick={() => setShowAutoModeDialog(false)} 
                variant="outline"
                size="sm"
                className="flex-1 h-10"
              >
                Cancelar
              </Button>
              <Button 
                onClick={startAutoMode}
                size="sm"
                className="flex-1 h-10 bg-primary hover:bg-primary/90"
              >
                <Zap className="w-3.5 h-3.5 mr-1.5" />
                Iniciar
              </Button>
            </div>
          </Card>
        </div>
      )}

      {/* Indicador de Modo Automático Ativo */}
      {autoModeEnabled && (
        <Card className="p-4 border-2 border-primary bg-gradient-to-r from-primary/10 to-primary/5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-full bg-primary/20 ${!autoModePaused && 'animate-pulse'}`}>
                <Zap className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h4 className="font-semibold text-sm">
                  🤖 Modo Automático {autoModePaused ? "Pausado" : "Ativo"}
                </h4>
                <p className="text-xs text-muted-foreground">
                  Operações: {autoModeOperationsCompleted} / {autoModeTarget}
                  {isAnalyzingPairs && " • Analisando..."}
                  {autoModePaused && " • Pausado"}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={async () => {
                  const newPausedState = !autoModePaused;
                  setAutoModePaused(newPausedState);
                  
                  // Atualizar no banco
                  const { data: { user } } = await supabase.auth.getUser();
                  if (user) {
                    await supabase.from("active_operations")
                      .update({ auto_mode_paused: newPausedState })
                      .eq('user_id', user.id)
                      .eq('trading_mode', isB3Mode ? 'b3' : 'crypto');
                  }
                  
                  toast({
                    title: autoModePaused ? "▶️ Robô Retomado" : "⏸️ Robô Pausado",
                    description: autoModePaused 
                      ? "O robô continuará as operações" 
                      : "O robô não iniciará novas operações",
                  });
                }}
                variant="outline"
                size="sm"
                className="text-xs border-gold"
              >
                {autoModePaused ? (
                  <>
                    <Play className="w-3 h-3 mr-1" />
                    Retomar
                  </>
                ) : (
                  <>
                    <Pause className="w-3 h-3 mr-1" />
                    Pausar
                  </>
                )}
              </Button>
              <Button
                onClick={stopAutoMode}
                variant="destructive"
                size="sm"
                className="text-xs"
              >
                <Square className="w-3 h-3 mr-1" />
                Parar
              </Button>
            </div>
          </div>
          
          {/* Barra de progresso */}
          <div className="mt-3 w-full bg-border/30 rounded-full h-2 overflow-hidden">
            <div 
              className="h-full bg-primary transition-all duration-500 rounded-full"
              style={{ width: `${(autoModeOperationsCompleted / autoModeTarget) * 100}%` }}
            />
          </div>
        </Card>
      )}

      <div className="flex flex-col gap-2 pt-2 sm:pt-4">
        {!isOperating ? (
          <>
            {userCredits === 0 && !isB3Mode && (
              <div className="bg-destructive/10 border border-destructive/50 rounded-lg p-3 mb-2">
                <p className="text-xs text-destructive font-medium">
                  ⚠️ Sem créditos! Apenas operações de teste disponíveis.
                </p>
                <button 
                  onClick={() => {
                    onNavigateToCredits?.();
                  }}
                  className="text-xs text-primary underline mt-1 hover:text-primary/80"
                >
                  Clique aqui para adquirir créditos
                </button>
              </div>
            )}
            {isB3Mode && (
              <div className="bg-primary/10 border border-primary/50 rounded-lg p-3 mb-2">
                <p className="text-xs text-primary font-medium">
                  🇧🇷 Modo B3 - Execução de ordens desativada. Apenas análise de correlação e ratio.
                </p>
              </div>
            )}
            {!isB3Mode ? (
              <>
                {/* Botão Modo Automático */}
                {!autoModeEnabled && (
                  <Button 
                    onClick={() => setShowAutoModeDialog(true)}
                    className="w-full h-10 bg-primary hover:bg-primary/90 text-white font-medium rounded-lg shadow-md transition-all duration-200 text-xs"
                  >
                    <Zap className="w-3.5 h-3.5 mr-1.5" />
                    <span>🤖 Modo Automático</span>
                  </Button>
                )}
                
                {/* Separador */}
                <div className="flex items-center gap-2 py-1">
                  <div className="flex-1 h-px bg-border/50"></div>
                  <span className="text-[9px] text-muted-foreground/70">manual</span>
                  <div className="flex-1 h-px bg-border/50"></div>
                </div>
                
                {/* Grid de Botões Manuais */}
                <div className="grid grid-cols-2 gap-2">
                  {/* Operação Real */}
                  <Button 
                    onClick={handleStart} 
                    disabled={userCredits === 0 || autoModeEnabled}
                    className="h-16 bg-profit hover:bg-profit/90 text-white font-medium rounded-lg shadow-md transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed p-1.5"
                  >
                    <div className="flex flex-col items-center justify-center gap-1">
                      <Play className="w-5 h-5" />
                      <div className="text-[11px] font-semibold">Real</div>
                      <div className="text-[8px] opacity-75 leading-tight">
                        {userCredits === 0 ? "Sem créditos" : "-1 crédito"}
                      </div>
                    </div>
                  </Button>
                  
                  {/* Operação Teste */}
                  <Button 
                    onClick={handleTestStart} 
                    disabled={autoModeEnabled}
                    className="h-16 bg-card hover:bg-card/90 text-primary font-medium rounded-lg shadow-md transition-all duration-200 border border-primary/30 disabled:opacity-50 p-1.5"
                  >
                    <div className="flex flex-col items-center justify-center gap-1">
                      <Play className="w-5 h-5" />
                      <div className="text-[11px] font-semibold">Teste</div>
                      <div className="text-[8px] opacity-70 leading-tight">Grátis</div>
                    </div>
                  </Button>
                </div>
              </>
            ) : (
              <Button 
                disabled
                className="w-full bg-primary/50 text-white text-xs sm:text-sm h-9 sm:h-10 cursor-not-allowed"
              >
                <Play className="w-3 h-3 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" />
                Modo B3 - Apenas Análise
              </Button>
            )}
          </>
        ) : (
          <Button 
            onClick={() => {
              if (autoModeEnabled) {
                stopAutoMode();
              }
              handleStop(false);
            }} 
            variant="destructive"
            className="w-full text-xs sm:text-sm h-9 sm:h-10"
          >
            <Square className="w-3 h-3 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" />
            {autoModeEnabled ? "Parar Modo Automático" : "Encerrar Operação"}
          </Button>
        )}
      </div>
    </div>
  );
};
