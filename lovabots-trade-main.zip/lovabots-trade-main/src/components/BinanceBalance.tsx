import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Wallet, TrendingUp, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useBinanceWebSocket } from "@/hooks/useBinanceWebSocket";

export const BinanceBalance = () => {
  const [balance, setBalance] = useState<number | null>(null);
  const [dailyPnl, setDailyPnl] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // WebSocket para PnL não realizado em tempo real
  const { accountData, isConnected } = useBinanceWebSocket(true);
  
  // Calcular PnL não realizado total em tempo real
  // Somar TODAS as posições com positionAmount diferente de 0
  const unrealizedPnl = accountData?.positions?.reduce((total, pos) => {
    const hasPosition = parseFloat(pos.positionAmount || '0') !== 0;
    if (!hasPosition) return total;
    return total + parseFloat(pos.unrealizedProfit || '0');
  }, 0) || 0;

  useEffect(() => {
    fetchDailyPnl();
    fetchBalance(); // Buscar saldo inicial
  }, []);

  const fetchDailyPnl = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const { data } = await supabase
      .from("trade_history")
      .select("profit")
      .eq("user_id", user.id)
      .gte("ended_at", today.toISOString());

    if (data) {
      const total = data.reduce((sum, trade) => sum + Number(trade.profit), 0);
      setDailyPnl(total);
    }
  };

  const fetchBalance = async () => {
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('binance-trading', {
        body: { action: 'get_account' }
      });

      if (error || !data?.success) {
        throw new Error(data?.error || 'Erro ao buscar saldo');
      }

      const accountBalance = parseFloat(data.data.totalWalletBalance);
      setBalance(accountBalance);
      
      toast({
        title: "Saldo atualizado",
        description: "Saldo da Binance carregado com sucesso",
      });
    } catch (error) {
      toast({
        title: "Erro ao buscar saldo",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <Card className="glass-card p-4 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Wallet className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="font-bold text-lg">Saldo Binance</h3>
              <p className="text-xs text-muted-foreground">Carteira de futuros</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={fetchBalance}
            disabled={isLoading}
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="flex items-center gap-2 text-muted-foreground">
              <Wallet className="w-4 h-4" />
              Saldo Total (USDT)
            </Label>
            <div className="p-4 bg-muted/50 rounded-lg">
              {balance !== null ? (
                <p className="font-bold text-2xl text-primary">
                  ${balance.toFixed(2)}
                </p>
              ) : (
                <p className="text-muted-foreground">
                  Clique em atualizar para carregar
                </p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2 text-muted-foreground">
              <TrendingUp className="w-4 h-4" />
              PnL Não Realizado {isConnected && <span className="w-2 h-2 rounded-full bg-profit animate-pulse ml-1"></span>}
            </Label>
            <div className="p-4 bg-muted/50 rounded-lg">
              <p className={`font-bold text-2xl ${unrealizedPnl >= 0 ? 'text-profit' : 'text-loss'} animate-pulse-subtle`}>
                ${unrealizedPnl.toFixed(2)}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Atualização em tempo real via WebSocket
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2 text-muted-foreground">
              <TrendingUp className="w-4 h-4" />
              Ganhos do Dia
            </Label>
            <div className="p-4 bg-muted/50 rounded-lg">
              <p className={`font-bold text-2xl ${dailyPnl >= 0 ? 'text-profit' : 'text-loss'}`}>
                ${dailyPnl.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};