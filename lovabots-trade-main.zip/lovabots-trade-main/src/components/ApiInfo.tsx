import { Card } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Key, Info, CheckCircle } from "lucide-react";

export const ApiInfo = () => {
  return (
    <div className="space-y-4">
      <Alert className="bg-primary/10 border-primary/20">
        <Info className="w-5 h-5 text-primary" />
        <AlertDescription className="text-foreground">
          <strong>Configuração de API</strong>
          <p className="mt-2 text-sm">
            As chaves da Binance API são configuradas diretamente no Lovable Cloud através de variáveis de ambiente seguras.
          </p>
        </AlertDescription>
      </Alert>

      <Card className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-3 pb-4 border-b border-border">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
            <Key className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="font-bold text-lg">Chaves Binance API</h3>
            <p className="text-sm text-muted-foreground">Gerenciadas pelo Cloud Secrets</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-start gap-3 p-3 bg-background/50 rounded-lg">
            <CheckCircle className="w-5 h-5 text-profit shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-sm">Configuração Atual</p>
              <p className="text-xs text-muted-foreground mt-1">
                As chaves <code className="bg-muted px-1 py-0.5 rounded">BINANCE_API_KEY</code> e{" "}
                <code className="bg-muted px-1 py-0.5 rounded">BINANCE_API_SECRET</code> estão configuradas no Cloud → Secrets
              </p>
            </div>
          </div>

          <div className="space-y-2 p-4 bg-muted/30 rounded-lg">
            <p className="font-medium text-sm">Requisitos da API Binance:</p>
            <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-2">
              <li>Habilitar Futures Trading</li>
              <li>Permitir leitura de dados da conta</li>
              <li>Permitir criação e gerenciamento de ordens</li>
              <li>NÃO habilitar permissões de saque</li>
            </ul>
          </div>

          <Alert className="bg-amber-500/10 border-amber-500/20">
            <Info className="w-4 h-4 text-amber-500" />
            <AlertDescription className="text-xs">
              <strong>Importante:</strong> Por segurança, nunca habilite permissões de saque (withdrawal) nas suas chaves API.
            </AlertDescription>
          </Alert>
        </div>
      </Card>
    </div>
  );
};
