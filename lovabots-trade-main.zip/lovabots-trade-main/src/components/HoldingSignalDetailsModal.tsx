import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Loader2, Sparkles, CheckCircle, AlertCircle } from "lucide-react";
import { HoldingSignal } from "@/hooks/useHoldingScanner";
import { TradingViewChart } from "./TradingViewChart";
import { ADXIndicatorChart } from "./ADXIndicatorChart";
import { ChandelierExitChart } from "./ChandelierExitChart";
import { Card } from "@/components/ui/card";

interface HoldingSignalDetailsModalProps {
  signal: HoldingSignal | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenTrade: (signal: HoldingSignal, isTest: boolean) => void;
  isLoading: boolean;
  disabled: boolean;
}

export const HoldingSignalDetailsModal = ({
  signal,
  isOpen,
  onClose,
  onOpenTrade,
  isLoading,
  disabled,
}: HoldingSignalDetailsModalProps) => {
  if (!signal) return null;

  const isLong = signal.direction === "LONG";

  const getQualityStyle = () => {
    switch (signal.quality) {
      case "Excelente":
        return {
          bg: "bg-green-500/10",
          border: "border-green-500/30",
          text: "text-green-400",
          icon: <Sparkles className="h-4 w-4" />,
          description: "Todos os indicadores alinhados perfeitamente",
        };
      case "Bom":
        return {
          bg: "bg-blue-500/10",
          border: "border-blue-500/30",
          text: "text-blue-400",
          icon: <CheckCircle className="h-4 w-4" />,
          description: "Indicadores mostram boa confluência",
        };
      default:
        return {
          bg: "bg-amber-500/10",
          border: "border-amber-500/30",
          text: "text-amber-400",
          icon: <AlertCircle className="h-4 w-4" />,
          description: "Confluência moderada dos indicadores",
        };
    }
  };

  const qualityStyle = getQualityStyle();

  const getConditionColor = (condition: string) => {
    if (condition === "Favorável" || condition === "Forte") {
      return "text-green-400 bg-green-500/10 border-green-500/30";
    }
    if (condition === "Moderado" || condition === "Neutro") {
      return "text-amber-400 bg-amber-500/10 border-amber-500/30";
    }
    return "text-muted-foreground bg-muted/20 border-border/30";
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[95vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-4">
            <div className={`p-3 rounded-xl ${isLong ? "bg-green-500/10 border border-green-500/30" : "bg-red-500/10 border border-red-500/30"}`}>
              {isLong ? (
                <TrendingUp className="h-6 w-6 text-green-500" />
              ) : (
                <TrendingDown className="h-6 w-6 text-red-500" />
              )}
            </div>
            <div>
              <span className="text-2xl font-bold">{signal.symbol}</span>
              <div className="flex items-center gap-2 mt-1">
                <Badge className={`text-sm ${isLong ? "bg-green-600" : "bg-red-600"}`}>
                  {isLong ? "COMPRA" : "VENDA"}
                </Badge>
                <Badge variant="outline" className={`flex items-center gap-1 ${qualityStyle.bg} ${qualityStyle.border} ${qualityStyle.text}`}>
                  {qualityStyle.icon}
                  {signal.quality}
                </Badge>
              </div>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 mt-6">
          {/* Preço atual e qualidade */}
          <div className="flex items-center justify-between p-5 bg-gradient-to-r from-card to-muted/20 rounded-xl border border-border/40">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Preço Atual</p>
              <p className="text-3xl font-bold font-mono">${signal.currentPrice.toFixed(4)}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground mb-1">Avaliação do Momento</p>
              <p className={`text-base font-medium ${qualityStyle.text}`}>{qualityStyle.description}</p>
            </div>
          </div>

          {/* Indicadores resumo - Descritivos */}
          <div className="grid grid-cols-4 gap-4">
            <Card className={`p-4 text-center border-2 ${signal.chandelierTrend === signal.direction ? "border-green-500/40 bg-green-500/5" : "border-red-500/40 bg-red-500/5"}`}>
              <p className="text-xs text-muted-foreground mb-2">🎯 Tendência</p>
              <p className={`text-xl font-bold ${signal.chandelierTrend === "LONG" ? "text-green-400" : "text-red-400"}`}>
                {signal.chandelierTrend === "LONG" ? "Alta" : "Baixa"}
              </p>
              <p className="text-xs text-muted-foreground mt-2">Chandelier Exit</p>
            </Card>
            <Card className={`p-4 text-center border-2 ${getConditionColor(signal.adxMomentum)}`}>
              <p className="text-xs text-muted-foreground mb-2">📊 Momentum</p>
              <p className="text-xl font-bold">{signal.adxMomentum}</p>
              <p className="text-xs text-muted-foreground mt-2">ADX</p>
            </Card>
            <Card className={`p-4 text-center border-2 ${getConditionColor(signal.rsiCondition)}`}>
              <p className="text-xs text-muted-foreground mb-2">⚡ Exaustão</p>
              <p className="text-xl font-bold">{signal.rsiCondition}</p>
              <p className="text-xs text-muted-foreground mt-2">RSI</p>
            </Card>
            <Card className={`p-4 text-center border-2 ${getConditionColor(signal.diAlignment)}`}>
              <p className="text-xs text-muted-foreground mb-2">🧭 Direção</p>
              <p className="text-xl font-bold">{signal.diAlignment}</p>
              <p className="text-xs text-muted-foreground mt-2">+DI / -DI</p>
            </Card>
          </div>

          {/* Razão do sinal */}
          <div className="p-4 bg-gradient-to-r from-primary/5 to-transparent rounded-xl border border-primary/20 text-center">
            <p className="text-sm font-medium text-foreground">{signal.signalReason}</p>
          </div>

          {/* Gráfico TradingView - Tamanho grande igual ao Trading */}
          <Card className="p-4 bg-card/40 border-border/30">
            <div className="flex items-center gap-2 mb-3">
              <div className={`h-2 w-2 rounded-full ${isLong ? 'bg-green-500' : 'bg-red-500'} animate-pulse`} />
              <span className="text-sm font-medium text-foreground">
                {signal.symbol}
              </span>
              <Badge variant="outline" className={`text-xs ${isLong ? 'border-green-500/30 text-green-500' : 'border-red-500/30 text-red-500'}`}>
                15min
              </Badge>
            </div>
            <TradingViewChart symbol={signal.symbol} className="h-[600px]" />
          </Card>

          {/* Indicadores lado a lado */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* ADX Chart */}
            <Card className="p-5 border-border/40 bg-card/80">
              <ADXIndicatorChart 
                symbol={signal.symbol} 
                settings={{ adxPeriod: 14, adxSmoothing: 14 }} 
              />
            </Card>

            {/* Chandelier Exit */}
            <Card className="p-5 border-border/40 bg-card/80">
              <ChandelierExitChart 
                symbol={signal.symbol} 
                settings={{ chandelierPeriod: 22, chandelierMultiplier: 3 }} 
              />
            </Card>
          </div>

          {/* Botões de ação */}
          <div className="flex gap-4 pt-4 sticky bottom-0 bg-background/95 backdrop-blur-sm py-4 -mx-6 px-6 border-t border-border/30">
            <Button
              variant="outline"
              className="flex-1 h-12"
              onClick={onClose}
            >
              Fechar
            </Button>
            <Button
              variant="outline"
              className="flex-1 h-12"
              onClick={() => onOpenTrade(signal, true)}
              disabled={isLoading || disabled}
            >
              🧪 Modo Teste
            </Button>
            <Button
              className={`flex-1 h-12 text-base font-bold ${isLong ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"}`}
              onClick={() => onOpenTrade(signal, false)}
              disabled={isLoading || disabled}
            >
              {isLoading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <>
                  {isLong ? <TrendingUp className="h-5 w-5 mr-2" /> : <TrendingDown className="h-5 w-5 mr-2" />}
                  Abrir {isLong ? "Compra" : "Venda"}
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
