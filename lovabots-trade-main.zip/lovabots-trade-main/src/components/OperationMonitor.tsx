import { useEffect, useState, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { TrendingUp, TrendingDown, Clock, Activity, Edit2, Check } from "lucide-react";
import { useBinancePrices } from "@/hooks/useBinancePrices";
import { useFundingRate } from "@/hooks/useFundingRate";
import { formatPrice } from "@/utils/priceFormatter";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { MomentumIndicator } from "./MomentumIndicator";
interface OperationMonitorProps {
  longSymbol: string;
  shortSymbol: string;
  leverageLong: number;
  leverageShort: number;
  amount: number;
  entryPriceLong: number;
  entryPriceShort: number;
  startTime: Date;
  onPnlUpdate: (pnl: number) => void;
  onTargetReached?: () => void;
  profitTarget: number;
  autoCloseEnabled: boolean;
  isTest?: boolean;
  operationId?: string;
  onAutoCloseChange?: (enabled: boolean) => void;
  onProfitTargetChange?: (target: number) => void;
}

export const OperationMonitor = ({
  longSymbol,
  shortSymbol,
  leverageLong: initialLeverageLong,
  leverageShort: initialLeverageShort,
  amount,
  entryPriceLong: initialEntryPriceLong,
  entryPriceShort: initialEntryPriceShort,
  startTime,
  onPnlUpdate,
  onTargetReached,
  profitTarget,
  autoCloseEnabled,
  isTest = false,
  operationId,
  onAutoCloseChange,
  onProfitTargetChange,
}: OperationMonitorProps) => {
  const [entryPriceLong, setEntryPriceLong] = useState(initialEntryPriceLong);
  const [entryPriceShort, setEntryPriceShort] = useState(initialEntryPriceShort);
  const [isFetchingEntryPrices, setIsFetchingEntryPrices] = useState(false);
  const [entryPriceAttempts, setEntryPriceAttempts] = useState(0);
  const MAX_ENTRY_PRICE_ATTEMPTS = 15;
  
  // PnL real da Binance (para operações reais)
  const [realLongPnl, setRealLongPnl] = useState<number | null>(null);
  const [realShortPnl, setRealShortPnl] = useState<number | null>(null);
  
  const [isEditingTarget, setIsEditingTarget] = useState(false);
  const [editedTarget, setEditedTarget] = useState(profitTarget.toString());
  const [localAutoClose, setLocalAutoClose] = useState(autoCloseEnabled);
  const [isTogglingAutoClose, setIsTogglingAutoClose] = useState(false);
  
  useEffect(() => {
    setLocalAutoClose(autoCloseEnabled);
  }, [autoCloseEnabled]);
  
  const { prices } = useBinancePrices([longSymbol, shortSymbol]);
  
  const longPositionSize = (amount / 2) * initialLeverageLong;
  const shortPositionSize = (amount / 2) * initialLeverageShort;
  
  const { fundingRates } = useFundingRate(
    [longSymbol, shortSymbol], 
    {
      [longSymbol]: longPositionSize,
      [shortSymbol]: shortPositionSize,
    }
  );
  
  const [elapsed, setElapsed] = useState("");
  
  const targetReachedCalledRef = useRef(false);

  useEffect(() => {
    if (initialEntryPriceLong > 0) {
      setEntryPriceLong(initialEntryPriceLong);
    }
  }, [initialEntryPriceLong]);

  useEffect(() => {
    if (initialEntryPriceShort > 0) {
      setEntryPriceShort(initialEntryPriceShort);
    }
  }, [initialEntryPriceShort]);

  // Buscar preços atuais do WebSocket
  const wsLongPrice = prices.find(p => p.symbol === longSymbol)?.price;
  const wsShortPrice = prices.find(p => p.symbol === shortSymbol)?.price;
  
  // VALIDAÇÃO CRÍTICA: Só usar preço do WebSocket se for válido e razoável
  const isValidWsLongPrice = wsLongPrice && wsLongPrice > 0;
  const isValidWsShortPrice = wsShortPrice && wsShortPrice > 0;
  
  // Usar preço do WebSocket apenas se disponível, senão manter preço de entrada
  const currentLongPrice = isValidWsLongPrice ? wsLongPrice : entryPriceLong;
  const currentShortPrice = isValidWsShortPrice ? wsShortPrice : entryPriceShort;
  
  // Validação estrita dos preços de entrada
  const hasValidLongEntry = entryPriceLong > 0;
  const hasValidShortEntry = entryPriceShort > 0;
  const hasValidCurrentPrices = currentLongPrice > 0 && currentShortPrice > 0;
  const hasValidEntryPrices = hasValidLongEntry && hasValidShortEntry && hasValidCurrentPrices;

  const longMargin = amount / 2;
  const shortMargin = amount / 2;
  
  const longNotional = longMargin * initialLeverageLong;
  const shortNotional = shortMargin * initialLeverageShort;

  // CÁLCULO DE PNL - USAR PNL REAL DA BINANCE PARA OPERAÇÕES REAIS
  // Para operações de teste, calcular baseado nos preços
  const MAX_PRICE_CHANGE = 0.10; // 10%
  
  let longPnl = 0;
  let shortPnl = 0;
  let longPnlPercent = 0;
  let shortPnlPercent = 0;
  
  if (!isTest && realLongPnl !== null && realShortPnl !== null) {
    // OPERAÇÃO REAL: Usar PnL direto da Binance (mais preciso)
    longPnl = realLongPnl;
    shortPnl = realShortPnl;
    
    // Calcular percentuais baseado no nocional
    longPnlPercent = longNotional > 0 ? (longPnl / longNotional) * 100 : 0;
    shortPnlPercent = shortNotional > 0 ? (shortPnl / shortNotional) * 100 : 0;
  } else if (hasValidEntryPrices) {
    // OPERAÇÃO TESTE ou fallback: Calcular manualmente
    const rawLongChange = (currentLongPrice - entryPriceLong) / entryPriceLong;
    const longPriceChange = Math.max(-MAX_PRICE_CHANGE, Math.min(MAX_PRICE_CHANGE, rawLongChange));
    
    const rawShortChange = (entryPriceShort - currentShortPrice) / entryPriceShort;
    const shortPriceChange = Math.max(-MAX_PRICE_CHANGE, Math.min(MAX_PRICE_CHANGE, rawShortChange));
    
    longPnl = longPriceChange * longNotional;
    shortPnl = shortPriceChange * shortNotional;
    
    longPnlPercent = longPriceChange * 100;
    shortPnlPercent = shortPriceChange * 100;
  }

  // PnL total com limite absoluto baseado no investimento
  const rawTotalPnl = longPnl + shortPnl;
  const totalPnl = Math.max(-amount, Math.min(amount, rawTotalPnl));

  // BUSCAR PNL REAL DA BINANCE PERIODICAMENTE (apenas para operações reais)
  useEffect(() => {
    if (isTest) {
      // Para operações de teste, não buscar da Binance
      return;
    }

    const fetchRealPnl = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('binance-trading', {
          body: { action: 'get_positions' }
        });

        // Em caso de erro, manter valores anteriores (não piscar para 0)
        if (error || !data?.success) {
          return;
        }

        const positions = Array.isArray(data.data?.positions) ? data.data.positions : [];
        
        // Se não houver posições, manter valores anteriores
        if (!positions.length) {
          return;
        }
        
        const longPosition = positions.find((p: any) => 
          p.symbol === longSymbol && parseFloat(p.positionAmt) !== 0
        );
        const shortPosition = positions.find((p: any) => 
          p.symbol === shortSymbol && parseFloat(p.positionAmt) !== 0
        );

        // CORREÇÃO: usar unrealizedProfit (minúsculo) conforme retorno da API
        if (longPosition) {
          const pnl = parseFloat(longPosition.unrealizedProfit || '0');
          setRealLongPnl(pnl);
        }

        if (shortPosition) {
          const pnl = parseFloat(shortPosition.unrealizedProfit || '0');
          setRealShortPnl(pnl);
        }
      } catch (err) {
        // Em caso de exceção, manter valores anteriores
        console.error('❌ Erro ao buscar PnL real:', err);
      }
    };

    // Buscar imediatamente
    fetchRealPnl();
    
    // Buscar a cada 3 segundos
    const interval = setInterval(fetchRealPnl, 3000);
    
    return () => clearInterval(interval);
  }, [isTest, longSymbol, shortSymbol]);

  useEffect(() => {
    const fetchEntryPricesFromPositions = async () => {
      if ((entryPriceLong > 0 && entryPriceShort > 0) || isFetchingEntryPrices) {
        return;
      }

      if (entryPriceAttempts >= MAX_ENTRY_PRICE_ATTEMPTS) {
        console.warn('⛔ Máximo de tentativas para buscar entry prices atingido.');
        return;
      }

      setIsFetchingEntryPrices(true);

      try {
        const { data, error } = await supabase.functions.invoke('binance-trading', {
          body: { action: 'get_positions' }
        });

        if (error || !data?.success) {
          return;
        }

        const positions = data.data?.positions || [];
        const longPosition = positions.find((p: any) => 
          p.symbol === longSymbol && parseFloat(p.positionAmt) !== 0
        );
        const shortPosition = positions.find((p: any) => 
          p.symbol === shortSymbol && parseFloat(p.positionAmt) !== 0
        );

        let foundLong = entryPriceLong > 0;
        let foundShort = entryPriceShort > 0;

        if (longPosition && parseFloat(longPosition.entryPrice) > 0 && entryPriceLong === 0) {
          setEntryPriceLong(parseFloat(longPosition.entryPrice));
          foundLong = true;
        }

        if (shortPosition && parseFloat(shortPosition.entryPrice) > 0 && entryPriceShort === 0) {
          setEntryPriceShort(parseFloat(shortPosition.entryPrice));
          foundShort = true;
        }

        if (operationId && (foundLong || foundShort)) {
          const updates: any = {};
          if (longPosition && entryPriceLong === 0 && foundLong) {
            updates.entry_price_long = parseFloat(longPosition.entryPrice);
          }
          if (shortPosition && entryPriceShort === 0 && foundShort) {
            updates.entry_price_short = parseFloat(shortPosition.entryPrice);
          }

          if (Object.keys(updates).length > 0) {
            const { data: { user } } = await supabase.auth.getUser();
            if (user) {
              await supabase
                .from('active_operations')
                .update(updates)
                .eq('id', operationId)
                .eq('user_id', user.id);
            }
          }
        }

        if (!foundLong || !foundShort) {
          setEntryPriceAttempts((prev) => prev + 1);
        }
      } catch (err) {
        setEntryPriceAttempts((prev) => prev + 1);
      } finally {
        setIsFetchingEntryPrices(false);
      }
    };

    const timer = setTimeout(fetchEntryPricesFromPositions, 2000);
    return () => clearTimeout(timer);
  }, [entryPriceLong, entryPriceShort, longSymbol, shortSymbol, operationId, isFetchingEntryPrices, entryPriceAttempts, MAX_ENTRY_PRICE_ATTEMPTS]);

  useEffect(() => {
    // Para operações reais com PnL da Binance, sempre atualizar
    if (!isTest && realLongPnl !== null && realShortPnl !== null) {
      onPnlUpdate(totalPnl);
      return;
    }
    
    // Para operações de teste, validar preços de entrada
    if (!hasValidEntryPrices) {
      onPnlUpdate(0);
      return;
    }
    onPnlUpdate(totalPnl);
  }, [totalPnl, hasValidEntryPrices, onPnlUpdate, isTest, realLongPnl, realShortPnl]);

  useEffect(() => {
    // Para operações reais, verificar se temos PnL da Binance
    const hasRealPnl = !isTest && realLongPnl !== null && realShortPnl !== null;
    
    // Para operações de teste, verificar preços de entrada
    if (!hasRealPnl && !hasValidEntryPrices) {
      return;
    }

    // REGRA: Adicionar buffer de 0.2% sobre o investimento antes de fechar
    // Ex: Meta 5% ($5 em $100) -> Fechar em 5.2% ($5.20)
    const bufferAmount = amount * 0.002; // 0.2% do investimento
    const targetWithBuffer = profitTarget + bufferAmount;

    if (autoCloseEnabled && totalPnl >= targetWithBuffer && onTargetReached && !targetReachedCalledRef.current) {
      console.log(`🎯 Meta atingida com buffer! PnL: $${totalPnl.toFixed(2)} >= Target+Buffer: $${targetWithBuffer.toFixed(2)}`);
      targetReachedCalledRef.current = true;
      onTargetReached();
    }
  }, [totalPnl, profitTarget, autoCloseEnabled, onTargetReached, hasValidEntryPrices, amount, isTest, realLongPnl, realShortPnl]);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const diff = now.getTime() - startTime.getTime();
      const hours = Math.floor(diff / 3600000);
      const minutes = Math.floor((diff % 3600000) / 60000);
      const seconds = Math.floor((diff % 60000) / 1000);
      setElapsed(`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
    }, 1000);

    return () => clearInterval(interval);
  }, [startTime]);

  const progressPercentage = Math.min(Math.max((totalPnl / profitTarget) * 100, 0), 100);

  const handleUpdateTarget = async () => {
    const newTarget = parseFloat(editedTarget);
    
    if (isNaN(newTarget) || newTarget <= 0) {
      toast.error("Meta inválida");
      setEditedTarget(profitTarget.toString());
      setIsEditingTarget(false);
      return;
    }

    if (!operationId) {
      toast.error("ID da operação não encontrado");
      setIsEditingTarget(false);
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error("Usuário não autenticado");
        return;
      }

      const { error } = await supabase
        .from('active_operations')
        .update({ profit_target: newTarget })
        .eq('id', operationId)
        .eq('user_id', user.id);

      if (error) throw error;

      toast.success(`Meta atualizada para $${newTarget.toFixed(2)}`);
      setIsEditingTarget(false);
    } catch (error) {
      console.error('Erro ao atualizar meta:', error);
      toast.error("Erro ao atualizar meta");
      setEditedTarget(profitTarget.toString());
      setIsEditingTarget(false);
    }
  };

  const handleToggleAutoClose = async () => {
    if (!operationId || isTogglingAutoClose) return;
    
    setIsTogglingAutoClose(true);
    const newValue = !localAutoClose;
    setLocalAutoClose(newValue);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error("Usuário não autenticado");
        setLocalAutoClose(!newValue);
        return;
      }

      const { error } = await supabase
        .from('active_operations')
        .update({ auto_close_enabled: newValue })
        .eq('id', operationId)
        .eq('user_id', user.id);

      if (error) throw error;

      toast.success(newValue ? "Saída automática ativada" : "Saída automática desativada");
      onAutoCloseChange?.(newValue);
    } catch (error) {
      console.error('Erro ao atualizar auto-close:', error);
      toast.error("Erro ao atualizar configuração");
      setLocalAutoClose(!newValue);
    } finally {
      setIsTogglingAutoClose(false);
    }
  };

  const handleTargetKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleUpdateTarget();
    } else if (e.key === 'Escape') {
      setEditedTarget(profitTarget.toString());
      setIsEditingTarget(false);
    }
  };

  return (
    <div className="space-y-3 sm:space-y-6 animate-fade-in">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-center gap-3 sm:gap-4">
          <div className="relative">
            <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl animate-pulse"></div>
            <div className="relative bg-gradient-to-br from-primary to-accent p-2.5 sm:p-4 rounded-xl sm:rounded-2xl shadow-2xl">
              <Activity className="w-5 h-5 sm:w-8 sm:h-8 text-primary-foreground" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 sm:gap-3 mb-1">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold tracking-tight">Operação Ativa</h2>
              {isTest && (
                <Badge className="bg-amber-500/20 text-amber-500 border border-amber-500/30 font-bold text-[10px] sm:text-xs px-2 sm:px-2.5">
                  TESTE
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2 sm:gap-3 text-muted-foreground">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span className="text-xs sm:text-sm font-mono font-bold">{elapsed}</span>
              </div>
              <span className="text-muted-foreground/50 text-xs sm:text-base">•</span>
              <Badge variant="outline" className="font-semibold text-[10px] sm:text-xs px-2 sm:px-2.5">
                <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-profit rounded-full mr-1.5 sm:mr-2 animate-pulse"></span>
                Ativo
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Main PnL Display */}
      <Card className="relative overflow-hidden border-2 border-primary/20 bg-gradient-to-br from-background via-background to-primary/5">
        <div className="absolute top-0 right-0 w-32 sm:w-64 h-32 sm:h-64 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="relative p-4 sm:p-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-8 items-center">
            {/* Total PnL */}
            <div className="lg:col-span-2">
              <p className="text-xs sm:text-sm font-bold text-muted-foreground uppercase tracking-widest mb-2 sm:mb-3">
                Lucro Total
              </p>
              <div className="flex items-baseline gap-2 sm:gap-4">
                <span className={`text-4xl sm:text-5xl md:text-6xl font-bold font-mono tracking-tight ${totalPnl >= 0 ? 'text-profit' : 'text-loss'}`}>
                  {hasValidEntryPrices ? `$${totalPnl.toFixed(2)}` : "$0.00"}
                </span>
                {hasValidEntryPrices && (
                  <span className={`text-xl sm:text-2xl font-bold font-mono ${totalPnl >= 0 ? 'text-profit' : 'text-loss'}`}>
                    {totalPnl >= 0 ? '+' : ''}{((totalPnl / amount) * 100).toFixed(2)}%
                  </span>
                )}
              </div>
              
              {/* Progress Bar */}
              <div className="mt-4 sm:mt-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] sm:text-xs font-bold text-muted-foreground uppercase tracking-wide">Progresso até a meta</span>
                  <span className="text-[10px] sm:text-xs font-bold text-primary">{progressPercentage.toFixed(1)}%</span>
                </div>
                <div className="relative h-2 sm:h-3 bg-muted/30 rounded-full overflow-hidden">
                  <div 
                    className={`absolute inset-y-0 left-0 rounded-full transition-all duration-700 ease-out ${
                      totalPnl >= 0 ? 'bg-gradient-to-r from-profit to-profit/80' : 'bg-gradient-to-r from-loss to-loss/80'
                    }`}
                    style={{ width: `${progressPercentage}%` }}
                  >
                    <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Target Info */}
            <div className="lg:border-l lg:border-border lg:pl-4 sm:lg:pl-8">
              <div className="space-y-3 sm:space-y-4">
                <div>
                  <p className="text-[10px] sm:text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1">
                    Meta de Lucro
                  </p>
                  {isEditingTarget ? (
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        value={editedTarget}
                        onChange={(e) => setEditedTarget(e.target.value)}
                        onKeyDown={handleTargetKeyDown}
                        onBlur={handleUpdateTarget}
                        className="text-2xl sm:text-3xl md:text-4xl font-bold font-mono h-auto py-1 px-2"
                        autoFocus
                      />
                      <button
                        onClick={handleUpdateTarget}
                        className="p-2 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors"
                      >
                        <Check className="w-5 h-5 text-primary" />
                      </button>
                    </div>
                  ) : (
                    <div
                      onClick={() => setIsEditingTarget(true)}
                      className="group flex items-center gap-2 cursor-pointer"
                    >
                      <p className="text-2xl sm:text-3xl md:text-4xl font-bold font-mono text-primary">
                        ${profitTarget.toFixed(2)}
                      </p>
                      <Edit2 className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  )}
                </div>
                <div>
                  <p className="text-[10px] sm:text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1">
                    Investimento Total
                  </p>
                  <p className="text-xl sm:text-2xl md:text-3xl font-bold font-mono">
                    ${amount.toFixed(2)}
                  </p>
                </div>
                <div className="pt-2 border-t border-border/50">
                  <div className="flex items-center justify-between">
                    <p className="text-[10px] sm:text-xs font-bold text-muted-foreground uppercase tracking-wider">
                      Saída Automática
                    </p>
                    <Switch
                      checked={localAutoClose}
                      onCheckedChange={handleToggleAutoClose}
                      disabled={isTogglingAutoClose}
                      className="data-[state=checked]:bg-profit"
                    />
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {localAutoClose ? "Fecha ao atingir meta" : "Desativada"}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Positions Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-2 sm:gap-3">
        {/* LONG Position */}
        <Card className="relative overflow-hidden border border-profit/30 bg-gradient-to-br from-background to-profit/5">
          <div className="absolute top-0 right-0 w-16 h-16 sm:w-20 sm:h-20 bg-profit/10 rounded-full blur-xl"></div>
          
          <div className="relative p-2 sm:p-3 space-y-2 sm:space-y-3">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <div className="bg-profit/20 p-1.5 sm:p-2 rounded-lg">
                  <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-profit" />
                </div>
                <div>
                  <div className="text-sm sm:text-lg font-bold text-profit">LONG</div>
                  <div className="text-[10px] sm:text-xs font-mono text-muted-foreground">{longSymbol}</div>
                </div>
              </div>
              
              <Badge className="bg-profit/20 text-profit border border-profit/30 px-1.5 sm:px-2 py-0.5 sm:py-1">
                <span className="text-xs sm:text-sm font-bold">{initialLeverageLong}x</span>
              </Badge>
            </div>

            {/* Metrics */}
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-1.5 sm:gap-2">
                <div className="bg-muted/30 rounded-lg p-1.5 sm:p-2">
                  <p className="text-[9px] sm:text-[10px] text-muted-foreground mb-0.5 uppercase tracking-wider">Investido</p>
                  <p className="text-xs sm:text-sm font-bold font-mono">${longMargin.toFixed(2)}</p>
                </div>
                <div className="bg-muted/30 rounded-lg p-1.5 sm:p-2">
                  <p className="text-[9px] sm:text-[10px] text-muted-foreground mb-0.5 uppercase tracking-wider">Alavancagem</p>
                  <p className="text-xs sm:text-sm font-bold font-mono">{initialLeverageLong}x</p>
                </div>
              </div>

              <div className="space-y-1 sm:space-y-1.5">
                <div className="flex items-center justify-between py-1 border-b border-border/50">
                  <span className="text-[10px] sm:text-xs text-muted-foreground">Entrada</span>
                  <span className="text-[10px] sm:text-xs font-mono font-semibold">
                    {hasValidLongEntry ? formatPrice(entryPriceLong) : "Carregando..."}
                  </span>
                </div>
                
                <div className="flex items-center justify-between py-1 border-b border-border/50">
                  <span className="text-[10px] sm:text-xs text-muted-foreground">Atual</span>
                  <span className="text-[10px] sm:text-xs font-mono font-bold text-profit animate-pulse">
                    {formatPrice(currentLongPrice)}
                  </span>
                </div>
              </div>

              {/* PnL Display */}
              <div className="bg-gradient-to-br from-profit/10 to-profit/5 rounded-lg p-2 sm:p-2.5 border border-profit/20">
                <p className="text-[9px] sm:text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1">
                  PnL
                </p>
                <div className="flex items-baseline gap-2">
                  <div className={`text-lg sm:text-2xl font-bold font-mono ${longPnl >= 0 ? "text-profit" : "text-loss"}`}>
                    {hasValidEntryPrices ? `$${longPnl.toFixed(2)}` : "$0.00"}
                  </div>
                  <div className={`text-xs sm:text-sm font-semibold ${longPnlPercent >= 0 ? "text-profit" : "text-loss"}`}>
                    {hasValidEntryPrices ? `${longPnlPercent >= 0 ? "+" : ""}${longPnlPercent.toFixed(2)}%` : "0.00%"}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* SHORT Position */}
        <Card className="relative overflow-hidden border border-loss/30 bg-gradient-to-br from-background to-loss/5">
          <div className="absolute top-0 right-0 w-16 h-16 sm:w-20 sm:h-20 bg-loss/10 rounded-full blur-xl"></div>
          
          <div className="relative p-2 sm:p-3 space-y-2 sm:space-y-3">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <div className="bg-loss/20 p-1.5 sm:p-2 rounded-lg">
                  <TrendingDown className="w-4 h-4 sm:w-5 sm:h-5 text-loss" />
                </div>
                <div>
                  <div className="text-sm sm:text-lg font-bold text-loss">SHORT</div>
                  <div className="text-[10px] sm:text-xs font-mono text-muted-foreground">{shortSymbol}</div>
                </div>
              </div>
              
              <Badge className="bg-loss/20 text-loss border border-loss/30 px-1.5 sm:px-2 py-0.5 sm:py-1">
                <span className="text-xs sm:text-sm font-bold">{initialLeverageShort}x</span>
              </Badge>
            </div>

            {/* Metrics */}
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-1.5 sm:gap-2">
                <div className="bg-muted/30 rounded-lg p-1.5 sm:p-2">
                  <p className="text-[9px] sm:text-[10px] text-muted-foreground mb-0.5 uppercase tracking-wider">Investido</p>
                  <p className="text-xs sm:text-sm font-bold font-mono">${shortMargin.toFixed(2)}</p>
                </div>
                <div className="bg-muted/30 rounded-lg p-1.5 sm:p-2">
                  <p className="text-[9px] sm:text-[10px] text-muted-foreground mb-0.5 uppercase tracking-wider">Alavancagem</p>
                  <p className="text-xs sm:text-sm font-bold font-mono">{initialLeverageShort}x</p>
                </div>
              </div>

              <div className="space-y-1 sm:space-y-1.5">
                <div className="flex items-center justify-between py-1 border-b border-border/50">
                  <span className="text-[10px] sm:text-xs text-muted-foreground">Entrada</span>
                  <span className="text-[10px] sm:text-xs font-mono font-semibold">
                    {hasValidShortEntry ? formatPrice(entryPriceShort) : "Carregando..."}
                  </span>
                </div>
                
                <div className="flex items-center justify-between py-1 border-b border-border/50">
                  <span className="text-[10px] sm:text-xs text-muted-foreground">Atual</span>
                  <span className="text-[10px] sm:text-xs font-mono font-bold text-loss animate-pulse">
                    {formatPrice(currentShortPrice)}
                  </span>
                </div>
              </div>

              {/* PnL Display */}
              <div className="bg-gradient-to-br from-loss/10 to-loss/5 rounded-lg p-2 sm:p-2.5 border border-loss/20">
                <p className="text-[9px] sm:text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1">
                  PnL
                </p>
                <div className="flex items-baseline gap-2">
                  <div className={`text-lg sm:text-2xl font-bold font-mono ${shortPnl >= 0 ? "text-profit" : "text-loss"}`}>
                    {hasValidEntryPrices ? `$${shortPnl.toFixed(2)}` : "$0.00"}
                  </div>
                  <div className={`text-xs sm:text-sm font-semibold ${shortPnlPercent >= 0 ? "text-profit" : "text-loss"}`}>
                    {hasValidEntryPrices ? `${shortPnlPercent >= 0 ? "+" : ""}${shortPnlPercent.toFixed(2)}%` : "0.00%"}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Gráficos de Momentum e Liquidez */}
      <Card className="p-4 bg-card/50 border-border/50">
        <MomentumIndicator
          longSymbol={longSymbol}
          shortSymbol={shortSymbol}
          entryTime={startTime}
        />
      </Card>
    </div>
  );
};