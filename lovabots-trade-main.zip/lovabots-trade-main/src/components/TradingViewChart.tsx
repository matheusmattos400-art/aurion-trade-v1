import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Settings, ChevronDown, ChevronUp } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ADXIndicatorChart } from "./ADXIndicatorChart";
import { ChandelierExitChart } from "./ChandelierExitChart";

interface TradingViewChartProps {
  symbol: string;
  className?: string;
}

interface IndicatorSettings {
  // Chandelier Exit settings
  chandelierPeriod: number;
  chandelierMultiplier: number;
  // ADX settings
  adxPeriod: number;
  adxSmoothing: number;
}

const defaultSettings: IndicatorSettings = {
  chandelierPeriod: 22,
  chandelierMultiplier: 3.0,
  adxPeriod: 14,
  adxSmoothing: 14,
};

export const TradingViewChart = ({ symbol, className }: TradingViewChartProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settings, setSettings] = useState<IndicatorSettings>(defaultSettings);
  const [key, setKey] = useState(0);

  // Converter símbolo para formato TradingView (BTCUSDT -> BINANCE:BTCUSDT.P)
  const getTradingViewSymbol = (sym: string) => {
    // Para futuros, usar .P no final
    return `BINANCE:${sym}.P`;
  };

  useEffect(() => {
    if (!containerRef.current || !symbol) return;

    // Preparar estrutura esperada pelo widget (precisa do __widget)
    containerRef.current.innerHTML =
      '<div class="tradingview-widget-container__widget" style="height:100%;width:100%"></div>';

    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";
    script.type = "text/javascript";
    script.async = true;

    // Configurar indicadores com settings
    const studies = [
      {
        id: "STD;Chandelier%1Exit",
        inputs: {
          in_0: settings.chandelierPeriod,
          in_1: settings.chandelierMultiplier,
        }
      },
      {
        id: "STD;ADX",
        inputs: {
          in_0: settings.adxPeriod,
          in_1: settings.adxSmoothing,
        }
      }
    ];

    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: getTradingViewSymbol(symbol),
      interval: "5",
      timezone: "America/Sao_Paulo",
      theme: "dark",
      style: "1",
      locale: "br",

      // Opções oficiais do widget (garante legendas e eixo de tempo)
      hide_top_toolbar: false,
      hide_side_toolbar: false,
      hide_legend: false,
      hide_volume: false,
      withdateranges: true,
      details: false,
      hotlist: false,
      calendar: false,
      allow_symbol_change: false,
      save_image: false,
      watchlist: [],
      compareSymbols: [],

      backgroundColor: "rgba(0, 0, 0, 0)",
      gridColor: "rgba(42, 46, 57, 0.3)",

      studies: studies,
      support_host: "https://www.tradingview.com",
    });

    containerRef.current.appendChild(script);

    return () => {
      if (containerRef.current) {
        containerRef.current.innerHTML = "";
      }
    };
  }, [symbol, key]);

  const handleSettingChange = (key: keyof IndicatorSettings, value: number) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const applySettings = () => {
    setKey(prev => prev + 1); // Force reload do widget
  };

  if (!symbol) {
    return (
      <Card className="p-4 bg-card/50 border-border/50">
        <p className="text-muted-foreground text-center">Selecione uma moeda para exibir o gráfico</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className={`bg-card/80 border-border/60 shadow-lg ${className}`}>
        <div className="p-4 border-b border-border/40 bg-gradient-to-r from-card to-card/80">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-foreground">
              📈 Gráfico {symbol} - 15min
            </h3>
            <Collapsible open={settingsOpen} onOpenChange={setSettingsOpen}>
              <CollapsibleTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2 bg-muted/30 hover:bg-muted/50">
                  <Settings className="h-4 w-4" />
                  Configurações
                  {settingsOpen ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="absolute right-0 mt-2 w-80 z-50 bg-card border border-border rounded-lg p-4 shadow-xl">
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-semibold text-primary mb-2">Chandelier Exit</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label className="text-xs">Período ATR</Label>
                        <Input
                          type="number"
                          value={settings.chandelierPeriod}
                          onChange={(e) => handleSettingChange("chandelierPeriod", Number(e.target.value))}
                          className="h-8 text-sm"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Multiplicador</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={settings.chandelierMultiplier}
                          onChange={(e) => handleSettingChange("chandelierMultiplier", Number(e.target.value))}
                          className="h-8 text-sm"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-primary mb-2">ADX e DI</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label className="text-xs">Período ADX</Label>
                        <Input
                          type="number"
                          value={settings.adxPeriod}
                          onChange={(e) => handleSettingChange("adxPeriod", Number(e.target.value))}
                          className="h-8 text-sm"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Suavização DI</Label>
                        <Input
                          type="number"
                          value={settings.adxSmoothing}
                          onChange={(e) => handleSettingChange("adxSmoothing", Number(e.target.value))}
                          className="h-8 text-sm"
                        />
                      </div>
                    </div>
                  </div>

                  <Button onClick={applySettings} className="w-full" size="sm">
                    Aplicar Configurações
                  </Button>
                </div>
              </CollapsibleContent>
            </Collapsible>
          </div>
        </div>
        
        <div 
          ref={containerRef} 
          className={`tradingview-widget-container ${className || ''}`}
          style={{ height: className?.includes('h-[') ? '100%' : '500px', width: '100%' }}
        />
      </Card>
    </div>
  );
};
