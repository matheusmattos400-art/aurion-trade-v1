import { useState, useEffect, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { TrendingUp, TrendingDown, ChevronLeft, ChevronRight, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TopMover {
  symbol: string;
  priceChangePercent: number;
  lastPrice: number;
}

export const TopMoverCarousel = () => {
  const [topMovers, setTopMovers] = useState<TopMover[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchTopMovers = useCallback(async () => {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 8000);

    try {
      // Usar API de Futuros da Binance (não tem bloqueio CORS)
      const url = `https://fapi.binance.com/fapi/v1/ticker/24hr`;
      const response = await fetch(url, {
        cache: "no-store",
        signal: controller.signal,
        headers: {
          "Cache-Control": "no-cache, no-store, must-revalidate",
          Pragma: "no-cache",
        },
      });

      if (!response.ok) {
        throw new Error(`Erro na resposta da API (${response.status})`);
      }

      const data: unknown = await response.json();
      if (!Array.isArray(data)) {
        throw new Error("Resposta inesperada da API");
      }

      // Filtrar apenas USDT pairs com variação POSITIVA e ordenar por maior alta
      const usdtPairs = data
        .filter(
          (item: any) =>
            item?.symbol?.endsWith("USDT") &&
            Number.parseFloat(item?.priceChangePercent) > 0,
        )
        .map((item: any) => ({
          symbol: String(item.symbol),
          priceChangePercent: Number.parseFloat(item.priceChangePercent),
          lastPrice: Number.parseFloat(item.lastPrice),
        }))
        .filter(
          (m: TopMover) =>
            Number.isFinite(m.priceChangePercent) && Number.isFinite(m.lastPrice),
        )
        .sort((a: TopMover, b: TopMover) => b.priceChangePercent - a.priceChangePercent)
        .slice(0, 10);

      setTopMovers(usdtPairs);
      setLastUpdate(new Date());
      setIsLoading(false);
    } catch (err) {
      const message =
        err instanceof DOMException && err.name === "AbortError"
          ? "Tempo esgotado ao buscar dados"
          : err instanceof Error
            ? err.message
            : "Erro ao buscar dados";

      console.error("Erro ao buscar top movers:", err);
      setError(message);
      setTopMovers([]);
      setIsLoading(false);
    } finally {
      window.clearTimeout(timeout);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchTopMovers();
    const interval = setInterval(fetchTopMovers, 10000); // Atualiza a cada 10 segundos
    return () => clearInterval(interval);
  }, [fetchTopMovers]);


  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + topMovers.length) % topMovers.length);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % topMovers.length);
  };

  const formatLastUpdate = () => {
    if (!lastUpdate) return '';
    return lastUpdate.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  if (isLoading) {
    return (
      <Card className="p-4 bg-card/50 border-border/30">
        <div className="animate-pulse flex items-center justify-center h-20">
          <span className="text-muted-foreground text-sm">Carregando top movers...</span>
        </div>
      </Card>
    );
  }

  if (topMovers.length === 0) {
    return (
      <Card className="p-3 bg-gradient-to-r from-card/80 to-card/50 border-border/30">
        <div className="flex items-center justify-between gap-2">
          <div className="flex flex-col">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              🚀 Top 10 Altas do Dia
            </h3>
            <p className="text-[11px] text-muted-foreground">
              {error ? `Sem dados agora: ${error}` : "Sem dados no momento."}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={fetchTopMovers}
            disabled={isRefreshing}
            aria-label="Atualizar Top 10"
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </Card>
    );
  }

  // Mostrar 3 itens por vez no desktop, 1 no mobile
  const visibleItems = 3;
  const getVisibleMovers = () => {
    const items = [];
    for (let i = 0; i < visibleItems; i++) {
      const index = (currentIndex + i) % topMovers.length;
      items.push({ ...topMovers[index], displayIndex: index });
    }
    return items;
  };

  const formatPrice = (price: number) => {
    if (price >= 1000) return `$${price.toFixed(2)}`;
    if (price >= 1) return `$${price.toFixed(4)}`;
    return `$${price.toFixed(6)}`;
  };

  return (
    <Card className="p-3 bg-gradient-to-r from-card/80 to-card/50 border-border/30 overflow-hidden">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            🚀 Top 10 Altas do Dia
          </h3>
          {lastUpdate && (
            <span className="text-[9px] text-muted-foreground/60">
              {formatLastUpdate()}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6"
            onClick={fetchTopMovers}
            disabled={isRefreshing}
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6"
            onClick={goToPrevious}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6"
            onClick={goToNext}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {getVisibleMovers().map((mover, idx) => {
          const isPositive = mover.priceChangePercent >= 0;
          const symbol = mover.symbol.replace('USDT', '');
          
          return (
            <div
              key={`${mover.symbol}-${idx}-${mover.priceChangePercent}`}
              className={`flex items-center justify-between p-3 rounded-lg transition-all duration-300 ${
                isPositive 
                  ? 'bg-profit/10 border border-profit/20' 
                  : 'bg-loss/10 border border-loss/20'
              }`}
            >
              <div className="flex items-center gap-2">
                <div className={`p-1.5 rounded-full ${
                  isPositive ? 'bg-profit/20' : 'bg-loss/20'
                }`}>
                  {isPositive ? (
                    <TrendingUp className="w-3.5 h-3.5 text-profit" />
                  ) : (
                    <TrendingDown className="w-3.5 h-3.5 text-loss" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-bold text-foreground">{symbol}</p>
                  <p className="text-[10px] text-muted-foreground font-mono">
                    {formatPrice(mover.lastPrice)}
                  </p>
                </div>
              </div>
              <div className={`text-right ${isPositive ? 'text-profit' : 'text-loss'}`}>
                <p className="text-sm font-bold font-mono">
                  {isPositive ? '+' : ''}{mover.priceChangePercent.toFixed(2)}%
                </p>
                <p className="text-[10px] text-muted-foreground">
                  #{mover.displayIndex + 1}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Indicadores de posição */}
      <div className="flex justify-center gap-1 mt-3">
        {topMovers.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentIndex(idx)}
            className={`w-1.5 h-1.5 rounded-full transition-all ${
              idx === currentIndex 
                ? 'bg-primary w-4' 
                : 'bg-muted-foreground/30 hover:bg-muted-foreground/50'
            }`}
          />
        ))}
      </div>
    </Card>
  );
};
