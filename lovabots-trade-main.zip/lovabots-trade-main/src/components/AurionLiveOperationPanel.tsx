import { useState, useEffect, useCallback, memo } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Loader2, 
  X, 
  DollarSign,
  Clock,
  Sparkles,
  RefreshCw,
  ExternalLink
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { AurionToken, SimulatedTrade } from "@/hooks/useAurionScanner";
import {
  disableAIGatewayForMinutes,
  getAIGatewayUserMessage,
  getInvokeErrorStatusCode,
  isAIGatewayTemporarilyDisabled,
  shouldToastPaymentRequiredOnce,
} from "@/utils/aiCreditsGuard";

interface LivePriceData {
  currentPrice: number;
  pnlPercent: number;
  pnlUsd: number;
  priceChange5m?: number;
  volume5m?: number;
}

interface AIAnalysis {
  recommendation: string;
  analysis: string;
  confidence: number;
  timestamp: number;
  score?: number;
  verdict?: string;
  tradeProfile?: string;
}

interface AurionLiveOperationPanelProps {
  trades: SimulatedTrade[];
  onExitTrade: (tradeId: string) => void;
  onOpenSellTerminal: (token: AurionToken) => void;
  onViewChart: (token: AurionToken) => void;
}

export const AurionLiveOperationPanel = memo(({ 
  trades, 
  onExitTrade, 
  onOpenSellTerminal,
  onViewChart 
}: AurionLiveOperationPanelProps) => {
  const [livePrices, setLivePrices] = useState<Record<string, LivePriceData>>({});
  const [aiAnalyses, setAiAnalyses] = useState<Record<string, AIAnalysis>>({});
  const [isLoadingAI, setIsLoadingAI] = useState<Record<string, boolean>>({});
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  const [lastAIRefresh, setLastAIRefresh] = useState<Record<string, Date>>({});
  const [previousPrices, setPreviousPrices] = useState<Record<string, number>>({});

  const openTrades = trades.filter(t => t.status === "open");

  // Fetch live prices
  const fetchLivePrices = useCallback(async () => {
    if (openTrades.length === 0) return;

    const newPrices: Record<string, LivePriceData> = {};
    
    await Promise.all(
      openTrades.map(async (trade) => {
        try {
          const response = await fetch(
            `https://api.dexscreener.com/latest/dex/pairs/${trade.token.chainId}/${trade.token.pairAddress}`
          );
          if (!response.ok) return;
          
          const data = await response.json();
          const pair = data.pair || data.pairs?.[0];
          if (!pair) return;
          
          const currentPrice = parseFloat(pair.priceUsd || "0");
          const pnlPercent = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100;
          const investment = trade.investmentAmount || 100;
          const pnlUsd = (pnlPercent / 100) * investment;
          
          newPrices[trade.id] = { 
            currentPrice, 
            pnlPercent, 
            pnlUsd,
            priceChange5m: pair.priceChange?.m5 || 0,
            volume5m: pair.volume?.m5 || 0
          };
        } catch (err) {
          console.error(`Error fetching price for ${trade.token.symbol}:`, err);
        }
      })
    );
    
    setLivePrices(prev => ({ ...prev, ...newPrices }));
    setLastRefresh(new Date());
  }, [openTrades]);

  // Fetch AI analysis for a trade - using aurion-full-analysis for complete data
  const fetchAIAnalysis = useCallback(async (trade: SimulatedTrade, forceUpdate = false) => {
    const tradeId = trade.id;
    
    // Skip if already loading
    if (isLoadingAI[tradeId]) return;
    
    setIsLoadingAI(prev => ({ ...prev, [tradeId]: true }));

    try {
      if (isAIGatewayTemporarilyDisabled()) {
        // Avoid hammering the backend when credits are missing / temporarily disabled.
        return;
      }

      const liveData = livePrices[tradeId];
      const currentPrice = liveData?.currentPrice || trade.entryPrice;
      const pnlPercent = liveData?.pnlPercent || 0;

      // Use aurion-full-analysis for comprehensive AI analysis
       const { data, error } = await supabase.functions.invoke("aurion-full-analysis", {
        body: {
          token: {
            ...trade.token,
            // Add current operation context
            currentPrice,
            entryPrice: trade.entryPrice,
            pnlPercent,
            investmentAmount: trade.investmentAmount || 100,
            timeInTrade: Date.now() - trade.entryTime
          }
        }
      });

       if (error) {
         const status = getInvokeErrorStatusCode(error) ?? null;
         if (status === 402) {
           disableAIGatewayForMinutes(10);
           if (shouldToastPaymentRequiredOnce()) {
             toast.error(getAIGatewayUserMessage(402));
           }
           return;
         }
         if (status === 429) {
           return;
         }
         throw error;
       }

      // Map AI response to recommendation
      let recommendation = "MANTER";
      if (data.verdict === "APROVADO" || data.verdict === "APROVADO_COM_RESSALVAS") {
        if (pnlPercent > 20) recommendation = "REALIZAR LUCRO";
        else recommendation = "MANTER";
      } else if (data.verdict === "REPROVADO" || data.verdict === "PERIGOSO" || data.verdict === "SCAM_CONFIRMADO") {
        recommendation = "VENDER";
      } else if (data.verdict === "NEUTRO") {
        if (pnlPercent < -10) recommendation = "STOP LOSS";
        else recommendation = "MONITORAR";
      }

      setAiAnalyses(prev => ({
        ...prev,
        [tradeId]: {
          recommendation,
          analysis: data.summary || data.finalRecommendation || "Análise atualizada",
          confidence: data.score || data.confidence || 50,
          timestamp: Date.now(),
          score: data.score,
          verdict: data.verdict,
          tradeProfile: data.tradeProfile
        }
      }));
      
      setLastAIRefresh(prev => ({ ...prev, [tradeId]: new Date() }));
      
    } catch (err) {
      console.error("Error fetching AI analysis:", err);
      // Don't show toast on every error to avoid spam
    } finally {
      setIsLoadingAI(prev => ({ ...prev, [tradeId]: false }));
    }
  }, [livePrices, isLoadingAI]);

  // Auto-refresh prices every 10 seconds and check for significant changes
  useEffect(() => {
    fetchLivePrices();
    const interval = setInterval(() => {
      fetchLivePrices();
      
      // Check for significant price changes that warrant AI re-analysis
      openTrades.forEach(trade => {
        const currentPrice = livePrices[trade.id]?.currentPrice;
        const previousPrice = previousPrices[trade.id];
        
        if (currentPrice && previousPrice) {
          const priceChangePercent = Math.abs((currentPrice - previousPrice) / previousPrice * 100);
          // If price changed more than 5%, trigger AI update
          if (priceChangePercent > 5) {
            console.log(`Significant price change detected for ${trade.token.symbol}: ${priceChangePercent.toFixed(2)}%`);
            fetchAIAnalysis(trade, true);
          }
        }
        
        if (currentPrice) {
          setPreviousPrices(prev => ({ ...prev, [trade.id]: currentPrice }));
        }
      });
    }, 10000);
    return () => clearInterval(interval);
  }, [fetchLivePrices, openTrades, livePrices, previousPrices, fetchAIAnalysis]);

  // Auto-refresh AI analysis every 30 seconds for open trades (more frequent updates)
  useEffect(() => {
    if (openTrades.length === 0) return;

    // Initial AI fetch for all trades that don't have analysis yet
    openTrades.forEach(trade => {
      if (!aiAnalyses[trade.id]) {
        fetchAIAnalysis(trade);
      }
    });

    // Refresh AI every 30 seconds (instead of 60)
    const interval = setInterval(() => {
      openTrades.forEach(trade => {
        fetchAIAnalysis(trade);
      });
    }, 30000);

    return () => clearInterval(interval);
  }, [openTrades.length, fetchAIAnalysis]);

  if (openTrades.length === 0) {
    return null;
  }

  const totalInvested = openTrades.reduce((sum, t) => sum + (t.investmentAmount || 100), 0);
  const totalPnlUsd = Object.values(livePrices).reduce((sum, p) => sum + p.pnlUsd, 0);
  const totalPnlPercent = totalInvested > 0 ? (totalPnlUsd / totalInvested) * 100 : 0;

  return (
    <Card className="glass-card p-3 sm:p-4 border-primary/30">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <h3 className="font-bold text-lg">Operações Ativas</h3>
          <Badge variant="outline">{openTrades.length}</Badge>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Clock className="w-3 h-3" />
          <span>Atualizado {formatDistanceToNow(lastRefresh, { addSuffix: true, locale: ptBR })}</span>
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={fetchLivePrices}>
            <RefreshCw className="w-3 h-3" />
          </Button>
        </div>
      </div>

      {/* Summary */}
      <div className={`rounded-lg p-3 mb-4 ${totalPnlPercent >= 0 ? 'bg-green-500/10 border border-green-500/20' : 'bg-red-500/10 border border-red-500/20'}`}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground">Saldo Total das Operações</p>
            <p className={`text-2xl font-bold ${totalPnlPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              ${(totalInvested + totalPnlUsd).toFixed(2)}
            </p>
          </div>
          <div className={`flex items-center gap-2 px-3 py-2 rounded-lg ${totalPnlPercent >= 0 ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
            {totalPnlPercent >= 0 ? <TrendingUp className="w-5 h-5 text-green-400" /> : <TrendingDown className="w-5 h-5 text-red-400" />}
            <div className="text-right">
              <p className={`font-bold ${totalPnlPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {totalPnlPercent >= 0 ? '+' : ''}{totalPnlPercent.toFixed(2)}%
              </p>
              <p className={`text-xs ${totalPnlPercent >= 0 ? 'text-green-400/80' : 'text-red-400/80'}`}>
                {totalPnlUsd >= 0 ? '+' : ''}${totalPnlUsd.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          Investido: ${totalInvested.toFixed(2)} em {openTrades.length} operação{openTrades.length > 1 ? 'ões' : ''}
        </p>
      </div>

      {/* Individual Operations */}
      <div className="max-h-[500px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-primary/20 scrollbar-track-transparent">
        <div className="space-y-3 pb-4">
          {openTrades.map((trade) => {
            const liveData = livePrices[trade.id];
            const aiAnalysis = aiAnalyses[trade.id];
            const isAILoading = isLoadingAI[trade.id];
            const currentPrice = liveData?.currentPrice || trade.entryPrice;
            const pnlPercent = liveData?.pnlPercent || 0;
            const pnlUsd = liveData?.pnlUsd || 0;
            const currentBalance = (trade.investmentAmount || 100) + pnlUsd;

            return (
              <Card 
                key={trade.id} 
                className={`p-3 ${pnlPercent >= 0 ? 'border-green-500/30 bg-green-500/5' : 'border-red-500/30 bg-red-500/5'}`}
              >
                {/* Token Header */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {trade.token.imageUrl && (
                      <img 
                        src={trade.token.imageUrl} 
                        alt={trade.token.symbol} 
                        className="w-8 h-8 rounded-full"
                        onError={(e) => { e.currentTarget.style.display = 'none'; }}
                      />
                    )}
                    <div>
                      <h4 className="font-bold">{trade.token.symbol}</h4>
                      <p className="text-xs text-muted-foreground">{trade.token.name}</p>
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded-lg ${pnlPercent >= 0 ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
                    <p className={`font-bold ${pnlPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {pnlPercent >= 0 ? '+' : ''}{pnlPercent.toFixed(2)}%
                    </p>
                  </div>
                </div>

                {/* Balance Highlight */}
                <div className={`rounded-lg p-2 mb-3 ${pnlPercent >= 0 ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Saldo:</span>
                    <span className={`text-lg font-bold ${pnlPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      ${currentBalance.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mt-1">
                    <span>Lucro/Prejuízo:</span>
                    <span className={pnlPercent >= 0 ? 'text-green-400' : 'text-red-400'}>
                      {pnlUsd >= 0 ? '+' : ''}${pnlUsd.toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Price Info */}
                <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Entrada:</span>
                    <span className="font-mono text-xs">
                      ${trade.entryPrice < 0.001 ? trade.entryPrice.toExponential(3) : trade.entryPrice.toFixed(6)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Atual:</span>
                    <span className="font-mono text-xs">
                      ${currentPrice < 0.001 ? currentPrice.toExponential(3) : currentPrice.toFixed(6)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Investido:</span>
                    <span className="font-bold">${(trade.investmentAmount || 100).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tempo:</span>
                    <span className="text-xs">
                      {formatDistanceToNow(new Date(trade.entryTime), { addSuffix: false, locale: ptBR })}
                    </span>
                  </div>
                </div>

                {/* AI Analysis Panel - Enhanced with real-time updates */}
                <div className={`rounded-lg p-2 mb-3 ${
                  aiAnalysis?.recommendation === "VENDER" || aiAnalysis?.recommendation === "STOP LOSS"
                    ? 'bg-red-500/10 border border-red-500/30'
                    : aiAnalysis?.recommendation === "REALIZAR LUCRO"
                      ? 'bg-yellow-500/10 border border-yellow-500/30'
                      : 'bg-card/50 border border-primary/20'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1">
                      <Sparkles className={`w-4 h-4 ${
                        isAILoading ? 'animate-pulse text-primary' : 'text-primary'
                      }`} />
                      <span className="text-xs font-medium">Análise IA (ao vivo)</span>
                      {lastAIRefresh[trade.id] && (
                        <span className="text-[10px] text-muted-foreground">
                          • {formatDistanceToNow(lastAIRefresh[trade.id], { addSuffix: true, locale: ptBR })}
                        </span>
                      )}
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-5 w-5"
                      onClick={() => fetchAIAnalysis(trade, true)}
                      disabled={isAILoading}
                    >
                      {isAILoading ? (
                        <Loader2 className="w-3 h-3 animate-spin" />
                      ) : (
                        <RefreshCw className="w-3 h-3" />
                      )}
                    </Button>
                  </div>
                  
                  {aiAnalysis ? (
                    <div className="space-y-2">
                      {/* Score and Verdict */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge 
                          variant={
                            aiAnalysis.recommendation === "MANTER" || aiAnalysis.recommendation === "MONITORAR"
                              ? "default" 
                              : aiAnalysis.recommendation === "VENDER" || aiAnalysis.recommendation === "STOP LOSS"
                                ? "destructive" 
                                : aiAnalysis.recommendation === "REALIZAR LUCRO"
                                  ? "secondary"
                                  : "outline"
                          }
                          className="text-xs font-bold"
                        >
                          {aiAnalysis.recommendation}
                        </Badge>
                        {aiAnalysis.score !== undefined && (
                          <Badge variant="outline" className="text-xs">
                            Score: {aiAnalysis.score}/100
                          </Badge>
                        )}
                        {aiAnalysis.verdict && (
                          <Badge 
                            variant="outline" 
                            className={`text-[10px] ${
                              aiAnalysis.verdict === "APROVADO" ? 'border-green-500 text-green-500' :
                              aiAnalysis.verdict === "REPROVADO" || aiAnalysis.verdict === "PERIGOSO" ? 'border-red-500 text-red-500' :
                              'border-yellow-500 text-yellow-500'
                            }`}
                          >
                            {aiAnalysis.verdict}
                          </Badge>
                        )}
                      </div>
                      
                      {/* Analysis text */}
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {aiAnalysis.analysis}
                      </p>
                      
                      {/* Confidence bar */}
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              aiAnalysis.confidence >= 70 ? 'bg-green-500' :
                              aiAnalysis.confidence >= 40 ? 'bg-yellow-500' :
                              'bg-red-500'
                            }`}
                            style={{ width: `${aiAnalysis.confidence}%` }}
                          />
                        </div>
                        <span className="text-[10px] text-muted-foreground">
                          {aiAnalysis.confidence}%
                        </span>
                      </div>
                    </div>
                  ) : isAILoading ? (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Loader2 className="w-3 h-3 animate-spin" />
                      Analisando em tempo real...
                    </div>
                  ) : (
                    <p className="text-xs text-muted-foreground">
                      Clique para analisar
                    </p>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => onViewChart(trade.token)}
                  >
                    <Activity className="w-3 h-3 mr-1" />
                    Gráfico
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    className="flex-1"
                    onClick={() => onOpenSellTerminal(trade.token)}
                  >
                    <ExternalLink className="w-3 h-3 mr-1" />
                    Vender
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </Card>
  );
});

AurionLiveOperationPanel.displayName = "AurionLiveOperationPanel";
