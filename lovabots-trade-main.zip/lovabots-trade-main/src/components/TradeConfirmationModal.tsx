import { memo, useState, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Zap,
  TestTube,
  AlertTriangle,
  DollarSign,
  TrendingUp,
  Shield,
  Loader2,
  ExternalLink,
} from "lucide-react";
import type { AurionToken } from "@/hooks/useAurionScanner";
import { AurionTradeTerminal } from "./AurionTradeTerminal";

// Interface para trade ativo (mesma do AurionTradeTerminal)
interface ActiveTrade {
  id: string;
  token: AurionToken;
  entryPrice: number;
  investmentAmount?: number;
  status: "open" | "closed" | "stopped" | "manual_exit";
}

interface TradeConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  token: AurionToken | null;
  investmentAmount: number;
  slippagePercent: number;
  onConfirmTest: () => void;
  activeTrades?: ActiveTrade[];
  onConfirmEntry?: (token: AurionToken, investmentAmount: number) => void;

  // Props legadas (mantidas para compatibilidade com AurionIntelligence)
  onConfirmReal: () => void;
  isWalletConnected: boolean;
  onConnectWallet: () => Promise<boolean>;

  isExecuting?: boolean;
}

export const TradeConfirmationModal = memo((props: TradeConfirmationModalProps) => {
  const {
    isOpen,
    onClose,
    token,
    investmentAmount,
    slippagePercent,
    onConfirmTest,
    activeTrades = [],
    onConfirmEntry,
    isExecuting = false,
  } = props;

  // Estado para o terminal integrado
  const [showTerminal, setShowTerminal] = useState(false);

  // Abre o terminal integrado (in-app)
  const handleOpenTerminal = useCallback(() => {
    if (!token) return;
    console.log("🚀 Abrindo Terminal Integrado:", {
      symbol: token.symbol,
      chainId: token.chainId,
      pairAddress: token.pairAddress,
    });
    setShowTerminal(true);
  }, [token]);

  // Fecha o terminal e o modal
  const handleCloseTerminal = useCallback(() => {
    setShowTerminal(false);
  }, []);

  if (!token) return null;

  const formatPrice = (price: number) => {
    if (price < 0.00001) return price.toExponential(4);
    if (price < 0.01) return price.toFixed(8);
    if (price < 1) return price.toFixed(6);
    return price.toFixed(4);
  };

  // Se o terminal está aberto, mostra ele
  if (showTerminal) {
    return (
      <AurionTradeTerminal
        token={token}
        isOpen={showTerminal}
        onClose={handleCloseTerminal}
        activeTrades={activeTrades}
        onConfirmEntry={onConfirmEntry}
      />
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-[calc(100vw-2rem)] max-w-md max-h-[90vh] overflow-y-auto overflow-x-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary shrink-0" />
            <span className="truncate">Confirmar Operação</span>
          </DialogTitle>
          <DialogDescription className="break-words">
            Escolha o tipo de operação para {token.symbol}
          </DialogDescription>
        </DialogHeader>

        {/* Token Info */}
        <Card className="p-3 sm:p-4 bg-muted/30">
          <div className="flex items-center gap-2 sm:gap-3 mb-3 flex-wrap">
            {token.imageUrl && (
              <img
                src={token.imageUrl}
                alt={token.symbol}
                className="w-8 h-8 sm:w-10 sm:h-10 rounded-full shrink-0"
                onError={(e) => {
                  e.currentTarget.style.display = "none";
                }}
              />
            )}
            <div className="min-w-0 flex-1">
              <h3 className="font-bold text-sm sm:text-base truncate">{token.symbol}</h3>
              <p className="text-xs text-muted-foreground truncate">{token.name}</p>
            </div>
            <Badge
              className="shrink-0 text-xs"
              variant={token.securityScore >= 80 ? "default" : "secondary"}
            >
              <Shield className="w-3 h-3 mr-1" />
              {token.securityScore}
            </Badge>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm">
            <div className="flex items-center gap-1 min-w-0">
              <DollarSign className="w-3 h-3 text-muted-foreground shrink-0" />
              <span className="text-muted-foreground shrink-0">Preço:</span>
              <span className="font-mono truncate">${formatPrice(token.priceUsd)}</span>
            </div>
            <div className="flex items-center gap-1 min-w-0">
              <TrendingUp className="w-3 h-3 text-muted-foreground shrink-0" />
              <span className="text-muted-foreground shrink-0">24h:</span>
              <span
                className={`truncate ${token.priceChange24h >= 0 ? "text-green-500" : "text-red-500"}`}
              >
                {token.priceChange24h >= 0 ? "+" : ""}
                {token.priceChange24h.toFixed(2)}%
              </span>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-border">
            <div className="flex justify-between items-center gap-2">
              <span className="text-xs sm:text-sm text-muted-foreground">Slippage:</span>
              <span className="font-bold text-orange-500 text-sm sm:text-base">
                {slippagePercent}%
              </span>
            </div>
          </div>
        </Card>

        {/* Trade Options - Grid Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Test Trade */}
          <Button
            variant="outline"
            className="h-auto py-4 px-4 flex flex-col items-center justify-center gap-2 text-center border-blue-500/30 hover:bg-blue-500/10 hover:border-blue-500/50 transition-all"
            onClick={onConfirmTest}
            disabled={isExecuting}
          >
            <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center">
              <TestTube className="w-6 h-6 text-blue-500" />
            </div>
            <div>
              <span className="font-bold text-blue-500 text-sm block">Operação Teste</span>
              <Badge variant="secondary" className="text-xs mt-1">
                Simulação
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Simula entrada sem ordem real
            </p>
          </Button>

          {/* Real Trade - Terminal Integrado */}
          <Button
            variant="outline"
            className="h-auto py-4 px-4 flex flex-col items-center justify-center gap-2 text-center border-purple-500/30 hover:bg-purple-500/10 hover:border-purple-500/50 transition-all"
            onClick={handleOpenTerminal}
            disabled={isExecuting}
          >
            <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center">
              {isExecuting ? (
                <Loader2 className="w-6 h-6 animate-spin text-purple-500" />
              ) : (
                <ExternalLink className="w-6 h-6 text-purple-500" />
              )}
            </div>
            <div>
              <span className="font-bold text-purple-500 text-sm block">DexScreener</span>
              <Badge variant="secondary" className="text-xs mt-1">
                In-App
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Gráfico + Swap integrados
            </p>
          </Button>
        </div>

        {/* Warning */}
        <div className="p-3 bg-destructive/10 rounded-lg border border-destructive/20">
          <div className="flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
            <p className="text-xs text-destructive">
              <strong>Aviso:</strong> Operações reais envolvem risco de perda. A análise do
              DexScreener não garante resultados.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
});

TradeConfirmationModal.displayName = "TradeConfirmationModal";

