import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { DollarSign, TrendingUp, Target, ChevronDown, ChevronUp, Settings2, Zap, Save } from "lucide-react";
import { toast } from "sonner";

interface TradingConfigProps {
  investment: number;
  leverage: number;
  profitTarget: number;
  autoCloseEnabled: boolean;
  onInvestmentChange: (value: number) => void;
  onLeverageChange: (value: number) => void;
  onProfitTargetChange: (value: number) => void;
  onAutoCloseChange: (value: boolean) => void;
}

const PROFIT_TARGETS = [2, 3, 5, 10] as const;

export const TradingConfig = ({
  investment,
  leverage,
  profitTarget,
  autoCloseEnabled,
  onInvestmentChange,
  onLeverageChange,
  onProfitTargetChange,
  onAutoCloseChange,
}: TradingConfigProps) => {
  const [isOpen, setIsOpen] = useState(false);
  
  // Estados locais para edição
  const [localInvestment, setLocalInvestment] = useState(investment.toString());
  const [localLeverage, setLocalLeverage] = useState(leverage);
  const [localProfitTarget, setLocalProfitTarget] = useState(profitTarget);
  const [localAutoClose, setLocalAutoClose] = useState(autoCloseEnabled);

  // Sincronizar quando props mudam externamente
  useEffect(() => {
    setLocalInvestment(investment.toString());
    setLocalLeverage(leverage);
    setLocalProfitTarget(profitTarget);
    setLocalAutoClose(autoCloseEnabled);
  }, [investment, leverage, profitTarget, autoCloseEnabled]);

  // Verificar se há alterações não salvas
  const hasChanges = 
    parseFloat(localInvestment) !== investment ||
    localLeverage !== leverage ||
    localProfitTarget !== profitTarget ||
    localAutoClose !== autoCloseEnabled;

  const handleSave = () => {
    const numInvestment = parseFloat(localInvestment);
    if (isNaN(numInvestment) || numInvestment <= 0) {
      toast.error("Valor de investimento inválido");
      return;
    }
    
    onInvestmentChange(numInvestment);
    onLeverageChange(localLeverage);
    onProfitTargetChange(localProfitTarget);
    onAutoCloseChange(localAutoClose);
    toast.success("Configurações salvas!");
  };

  // Cálculo correto: lucro esperado = investimento * (meta% / 100)
  const localInvestmentNum = parseFloat(localInvestment) || 0;
  const expectedProfit = (localInvestmentNum * localProfitTarget) / 100;

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      {/* Botão de Configurações com aparência de botão real */}
      <CollapsibleTrigger asChild>
        <Button
          variant="outline"
          className="w-full h-auto py-3 px-4 flex items-center justify-between bg-card hover:bg-accent/50 border-2 border-border hover:border-primary/50 transition-all duration-200 rounded-xl shadow-sm hover:shadow-md"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Settings2 className="h-5 w-5 text-primary" />
            </div>
            <div className="text-left">
              <span className="text-sm font-semibold text-foreground">Configurações de Trading</span>
              <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground mt-0.5">
                <span className="px-2 py-0.5 bg-muted rounded-full">${investment}</span>
                <span className="px-2 py-0.5 bg-muted rounded-full">{leverage}x</span>
                <span className="px-2 py-0.5 bg-muted rounded-full">Meta {profitTarget}%</span>
                <span className="px-2 py-0.5 bg-primary/20 text-primary rounded-full font-medium">
                  Lucro: ${(investment * profitTarget / 100).toFixed(2)}
                </span>
                <span className={`px-2 py-0.5 rounded-full ${autoCloseEnabled ? "bg-green-500/20 text-green-500" : "bg-muted text-muted-foreground"}`}>
                  Auto: {autoCloseEnabled ? "ON" : "OFF"}
                </span>
              </div>
            </div>
          </div>
          <div className="p-1.5 rounded-lg bg-muted">
            {isOpen ? (
              <ChevronUp className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            )}
          </div>
        </Button>
      </CollapsibleTrigger>

      {/* Conteúdo expansível */}
      <CollapsibleContent className="mt-3">
        <Card className="p-4 bg-card/50 backdrop-blur-sm border-border/50">
          <div className="space-y-6">
            {/* Linha 1: Investimento e Alavancagem */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Investimento */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <DollarSign className="h-4 w-4 text-primary" />
                  Investimento (USDT)
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                  <Input
                    type="number"
                    value={localInvestment}
                    onChange={(e) => setLocalInvestment(e.target.value)}
                    className="pl-7 h-11 text-base font-semibold bg-background/50 border-border/50 focus:border-primary"
                    placeholder="100"
                    min={10}
                    max={100000}
                  />
                </div>
              </div>

              {/* Alavancagem */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  Alavancagem
                </Label>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xl font-bold text-foreground">{localLeverage}x</span>
                    <span className="text-xs text-muted-foreground px-2 py-1 rounded bg-muted">
                      {localLeverage <= 10 ? "Conservador" : localLeverage <= 50 ? "Moderado" : "Agressivo"}
                    </span>
                  </div>
                  <Slider
                    value={[localLeverage]}
                    onValueChange={([value]) => setLocalLeverage(value)}
                    min={1}
                    max={125}
                    step={1}
                    className="py-2"
                  />
                </div>
              </div>
            </div>

            {/* Linha 2: Meta de Lucro e Auto-Close */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Meta de Lucro */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <Target className="h-4 w-4 text-primary" />
                  Meta de Lucro
                </Label>
                <RadioGroup
                  value={localProfitTarget.toString()}
                  onValueChange={(value) => setLocalProfitTarget(parseInt(value))}
                  className="grid grid-cols-4 gap-2"
                >
                  {PROFIT_TARGETS.map((target) => (
                    <div key={target}>
                      <RadioGroupItem
                        value={target.toString()}
                        id={`target-${target}`}
                        className="peer sr-only"
                      />
                      <Label
                        htmlFor={`target-${target}`}
                        className="flex flex-col items-center justify-center h-11 rounded-lg border-2 border-border/50 bg-background/50 cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 peer-data-[state=checked]:text-primary hover:bg-muted/50 text-sm font-bold"
                      >
                        {target}%
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
                <p className="text-xs text-muted-foreground">
                  Lucro esperado: <span className="text-primary font-semibold">${expectedProfit.toFixed(2)}</span>
                </p>
              </div>

              {/* Saída Automática */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <Zap className="h-4 w-4 text-primary" />
                  Saída Automática
                </Label>
                <div 
                  className="flex items-center justify-between h-11 px-4 rounded-lg border-2 border-border/50 bg-background/50 cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => setLocalAutoClose(!localAutoClose)}
                >
                  <span className={`text-sm font-medium ${localAutoClose ? "text-green-500" : "text-muted-foreground"}`}>
                    {localAutoClose ? "Ativado" : "Desativado"}
                  </span>
                  <Switch
                    checked={localAutoClose}
                    onCheckedChange={setLocalAutoClose}
                    className="data-[state=checked]:bg-green-500"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Fecha ao atingir meta +0.2%
                </p>
              </div>
            </div>

            {/* Botão Salvar */}
            {hasChanges && (
              <div className="pt-4 border-t border-border/50">
                <Button
                  onClick={handleSave}
                  className="w-full bg-primary hover:bg-primary/90"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Configurações
                </Button>
              </div>
            )}
          </div>
        </Card>
      </CollapsibleContent>
    </Collapsible>
  );
};