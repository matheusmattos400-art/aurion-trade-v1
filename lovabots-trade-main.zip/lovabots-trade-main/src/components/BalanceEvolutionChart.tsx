import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";
import { format } from "date-fns";
import { TrendingUp, TrendingDown, Activity } from "lucide-react";

interface BalancePoint {
  date: string;
  balance: number;
  displayDate: string;
}

interface BalanceEvolutionChartProps {
  mode: "real" | "test";
}

export const BalanceEvolutionChart = ({ mode }: BalanceEvolutionChartProps) => {
  const [data, setData] = useState<BalancePoint[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchBalanceHistory = async () => {
      setIsLoading(true);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setIsLoading(false);
        return;
      }

      const isTestMode = mode === "test";

      const historyQuery = supabase
        .from("trade_history")
        .select("started_at, ended_at, profit, is_test, long_symbol, short_symbol")
        .eq("user_id", user.id)
        .eq("is_test", isTestMode);

      const closedOpsQuery = supabase
        .from("active_operations")
        .select("started_at, updated_at, long_close_pnl, short_close_pnl, is_test, long_symbol, short_symbol")
        .eq("user_id", user.id)
        .eq("status", "closed")
        .eq("is_test", isTestMode);

      const [{ data: trades, error }, { data: closedOps, error: closedError }] = await Promise.all([
        historyQuery.order("ended_at", { ascending: true }),
        closedOpsQuery.order("updated_at", { ascending: true }),
      ]);

      if (error) {
        console.error("Erro ao buscar histórico:", error);
        setIsLoading(false);
        return;
      }

      if (closedError) {
        console.error("Erro ao buscar operações fechadas:", closedError);
        setIsLoading(false);
        return;
      }

      const historyKey = new Set(
        (trades ?? [])
          .filter((t) => t.started_at)
          .map((t) => `${t.long_symbol}|${t.short_symbol}|${t.started_at}`)
      );

      const merged = [
        ...(trades ?? [])
          .filter((t) => !!t.ended_at)
          .map((t) => ({
            endedAt: t.ended_at as string,
            profit: Number(t.profit),
          })),
        ...(closedOps ?? [])
          .filter((op) => !!op.updated_at)
          .filter((op) => {
            if (!op.started_at) return true;
            const key = `${op.long_symbol}|${op.short_symbol}|${op.started_at}`;
            return !historyKey.has(key);
          })
          .map((op) => ({
            endedAt: op.updated_at as string,
            profit: Number(op.long_close_pnl || 0) + Number(op.short_close_pnl || 0),
          })),
      ].sort((a, b) => new Date(a.endedAt).getTime() - new Date(b.endedAt).getTime());

      let accumulatedBalance = 0;
      const balancePoints: BalancePoint[] = merged.map((item) => {
        accumulatedBalance += item.profit;
        return {
          date: item.endedAt,
          balance: Number(accumulatedBalance.toFixed(2)),
          displayDate: format(new Date(item.endedAt), "dd/MM HH:mm"),
        };
      });

      setData(balancePoints);
      setIsLoading(false);
    };

    fetchBalanceHistory();

    // Atualizar quando houver novos trades ou operações encerradas
    const channel = supabase
      .channel(`balance_chart_${mode}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "trade_history",
        },
        () => {
          fetchBalanceHistory();
        }
      )
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "active_operations",
        },
        () => {
          fetchBalanceHistory();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [mode]);

  const maxBalance = data.length > 0 ? Math.max(...data.map(d => d.balance)) : 0;
  const minBalance = data.length > 0 ? Math.min(...data.map(d => d.balance)) : 0;
  const latestBalance = data.length > 0 ? data[data.length - 1]?.balance || 0 : 0;
  const totalTrades = data.length;
  const isPositive = latestBalance >= 0;

  const accentColor = mode === "test" ? "hsl(var(--chart-warning))" : "hsl(var(--primary))";

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-background/50 border border-border/30">
          <div className="flex items-center gap-2 mb-1">
            <Activity className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Total Operações</span>
          </div>
          <p className="text-2xl font-bold text-foreground">{totalTrades}</p>
        </div>
        
        <div className="p-4 rounded-xl bg-background/50 border border-border/30">
          <div className="flex items-center gap-2 mb-1">
            {isPositive ? (
              <TrendingUp className="h-4 w-4 text-profit" />
            ) : (
              <TrendingDown className="h-4 w-4 text-loss" />
            )}
            <span className="text-xs text-muted-foreground">Saldo Atual</span>
          </div>
          <p className={`text-2xl font-bold ${isPositive ? 'text-profit' : 'text-loss'}`}>
            ${latestBalance.toFixed(2)}
          </p>
        </div>
        
        <div className="p-4 rounded-xl bg-background/50 border border-border/30">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="h-4 w-4 text-profit" />
            <span className="text-xs text-muted-foreground">Máximo</span>
          </div>
          <p className="text-2xl font-bold text-profit">${maxBalance.toFixed(2)}</p>
        </div>
        
        <div className="p-4 rounded-xl bg-background/50 border border-border/30">
          <div className="flex items-center gap-2 mb-1">
            <TrendingDown className="h-4 w-4 text-loss" />
            <span className="text-xs text-muted-foreground">Mínimo</span>
          </div>
          <p className="text-2xl font-bold text-loss">${minBalance.toFixed(2)}</p>
        </div>
      </div>

      {/* Chart */}
      <div className="rounded-xl bg-background/30 p-4 border border-border/20">
        {isLoading ? (
          <div className="flex items-center justify-center h-[280px]">
            <div className="flex flex-col items-center gap-3">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              <span className="text-sm text-muted-foreground">Carregando gráfico...</span>
            </div>
          </div>
        ) : data.length === 0 ? (
          <div className="flex items-center justify-center h-[280px]">
            <div className="text-center">
              <Activity className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
              <p className="text-muted-foreground">Nenhum histórico disponível</p>
              <p className="text-xs text-muted-foreground/70 mt-1">Realize operações para ver a evolução</p>
            </div>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id={`colorBalance${mode}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={accentColor} stopOpacity={0.3}/>
                  <stop offset="95%" stopColor={accentColor} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.2} vertical={false} />
              <XAxis 
                dataKey="displayDate" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                interval="preserveStartEnd"
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `$${value}`}
                width={55}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "12px",
                  color: "hsl(var(--foreground))",
                  boxShadow: "0 10px 40px -10px rgba(0,0,0,0.3)",
                }}
                formatter={(value: number) => [`$${value.toFixed(2)}`, "Saldo"]}
                labelStyle={{ color: "hsl(var(--muted-foreground))" }}
              />
              <Area 
                type="monotone" 
                dataKey="balance" 
                stroke={accentColor}
                strokeWidth={2.5}
                fill={`url(#colorBalance${mode})`}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
};