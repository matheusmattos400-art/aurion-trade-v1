import { memo } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';

export const SolanaWalletButton = memo(() => {
  const { connected, publicKey } = useWallet();

  return (
    <div className="solana-wallet-button relative z-50">
      <WalletMultiButton 
        style={{
          backgroundColor: connected ? 'rgba(139, 92, 246, 0.2)' : 'rgb(139, 92, 246)',
          border: connected ? '1px solid rgba(139, 92, 246, 0.5)' : 'none',
          borderRadius: '0.375rem',
          height: '32px',
          fontSize: '12px',
          fontWeight: 500,
          padding: '0 12px',
        }}
      />
    </div>
  );
});

SolanaWalletButton.displayName = 'SolanaWalletButton';
