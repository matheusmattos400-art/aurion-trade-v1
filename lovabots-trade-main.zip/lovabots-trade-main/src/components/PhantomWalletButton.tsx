import { memo } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Wallet, LogOut, Copy, ExternalLink, Loader2 } from "lucide-react";
import { usePhantomDeepLink } from "@/hooks/usePhantomDeepLink";
import { toast } from "sonner";

export const PhantomWalletButton = memo(() => {
  const {
    isConnected,
    publicKey,
    balance,
    isConnecting,
    hasPhantom,
    isMobile,
    isInPhantomBrowser,
    connectWallet,
    disconnectWallet,
  } = usePhantomDeepLink();

  const copyAddress = () => {
    if (publicKey) {
      navigator.clipboard.writeText(publicKey);
      toast.success("Endereço copiado!");
    }
  };

  const openExplorer = () => {
    if (!publicKey) return;
    window.open(`https://solscan.io/account/${publicKey}`, "_blank");
  };

  // Not connected - show connect button
  if (!isConnected) {
    return (
      <Button 
        onClick={connectWallet} 
        disabled={isConnecting}
        size="sm"
        className="bg-purple-600 hover:bg-purple-700 text-white"
      >
        {isConnecting ? (
          <Loader2 className="w-4 h-4 animate-spin mr-1" />
        ) : (
          <Wallet className="w-4 h-4 mr-1" />
        )}
        <span className="hidden sm:inline">
          {isConnecting 
            ? "Conectando..." 
            : isInPhantomBrowser 
              ? "Conectar" 
              : hasPhantom 
                ? "Conectar Phantom" 
                : isMobile 
                  ? "Abrir Phantom" 
                  : "Conectar Phantom"}
        </span>
        <span className="sm:hidden">
          {isConnecting ? "..." : "Phantom"}
        </span>
      </Button>
    );
  }

  // Connected - show dropdown with wallet info
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="border-purple-500/50 text-purple-400 hover:bg-purple-500/10">
          <div className="w-2 h-2 rounded-full bg-purple-500 animate-pulse mr-2" />
          <span className="font-mono text-xs">
            {publicKey?.slice(0, 4)}...{publicKey?.slice(-4)}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium">Phantom Wallet</p>
            <p className="text-xs text-muted-foreground font-mono">
              {publicKey?.slice(0, 8)}...{publicKey?.slice(-8)}
            </p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        <div className="px-2 py-1.5 space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs text-muted-foreground">Rede:</span>
            <Badge variant="outline" className="text-xs bg-purple-500/10 text-purple-400 border-purple-500/30">
              Solana
            </Badge>
          </div>
          {balance !== null && (
            <div className="flex justify-between items-center">
              <span className="text-xs text-muted-foreground">Saldo:</span>
              <span className="text-xs font-mono">
                {balance.toFixed(4)} SOL
              </span>
            </div>
          )}
        </div>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={copyAddress}>
          <Copy className="w-4 h-4 mr-2" />
          Copiar Endereço
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={openExplorer}>
          <ExternalLink className="w-4 h-4 mr-2" />
          Ver no Solscan
        </DropdownMenuItem>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={disconnectWallet} className="text-destructive focus:text-destructive">
          <LogOut className="w-4 h-4 mr-2" />
          Desconectar
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
});

PhantomWalletButton.displayName = "PhantomWalletButton";
