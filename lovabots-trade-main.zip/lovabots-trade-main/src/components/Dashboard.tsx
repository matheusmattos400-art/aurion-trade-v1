import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { OperationControls } from "./OperationControls";
import { StatusDisplay } from "./StatusDisplay";
import { ApiInfo } from "./ApiInfo";
import { AurionRatioChart } from "./AurionRatioChart";
import { MomentumIndicator } from "./MomentumIndicator";
import { OperationMonitor } from "./OperationMonitor";
import { UserProfile } from "./UserProfile";
import { BinanceBalance } from "./BinanceBalance";
import { LoadingScreen } from "./LoadingScreen";
import { Credits } from "./Credits";
import { CryptoTicker } from "./CryptoTicker";
import { BinanceTest } from "./BinanceTest";
import { ConnectionToggle } from "./ConnectionToggle";
import { TradingSignals } from "./TradingSignals";
import { CloseOperationModal } from "./CloseOperationModal";
import { WelcomeDashboard } from "./WelcomeDashboard";
import { supabase } from "@/integrations/supabase/client";
import { Coins, Key, Wallet, LogOut, TestTube2, ChevronDown, ChevronUp, Square, History, BarChart3, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import aurionLogo from "@/assets/aurion-triangle-logo.png";
import { useTradingMode } from "@/contexts/TradingModeContext";
import { useIsMobile } from "@/hooks/use-mobile";
import { useNavigate } from "react-router-dom";

interface ActiveOperation {
  id?: string;
  longSymbol: string;
  shortSymbol: string;
  leverageLong: number;
  leverageShort: number;
  amount: number;
  entryPriceLong: number;
  entryPriceShort: number;
  startTime: Date;
  profitTarget?: number;
  autoCloseEnabled?: boolean;
  isTest?: boolean;
  entryMomentum?: number; // Momentum congelado no momento da entrada
}
export const Dashboard = ({ onShowDatabaseInfo }: { onShowDatabaseInfo?: () => void }) => {
  const { mode, toggleMode, isB3Mode } = useTradingMode();
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  
  console.log("🎯 Dashboard renderizado com modo:", mode);
  
  const [operationStatus, setOperationStatus] = useState<"idle" | "running" | "profit" | "closed">("idle");
  const [currentPnl, setCurrentPnl] = useState(0);
  const [binanceBalance, setBinanceBalance] = useState(0);
  const [activeOperation, setActiveOperation] = useState<ActiveOperation | null>(null);
  const [currentView, setCurrentView] = useState<"dashboard" | "api" | "profile" | "credits">("dashboard");
  const [isLoading, setIsLoading] = useState(true);
  const [selectedLongPair, setSelectedLongPair] = useState("");
  const [selectedShortPair, setSelectedShortPair] = useState("");
  const [userCredits, setUserCredits] = useState(0);
  const [userName, setUserName] = useState<string>("");
  const [mobileMenuExpanded, setMobileMenuExpanded] = useState(false);
  const [configExpanded, setConfigExpanded] = useState(true);
  const [hasAutoCollapsed, setHasAutoCollapsed] = useState(false);
  const [isClosingOperation, setIsClosingOperation] = useState(false);
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [orphanPositions, setOrphanPositions] = useState<
    Array<{
      symbol: string;
      positionAmt: string;
      entryPrice?: string;
      leverage?: string;
      unrealizedProfit?: string;
    }>
  >([]);
  const orphanToastShownRef = useRef(false);
  const recoverAttemptedRef = useRef(false);
  const { toast } = useToast();

  // Buscar saldo da Binance e créditos do usuário
  useEffect(() => {
    const initializeDashboard = async () => {
      try {
        const {
          data: {
            user
          }
        } = await supabase.auth.getUser();
        
        if (!user) {
          setIsLoading(false);
          return;
        }

        console.log("🔄 Inicializando Dashboard (carregando saldo Binance e créditos)");

        // Extrair nome do usuário do email ou metadata
        const userEmail = user.email || "";
        const userMeta = user.user_metadata;
        const displayName = userMeta?.full_name || userMeta?.name || userEmail.split('@')[0] || "Trader";
        setUserName(displayName);

        // Carregar créditos do usuário
        const creditsResult = await supabase
          .from("user_credits")
          .select("credits")
          .eq("user_id", user.id)
          .maybeSingle();

        if (creditsResult.data) {
          setUserCredits(creditsResult.data.credits);
        }

        // Buscar saldo da Binance
        try {
          const { data: balanceData, error: balanceError } = await supabase.functions.invoke('binance-trading', {
            body: { action: 'get_account' },
          });

          if (balanceError) {
            console.error('Erro ao buscar saldo:', balanceError);
          } else if (balanceData?.success && balanceData?.data?.totalWalletBalance) {
            const balance = parseFloat(balanceData.data.totalWalletBalance);
            setBinanceBalance(balance);
            console.log("💰 Saldo Binance carregado:", balance);
          }
        } catch (error) {
          console.error('Erro ao carregar saldo Binance:', error);
        }

        setIsLoading(false);
      } catch (error) {
        console.error("❌ Erro ao inicializar Dashboard:", error);
        toast({
          title: "Erro ao carregar dados",
          description: "Tente recarregar a página",
          variant: "destructive",
        });
        setIsLoading(false);
      }
    };

    initializeDashboard();

    // Atualizar saldo da Binance periodicamente (a cada 30 segundos)
    const balanceInterval = setInterval(async () => {
      try {
        const { data: balanceData } = await supabase.functions.invoke('binance-trading', {
          body: { action: 'get_account' },
        });

        if (balanceData?.success && balanceData?.data?.totalWalletBalance) {
          const balance = parseFloat(balanceData.data.totalWalletBalance);
          setBinanceBalance(balance);
        }
      } catch (error) {
        console.error('Erro ao atualizar saldo:', error);
      }
    }, 30000);

    // Escutar mudanças nos créditos e operações
    const channel = supabase
      .channel("dashboard_updates")
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "user_credits"
      }, async (payload) => {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;
        
        const newData = payload.new as { user_id: string; credits: number } | null;
        if (newData && newData.user_id === user.id) {
          setUserCredits(newData.credits);
        }
      })
      .on("postgres_changes", {
        event: "UPDATE",
        schema: "public",
        table: "active_operations"
      }, async (payload) => {
        console.log("🔄 Operação ativa atualizada:", payload);
        const updatedOp = payload.new;
        
        // Atualizar apenas se for a operação ativa atual
        if (activeOperation && updatedOp.status === "active") {
          setActiveOperation(prev => prev ? {
            ...prev,
            profitTarget: Number(updatedOp.profit_target || prev.profitTarget),
            autoCloseEnabled: updatedOp.auto_close_enabled ?? prev.autoCloseEnabled,
            leverageLong: updatedOp.leverage_long || prev.leverageLong,
            leverageShort: updatedOp.leverage_short || prev.leverageShort,
            entryPriceLong: Number(updatedOp.entry_price_long || prev.entryPriceLong),
            entryPriceShort: Number(updatedOp.entry_price_short || prev.entryPriceShort),
          } : null);
        }
      })
      .subscribe();
    
    return () => {
      clearInterval(balanceInterval);
      supabase.removeChannel(channel);
    };
  }, []);

  // Carregar operação ativa baseada no modo atual (roda na montagem E quando modo muda)
  useEffect(() => {
    const loadOperationForMode = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.log("❌ Nenhum usuário autenticado");
        return;
      }

      console.log("🔍 Carregando operação ativa para o modo:", mode, "user:", user.id);

      // 1. Primeiro buscar operação no banco de dados
      const { data: activeOp, error } = await supabase
        .from("active_operations")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "active")
        .neq("long_symbol", "")
        .or(`trading_mode.eq.${mode},trading_mode.is.null`)
        .order("started_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      console.log("📊 Operação no banco:", activeOp, "Error:", error);

      // 2. Se encontrou operação no banco
      if (activeOp) {
        // Para operações REAIS, verificar se existe posição na Binance
        if (!activeOp.is_test) {
          console.log("🔍 Verificando posições REAIS na Binance...");
          try {
            const { data: positionsData } = await supabase.functions.invoke('binance-trading', {
              body: { action: 'get_positions' }
            });

            const positions = positionsData?.data?.positions || [];
            const hasLongPosition = positions.some((p: any) => 
              p.symbol === activeOp.long_symbol && parseFloat(p.positionAmt) !== 0
            );
            const hasShortPosition = positions.some((p: any) => 
              p.symbol === activeOp.short_symbol && parseFloat(p.positionAmt) !== 0
            );

            console.log("📊 Posições Binance:", { hasLongPosition, hasShortPosition });

            // Se não tem posição na Binance, marcar como closed no banco
            if (!hasLongPosition && !hasShortPosition) {
              console.log("⚠️ Operação REAL sem posição na Binance - marcando como closed");
              await supabase
                .from("active_operations")
                .update({ status: "closed" })
                .eq("id", activeOp.id);
              
              setActiveOperation(null);
              setOperationStatus("idle");
              return;
            }
          } catch (error) {
            console.error("❌ Erro ao verificar posições Binance:", error);
            // Em caso de erro, manter a operação ativa (fail-safe)
          }
        }

        // Restaurar operação (TESTE ou REAL com posição confirmada)
        console.log("✅ Restaurando operação ativa:", {
          long: activeOp.long_symbol,
          short: activeOp.short_symbol,
          mode: activeOp.trading_mode,
          isTest: activeOp.is_test,
        });

        const operation = {
          id: activeOp.id,
          longSymbol: activeOp.long_symbol,
          shortSymbol: activeOp.short_symbol,
          leverageLong: activeOp.leverage_long,
          leverageShort: activeOp.leverage_short,
          amount: Number(activeOp.investment_amount),
          entryPriceLong: Number(activeOp.entry_price_long || 0),
          entryPriceShort: Number(activeOp.entry_price_short || 0),
          startTime: new Date(activeOp.started_at),
          profitTarget: Number(activeOp.profit_target || 10),
          autoCloseEnabled: activeOp.auto_close_enabled ?? false,
          isTest: activeOp.is_test ?? false,
        };
        
        setOrphanPositions([]);
        orphanToastShownRef.current = false;
        recoverAttemptedRef.current = false;

        setActiveOperation(operation);
        setOperationStatus("running");
        setCurrentPnl(Number(activeOp.current_pnl || 0));
      } else {
        // 3. Se não tem no banco, verificar se tem posição na Binance (para operações reais que perderam registro)
        console.log("⚠️ Nenhuma operação no banco, verificando Binance para posições abertas...");

        try {
          const { data: positionsData, error: positionsError } = await supabase.functions.invoke(
            "binance-trading",
            { body: { action: "get_positions" } }
          );

          if (positionsError || !positionsData?.success) {
            throw new Error(
              positionsData?.error || positionsError?.message || "Falha ao buscar posições"
            );
          }

          const positionsRaw = Array.isArray(positionsData?.data?.positions)
            ? positionsData.data.positions
            : [];

          const positions = positionsRaw.filter(
            (p: any) => Number.parseFloat(p.positionAmt) !== 0
          );

          // ✅ Correção principal: auto-recuperar a operação quando existir exatamente 1 LONG e 1 SHORT abertos
          if (!recoverAttemptedRef.current && positions.length === 2) {
            const longPos = positions.find((p: any) => Number.parseFloat(p.positionAmt) > 0);
            const shortPos = positions.find((p: any) => Number.parseFloat(p.positionAmt) < 0);

            if (longPos && shortPos) {
              recoverAttemptedRef.current = true;

              const { data: settings } = await supabase
                .from("user_trading_settings")
                .select("investment_amount, leverage, profit_target, auto_close_enabled")
                .eq("user_id", user.id)
                .maybeSingle();

              const leverageFallback = Number(settings?.leverage ?? 1);
              const leverageLong = Number(longPos.leverage ?? leverageFallback) || leverageFallback;
              const leverageShort = Number(shortPos.leverage ?? leverageFallback) || leverageFallback;

              const investmentAmount = Number(settings?.investment_amount ?? 100);
              const profitTarget = Number(settings?.profit_target ?? 10);
              const autoCloseEnabled = Boolean(settings?.auto_close_enabled ?? false);

              const entryPriceLong = Number(longPos.entryPrice ?? 0);
              const entryPriceShort = Number(shortPos.entryPrice ?? 0);
              const recoveredPnl =
                Number(longPos.unrealizedProfit ?? 0) + Number(shortPos.unrealizedProfit ?? 0);

              const { data: recoveredOp, error: recoverError } = await supabase
                .from("active_operations")
                .insert({
                  user_id: user.id,
                  long_symbol: String(longPos.symbol),
                  short_symbol: String(shortPos.symbol),
                  leverage: Math.max(leverageLong, leverageShort),
                  leverage_long: leverageLong,
                  leverage_short: leverageShort,
                  investment_amount: investmentAmount,
                  status: "active",
                  profit_target: profitTarget,
                  auto_close_enabled: autoCloseEnabled,
                  entry_price_long: entryPriceLong > 0 ? entryPriceLong : null,
                  entry_price_short: entryPriceShort > 0 ? entryPriceShort : null,
                  current_pnl: recoveredPnl,
                  trading_mode: mode,
                })
                .select("*")
                .single();

              if (!recoverError && recoveredOp) {
                console.log("✅ Operação recuperada automaticamente:", recoveredOp.id);

                setOrphanPositions([]);
                orphanToastShownRef.current = false;

                const operation = {
                  id: recoveredOp.id,
                  longSymbol: recoveredOp.long_symbol,
                  shortSymbol: recoveredOp.short_symbol,
                  leverageLong: recoveredOp.leverage_long,
                  leverageShort: recoveredOp.leverage_short,
                  amount: Number(recoveredOp.investment_amount),
                  entryPriceLong: Number(recoveredOp.entry_price_long || 0),
                  entryPriceShort: Number(recoveredOp.entry_price_short || 0),
                  startTime: new Date(recoveredOp.started_at || new Date().toISOString()),
                  profitTarget: Number(recoveredOp.profit_target || 10),
                  autoCloseEnabled: recoveredOp.auto_close_enabled ?? false,
                  isTest: recoveredOp.is_test ?? false,
                };

                setActiveOperation(operation);
                setOperationStatus("running");
                setCurrentPnl(Number(recoveredOp.current_pnl || 0));
                return;
              }

              // se falhar, libera para tentar novamente em uma próxima recarga
              recoverAttemptedRef.current = false;
            }
          }

          // Fallback: apenas avisar que há posições abertas mas sem rastreio
          const mapped = positions.map((p: any) => ({
            symbol: String(p.symbol),
            positionAmt: String(p.positionAmt ?? "0"),
            entryPrice: String(p.entryPrice ?? ""),
            leverage: String(p.leverage ?? ""),
            unrealizedProfit: String(p.unrealizedProfit ?? "0"),
          }));

          setOrphanPositions(mapped);

          if (mapped.length > 0) {
            console.log(
              "⚠️ Encontradas posições abertas sem rastreio:",
              mapped.map((p: any) => p.symbol)
            );

            if (!orphanToastShownRef.current) {
              orphanToastShownRef.current = true;
              toast({
                title: "⚠️ Posições abertas detectadas",
                description: `Você tem ${mapped.length} posição(ões) abertas que não estão sendo rastreadas pelo app.`,
                variant: "destructive",
              });
            }
          } else {
            orphanToastShownRef.current = false;
          }
        } catch (error) {
          console.error("❌ Erro ao verificar posições Binance:", error);
        }

        setActiveOperation(null);
        setOperationStatus("idle");
      }
    };

    loadOperationForMode();
  }, [mode, toast]);

  // Colapsar automaticamente apenas na primeira vez que detectar operação ativa
  useEffect(() => {
    if (activeOperation && !hasAutoCollapsed) {
      setConfigExpanded(false);
      setHasAutoCollapsed(true);
    }

    if (!activeOperation) {
      setConfigExpanded(true);
      setHasAutoCollapsed(false);
    }
  }, [activeOperation, hasAutoCollapsed]);

  const handleOperationStart = (data: ActiveOperation) => {
    console.log("🚀 handleOperationStart chamado:", data);
    setActiveOperation(data);
    setOperationStatus("running");
    setCurrentPnl(0);
  };
  
  const handleOperationStop = () => {
    setActiveOperation(null);
    setOperationStatus("idle");
    setCurrentPnl(0);
  };
  const handlePnlUpdate = (pnl: number) => {
    setCurrentPnl(pnl);
  };

  const handleTargetReached = async () => {
    // 🛡️ PROTEÇÃO: Evitar fechamentos duplicados
    if (isClosingOperation) {
      console.log('⚠️ Já existe um fechamento em andamento, ignorando...');
      return;
    }

    console.log('🎯 ALVO ATINGIDO! Iniciando fechamento automático das posições...');
    console.log('💰 PnL atual:', currentPnl);
    console.log('🎯 Meta configurada:', activeOperation?.profitTarget);
    
    setIsClosingOperation(true);
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.error('❌ Usuário não autenticado');
      setIsClosingOperation(false);
      return;
    }

    try {
      // Buscar operação ativa
      const { data: activeOp, error: fetchError } = await supabase
        .from("active_operations")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "active")
        .maybeSingle();

      if (fetchError) {
        console.error('❌ Erro ao buscar operação ativa:', fetchError);
        throw fetchError;
      }

      if (!activeOp) {
        console.log('⚠️ Nenhuma operação ativa encontrada para fechar');
        setIsClosingOperation(false);
        return;
      }

      console.log('📋 Operação encontrada:', {
        id: activeOp.id,
        long: activeOp.long_symbol,
        short: activeOp.short_symbol,
        is_test: activeOp.is_test,
        auto_close_enabled: activeOp.auto_close_enabled
      });

      // Marcar como "closing" ANTES de fechar posições
      const { error: updateError } = await supabase
        .from("active_operations")
        .update({ status: "closing" })
        .eq("id", activeOp.id);

      if (updateError) {
        console.error('❌ Erro ao marcar operação como closing:', updateError);
        throw updateError;
      }

      console.log('✅ Operação marcada como "closing"');

      // Capturar lucro real da Binance
      let realProfit = currentPnl; // Fallback para operações de teste
      
      if (!activeOp.is_test) {
        console.log('📊 Fechando posições REAIS na Binance...');
        
        toast({
          title: "🎯 Meta atingida!",
          description: "Capturando saldo e fechando posições...",
        });

        try {
          // 1. Buscar saldo ANTES de fechar
          console.log('💰 Buscando saldo inicial da Binance...');
          const { data: accountBefore, error: accountBeforeError } = await supabase.functions.invoke('binance-trading', {
            body: { action: 'get_account' }
          });

          if (accountBeforeError || !accountBefore?.success) {
            throw new Error('Erro ao buscar saldo inicial da Binance');
          }

          const balanceBefore = parseFloat(accountBefore.data.totalWalletBalance || '0');
          console.log('💰 Saldo ANTES:', balanceBefore, 'USDT');

          // 2. Fechar LONG e SHORT em PARALELO para máxima velocidade
          console.log(`⚡ Fechando posições em PARALELO: ${activeOp.long_symbol} / ${activeOp.short_symbol}`);
          
          const closePromises = [];
          
          if (activeOp.long_symbol && activeOp.long_symbol !== "") {
            closePromises.push(
              supabase.functions.invoke('binance-trading', {
                body: { action: 'close_position', symbol: activeOp.long_symbol }
              }).then(result => ({ type: 'LONG', ...result }))
            );
          }
          
          if (activeOp.short_symbol && activeOp.short_symbol !== "") {
            closePromises.push(
              supabase.functions.invoke('binance-trading', {
                body: { action: 'close_position', symbol: activeOp.short_symbol }
              }).then(result => ({ type: 'SHORT', ...result }))
            );
          }
          
          const closeResults = await Promise.all(closePromises);
          
          for (const result of closeResults) {
            if (result.error || !result.data?.success) {
              console.error(`❌ Erro ao fechar ${result.type}:`, result.error || result.data?.error);
            } else {
              console.log(`✅ Posição ${result.type} fechada com sucesso`);
            }
          }

          // 3. Buscar saldo DEPOIS de fechar (sem delay - posições já fechadas)
          console.log('💰 Buscando saldo final da Binance...');
          const { data: accountAfter, error: accountAfterError } = await supabase.functions.invoke('binance-trading', {
            body: { action: 'get_account' }
          });

          if (accountAfterError || !accountAfter?.success) {
            throw new Error('Erro ao buscar saldo final da Binance');
          }

          const balanceAfter = parseFloat(accountAfter.data.totalWalletBalance || '0');
          console.log('💰 Saldo DEPOIS:', balanceAfter, 'USDT');

          // 4. Calcular lucro real
          realProfit = balanceAfter - balanceBefore;
          console.log('💰 LUCRO REAL:', realProfit, 'USDT');

          console.log('✅ Todas as posições fechadas na Binance');
        } catch (error) {
          console.error('❌ Erro ao capturar lucro real:', error);
          // Manter realProfit como currentPnl em caso de erro
        }
      } else {
        console.log('🧪 Operação TESTE - não fechando posições na Binance');
      }

      // Salvar no histórico com lucro REAL
      console.log('💾 Salvando operação no histórico...');
      const { error: historyError } = await supabase.from("trade_history").insert({
        user_id: user.id,
        long_symbol: activeOp.long_symbol,
        short_symbol: activeOp.short_symbol,
        leverage: activeOp.leverage_long,
        leverage_long: activeOp.leverage_long,
        leverage_short: activeOp.leverage_short,
        investment_amount: activeOp.investment_amount,
        profit: realProfit,
        started_at: activeOp.started_at,
        ended_at: new Date().toISOString(),
        duration_seconds: Math.floor((Date.now() - new Date(activeOp.started_at).getTime()) / 1000),
        is_test: activeOp.is_test || false,
      });

      if (historyError) {
        console.error('⚠️ Erro ao salvar histórico (não crítico):', historyError);
      } else {
        console.log('✅ Operação salva no histórico');
      }

      // Marcar como fechada definitivamente
      const { error: finalUpdateError } = await supabase
        .from("active_operations")
        .update({ status: "closed" })
        .eq("id", activeOp.id);

      if (finalUpdateError) {
        console.error('❌ Erro ao marcar operação como closed:', finalUpdateError);
        throw finalUpdateError;
      }

      console.log('✅ Operação marcada como "closed"');

      // Limpar estado
      setActiveOperation(null);
      setOperationStatus("idle");
      setCurrentPnl(0);

      toast({
        title: "✅ Operação fechada automaticamente!",
        description: `Lucro REAL de $${realProfit.toFixed(2)} realizado. Posições fechadas no mercado.`,
      });
      
      console.log('🎉 Fechamento automático concluído com sucesso!');
    } catch (error) {
      console.error("❌ ERRO CRÍTICO ao fechar operação automaticamente:", error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      
      toast({
        title: "❌ Erro ao fechar operação",
        description: `${errorMessage}. Use o botão de encerramento manual.`,
        variant: "destructive",
      });
    } finally {
      setIsClosingOperation(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast({
      title: "Logout realizado",
      description: "Até logo!",
    });
  };

  // Função para encerrar operação MANUALMENTE (botão "Encerrar")
  // NOVA IMPLEMENTAÇÃO: Abre modal com ordens LIMIT
  const handleCloseOperation = async () => {
    if (isClosingOperation) {
      console.log('⚠️ Já existe um fechamento em andamento, ignorando...');
      return;
    }

    if (!activeOperation) {
      console.log('⚠️ Nenhuma operação ativa');
      return;
    }

    // Para operações de TESTE, fechar direto
    if (activeOperation.isTest) {
      const pnlAtClose = currentPnl;
      
      setActiveOperation(null);
      setOperationStatus("idle");
      setCurrentPnl(0);
      
      toast({
        title: "✅ Operação TESTE encerrada",
        description: `Lucro simulado: $${pnlAtClose.toFixed(2)}`,
      });

      // Salvar em background
      const operationToClose = activeOperation;
      (async () => {
        try {
          const { data: { user } } = await supabase.auth.getUser();
          if (!user) return;

          const { data: activeOp } = await supabase
            .from("active_operations")
            .select("*")
            .eq("id", operationToClose.id)
            .maybeSingle();

          if (activeOp) {
            await supabase.from("trade_history").insert({
              user_id: user.id,
              long_symbol: activeOp.long_symbol,
              short_symbol: activeOp.short_symbol,
              leverage: activeOp.leverage_long,
              leverage_long: activeOp.leverage_long,
              leverage_short: activeOp.leverage_short,
              investment_amount: activeOp.investment_amount,
              profit: pnlAtClose,
              started_at: activeOp.started_at,
              ended_at: new Date().toISOString(),
              duration_seconds: Math.floor((Date.now() - new Date(activeOp.started_at).getTime()) / 1000),
              is_test: true,
            });

            await supabase
              .from("active_operations")
              .update({ status: "closed" })
              .eq("id", activeOp.id);
          }
        } catch (bgError) {
          console.error('❌ Erro em background:', bgError);
        }
      })();
      
      return;
    }

    // Para operações REAIS, abrir modal com ordens LIMIT
    setShowCloseModal(true);
  };

  // Callback quando o modal de fechamento tiver sucesso
  const handleCloseModalSuccess = async () => {
    const pnlAtClose = currentPnl;
    const operationToClose = activeOperation;

    // Limpar estado
    setActiveOperation(null);
    setOperationStatus("idle");
    setCurrentPnl(0);
    setShowCloseModal(false);

    // Salvar histórico em background
    if (operationToClose) {
      (async () => {
        try {
          const { data: { user } } = await supabase.auth.getUser();
          if (!user) return;

          const { data: activeOp } = await supabase
            .from("active_operations")
            .select("*")
            .eq("id", operationToClose.id)
            .maybeSingle();

          if (activeOp) {
            await supabase.from("trade_history").insert({
              user_id: user.id,
              long_symbol: activeOp.long_symbol,
              short_symbol: activeOp.short_symbol,
              leverage: activeOp.leverage_long,
              leverage_long: activeOp.leverage_long,
              leverage_short: activeOp.leverage_short,
              investment_amount: activeOp.investment_amount,
              profit: pnlAtClose,
              started_at: activeOp.started_at,
              ended_at: new Date().toISOString(),
              duration_seconds: Math.floor((Date.now() - new Date(activeOp.started_at).getTime()) / 1000),
              is_test: false,
            });

            await supabase
              .from("active_operations")
              .update({ status: "closed" })
              .eq("id", activeOp.id);

            console.log('✅ Histórico salvo após fechamento com ordens LIMIT');
          }
        } catch (bgError) {
          console.error('❌ Erro em background:', bgError);
        }
      })();
    }
  };

  const handleEmergencyStop = async () => {
    const confirmed = window.confirm(
      "⚠️ ENCERRAMENTO DE EMERGÊNCIA\n\n" +
      "Isso vai encerrar a operação ativa e limpar o estado.\n" +
      "NÃO fecha posições na Binance!\n" +
      "Use apenas se a operação estiver travada.\n\n" +
      "Continuar?"
    );

    if (!confirmed) return;

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    try {
      const { data: activeOp } = await supabase
        .from("active_operations")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "active")
        .maybeSingle();

      if (activeOp) {
        await supabase.from("trade_history").insert({
          user_id: user.id,
          long_symbol: activeOp.long_symbol,
          short_symbol: activeOp.short_symbol,
          leverage: activeOp.leverage_long,
          leverage_long: activeOp.leverage_long,
          leverage_short: activeOp.leverage_short,
          investment_amount: activeOp.investment_amount,
          profit: currentPnl,
          started_at: activeOp.started_at,
          ended_at: new Date().toISOString(),
          duration_seconds: Math.floor((Date.now() - new Date(activeOp.started_at).getTime()) / 1000),
          is_test: activeOp.is_test || false,
        });

        await supabase
          .from("active_operations")
          .update({ status: "closed" })
          .eq("id", activeOp.id);
      }

      setActiveOperation(null);
      setOperationStatus("idle");
      setCurrentPnl(0);

      toast({
        title: "✅ Estado limpo",
        description: "Verifique suas posições na Binance manualmente",
      });
    } catch (error) {
      console.error("Erro no encerramento de emergência:", error);
      toast({
        title: "Erro",
        description: "Falha ao encerrar operação",
        variant: "destructive",
      });
    }
  };

  const navItems = [
    { icon: null, label: "Meu cadastro", action: () => setCurrentView("profile"), useLogo: true },
    { icon: BarChart3, label: "Trading", action: () => navigate("/aurion-strategy") },
    { icon: Zap, label: "Aurion", action: () => navigate("/aurion") },
    { icon: History, label: "Histórico", action: () => navigate("/history") },
    { icon: Coins, label: "Créditos", action: () => setCurrentView("credits") },
    { icon: Key, label: "API", action: () => setCurrentView("api") },
    { icon: LogOut, label: "Sair", action: handleLogout },
  ];

  return <div className="min-h-screen bg-background p-1 sm:p-2 md:p-4">
      <div className="max-w-7xl mx-auto space-y-2 sm:space-y-3 overflow-x-hidden">
        {/* WebSocket Status - Mobile Only (Above Header) */}
        {isMobile && (
          <div className="flex justify-center">
            <ConnectionToggle />
          </div>
        )}

        {/* Header with circular navigation */}
        <div className="relative">
          <header className="gradient-header rounded-xl sm:rounded-2xl p-2 sm:p-3 md:p-4 premium-border relative overflow-hidden">
            <div className="absolute inset-0 gradient-premium opacity-50 pointer-events-none"></div>
            
            <div className="relative flex items-center justify-between gap-2 sm:gap-3">
              {/* Logo Circle - Início */}
              <button 
                onClick={() => setCurrentView("dashboard")}
                className="flex flex-col items-center gap-0.5 sm:gap-1 group flex-shrink-0"
              >
                <div className="w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14 rounded-full bg-card/50 backdrop-blur-sm border-2 border-primary p-2 sm:p-2.5 hover:scale-110 hover:border-primary/80 transition-all flex items-center justify-center shadow-glow">
                  <img src={aurionLogo} alt="AURION" className="w-full h-full object-contain drop-shadow-lg" />
                </div>
                <span className="text-[9px] sm:text-[10px] text-primary font-bold uppercase tracking-wide">INÍCIO</span>
              </button>

              {/* Logo AURION texto - Apenas Mobile Centralizado */}
              {isMobile && (
                <div className="absolute left-1/2 transform -translate-x-1/2">
                  <h1 className="text-2xl sm:text-3xl font-black tracking-tight" style={{ 
                    fontFamily: 'Inter, system-ui, sans-serif',
                    fontWeight: 900,
                    color: '#C9943B',
                    textShadow: '0 4px 8px rgba(201, 148, 59, 0.3)',
                    letterSpacing: '0.1em'
                  }}>
                    AURION
                  </h1>
                </div>
              )}

              {/* Navigation circles */}
              <div className="flex items-center gap-1 sm:gap-1.5 md:gap-3 flex-wrap justify-end flex-1 min-w-0">
                {/* Mobile: Botão de expansão do menu */}
                {isMobile && (
                  <button
                    onClick={() => setMobileMenuExpanded(!mobileMenuExpanded)}
                    className="flex flex-col items-center gap-0.5 group flex-shrink-0"
                  >
                    <div className="w-9 h-9 rounded-full bg-card/50 backdrop-blur-sm border-2 border-primary p-1.5 hover:scale-110 hover:border-primary/80 transition-all flex items-center justify-center shadow-glow">
                      <img src={aurionLogo} alt="Menu" className="w-full h-full object-contain drop-shadow-lg" />
                    </div>
                    <span className="text-[7px] text-primary font-bold uppercase">MENU</span>
                  </button>
                )}

                {/* Desktop: Sempre mostra */}
                {!isMobile && (
                  <div className="flex items-center gap-1 sm:gap-1.5 md:gap-3 flex-wrap">
                    {/* Connection Status Indicator */}
                    <div className="mr-1.5 sm:mr-2">
                      <ConnectionToggle />
                    </div>
                    
                    {navItems.map((item, index) => (
                      <button
                        key={index}
                        onClick={item.action}
                        className="flex flex-col items-center gap-0.5 group flex-shrink-0"
                      >
                        <div className={`w-8 h-8 sm:w-9 sm:h-9 md:w-10 md:h-10 rounded-full backdrop-blur-sm transition-all flex items-center justify-center ${
                          item.useLogo 
                            ? 'bg-card/50 border-2 border-primary p-1.5 hover:scale-110 hover:border-primary/80 shadow-glow' 
                            : 'bg-primary/10 hover:bg-primary/20'
                        }`}>
                          {item.useLogo ? (
                            <img src={aurionLogo} alt={item.label} className="w-full h-full object-contain drop-shadow-lg" />
                          ) : (
                            <item.icon className="w-3.5 h-3.5 sm:w-5 sm:h-5 text-primary" />
                          )}
                        </div>
                        <span className="text-[8px] sm:text-[9px] font-bold uppercase tracking-wide text-primary">{item.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

        </header>

        {/* Mobile: Menu expandido ABAIXO do header */}
        {isMobile && mobileMenuExpanded && (
          <div className="gradient-header rounded-xl p-3 premium-border animate-fade-in">
            <div className="flex items-center gap-3 flex-wrap justify-center">
              {navItems.map((item, index) => (
                <button
                  key={index}
                  onClick={() => {
                    item.action();
                    setMobileMenuExpanded(false);
                  }}
                  className="flex flex-col items-center gap-0.5 group flex-shrink-0"
                >
                  <div className={`w-10 h-10 rounded-full backdrop-blur-sm transition-all flex items-center justify-center ${
                    item.useLogo 
                      ? 'bg-card/50 border-2 border-primary p-2 hover:scale-110 hover:border-primary/80 shadow-glow' 
                      : 'bg-primary/10 hover:bg-primary/20'
                  }`}>
                    {item.useLogo ? (
                      <img src={aurionLogo} alt={item.label} className="w-full h-full object-contain drop-shadow-lg" />
                    ) : (
                      <item.icon className="w-5 h-5 text-primary" />
                    )}
                  </div>
                  <span className="text-[9px] font-bold uppercase tracking-wide text-primary">{item.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}
        </div>

        {/* Mode Indicator */}
        {isB3Mode && (
          <div className="text-center py-2 px-4 bg-primary/10 rounded-lg border border-primary/20">
            <p className="text-xs sm:text-sm text-primary font-medium">
              🇧🇷 Aurion B3 — Modo Análise de Ativos Brasileiros
            </p>
          </div>
        )}

        {/* Content */}
        {currentView === "dashboard" ? (
          <WelcomeDashboard 
            binanceBalance={binanceBalance}
            userCredits={userCredits}
            userName={userName}
            orphanPositions={orphanPositions}
            onAddCredits={() => setCurrentView("credits")}
          />
        ) : <Card className="glass-card premium-border p-3 sm:p-4 max-w-2xl mx-auto">
            {currentView === "api" ? (
              <>
                <h2 className="text-base sm:text-lg md:text-xl font-bold mb-3 sm:mb-4 gradient-primary bg-clip-text text-transparent">
                  Integrações & Configurações
                </h2>
                <div className="space-y-4">
                  <div className="border-b border-border pb-4">
                    <h3 className="text-sm sm:text-base font-bold mb-2 text-primary uppercase tracking-wide">Credenciais Binance API</h3>
                    <ApiInfo />
                  </div>
                  
                  <div className="border-b border-border pb-4">
                    <h3 className="text-sm sm:text-base font-bold mb-2 text-primary uppercase tracking-wide">Meu Saldo</h3>
                    <BinanceBalance />
                  </div>
                  
                  <div>
                    <h3 className="text-sm sm:text-base font-bold mb-2 text-primary uppercase tracking-wide">Testes de Integração</h3>
                    <BinanceTest />
                  </div>
                </div>
              </>
            ) : (
              <>
                <h2 className="text-base sm:text-lg md:text-xl font-bold mb-3 sm:mb-4 gradient-primary bg-clip-text text-transparent">
                  {currentView === "profile" ? "Meu Cadastro" : "Créditos"}
                </h2>
                {currentView === "profile" && <UserProfile />}
                {currentView === "credits" && <Credits />}
              </>
            )}
          </Card>}
      </div>

      {/* Modal de fechamento com ordens LIMIT */}
      <CloseOperationModal
        isOpen={showCloseModal}
        onClose={() => setShowCloseModal(false)}
        operation={activeOperation}
        onSuccess={handleCloseModalSuccess}
      />
    </div>;
};