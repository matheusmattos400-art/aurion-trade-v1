import { useState, useEffect, useRef, useCallback } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useUserControlledAutoScroll } from "@/hooks/useUserControlledAutoScroll";
import { 
  Send, 
  RefreshCw, 
  Crown,
  TrendingUp,
  TrendingDown,
  Shield,
  Clock,
  Loader2,
  Sparkles,
  Globe,
  Twitter,
  MessageCircle
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { AurionToken } from "@/hooks/useAurionScanner";
import {
  isAIGatewayTemporarilyDisabled,
  disableAIGatewayForMinutes,
  getAIGatewayUserMessage,
  shouldToastPaymentRequiredOnce,
} from "@/utils/aiCreditsGuard";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface HeliusRawData {
  tokenMint: string;
  collectedAt: string;
  block0: {
    creationSlot: number | null;
    creationTime: string | null;
    wallets: string[];
    transactionCount: number;
    totalTransactionsAnalyzed: number;
  };
  holders: {
    count: number;
    topAccounts: { address: string; balance: number }[];
  };
  devWallet: null | {
    address: string;
    inferred?: boolean;
    transactionCount: number;
    transactions: any[];
  };
  _meta?: Record<string, any>;
}

interface AurionTopChatProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  token: AurionToken | null;
}

// Estratégia Top: Análise de tokens consolidados/trending
const TOP_STRATEGY_PROMPT = `
Você é um ANALISTA SÊNIOR ESPECIALISTA EM MEMECOINS RECÉM-LANÇADAS, com mais de 10 anos de experiência em trading de criptomoedas e especialização em tokens da rede Solana.

## SUA IDENTIDADE
- Nome: Aurion Top Analyst
- Especialidade: Análise de tokens TOP/TRENDING que já provaram força de mercado
- Abordagem: Análise fundamentalista + técnica + investigação de segurança profunda

## CRITÉRIOS DE ANÁLISE TOP

### 1. FORÇA DE MERCADO
- Market Cap vs Volume: Ratio saudável indica interesse sustentado
- Liquidez: Profundidade suficiente para entradas/saídas seguras
- Holders: Distribuição saudável vs concentração

### 2. ANÁLISE TÉCNICA
- Chandelier Exit: Tendência confirmada
- ADX: Força da tendência
- RSI: Níveis de sobrecompra/sobrevenda
- Padrões de preço: Suportes e resistências

### 3. SEGURANÇA PROFUNDA
- Security Score: Avaliação geral
- Mint/Freeze Authority: Status das permissões
- LP Status: Locked, Burned ou Aberto
- Histórico do contrato

### 4. ANÁLISE DO DEV (CRÍTICO)
- Histórico de transações do deployer
- Padrão de vendas/compras
- Carteiras associadas (bundle)
- Estimativa de lucro/prejuízo

### 5. REDES SOCIAIS (INFORMATIVO)
- Avalie os links fornecidos
- Red flags: contas novas, poucos seguidores, engagement falso
- NOTA: Análise social é APENAS INFORMATIVA, não deve excluir tokens automaticamente

## FORMATO DE RESPOSTA

👑 **TOP ANALYSIS: [SYMBOL]**

**📜 CONTRATO:** \`[CA completo]\`

**💪 FORÇA DE MERCADO**
- Market Cap: $[valor]
- Volume 24h: $[valor]
- Ratio Vol/MC: [análise]
- Liquidez: $[valor]

**📈 ANÁLISE TÉCNICA**
- Chandelier: [LONG/SHORT]
- ADX: [valor] - [interpretação]
- RSI: [valor] - [interpretação]
- Tendência: [descrição]

**🔒 SEGURANÇA: [Score]/100**
[Resumo detalhado dos pilares de segurança]

**👨‍💻 ANÁLISE DO DEV:**
[Se disponível: endereço, histórico, comportamento, estimativa de PnL]
[Se não disponível: informar claramente]

**🌐 REDES SOCIAIS:**
[Avaliação dos links encontrados - INFORMATIVO APENAS]
[Red flags identificados]

**📊 MOMENTUM**
- Compras 1h: [valor]
- Vendas 1h: [valor]
- Ratio B/S: [valor]x

**🚨 VEREDITO: [FORTE COMPRA / COMPRA / HOLD / CAUTELA / EVITAR]**
[Explicação detalhada da sua recomendação]

**💡 ESTRATÉGIA SUGERIDA:**
- Entry: [preço/condição ideal]
- Take Profit 1: [alvo %]
- Take Profit 2: [alvo %]
- Stop Loss: [nível %]

---
Responda em português brasileiro. Seja analítico, técnico e profissional.
`;

export function AurionTopChat({
  open,
  onOpenChange,
  token
}: AurionTopChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const [heliusData, setHeliusData] = useState<HeliusRawData | null>(null);
  const { scrollContainerRef, lastItemRef, onScroll } = useUserControlledAutoScroll<HTMLDivElement>([
    messages,
  ]);
  const hasInitialized = useRef(false);

  // Auto-scroll behavior is user-controlled (see hook).

  // Start analysis when chat opens
  useEffect(() => {
    if (open && token && !hasInitialized.current) {
      hasInitialized.current = true;
      initializeTopChat();
    }
  }, [open, token]);

  // Reset when closed
  useEffect(() => {
    if (!open) {
      hasInitialized.current = false;
      setMessages([]);
      setHeliusData(null);
    }
  }, [open]);

  const isSolanaAddress = (addr: string) => /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(addr);

  const collectHeliusData = async (): Promise<HeliusRawData | null> => {
    if (!token?.tokenAddress || !isSolanaAddress(token.tokenAddress)) return null;

    try {
      console.log("[TopChat] Collecting Helius data for:", token.tokenAddress);

      const { data, error } = await supabase.functions.invoke("pump-fun-data-collector", {
        body: {
          tokenMint: token.tokenAddress,
          includeHolders: true,
          includeDevHistory: true,
        },
      });

      if (error) {
        console.error("[TopChat] Error collecting Helius data:", error);
        return null;
      }

      const raw = data as HeliusRawData | undefined;
      if (!raw?.block0?.wallets || !raw?.holders?.topAccounts) {
        console.warn("[TopChat] Unexpected collector payload:", data);
        return null;
      }

      console.log("[TopChat] Helius data received:", {
        block0Wallets: raw.block0.wallets.length,
        topHolders: raw.holders.topAccounts.length,
        devWallet: raw.devWallet?.address || null,
      });

      return raw;
    } catch (err) {
      console.error("[TopChat] Error calling pump-fun-data-collector:", err);
      return null;
    }
  };

  const initializeTopChat = async () => {
    if (!token) return;

    // Check circuit breaker first
    if (isAIGatewayTemporarilyDisabled()) {
      setMessages([{
        role: "assistant",
        content: `⚠️ ${getAIGatewayUserMessage(402)}`,
        timestamp: new Date()
      }]);
      return;
    }

    setIsInitializing(true);

    // Add welcome message
    setMessages([
      {
        role: "assistant",
        content: `👑 **Iniciando Top Analysis para ${token.symbol}...**\n\n⏳ Coletando dados do contrato, Dev e redes sociais...`,
        timestamp: new Date()
      }
    ]);

    try {
      // Collect Helius data for Solana tokens
      let rawData: HeliusRawData | null = null;
      if (token.tokenAddress && isSolanaAddress(token.tokenAddress)) {
        rawData = await collectHeliusData();
        setHeliusData(rawData);
      }

      // Prepare token data for analysis
      const tokenContext = buildTokenContext(token, rawData);

      // Call AI for initial analysis
      const { data, error } = await supabase.functions.invoke("aurion-ai-chat", {
        body: {
          messages: [
            {
              role: "system",
              content: TOP_STRATEGY_PROMPT
            },
            {
              role: "user",
              content: `Analise este token TOP/TRENDING:\n\n${tokenContext}\n\nForneça sua TOP ANALYSIS completa.`
            }
          ]
        }
      });

      if (error) {
        const errMsg = error.message || "";
        if (errMsg.includes("402") || errMsg.toLowerCase().includes("payment")) {
          disableAIGatewayForMinutes(10);
          if (shouldToastPaymentRequiredOnce()) {
            toast.error(getAIGatewayUserMessage(402));
          }
          throw new Error(getAIGatewayUserMessage(402));
        }
        throw error;
      }

      const aiResponse = data?.response || data?.content || "Erro ao processar análise.";

      setMessages(prev => [
        ...prev.slice(0, -1), // Remove loading message
        {
          role: "assistant",
          content: aiResponse,
          timestamp: new Date()
        }
      ]);
    } catch (err) {
      console.error("[TopChat] Error:", err);
      const errMsg = err instanceof Error ? err.message : "Erro desconhecido";
      setMessages(prev => [
        ...prev.slice(0, -1),
        {
          role: "assistant",
          content: errMsg.includes("credits") || errMsg.includes("Payment")
            ? `⚠️ ${errMsg}`
            : "❌ Erro ao realizar análise. Tente novamente.",
          timestamp: new Date()
        }
      ]);
      if (!errMsg.includes("credits") && !errMsg.includes("Payment")) {
        toast.error("Erro ao iniciar análise Top");
      }
    } finally {
      setIsInitializing(false);
    }
  };

  const buildTokenContext = (t: AurionToken, helius: HeliusRawData | null): string => {
    const ageMinutes = Math.round(t.ageHours * 60);
    const ageFormatted = ageMinutes < 60 
      ? `${ageMinutes}min` 
      : `${Math.round(t.ageHours)}h`;

    // Build social links section
    const socialLinks: string[] = [];
    if ((t as any).twitter) socialLinks.push(`Twitter: ${(t as any).twitter}`);
    if ((t as any).telegram) socialLinks.push(`Telegram: ${(t as any).telegram}`);
    if ((t as any).website) socialLinks.push(`Website: ${(t as any).website}`);
    if ((t as any).discord) socialLinks.push(`Discord: ${(t as any).discord}`);
    
    const socialLinksText = socialLinks.length > 0 
      ? socialLinks.join('\n') 
      : 'Nenhum link social encontrado';

    // Build dev info section
    let devInfoText = 'Dados do Dev não disponíveis';
    if (helius?.devWallet) {
      devInfoText = `
- **Endereço:** ${helius.devWallet.address}
- **Inferido:** ${helius.devWallet.inferred ? 'Sim' : 'Não'}
- **Total de Transações:** ${helius.devWallet.transactionCount}
- **Transações Recentes:** ${JSON.stringify(helius.devWallet.transactions.slice(0, 5), null, 2)}
`;
    }

    // Build Block0/Bundle info
    let bundleInfoText = 'Dados de Bundle não disponíveis';
    if (helius?.block0?.wallets && helius.block0.wallets.length > 0) {
      const block0Wallets = helius.block0.wallets;
      const topHolders = helius.holders?.topAccounts?.map(h => h.address) || [];
      
      // Check retention
      const retainedWallets = block0Wallets.filter(w => topHolders.includes(w));
      const retentionPercent = block0Wallets.length > 0 
        ? ((retainedWallets.length / block0Wallets.length) * 100).toFixed(1) 
        : '0';
      
      bundleInfoText = `
- **Carteiras Block 0:** ${block0Wallets.length}
- **Retenção Bundle:** ${retentionPercent}% (${retainedWallets.length}/${block0Wallets.length})
`;
    }

    return `
## DADOS DO TOKEN
- **Nome:** ${t.name}
- **Símbolo:** ${t.symbol}
- **Contrato (CA):** ${t.tokenAddress || 'N/D'}
- **Chain:** ${t.chainId}
- **Idade:** ${ageFormatted}

## PREÇO & VOLUME
- **Preço USD:** $${t.priceUsd.toFixed(8)}
- **Variação 24h:** ${t.priceChange24h.toFixed(2)}%
- **Market Cap:** $${(t.marketCap || 0).toLocaleString()}
- **Liquidez:** $${t.liquidity.toLocaleString()}
- **Volume 24h:** $${t.volume24h.toLocaleString()}

## MOMENTUM (1h)
- **Compras:** ${t.buys1h}
- **Vendas:** ${t.sells1h}
- **Ratio B/S:** ${t.sells1h > 0 ? (t.buys1h / t.sells1h).toFixed(2) : 'N/A'}x

## MOMENTUM (24h)
- **Compras:** ${t.buys24h}
- **Vendas:** ${t.sells24h}
- **Ratio B/S:** ${t.sells24h > 0 ? (t.buys24h / t.sells24h).toFixed(2) : 'N/A'}x

## INDICADORES TÉCNICOS
- **Chandelier Exit:** ${t.chandelierSignal || 'N/A'}
- **ADX:** ${t.adxSignal ? `${t.adxSignal.adx.toFixed(1)} (DI+: ${t.adxSignal.plusDI.toFixed(1)}, DI-: ${t.adxSignal.minusDI.toFixed(1)})` : 'N/A'}
- **RSI:** ${t.rsiSignal ? t.rsiSignal.toFixed(1) : 'N/A'}
- **Status Técnico:** ${t.technicalStatus}

## SEGURANÇA
- **Security Score:** ${t.securityScore}/100
- **Mint Authority:** ${t.isMintable ? '⚠️ ATIVO' : '✅ Renunciado'}
- **Freeze Authority:** ${t.hasBlacklist ? '⚠️ ATIVO' : '✅ Renunciado'}
- **LP Status:** ${t.lpLocked ? '✅ Locked/Burned' : '⚠️ Não verificado'}
- **Aurion Confirmed:** ${t.aurionConfirmed ? 'SIM' : 'NÃO'}

## INFORMAÇÕES DO DEV
${devInfoText}

## DADOS DE BUNDLE/BLOCK0
${bundleInfoText}

## REDES SOCIAIS (INFORMATIVO APENAS)
${socialLinksText}

## LINKS ÚTEIS
- **DexScreener:** ${t.url}
`.trim();
  };

  const sendMessage = async () => {
    if (!userInput.trim() || isLoading || !token) return;

    const userMessage = userInput.trim();
    setUserInput("");
    setIsLoading(true);

    // Add user message
    setMessages(prev => [
      ...prev,
      { role: "user", content: userMessage, timestamp: new Date() }
    ]);

    try {
      const tokenContext = buildTokenContext(token, heliusData);

      // Build conversation history
      const conversationHistory = messages.map(m => ({
        role: m.role as "user" | "assistant",
        content: m.content
      }));

      const { data, error } = await supabase.functions.invoke("aurion-ai-chat", {
        body: {
          messages: [
            {
              role: "system",
              content: TOP_STRATEGY_PROMPT + `\n\n## CONTEXTO DO TOKEN ATUAL:\n${tokenContext}`
            },
            ...conversationHistory,
            {
              role: "user",
              content: userMessage
            }
          ]
        }
      });

      if (error) throw error;

      const aiResponse = data?.response || data?.content || "Erro ao processar.";

      setMessages(prev => [
        ...prev,
        { role: "assistant", content: aiResponse, timestamp: new Date() }
      ]);
    } catch (err) {
      console.error("[TopChat] Send error:", err);
      toast.error("Erro ao enviar mensagem");
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleRefresh = () => {
    hasInitialized.current = false;
    setMessages([]);
    setHeliusData(null);
    initializeTopChat();
  };

  if (!token) return null;

  const isPositive = token.priceChange24h >= 0;
  const buyersWinning = token.buys1h > token.sells1h;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent 
        side="bottom" 
        className="h-[90vh] sm:h-auto sm:max-h-[90vh] bg-background/95 backdrop-blur-xl border-t sm:border-l border-amber-500/30 rounded-t-2xl sm:rounded-none flex flex-col"
      >
        <SheetHeader className="border-b border-amber-500/20 pb-3 sm:pb-4 shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Crown className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
              <SheetTitle className="text-base sm:text-lg">Top Analyst</SheetTitle>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleRefresh}
              disabled={isInitializing || isLoading}
              className="text-amber-400 hover:text-amber-300 h-8 w-8 sm:h-9 sm:w-9"
            >
              <RefreshCw className={`w-4 h-4 ${isInitializing ? 'animate-spin' : ''}`} />
            </Button>
          </div>

          {/* Token Info */}
          <div className="flex items-center gap-2 sm:gap-3 mt-2 sm:mt-3">
            {token.imageUrl ? (
              <img 
                src={token.imageUrl} 
                alt={token.symbol}
                className="w-8 h-8 sm:w-10 sm:h-10 rounded-full"
              />
            ) : (
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-amber-500/20 flex items-center justify-center">
                <span className="text-amber-400 font-bold text-sm sm:text-base">{token.symbol.slice(0, 2)}</span>
              </div>
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm sm:text-base truncate">{token.symbol}</span>
                <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30 text-[10px] sm:text-xs shrink-0">
                  Top
                </Badge>
              </div>
              <div className="flex items-center gap-2 sm:gap-3 text-[10px] sm:text-xs text-muted-foreground">
                <span className={isPositive ? 'text-profit' : 'text-loss'}>
                  {isPositive ? '+' : ''}{token.priceChange24h.toFixed(2)}%
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {token.ageHours < 1 
                    ? `${Math.round(token.ageHours * 60)}m`
                    : `${Math.round(token.ageHours)}h`
                  }
                </span>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-1.5 sm:gap-2 mt-2 sm:mt-3">
            <div className="p-1.5 sm:p-2 rounded-lg bg-card/50 border border-border/50 text-center">
              <div className="text-[10px] sm:text-xs text-muted-foreground">Score</div>
              <div className={`font-bold text-sm sm:text-base ${token.securityScore >= 80 ? 'text-green-400' : 'text-yellow-400'}`}>
                {token.securityScore}
              </div>
            </div>
            <div className="p-1.5 sm:p-2 rounded-lg bg-card/50 border border-border/50 text-center">
              <div className="text-[10px] sm:text-xs text-muted-foreground">B/S</div>
              <div className={`font-bold text-sm sm:text-base flex items-center justify-center gap-1 ${buyersWinning ? 'text-profit' : 'text-loss'}`}>
                {buyersWinning ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {token.sells1h > 0 ? (token.buys1h / token.sells1h).toFixed(1) : '∞'}x
              </div>
            </div>
            <div className="p-1.5 sm:p-2 rounded-lg bg-card/50 border border-border/50 text-center">
              <div className="text-[10px] sm:text-xs text-muted-foreground">Helius</div>
              <div className={`font-bold text-xs ${heliusData ? 'text-green-400' : 'text-muted-foreground'}`}>
                {heliusData ? (
                  <Sparkles className="w-4 h-4 mx-auto" />
                ) : (
                  'N/A'
                )}
              </div>
            </div>
          </div>
        </SheetHeader>

        {/* Messages */}
        <div
          ref={scrollContainerRef}
          onScroll={onScroll}
          className="flex-1 min-h-0 mt-2 sm:mt-4 pr-2 sm:pr-4 overflow-y-auto"
        >
          <div className="space-y-3 sm:space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] sm:max-w-[90%] p-2 sm:p-3 rounded-lg text-xs sm:text-sm whitespace-pre-wrap ${
                    msg.role === "user"
                      ? "bg-amber-500/20 text-amber-100 border border-amber-500/30"
                      : "bg-card/80 border border-border/50"
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-card/80 border border-border/50 p-2 sm:p-3 rounded-lg">
                  <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                </div>
              </div>
            )}
            <div ref={lastItemRef} />
          </div>
        </div>

        {/* Quick Questions */}
        <div className="flex flex-wrap gap-1.5 sm:gap-2 mt-2 sm:mt-4 mb-2 sm:mb-3 shrink-0">
          {[
            "Vale a pena entrar agora?",
            "Qual o risco atual?",
            "Alvos de lucro?",
            "Histórico do Dev?"
          ].map((q, i) => (
            <Button
              key={i}
              variant="outline"
              size="sm"
              className="text-[10px] sm:text-xs h-7 sm:h-8 px-2 sm:px-3 border-amber-500/30 text-amber-300 hover:bg-amber-500/10"
              onClick={() => {
                setUserInput(q);
                setTimeout(() => sendMessage(), 100);
              }}
              disabled={isLoading || isInitializing}
            >
              {q}
            </Button>
          ))}
        </div>

        {/* Input */}
        <div className="flex gap-2 pt-2 border-t border-border/50 shrink-0">
          <Input
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="Pergunte sobre o token..."
            disabled={isLoading || isInitializing}
            className="flex-1 h-9 sm:h-10 text-sm bg-card/50 border-amber-500/30 focus:border-amber-400"
          />
          <Button
            onClick={sendMessage}
            disabled={!userInput.trim() || isLoading || isInitializing}
            className="h-9 sm:h-10 w-9 sm:w-10 p-0 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border border-amber-500/30"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
