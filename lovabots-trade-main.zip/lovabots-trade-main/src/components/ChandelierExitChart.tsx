import { useState, useEffect, useRef } from "react";
import { ArrowUpCircle, ArrowDownCircle } from "lucide-react";

interface ChandelierExitChartProps {
  symbol: string;
  settings: {
    chandelierPeriod: number;
    chandelierMultiplier: number;
  };
}

interface SignalData {
  time: string;
  timestamp: number;
  type: 'BUY' | 'SELL';
  price: number;
}

export const ChandelierExitChart = ({ symbol, settings }: ChandelierExitChartProps) => {
  const [signals, setSignals] = useState<SignalData[]>([]);
  const [currentTrend, setCurrentTrend] = useState<'LONG' | 'SHORT'>('LONG');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<NodeJS.Timeout>();

  // Calcular ATR
  const calculateATR = (klines: any[], period: number): number[] => {
    const trValues: number[] = [];
    
    for (let i = 1; i < klines.length; i++) {
      const high = parseFloat(klines[i][2]);
      const low = parseFloat(klines[i][3]);
      const prevClose = parseFloat(klines[i - 1][4]);
      
      const tr = Math.max(
        high - low,
        Math.abs(high - prevClose),
        Math.abs(low - prevClose)
      );
      trValues.push(tr);
    }

    // Calcular ATR com média móvel
    const atrValues: number[] = [];
    for (let i = 0; i < trValues.length; i++) {
      if (i < period - 1) {
        atrValues.push(0);
      } else {
        const sum = trValues.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
        atrValues.push(sum / period);
      }
    }

    return atrValues;
  };

  useEffect(() => {
    if (!symbol) {
      setIsLoading(false);
      return;
    }

    const fetchChandelierData = async () => {
      try {
        setIsLoading(true);
        setError(null);

        const limit = 100;
        const response = await fetch(
          `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=5m&limit=${limit}`
        );

        if (!response.ok) {
          throw new Error("Erro ao buscar dados da Binance");
        }

        const klines = await response.json();

        if (klines.length < settings.chandelierPeriod + 10) {
          throw new Error("Dados insuficientes");
        }

        // Calcular ATR
        const atrValues = calculateATR(klines, settings.chandelierPeriod);

        // Detectar sinais
        const detectedSignals: SignalData[] = [];
        let prevTrend: 'LONG' | 'SHORT' = 'LONG';
        let latestTrend: 'LONG' | 'SHORT' = 'LONG';

        for (let i = settings.chandelierPeriod; i < klines.length; i++) {
          const atrIndex = i - 1;
          if (atrIndex < 0 || atrIndex >= atrValues.length) continue;

          const atr = atrValues[atrIndex];
          if (atr === 0) continue;

          // Calcular Highest High e Lowest Low do período
          let highestHigh = 0;
          let lowestLow = Infinity;

          for (let j = Math.max(0, i - settings.chandelierPeriod); j <= i; j++) {
            const high = parseFloat(klines[j][2]);
            const low = parseFloat(klines[j][3]);
            if (high > highestHigh) highestHigh = high;
            if (low < lowestLow) lowestLow = low;
          }

          const close = parseFloat(klines[i][4]);
          const timestamp = new Date(klines[i][0]);
          const timeKey = timestamp.toLocaleTimeString('pt-BR', { 
            hour: '2-digit', 
            minute: '2-digit' 
          });

          // Chandelier Exit levels
          const longStop = highestHigh - (atr * settings.chandelierMultiplier);
          const shortStop = lowestLow + (atr * settings.chandelierMultiplier);

          // Determinar tendência atual
          let trend: 'LONG' | 'SHORT';
          if (close > shortStop) {
            trend = 'LONG';
          } else if (close < longStop) {
            trend = 'SHORT';
          } else {
            trend = prevTrend;
          }

          // Detectar sinais de mudança de tendência
          if (prevTrend === 'SHORT' && trend === 'LONG') {
            detectedSignals.push({
              time: timeKey,
              timestamp: klines[i][0],
              type: 'BUY',
              price: close
            });
          } else if (prevTrend === 'LONG' && trend === 'SHORT') {
            detectedSignals.push({
              time: timeKey,
              timestamp: klines[i][0],
              type: 'SELL',
              price: close
            });
          }

          prevTrend = trend;
          latestTrend = trend;
        }

        setSignals(detectedSignals);
        setCurrentTrend(latestTrend);
        setIsLoading(false);
      } catch (err) {
        console.error('Erro ao calcular Chandelier Exit:', err);
        setError(err instanceof Error ? err.message : 'Erro desconhecido');
        setIsLoading(false);
      }
    };

    fetchChandelierData();
    intervalRef.current = setInterval(fetchChandelierData, 30000);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [symbol, settings.chandelierPeriod, settings.chandelierMultiplier]);

  if (isLoading) {
    return (
      <div className="h-[80px] flex items-center justify-center text-muted-foreground">
        <div className="animate-pulse">Calculando Chandelier Exit...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-[80px] flex items-center justify-center text-red-400 text-sm">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header com status atual */}
      <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-muted/30 to-transparent rounded-lg">
        <div className="flex items-center gap-4">
          <div>
            <h4 className="text-sm font-bold text-foreground">
              🎯 Chandelier Exit
            </h4>
            <p className="text-xs text-muted-foreground">Período: {settings.chandelierPeriod} | Mult: {settings.chandelierMultiplier}x</p>
          </div>
          <span className={`px-4 py-2 rounded-full text-sm font-bold ${
            currentTrend === 'LONG' 
              ? 'bg-green-500/20 text-green-400 border border-green-500/40' 
              : 'bg-red-500/20 text-red-400 border border-red-500/40'
          }`}>
            {currentTrend === 'LONG' ? '📈 TENDÊNCIA DE ALTA' : '📉 TENDÊNCIA DE BAIXA'}
          </span>
        </div>
      </div>

      {/* Sinais recentes */}
      <div className="px-4">
        <p className="text-xs text-muted-foreground mb-3">Sinais recentes de mudança de tendência:</p>
        {signals.length > 0 ? (
          <div className="flex flex-wrap gap-3">
            {signals.slice(-10).map((signal, index) => (
              <div 
                key={index}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium transition-all hover:scale-105 ${
                  signal.type === 'BUY' 
                    ? 'bg-green-500/10 text-green-400 border-green-500/40' 
                    : 'bg-red-500/10 text-red-400 border-red-500/40'
                }`}
              >
                {signal.type === 'BUY' ? (
                  <ArrowUpCircle className="w-4 h-4" />
                ) : (
                  <ArrowDownCircle className="w-4 h-4" />
                )}
                <span className="font-mono">{signal.time}</span>
                <span className="text-xs opacity-75">
                  {signal.type === 'BUY' ? 'Compra' : 'Venda'}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-sm text-muted-foreground py-4 text-center bg-muted/20 rounded-lg">
            Nenhum sinal de reversão detectado no período analisado
          </div>
        )}
      </div>

      {/* Explicação do indicador */}
      <div className="px-4 py-3 bg-muted/10 rounded-lg mx-4">
        <p className="text-xs text-muted-foreground text-center">
          O Chandelier Exit indica a tendência atual baseado em volatilidade (ATR). 
          <span className="text-green-400"> Verde = Alta</span> | 
          <span className="text-red-400"> Vermelho = Baixa</span>
        </p>
      </div>
    </div>
  );
};
