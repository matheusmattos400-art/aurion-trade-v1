import { useState, useEffect, useRef, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Sparkles,
  Send,
  Loader2,
  Plus,
  Trash2,
  MessageSquare,
  Bot,
  User,
  Clock,
  ImagePlus,
  X,
  Maximize2,
  Bookmark,
  BookmarkCheck,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  isAIGatewayTemporarilyDisabled,
  disableAIGatewayForMinutes,
  getAIGatewayUserMessage,
  shouldToastPaymentRequiredOnce,
} from "@/utils/aiCreditsGuard";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  created_at: string;
  image_url?: string;
  isInstruction?: boolean;
  instructionSaved?: boolean;
}

interface Conversation {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
}

const INSTRUCTION_HINTS = [
  "sempre",
  "nunca",
  "a partir de agora",
  "daqui pra frente",
  "regra",
  "regras",
  "coordenada",
  "coordenadas",
  "priorize",
  "priorizar",
  "evite",
  "evitar",
  "ignore",
  "ignorar",
  "use ",
  "não use",
  "nao use",
  "aplique",
  "configurar",
  "configure",
  "mude",
  "alterar",
  "atualize",
];

function inferIsInstructionText(text: string): boolean {
  const t = (text || "").toLowerCase().trim();
  if (!t) return false;

  // Perguntas curtas normalmente não são "coordenadas"
  const isShortQuestion = t.endsWith("?") && t.split(/\s+/).length < 10;
  if (isShortQuestion) return false;

  return INSTRUCTION_HINTS.some((k) => t.includes(k));
}

export const AurionAIChatPanel = () => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingConversations, setIsLoadingConversations] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [saveInstructionDialogOpen, setSaveInstructionDialogOpen] = useState(false);
  const [pendingInstruction, setPendingInstruction] = useState<{ messageId: string; content: string } | null>(null);
  const [instructionTitle, setInstructionTitle] = useState("");
  const [isSavingInstruction, setIsSavingInstruction] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const lastMessageRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Get current user
  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setUserId(user.id);
      }
    };
    getUser();
  }, []);

  // Load conversations
  useEffect(() => {
    if (!userId) return;
    
    const loadConversations = async () => {
      setIsLoadingConversations(true);
      const { data, error } = await supabase
        .from("aurion_ai_conversations")
        .select("*")
        .eq("user_id", userId)
        .order("updated_at", { ascending: false });

      if (error) {
        console.error("Error loading conversations:", error);
        toast.error("Erro ao carregar conversas");
      } else {
        setConversations(data || []);
        if (data && data.length > 0) {
          setCurrentConversationId(data[0].id);
        }
      }
      setIsLoadingConversations(false);
    };

    loadConversations();
  }, [userId]);

  useEffect(() => {
    if (currentConversationId) {
      localStorage.setItem("aurion_ai_active_conversation_id", currentConversationId);
    }
  }, [currentConversationId]);

  useEffect(() => {
    if (!currentConversationId) {
      setMessages([]);
      return;
    }

    const loadMessages = async () => {
      const { data, error } = await supabase
        .from("aurion_ai_messages")
        .select("*")
        .eq("conversation_id", currentConversationId)
        .order("created_at", { ascending: true });

      if (error) {
        console.error("Error loading messages:", error);
      } else if (data) {
        setMessages(
          data.map((msg) => {
            const role = msg.role as "user" | "assistant";
            return {
              ...msg,
              role,
              isInstruction: role === "user" ? inferIsInstructionText(msg.content) : undefined,
            };
          })
        );
      }
    };

    loadMessages();
  }, [currentConversationId]);

  // Track if user is near bottom to decide auto-scroll
  const isUserNearBottomRef = useRef(true);

  const handleScroll = useCallback(() => {
    if (!scrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    // Consider "near bottom" if within 100px of the bottom
    isUserNearBottomRef.current = scrollHeight - scrollTop - clientHeight < 100;
  }, []);

  // Initialize near-bottom detection on mount
  useEffect(() => {
    handleScroll();
  }, [handleScroll]);

  // Only auto-scroll if user was already at bottom
  useEffect(() => {
    if (!isUserNearBottomRef.current) return;
    // Align the *start* of the last message so long AI responses don't jump to the end.
    lastMessageRef.current?.scrollIntoView({ behavior: "auto", block: "start" });
  }, [messages]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Imagem muito grande. Máximo 5MB.");
        return;
      }
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
    setImageFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const createNewConversation = async () => {
    if (!userId) return;

    const { data, error } = await supabase
      .from("aurion_ai_conversations")
      .insert({
        user_id: userId,
        title: "Nova Conversa",
      })
      .select()
      .single();

    if (error) {
      console.error("Error creating conversation:", error);
      toast.error("Erro ao criar conversa");
      return null;
    }

    setConversations((prev) => [data, ...prev]);
    setCurrentConversationId(data.id);
    localStorage.setItem("aurion_ai_active_conversation_id", data.id);
    setMessages([]);
    return data;
  };

  const deleteConversation = async (conversationId: string) => {
    const { error } = await supabase
      .from("aurion_ai_conversations")
      .delete()
      .eq("id", conversationId);

    if (error) {
      console.error("Error deleting conversation:", error);
      toast.error("Erro ao deletar conversa");
      return;
    }

    setConversations(prev => prev.filter(c => c.id !== conversationId));
    if (currentConversationId === conversationId) {
      const remaining = conversations.filter(c => c.id !== conversationId);
      setCurrentConversationId(remaining.length > 0 ? remaining[0].id : null);
    }
    toast.success("Conversa deletada");
  };

  const updateConversationTitle = async (conversationId: string, firstMessage: string) => {
    const title = firstMessage.slice(0, 50) + (firstMessage.length > 50 ? "..." : "");
    
    const { error } = await supabase
      .from("aurion_ai_conversations")
      .update({ title, updated_at: new Date().toISOString() })
      .eq("id", conversationId);

    if (!error) {
      setConversations(prev => 
        prev.map(c => c.id === conversationId ? { ...c, title } : c)
      );
    }
  };

  const sendMessage = useCallback(async () => {
    if ((!inputMessage.trim() && !selectedImage) || isLoading || !userId) return;

    // Check circuit breaker first
    if (isAIGatewayTemporarilyDisabled()) {
      toast.error(getAIGatewayUserMessage(402));
      return;
    }

    let conversationId = currentConversationId;
    
    if (!conversationId) {
      const newConversation = await createNewConversation();
      if (!newConversation) return;
      conversationId = newConversation.id;
    }

    localStorage.setItem("aurion_ai_active_conversation_id", conversationId);

    const userMessage = inputMessage.trim();
    const imageToSend = selectedImage;
    
    setInputMessage("");
    setSelectedImage(null);
    setImageFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    setIsLoading(true);

    // Build content for AI (include image description request if image present)
    let contentForAI = userMessage;
    if (imageToSend) {
      contentForAI = userMessage 
        ? `[Imagem anexada]\n\n${userMessage}`
        : "[Imagem anexada] Por favor, analise esta imagem.";
    }

    const { data: savedUserMsg, error: userMsgError } = await supabase
      .from("aurion_ai_messages")
      .insert({
        conversation_id: conversationId,
        user_id: userId,
        role: "user",
        content: contentForAI,
      })
      .select()
      .single();

    if (userMsgError) {
      console.error("Error saving user message:", userMsgError);
      toast.error("Erro ao salvar mensagem");
      setIsLoading(false);
      return;
    }

    setMessages(prev => [...prev, {
      ...savedUserMsg,
      role: savedUserMsg.role as "user" | "assistant",
      image_url: imageToSend || undefined,
      isInstruction: inferIsInstructionText(userMessage || contentForAI),
    }]);

    if (messages.length === 0) {
      updateConversationTitle(conversationId, userMessage || "Análise de imagem");
    }

    try {
      const conversationHistory = messages.map(msg => ({
        role: msg.role as "user" | "assistant",
        content: msg.content,
      }));

      // Prepare message content with image if present
      let messageContent: any = contentForAI;
      if (imageToSend) {
        messageContent = [
          { type: "text", text: contentForAI },
          { type: "image_url", image_url: { url: imageToSend } }
        ];
      }

      const { data, error } = await supabase.functions.invoke("aurion-ai-chat", {
        body: {
          messages: [{ role: "user", content: messageContent }],
          conversationHistory,
        },
      });

      if (error) {
        const errMsg = error.message || "";
        if (errMsg.includes("402") || errMsg.toLowerCase().includes("payment")) {
          disableAIGatewayForMinutes(10);
          if (shouldToastPaymentRequiredOnce()) {
            toast.error(getAIGatewayUserMessage(402));
          }
          throw new Error(getAIGatewayUserMessage(402));
        }
        throw error;
      }

      const aiResponse = data.response;
      const isInstruction = data.isInstruction === true;

      const { data: savedAiMsg, error: aiMsgError } = await supabase
        .from("aurion_ai_messages")
        .insert({
          conversation_id: conversationId,
          user_id: userId,
          role: "assistant",
          content: aiResponse,
        })
        .select()
        .single();

      if (aiMsgError) {
        console.error("Error saving AI message:", aiMsgError);
      } else {
        setMessages(prev => [...prev, {
          ...savedAiMsg,
          role: savedAiMsg.role as "user" | "assistant",
          isInstruction
        }]);
      }

      await supabase
        .from("aurion_ai_conversations")
        .update({ updated_at: new Date().toISOString() })
        .eq("id", conversationId);

    } catch (error) {
      console.error("Error calling AI:", error);
      toast.error(error instanceof Error ? error.message : "Erro ao comunicar com IA");
    } finally {
      setIsLoading(false);
    }
  }, [inputMessage, selectedImage, isLoading, userId, currentConversationId, messages]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const openSaveInstructionDialog = (clickedMessageId: string) => {
    const msgIndex = messages.findIndex((m) => m.id === clickedMessageId);
    if (msgIndex === -1) return;

    const msg = messages[msgIndex];

    // Se o clique veio do assistant, salvar a mensagem do usuário anterior (onde normalmente está a "coordenada")
    if (msg.role === "assistant" && msgIndex > 0) {
      const prevMsg = messages[msgIndex - 1];
      if (prevMsg.role === "user") {
        setPendingInstruction({ messageId: prevMsg.id, content: prevMsg.content });
        setInstructionTitle(
          prevMsg.content.slice(0, 50) + (prevMsg.content.length > 50 ? "..." : "")
        );
        setSaveInstructionDialogOpen(true);
        return;
      }
    }

    // Caso padrão: salvar a própria mensagem clicada
    setPendingInstruction({ messageId: msg.id, content: msg.content });
    setInstructionTitle(msg.content.slice(0, 50) + (msg.content.length > 50 ? "..." : ""));
    setSaveInstructionDialogOpen(true);
  };

  const saveInstruction = async () => {
    if (!pendingInstruction || !userId || !instructionTitle.trim()) return;
    
    setIsSavingInstruction(true);
    
    try {
      const { error } = await supabase
        .from("aurion_ai_instructions")
        .insert({
          user_id: userId,
          content: pendingInstruction.content,
          title: instructionTitle.trim(),
          is_active: true
        });

      if (error) throw error;

      // Mark message as saved
      setMessages(prev => prev.map(m => 
        m.id === pendingInstruction.messageId 
          ? { ...m, instructionSaved: true } 
          : m
      ));

      toast.success("Instrução salva com sucesso!", {
        description: "Esta regra será aplicada em todas as análises futuras."
      });
      
      setSaveInstructionDialogOpen(false);
      setPendingInstruction(null);
      setInstructionTitle("");
    } catch (error) {
      console.error("Error saving instruction:", error);
      toast.error("Erro ao salvar instrução");
    } finally {
      setIsSavingInstruction(false);
    }
  };

  const currentConversation = conversations.find(c => c.id === currentConversationId);

  return (
    <div className="flex flex-col h-[calc(100vh-200px)] min-h-[400px] max-h-[800px]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 mb-4 pb-4 border-b border-border/50">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center shadow-lg shadow-purple-500/20">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Aurion AI</h2>
            <p className="text-xs text-muted-foreground">Assistente de Trading</p>
          </div>
        </div>
        
        <div className="flex flex-1 items-center gap-2 w-full sm:w-auto">
          <Select
            value={currentConversationId || ""}
            onValueChange={setCurrentConversationId}
          >
            <SelectTrigger className="flex-1 sm:w-[200px] bg-background/50 border-border/50 h-9">
              <SelectValue placeholder="Selecione uma conversa" />
            </SelectTrigger>
            <SelectContent>
              {conversations.map(conv => (
                <SelectItem key={conv.id} value={conv.id}>
                  <div className="flex items-center gap-2">
                    <MessageSquare className="w-3 h-3 text-muted-foreground" />
                    <span className="truncate max-w-[150px]">{conv.title}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            onClick={createNewConversation}
            size="sm"
            variant="outline"
            className="shrink-0 h-9"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline ml-1">Nova</span>
          </Button>

          {currentConversationId && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  size="sm"
                  variant="ghost"
                  className="text-destructive hover:text-destructive shrink-0 h-9 w-9 p-0"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Deletar conversa?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Todas as mensagens desta conversa serão perdidas permanentemente.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => deleteConversation(currentConversationId)}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    Deletar
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

        {currentConversation && (
          <Badge variant="outline" className="text-xs text-muted-foreground shrink-0 hidden sm:flex">
            <Clock className="w-3 h-3 mr-1" />
            {formatDistanceToNow(new Date(currentConversation.updated_at), { addSuffix: true, locale: ptBR })}
          </Badge>
        )}
      </div>

      {/* Messages Area */}
      <Card className="flex-1 overflow-hidden border-border/50 bg-gradient-to-b from-card/80 to-card/40 backdrop-blur-sm">
        <div 
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="h-full overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-primary/20 scrollbar-track-transparent"
        >
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-8">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-purple-500 via-blue-500 to-cyan-500 flex items-center justify-center mb-6 shadow-xl shadow-purple-500/30 animate-pulse">
                <Bot className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                Treine o Aurion AI
              </h3>
              <p className="text-muted-foreground text-sm max-w-sm mb-6">
                Converse com a IA para ensinar seu padrão de operações. 
                Todas as suas mensagens alimentam o cérebro do Aurion AI!
              </p>
              <div className="flex flex-wrap justify-center gap-2">
                <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/20 hover:bg-purple-500/20">
                  🧠 Treinamento
                </Badge>
                <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20 hover:bg-blue-500/20">
                  📊 Padrões
                </Badge>
                <Badge className="bg-cyan-500/10 text-cyan-400 border-cyan-500/20 hover:bg-cyan-500/20">
                  🎯 Estratégias
                </Badge>
                <Badge className="bg-green-500/10 text-green-400 border-green-500/20 hover:bg-green-500/20">
                  ⚡ Coordenadas
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-4 max-w-xs">
                Dica: Diga à IA qual tipo de token você busca, liquidez mínima, 
                quando entrar/sair, e ela usará nas análises!
              </p>
            </div>
          ) : (
            <>
              {messages.map((msg, idx) => (
                <div
                  key={msg.id}
                  ref={idx === messages.length - 1 ? lastMessageRef : undefined}
                  className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {msg.role === "assistant" && (
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center shrink-0 shadow-md shadow-purple-500/20">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                  )}
                  
                  <div
                    className={`max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-3 shadow-sm ${
                      msg.role === "user"
                        ? "bg-gradient-to-r from-primary to-primary/80 text-primary-foreground rounded-br-md"
                        : "bg-muted/60 backdrop-blur-sm border border-border/50 rounded-bl-md"
                    }`}
                  >
                    {msg.image_url && (
                      <Dialog>
                        <DialogTrigger asChild>
                          <div className="relative mb-3 cursor-pointer group">
                            <img 
                              src={msg.image_url} 
                              alt="Imagem enviada"
                              className="max-w-full max-h-48 rounded-lg object-cover"
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                              <Maximize2 className="w-6 h-6 text-white" />
                            </div>
                          </div>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl p-2">
                          <img 
                            src={msg.image_url} 
                            alt="Imagem enviada"
                            className="w-full h-auto max-h-[80vh] object-contain rounded-lg"
                          />
                        </DialogContent>
                      </Dialog>
                    )}
                    <p className="text-sm whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                    
                    {/* Indicador de que a mensagem do usuário alimenta o cérebro da IA */}
                    {msg.role === "user" && (
                      <div className="mt-2 flex items-center gap-1.5 text-[10px] text-primary-foreground/70">
                        <span className="inline-block w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                        <span>Treinando IA</span>
                      </div>
                    )}
                    
                    <p className={`text-[10px] mt-2 ${msg.role === "user" ? "text-primary-foreground/60" : "text-muted-foreground"}`}>
                      {formatDistanceToNow(new Date(msg.created_at), { addSuffix: true, locale: ptBR })}
                    </p>
                  </div>

                  {msg.role === "user" && (
                    <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center shrink-0">
                      <User className="w-4 h-4 text-primary" />
                    </div>
                  )}
                </div>
              ))}

              {isLoading && (
                <div className="flex gap-3 justify-start">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center shrink-0 shadow-md shadow-purple-500/20">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-muted/60 backdrop-blur-sm border border-border/50 rounded-2xl rounded-bl-md px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="flex gap-1">
                        <div className="w-2 h-2 rounded-full bg-purple-500 animate-bounce" style={{ animationDelay: "0ms" }} />
                        <div className="w-2 h-2 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: "150ms" }} />
                        <div className="w-2 h-2 rounded-full bg-cyan-500 animate-bounce" style={{ animationDelay: "300ms" }} />
                      </div>
                      <span className="text-sm text-muted-foreground ml-1">Analisando...</span>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </Card>

      {/* Image Preview */}
      {selectedImage && (
        <div className="mt-3 relative inline-block">
          <img 
            src={selectedImage} 
            alt="Preview" 
            className="max-h-24 rounded-lg border border-border/50 shadow-md"
          />
          <button
            onClick={removeImage}
            className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center shadow-md hover:scale-110 transition-transform"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Input Area */}
      <div className="mt-3 flex gap-2 items-end">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleImageSelect}
          className="hidden"
        />
        
        <Button
          onClick={() => fileInputRef.current?.click()}
          size="icon"
          variant="outline"
          className="shrink-0 h-10 w-10 rounded-xl border-border/50 hover:bg-primary/10 hover:border-primary/50 transition-colors"
          disabled={isLoading || !userId}
        >
          <ImagePlus className="w-5 h-5" />
        </Button>

        <div className="flex-1 relative">
          <Textarea
            ref={textareaRef}
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Digite sua mensagem..."
            className="min-h-[44px] max-h-[120px] resize-none bg-background/50 border-border/50 rounded-xl pr-4 py-3 text-sm placeholder:text-muted-foreground/60"
            disabled={isLoading || !userId}
          />
        </div>

        <Button
          onClick={sendMessage}
          disabled={(!inputMessage.trim() && !selectedImage) || isLoading || !userId}
          className="shrink-0 h-10 w-10 rounded-xl bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700 shadow-lg shadow-purple-500/20 disabled:opacity-50 disabled:shadow-none transition-all"
          size="icon"
        >
          {isLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <Send className="w-5 h-5" />
          )}
        </Button>
      </div>

      {!userId && (
        <p className="text-center text-sm text-muted-foreground mt-4">
          Faça login para usar o chat
        </p>
      )}

      {/* Save Instruction Dialog */}
      <Dialog open={saveInstructionDialogOpen} onOpenChange={setSaveInstructionDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bookmark className="w-5 h-5 text-amber-400" />
              Salvar Instrução
            </DialogTitle>
            <DialogDescription>
              Esta instrução será aplicada em todas as análises futuras do Aurion AI.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Título da Instrução</label>
              <Input
                value={instructionTitle}
                onChange={(e) => setInstructionTitle(e.target.value)}
                placeholder="Ex: Priorizar tokens com alta liquidez"
                className="bg-background/50"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Conteúdo</label>
              <div className="p-3 rounded-lg bg-muted/50 border border-border/50 text-sm text-muted-foreground max-h-32 overflow-y-auto">
                {pendingInstruction?.content}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setSaveInstructionDialogOpen(false)}
              disabled={isSavingInstruction}
            >
              Cancelar
            </Button>
            <Button
              onClick={saveInstruction}
              disabled={!instructionTitle.trim() || isSavingInstruction}
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
            >
              {isSavingInstruction ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <BookmarkCheck className="w-4 h-4 mr-2" />
                  Salvar Instrução
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
