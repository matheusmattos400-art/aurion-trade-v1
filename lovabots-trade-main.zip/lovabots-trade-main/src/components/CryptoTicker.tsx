import { useBinancePrices } from "@/hooks/useBinancePrices";
import { TrendingUp, TrendingDown } from "lucide-react";
import { useTradingMode } from "@/contexts/TradingModeContext";
import { formatPrice } from "@/utils/priceFormatter";

const CRYPTO_SYMBOLS = [
  "BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT"
];

const B3_SYMBOLS = [
  "PETR4", "VALE3", "ITUB4", 
  "BBDC4", "ABEV3", "WEGE3"
];

export const CryptoTicker = () => {
  const { isB3Mode } = useTradingMode();
  const symbols = isB3Mode ? B3_SYMBOLS : CRYPTO_SYMBOLS;
  const { prices } = useBinancePrices(symbols);

  return (
    <div className="bg-card/50 backdrop-blur-sm border-y border-border overflow-hidden">
      <div className="ticker-wrapper">
        <div className="ticker-content">
          {/* Duplicar os itens para criar efeito contínuo */}
          {[...prices, ...prices].map((price, index) => {
            const isPositive = price.change24h >= 0;
            const symbol = isB3Mode ? price.symbol : price.symbol.replace("USDT", "");
            
            return (
              <div
                key={`${price.symbol}-${index}`}
                className="ticker-item inline-flex items-center gap-2 px-4 py-2 border-r border-border/50"
              >
                <span className="text-xs font-bold text-foreground">
                  {symbol}
                </span>
                <span className="text-xs font-mono text-muted-foreground">
                  {isB3Mode ? formatPrice(price.price, 'R$ ') : formatPrice(price.price, '$')}
                </span>
                <div className={`flex items-center gap-1 text-xs font-medium ${
                  isPositive ? 'text-profit' : 'text-loss'
                }`}>
                  {isPositive ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  <span>
                    {isPositive ? '+' : ''}{price.change24h.toFixed(2)}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
