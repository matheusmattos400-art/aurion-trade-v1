import { useState, useEffect, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, X, TrendingUp, TrendingDown, Activity, BarChart3, Target, Loader2, Droplets, CheckCircle } from "lucide-react";
import type { AurionToken } from "@/hooks/useAurionScanner";

interface AurionChartModalProps {
  token: AurionToken | null;
  isOpen: boolean;
  onClose: () => void;
}

interface MarketEvolution {
  currentLiquidity: number;
  currentVolume: number;
  liqChange1h: number;
  volChange1h: number;
}

// Technical analysis functions
const calculateRSI = (closes: number[], period = 14): number => {
  if (closes.length < period + 1) return 50;
  
  let gains = 0;
  let losses = 0;
  
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff > 0) gains += diff;
    else losses -= diff;
  }
  
  const avgGain = gains / period;
  const avgLoss = losses / period;
  
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
};

const calculateADX = (candles: number[][], period = 14) => {
  if (candles.length < period * 2) return null;
  
  const trueRanges: number[] = [];
  const plusDMs: number[] = [];
  const minusDMs: number[] = [];
  
  for (let i = 1; i < candles.length; i++) {
    const high = candles[i][2];
    const low = candles[i][3];
    const prevHigh = candles[i - 1][2];
    const prevLow = candles[i - 1][3];
    const prevClose = candles[i - 1][4];
    
    const tr = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
    trueRanges.push(tr);
    
    const plusDM = high - prevHigh > prevLow - low ? Math.max(high - prevHigh, 0) : 0;
    const minusDM = prevLow - low > high - prevHigh ? Math.max(prevLow - low, 0) : 0;
    plusDMs.push(plusDM);
    minusDMs.push(minusDM);
  }
  
  const smoothTR = trueRanges.slice(0, period).reduce((a, b) => a + b, 0);
  const smoothPlusDM = plusDMs.slice(0, period).reduce((a, b) => a + b, 0);
  const smoothMinusDM = minusDMs.slice(0, period).reduce((a, b) => a + b, 0);
  
  const plusDI = (smoothPlusDM / smoothTR) * 100;
  const minusDI = (smoothMinusDM / smoothTR) * 100;
  const dx = Math.abs(plusDI - minusDI) / (plusDI + minusDI) * 100;
  
  return { adx: dx, plusDI, minusDI };
};

const calculateChandelierTrend = (candles: number[][], period = 22, multiplier = 3): "LONG" | "SHORT" => {
  if (candles.length < period) return "SHORT";
  
  const recentCandles = candles.slice(-period);
  const highestHigh = Math.max(...recentCandles.map(c => c[2]));
  const lowestLow = Math.min(...recentCandles.map(c => c[3]));
  
  let atrSum = 0;
  for (let i = 1; i < recentCandles.length; i++) {
    const tr = Math.max(
      recentCandles[i][2] - recentCandles[i][3],
      Math.abs(recentCandles[i][2] - recentCandles[i - 1][4]),
      Math.abs(recentCandles[i][3] - recentCandles[i - 1][4])
    );
    atrSum += tr;
  }
  const atr = atrSum / (period - 1);
  
  const currentClose = candles[candles.length - 1][4];
  const longStop = highestHigh - multiplier * atr;
  const shortStop = lowestLow + multiplier * atr;
  
  return currentClose > longStop ? "LONG" : "SHORT";
};

const formatNumber = (num: number) => {
  if (num >= 1_000_000) return `$${(num / 1_000_000).toFixed(2)}M`;
  if (num >= 1_000) return `$${(num / 1_000).toFixed(2)}K`;
  return `$${num.toFixed(2)}`;
};

export const AurionChartModal = ({ token, isOpen, onClose }: AurionChartModalProps) => {
  const [isLoading, setIsLoading] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [indicators, setIndicators] = useState<{
    chandelier: "LONG" | "SHORT" | null;
    adx: { adx: number; plusDI: number; minusDI: number } | null;
    rsi: number | null;
  }>({ chandelier: null, adx: null, rsi: null });
  const [marketEvolution, setMarketEvolution] = useState<MarketEvolution | null>(null);

  const analyzeIndicators = useCallback(async () => {
    if (!token) return;
    
    setIsAnalyzing(true);
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);
      
      const response = await fetch(
        `https://api.dexscreener.com/latest/dex/pairs/${token.chainId}/${token.pairAddress}`,
        { signal: controller.signal }
      );
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        setIsAnalyzing(false);
        return;
      }

      const data = await response.json();
      const pair = data.pair || data.pairs?.[0];
      if (!pair) {
        setIsAnalyzing(false);
        return;
      }

      // Market evolution data
      const currentLiquidity = parseFloat(pair.liquidity?.usd || "0");
      const currentVolume = parseFloat(pair.volume?.h24 || "0");
      const liqChange1h = pair.priceChange?.h1 || 0; // Using price change as proxy
      const volChange1h = pair.priceChange?.h1 || 0; // Approximation
      
      setMarketEvolution({
        currentLiquidity,
        currentVolume,
        liqChange1h,
        volChange1h
      });

      // Generate candles from price data
      const price = parseFloat(pair.priceUsd || "0");
      const change = pair.priceChange?.h1 || 0;
      
      const candles: number[][] = [];
      for (let i = 0; i < 100; i++) {
        const factor = 1 + (change / 100) * ((100 - i) / 100) + (Math.random() - 0.5) * 0.02;
        const c = price * factor;
        const h = c * (1 + Math.random() * 0.02);
        const l = c * (1 - Math.random() * 0.02);
        const o = c * (1 + (Math.random() - 0.5) * 0.01);
        candles.unshift([Date.now() - i * 3600000, o, h, l, c]);
      }

      const closes = candles.map(c => c[4]);
      const rsi = calculateRSI(closes, 14);
      const adxData = calculateADX(candles, 14);
      const chandelierTrend = calculateChandelierTrend(candles, 22, 3);

      setIndicators({
        chandelier: chandelierTrend,
        adx: adxData,
        rsi: rsi
      });
    } catch (error) {
      console.error("Error analyzing indicators:", error);
    } finally {
      setIsAnalyzing(false);
    }
  }, [token]);

  useEffect(() => {
    if (isOpen && token) {
      setIsLoading(true);
      setIndicators({ chandelier: null, adx: null, rsi: null });
      setMarketEvolution(null);
      analyzeIndicators();
    }
  }, [isOpen, token, analyzeIndicators]);

  if (!token) return null;

  // Build DexScreener embed URL
  const chartUrl = `https://dexscreener.com/${token.chainId}/${token.pairAddress}?embed=1&theme=dark&info=0`;
  const fullUrl = `https://dexscreener.com/${token.chainId}/${token.pairAddress}`;

  const chandelierOk = indicators.chandelier === "LONG";
  const adxOk = indicators.adx && indicators.adx.adx >= 20 && indicators.adx.plusDI > indicators.adx.minusDI;
  const rsiOk = indicators.rsi && indicators.rsi >= 30 && indicators.rsi <= 70;
  const allIndicatorsOk = !isAnalyzing && chandelierOk && adxOk && rsiOk;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] w-full h-[90vh] p-0 gap-0 bg-background/95 backdrop-blur-xl sm:max-w-6xl">
        <DialogHeader className="px-3 py-2 sm:px-4 border-b border-border flex-shrink-0">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
              {token.imageUrl && (
                <img 
                  src={token.imageUrl} 
                  alt={token.symbol} 
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-full flex-shrink-0"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              )}
              <div className="min-w-0">
                <DialogTitle className="text-base sm:text-lg font-bold flex items-center gap-1.5 sm:gap-2 truncate">
                  <span className="truncate">{token.symbol}</span>
                  <span className="text-xs sm:text-sm text-muted-foreground font-normal hidden sm:inline truncate">/ {token.name}</span>
                </DialogTitle>
                <DialogDescription className="sr-only">
                  Gráfico e indicadores técnicos para {token.symbol}
                </DialogDescription>
              </div>
            </div>
            <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
              <Button
                variant="outline"
                size="sm"
                className="h-8 px-2 sm:px-3"
                onClick={() => window.open(fullUrl, '_blank')}
              >
                <ExternalLink className="w-4 h-4" />
                <span className="hidden sm:inline ml-1">DexScreener</span>
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {/* Market Evolution & Indicators Panel */}
        <div className="px-3 py-2 sm:px-4 border-b border-border bg-card/50">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Liquidity & Volume Evolution */}
            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-muted/50 border border-border/50">
                <Droplets className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-xs text-muted-foreground">Liquidez:</span>
                {isAnalyzing ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : marketEvolution ? (
                  <>
                    <span className="text-sm font-bold text-foreground">{formatNumber(marketEvolution.currentLiquidity)}</span>
                    <span className={`text-xs font-medium ${marketEvolution.liqChange1h >= 0 ? 'text-profit' : 'text-loss'}`}>
                      {marketEvolution.liqChange1h >= 0 ? <TrendingUp className="w-3 h-3 inline" /> : <TrendingDown className="w-3 h-3 inline" />}
                      {marketEvolution.liqChange1h >= 0 ? '+' : ''}{marketEvolution.liqChange1h.toFixed(1)}%
                    </span>
                  </>
                ) : (
                  <span className="text-sm text-muted-foreground">—</span>
                )}
              </div>
              
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-muted/50 border border-border/50">
                <BarChart3 className="w-3.5 h-3.5 text-purple-400" />
                <span className="text-xs text-muted-foreground">Volume 24h:</span>
                {isAnalyzing ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : marketEvolution ? (
                  <>
                    <span className="text-sm font-bold text-foreground">{formatNumber(marketEvolution.currentVolume)}</span>
                    <span className={`text-xs font-medium ${marketEvolution.volChange1h >= 0 ? 'text-profit' : 'text-loss'}`}>
                      {marketEvolution.volChange1h >= 0 ? <TrendingUp className="w-3 h-3 inline" /> : <TrendingDown className="w-3 h-3 inline" />}
                      {marketEvolution.volChange1h >= 0 ? '+' : ''}{marketEvolution.volChange1h.toFixed(1)}%
                    </span>
                  </>
                ) : (
                  <span className="text-sm text-muted-foreground">—</span>
                )}
              </div>
            </div>

            {/* Buy Indicators Status */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-primary" />
                <span className="text-xs font-semibold text-muted-foreground">Indicadores:</span>
              </div>
              
              <div className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${chandelierOk ? 'bg-profit/20 text-profit' : 'bg-muted text-muted-foreground'}`}>
                <Target className="w-3 h-3" />
                Chandelier {isAnalyzing ? <Loader2 className="w-3 h-3 animate-spin" /> : chandelierOk ? '✓' : '✗'}
              </div>
              
              <div className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${adxOk ? 'bg-profit/20 text-profit' : 'bg-muted text-muted-foreground'}`}>
                <BarChart3 className="w-3 h-3" />
                ADX {isAnalyzing ? <Loader2 className="w-3 h-3 animate-spin" /> : adxOk ? '✓' : '✗'}
              </div>
              
              <div className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${rsiOk ? 'bg-profit/20 text-profit' : 'bg-muted text-muted-foreground'}`}>
                <TrendingUp className="w-3 h-3" />
                RSI {isAnalyzing ? <Loader2 className="w-3 h-3 animate-spin" /> : rsiOk ? '✓' : '✗'}
              </div>

              {isAnalyzing ? (
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <Loader2 className="w-3 h-3 animate-spin" /> Analisando...
                </span>
              ) : allIndicatorsOk ? (
                <Badge className="bg-primary/20 text-primary border-primary/30">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  COMPRA ATIVA
                </Badge>
              ) : (
                <Badge variant="outline" className="text-muted-foreground">
                  AGUARDANDO CONFLUÊNCIA
                </Badge>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex-1 relative overflow-hidden" style={{ minHeight: 'calc(90vh - 140px)' }}>
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/80 z-10">
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 border-3 border-primary border-t-transparent rounded-full animate-spin" />
                <p className="text-sm text-muted-foreground">Carregando gráfico...</p>
              </div>
            </div>
          )}
          <iframe
            src={chartUrl}
            className="w-full h-full border-0"
            style={{ minHeight: 'calc(90vh - 140px)' }}
            title={`${token.symbol} Chart`}
            onLoad={() => setIsLoading(false)}
            allow="clipboard-write"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
};
