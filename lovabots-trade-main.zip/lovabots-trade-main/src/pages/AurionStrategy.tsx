import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

import { CryptoTicker } from "@/components/CryptoTicker";
import { TradingSignals } from "@/components/TradingSignals";
import { AurionStrategyOperationPanel } from "@/components/AurionStrategyOperationPanel";
import { ApiInfo } from "@/components/ApiInfo";
import { LoadingScreen } from "@/components/LoadingScreen";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import aurionLogo from "@/assets/aurion-triangle-logo.png";
import { useTradingMode } from "@/contexts/TradingModeContext";
import { useIsMobile } from "@/hooks/use-mobile";
import { 
  History, 
  Wallet, 
  ChevronDown, 
  ChevronUp, 
  ArrowLeft,
  Activity,
  TrendingUp,
  Zap,
  Shield,
  Target,
  Settings,
  BarChart3,
  Repeat
} from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface ActiveOperation {
  id: string;
  longSymbol: string;
  shortSymbol: string;
  leverageLong: number;
  leverageShort: number;
  amount: number;
  entryPriceLong: number;
  entryPriceShort: number;
  startTime: Date;
  profitTarget?: number;
  autoCloseEnabled?: boolean;
  isTest?: boolean;
  longClosed?: boolean;
  shortClosed?: boolean;
  longClosePnl?: number;
  shortClosePnl?: number;
  // Campos para persistência de ordens
  limitOrderId?: string | null;
  limitOrderCreated?: boolean;
  customOrderId?: string | null;
  customOrderPrice?: number | null;
  customOrderCreated?: boolean;
}

const AurionStrategy = () => {
  const { mode, isB3Mode } = useTradingMode();
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [currentView, setCurrentView] = useState<"main" | "api">("main");
  const [isLoading, setIsLoading] = useState(true);
  const [binanceBalance, setBinanceBalance] = useState(0);
  const [userCredits, setUserCredits] = useState(0);
  const [activeOperations, setActiveOperations] = useState<ActiveOperation[]>([]);
  const [mobileMenuExpanded, setMobileMenuExpanded] = useState(false);
  const [collapsedOperations, setCollapsedOperations] = useState<Set<string>>(new Set());

  // Carregar dados iniciais
  useEffect(() => {
    const initialize = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          setIsLoading(false);
          return;
        }

        // Carregar créditos
        const { data: creditsData } = await supabase
          .from("user_credits")
          .select("credits")
          .eq("user_id", user.id)
          .maybeSingle();

        if (creditsData) {
          setUserCredits(creditsData.credits);
        }

        // Buscar saldo Binance
        const { data: balanceData } = await supabase.functions.invoke("binance-trading", {
          body: { action: "get_account" },
        });

        if (balanceData?.success && balanceData?.data?.totalWalletBalance) {
          setBinanceBalance(parseFloat(balanceData.data.totalWalletBalance));
        }

        // Buscar TODAS as operações ativas
        const { data: activeOps } = await supabase
          .from("active_operations")
          .select("*")
          .eq("user_id", user.id)
          .eq("status", "active")
          .order("started_at", { ascending: false });

        if (activeOps && activeOps.length > 0) {
          const operations = activeOps.map(op => ({
            id: op.id,
            longSymbol: op.long_symbol,
            shortSymbol: op.short_symbol,
            leverageLong: op.leverage_long,
            leverageShort: op.leverage_short,
            amount: Number(op.investment_amount),
            entryPriceLong: Number(op.entry_price_long || 0),
            entryPriceShort: Number(op.entry_price_short || 0),
            startTime: new Date(op.started_at),
            profitTarget: Number(op.profit_target || 10),
            autoCloseEnabled: op.auto_close_enabled ?? false,
            isTest: op.is_test ?? false,
            longClosed: (op as any).long_closed ?? false,
            shortClosed: (op as any).short_closed ?? false,
            longClosePnl: Number((op as any).long_close_pnl || 0),
            shortClosePnl: Number((op as any).short_close_pnl || 0),
            limitOrderId: (op as any).limit_order_id || null,
            limitOrderCreated: (op as any).limit_order_created ?? false,
            customOrderId: (op as any).custom_order_id || null,
            customOrderPrice: Number((op as any).custom_order_price) || null,
            customOrderCreated: (op as any).custom_order_created ?? false,
          }));
          setActiveOperations(operations);
        }

        setIsLoading(false);
      } catch (error) {
        console.error("Erro ao inicializar:", error);
        setIsLoading(false);
      }
    };

    initialize();

    // Atualizar a cada 3 segundos para PWA
    const refreshInterval = setInterval(async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: activeOps } = await supabase
        .from("active_operations")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "active")
        .order("started_at", { ascending: false });

      if (activeOps) {
        const operations = activeOps.map(op => ({
          id: op.id,
          longSymbol: op.long_symbol,
          shortSymbol: op.short_symbol,
          leverageLong: op.leverage_long,
          leverageShort: op.leverage_short,
          amount: Number(op.investment_amount),
          entryPriceLong: Number(op.entry_price_long || 0),
          entryPriceShort: Number(op.entry_price_short || 0),
          startTime: new Date(op.started_at),
          profitTarget: Number(op.profit_target || 10),
          autoCloseEnabled: op.auto_close_enabled ?? false,
          isTest: op.is_test ?? false,
          longClosed: (op as any).long_closed ?? false,
          shortClosed: (op as any).short_closed ?? false,
          longClosePnl: Number((op as any).long_close_pnl || 0),
          shortClosePnl: Number((op as any).short_close_pnl || 0),
          limitOrderId: (op as any).limit_order_id || null,
          limitOrderCreated: (op as any).limit_order_created ?? false,
          customOrderId: (op as any).custom_order_id || null,
          customOrderPrice: Number((op as any).custom_order_price) || null,
          customOrderCreated: (op as any).custom_order_created ?? false,
        }));
        setActiveOperations(operations);
      } else {
        setActiveOperations([]);
      }

      // Atualizar saldo
      const { data: balanceData } = await supabase.functions.invoke("binance-trading", {
        body: { action: "get_account" },
      });
      if (balanceData?.success && balanceData?.data?.totalWalletBalance) {
        setBinanceBalance(parseFloat(balanceData.data.totalWalletBalance));
      }
    }, 3000);

    return () => clearInterval(refreshInterval);
  }, []);

  const handleOperationStart = (data: any) => {
    const newOp = {
      id: data.id || "",
      ...data,
    };
    setActiveOperations(prev => [newOp, ...prev]);
  };

  const handleOperationClosed = async (operationId: string) => {
    const operationToClose = activeOperations.find(op => op.id === operationId);
    if (!operationToClose) return;

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    try {
      // Buscar operação atualizada do banco
      const { data: activeOp } = await supabase
        .from("active_operations")
        .select("*")
        .eq("id", operationId)
        .maybeSingle();

      if (activeOp) {
        // Calcular profit final
        const totalProfit = Number((activeOp as any).long_close_pnl || 0) + Number((activeOp as any).short_close_pnl || 0);

        // Salvar no histórico
        await supabase.from("trade_history").insert({
          user_id: user.id,
          long_symbol: activeOp.long_symbol,
          short_symbol: activeOp.short_symbol,
          leverage: activeOp.leverage_long,
          leverage_long: activeOp.leverage_long,
          leverage_short: activeOp.leverage_short,
          investment_amount: activeOp.investment_amount,
          profit: totalProfit,
          started_at: activeOp.started_at,
          ended_at: new Date().toISOString(),
          duration_seconds: Math.floor((Date.now() - new Date(activeOp.started_at).getTime()) / 1000),
          is_test: activeOp.is_test || false,
        });

        // Marcar como closed
        await supabase
          .from("active_operations")
          .update({ status: "closed" })
          .eq("id", operationId);

        toast({
          title: "✅ Operação finalizada",
          description: `Lucro de $${totalProfit.toFixed(2)} salvo no histórico.`,
        });
      }
    } catch (error) {
      console.error("Erro ao finalizar operação:", error);
    }

    // Remover da lista local
    setActiveOperations(prev => prev.filter(op => op.id !== operationId));
  };

  const toggleOperationCollapse = (operationId: string) => {
    setCollapsedOperations(prev => {
      const newSet = new Set(prev);
      if (newSet.has(operationId)) {
        newSet.delete(operationId);
      } else {
        newSet.add(operationId);
      }
      return newSet;
    });
  };

  if (isLoading) {
    return <LoadingScreen />;
  }

  const StatCard = ({ 
    icon: Icon, 
    label, 
    value, 
    valueColor = "text-foreground",
    trend 
  }: { 
    icon: any; 
    label: string; 
    value: string; 
    valueColor?: string;
    trend?: "up" | "down" | null;
  }) => (
    <Card className="p-3 bg-card/60 border-border/30">
      <div className="flex items-center gap-2">
        <div className="p-2 rounded-lg bg-primary/10">
          <Icon className="h-4 w-4 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</p>
          <p className={`text-base font-bold font-mono truncate ${valueColor}`}>{value}</p>
        </div>
        {trend && (
          <div className={`p-1 rounded ${trend === "up" ? "bg-green-500/10" : "bg-red-500/10"}`}>
            <TrendingUp className={`h-4 w-4 ${trend === "up" ? "text-green-500" : "text-red-500 rotate-180"}`} />
          </div>
        )}
      </div>
    </Card>
  );

  const renderMobileLayout = () => (
    <div className="min-h-screen bg-background">
      {/* Header Mobile Compacto */}
      <div className="sticky top-0 z-50 gradient-header border-b border-border/30">
        <div className="px-3 py-2 flex items-center justify-between">
          {/* Voltar + Logo */}
          <div className="flex items-center gap-2">
            <button 
              onClick={() => navigate("/")}
              className="w-8 h-8 rounded-full bg-card/50 border border-primary/50 flex items-center justify-center"
            >
              <ArrowLeft className="h-4 w-4 text-primary" />
            </button>
            <div className="flex items-center gap-1.5">
              <img src={aurionLogo} alt="Aurion" className="h-6 w-6" />
              <span className="font-bold text-primary text-sm">Trading</span>
            </div>
          </div>

          {/* Stats inline */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 px-2 py-1 bg-card/50 rounded-md border border-border/30">
              <Wallet className="h-3 w-3 text-primary" />
              <span className="text-[10px] font-mono font-bold text-primary">${binanceBalance.toFixed(0)}</span>
            </div>
            <button 
              onClick={() => navigate("/history")}
              className="w-8 h-8 rounded-full bg-card/50 border border-border/30 flex items-center justify-center"
            >
              <History className="h-4 w-4 text-muted-foreground" />
            </button>
          </div>
        </div>

        {/* Operações ativas badge */}
        {activeOperations.length > 0 && (
          <div className="px-3 pb-2">
            <Badge variant="default" className="animate-pulse text-[10px]">
              <Activity className="h-3 w-3 mr-1" />
              {activeOperations.length} Operação(ões) Ativa(s)
            </Badge>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="px-3 py-2 flex gap-2 border-b border-border/20 bg-card/20">
        <Button 
          variant={currentView === "main" ? "default" : "outline"} 
          size="sm" 
          className="flex-1 h-8 text-xs"
          onClick={() => setCurrentView("main")}
        >
          <Target className="h-3.5 w-3.5 mr-1" />
          Sinais
        </Button>
        <Button 
          variant={currentView === "api" ? "default" : "outline"} 
          size="sm" 
          className="flex-1 h-8 text-xs"
          onClick={() => setCurrentView("api")}
        >
          <Settings className="h-3.5 w-3.5 mr-1" />
          API
        </Button>
      </div>

      {/* Content Mobile */}
      <div className="p-3 space-y-3">
        {currentView === "api" ? (
          <ApiInfo />
        ) : (
          <>
            {activeOperations.map((operation) => (
              <CollapsibleOperationCard
                key={operation.id}
                operation={operation}
                isCollapsed={collapsedOperations.has(operation.id)}
                onToggleCollapse={() => toggleOperationCollapse(operation.id)}
                onOperationClosed={() => handleOperationClosed(operation.id)}
              />
            ))}

            <CryptoTicker />

            <TradingSignals
              onOperationStart={handleOperationStart}
              binanceBalance={binanceBalance}
            />
          </>
        )}
      </div>
    </div>
  );

  const renderDesktopLayout = () => (
    <div className="min-h-screen bg-background p-1 sm:p-2 md:p-4">
      <div className="max-w-7xl mx-auto space-y-2 sm:space-y-3 overflow-x-hidden">
        {/* Header igual ao Dashboard */}
        <header className="gradient-header rounded-xl p-2 premium-border relative overflow-hidden">
          <div className="absolute inset-0 gradient-premium opacity-50 pointer-events-none"></div>
          
          <div className="relative flex items-center justify-between gap-2">
            {/* Botão Voltar + Logo */}
            <div className="flex items-center gap-2">
              <button 
                onClick={() => navigate("/")}
                className="flex flex-col items-center gap-0.5 group flex-shrink-0"
              >
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-card/50 backdrop-blur-sm border-2 border-primary p-1.5 hover:scale-110 transition-all flex items-center justify-center shadow-glow">
                  <img src={aurionLogo} alt="AURION" className="w-full h-full object-contain" />
                </div>
                <span className="text-[8px] text-primary font-bold uppercase">VOLTAR</span>
              </button>

              <div className="hidden sm:block">
                <h1 className="text-sm font-bold text-primary">Trading</h1>
              </div>
            </div>

            {/* Navigation circles */}
            <div className="flex items-center gap-1.5 flex-wrap justify-end flex-1 min-w-0">
              {/* Saldo */}
              <div className="flex flex-col items-center gap-0.5 flex-shrink-0">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <Wallet className="w-4 h-4 text-primary" />
                </div>
                <span className="text-[8px] text-primary font-bold font-mono">${binanceBalance.toFixed(0)}</span>
              </div>

              {/* API */}
              <button 
                onClick={() => setCurrentView(currentView === "api" ? "main" : "api")}
                className="flex flex-col items-center gap-0.5 flex-shrink-0"
              >
                <div className="w-8 h-8 rounded-full bg-primary/10 hover:bg-primary/20 transition-all flex items-center justify-center">
                  <Settings className="w-4 h-4 text-primary" />
                </div>
                <span className="text-[8px] text-primary font-bold uppercase">API</span>
              </button>

              {/* Histórico */}
              <button 
                onClick={() => navigate("/history")}
                className="flex flex-col items-center gap-0.5 flex-shrink-0"
              >
                <div className="w-8 h-8 rounded-full bg-primary/10 hover:bg-primary/20 transition-all flex items-center justify-center">
                  <History className="w-4 h-4 text-primary" />
                </div>
                <span className="text-[8px] text-primary font-bold uppercase">Histórico</span>
              </button>

            </div>
          </div>
        </header>

        {/* Main Content */}
        {currentView === "api" ? (
          <ApiInfo />
        ) : (
          <div className="space-y-4">
            {activeOperations.map((operation) => (
              <CollapsibleOperationCard
                key={operation.id}
                operation={operation}
                isCollapsed={collapsedOperations.has(operation.id)}
                onToggleCollapse={() => toggleOperationCollapse(operation.id)}
                onOperationClosed={() => handleOperationClosed(operation.id)}
              />
            ))}

            <CryptoTicker />

            <TradingSignals
              onOperationStart={handleOperationStart}
              binanceBalance={binanceBalance}
            />
          </div>
        )}
      </div>
    </div>
  );

  return isMobile ? renderMobileLayout() : renderDesktopLayout();
};

// Componente para operação colapsável
const CollapsibleOperationCard = ({
  operation,
  isCollapsed,
  onToggleCollapse,
  onOperationClosed,
}: {
  operation: ActiveOperation;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onOperationClosed: () => void;
}) => {
  const [currentPnl, setCurrentPnl] = useState(0);

  // Buscar PnL em tempo real
  useEffect(() => {
    const fetchPnl = async () => {
      try {
        if (operation.isTest) {
          // Simular PnL para operações de teste
          const longRes = await fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${operation.longSymbol}`);
          const longData = await longRes.json();
          const shortRes = await fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${operation.shortSymbol}`);
          const shortData = await shortRes.json();

          const currentLongPrice = parseFloat(longData.price);
          const currentShortPrice = parseFloat(shortData.price);

          let longPnl = 0;
          let shortPnl = 0;

          if (!operation.longClosed && operation.entryPriceLong > 0) {
            const longNotional = (operation.amount / 2) * operation.leverageLong;
            const longChange = (currentLongPrice - operation.entryPriceLong) / operation.entryPriceLong;
            longPnl = longChange * longNotional;
          } else {
            longPnl = operation.longClosePnl || 0;
          }

          if (!operation.shortClosed && operation.entryPriceShort > 0) {
            const shortNotional = (operation.amount / 2) * operation.leverageShort;
            const shortChange = (operation.entryPriceShort - currentShortPrice) / operation.entryPriceShort;
            shortPnl = shortChange * shortNotional;
          } else {
            shortPnl = operation.shortClosePnl || 0;
          }

          setCurrentPnl(longPnl + shortPnl);
        } else {
          // Operação real - buscar da Binance
          const { data } = await supabase.functions.invoke('binance-trading', {
            body: { action: 'get_positions' }
          });

          if (data?.success) {
            const positions = data.data?.positions || [];
            let longPnl = operation.longClosed ? (operation.longClosePnl || 0) : 0;
            let shortPnl = operation.shortClosed ? (operation.shortClosePnl || 0) : 0;

            if (!operation.longClosed) {
              const longPos = positions.find((p: any) => p.symbol === operation.longSymbol);
              if (longPos) longPnl = parseFloat(longPos.unrealizedProfit || '0');
            }

            if (!operation.shortClosed) {
              const shortPos = positions.find((p: any) => p.symbol === operation.shortSymbol);
              if (shortPos) shortPnl = parseFloat(shortPos.unrealizedProfit || '0');
            }

            setCurrentPnl(longPnl + shortPnl);
          }
        }
      } catch (error) {
        console.error('Erro ao buscar PnL:', error);
      }
    };

    fetchPnl();
    const interval = setInterval(fetchPnl, 2000);
    return () => clearInterval(interval);
  }, [operation]);

  if (isCollapsed) {
    // Visualização colapsada - só mostra moedas e saldo
    return (
      <Card className="p-3 bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-500/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/30">
              <Activity className="h-4 w-4 text-amber-400" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">
                {operation.longSymbol} / {operation.shortSymbol}
              </p>
              {operation.isTest && (
                <Badge variant="outline" className="text-[9px] border-blue-500/30 text-blue-400">
                  TESTE
                </Badge>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <span className={`text-lg font-bold font-mono ${
              currentPnl >= 0 ? 'text-profit' : 'text-loss'
            }`}>
              {currentPnl >= 0 ? '+' : ''}${currentPnl.toFixed(2)}
            </span>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onToggleCollapse}
              className="h-8 px-2"
            >
              <ChevronDown className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  // Visualização expandida
  return (
    <div className="space-y-2">
      <div className="flex justify-end">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onToggleCollapse}
          className="h-8 px-2 gap-1"
        >
          <ChevronUp className="h-4 w-4" />
          Recolher
        </Button>
      </div>
      <AurionStrategyOperationPanel
        operation={operation}
        onOperationClosed={onOperationClosed}
      />
    </div>
  );
};

export default AurionStrategy;