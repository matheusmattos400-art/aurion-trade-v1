import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { User } from "@supabase/supabase-js";
import { Dashboard } from "@/components/Dashboard";
import { AuthForm } from "@/components/AuthForm";
import { LoadingScreen } from "@/components/LoadingScreen";
import { DatabaseConnectionInfo } from "@/components/DatabaseConnectionInfo";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

const Index = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [showDatabaseInfo, setShowDatabaseInfo] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
    return <LoadingScreen />;
  }

  if (!user) {
    return <AuthForm />;
  }

  if (showDatabaseInfo) {
    return (
      <div className="min-h-screen bg-background p-4">
        <Button
          variant="ghost"
          onClick={() => setShowDatabaseInfo(false)}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Dashboard
        </Button>
        <DatabaseConnectionInfo />
      </div>
    );
  }

  return <Dashboard onShowDatabaseInfo={() => setShowDatabaseInfo(true)} />;
};

export default Index;
