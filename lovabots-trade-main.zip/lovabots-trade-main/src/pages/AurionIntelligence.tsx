import { useState, useEffect, useCallback, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { 
  RefreshCw, 
  Star, 
  Radar, 
  Shield, 
  Zap,
  AlertTriangle,
  Clock,
  Home,
  DollarSign,
  Save,
  Check,
  History,
  ChevronDown,
  ChevronUp,
  Settings,
  TrendingUp,
  X,
  Award,
  ShieldCheck,
  Lock,
  Sparkles,
  Search,
  Crown,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAurionScanner, type AurionToken } from "@/hooks/useAurionScanner";
import { AurionTokenCard } from "@/components/AurionTokenCard";
import { AurionSimulatorPanel } from "@/components/AurionSimulatorPanel";
import { AurionChartModal } from "@/components/AurionChartModal";
import { AurionAIAnalysisDrawer } from "@/components/AurionAIAnalysisDrawer";
import { AurionAIChatPanel } from "@/components/AurionAIChatPanel";
import { AurionActiveTradeCard } from "@/components/AurionActiveTradeCard";
import { AurionLiveOperationPanel } from "@/components/AurionLiveOperationPanel";
import { SolanaWalletButton } from "@/components/SolanaWalletButton";
import { TradeConfirmationModal } from "@/components/TradeConfirmationModal";
import { AurionTradeTerminal } from "@/components/AurionTradeTerminal";
import { useSolanaWallet } from "@/hooks/useSolanaWallet";
import aurionLogo from "@/assets/aurion-triangle-logo.png";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import { executeJupiterSwap, calculateSolAmount, SOLANA_TOKENS, createJupiterLimitOrder, isValidSolanaAddress } from "@/utils/jupiterSwap";
import { AurionPlusCard, type AurionPlusAnalysis } from "@/components/AurionPlusCard";
import { usePumpFunAnalysis } from "@/hooks/usePumpFunAnalysis";
import { AurionPlusSniperChat } from "@/components/AurionPlusSniperChat";
import { AurionRadarChat } from "@/components/AurionRadarChat";
import { AurionTopChat } from "@/components/AurionTopChat";

export const AurionIntelligence = () => {
  const navigate = useNavigate();
  const [selectedToken, setSelectedToken] = useState<AurionToken | null>(null);
  const [chartModalOpen, setChartModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("opportunities");
  // Radar filters - unified into single "Aurion View" filter
  const [aurionViewFilter, setAurionViewFilter] = useState(false);
  const [radarSearchQuery, setRadarSearchQuery] = useState("");
  const [plusSearchQuery, setPlusSearchQuery] = useState("");
  
  // Pump.fun real analysis hook
  const { 
    analyzeToken: analyzePumpFunToken, 
    analysisCache: plusAnalysisCache, 
    isAnalyzing: isPlusAnalyzing,
    clearCache: clearPlusCache 
  } = usePumpFunAnalysis();
  
  const [configExpanded, setConfigExpanded] = useState(false);
  
  // Trade confirmation modal state
  const [tradeModalOpen, setTradeModalOpen] = useState(false);
  const [pendingTradeToken, setPendingTradeToken] = useState<AurionToken | null>(null);
  const [isExecutingTrade, setIsExecutingTrade] = useState(false);
  
  // Sell terminal state (abre terminal para vender)
  const [sellTerminalOpen, setSellTerminalOpen] = useState(false);
  const [sellTerminalToken, setSellTerminalToken] = useState<AurionToken | null>(null);
  
  // Aurion AI Analysis drawer state
  const [aiDrawerOpen, setAiDrawerOpen] = useState(false);
  const [aiAnalysisToken, setAiAnalysisToken] = useState<AurionToken | null>(null);
  
  // Aurion Plus Sniper Chat state
  const [sniperChatOpen, setSniperChatOpen] = useState(false);
  const [sniperChatToken, setSniperChatToken] = useState<AurionToken | null>(null);

  // Aurion Radar Chat state
  const [radarChatOpen, setRadarChatOpen] = useState(false);
  const [radarChatToken, setRadarChatToken] = useState<AurionToken | null>(null);

  // Aurion Top Chat state
  const [topChatOpen, setTopChatOpen] = useState(false);
  const [topChatToken, setTopChatToken] = useState<AurionToken | null>(null);
  // Jupiter availability check removed - let the API handle errors at swap time
  
  // Solana Wallet connection (supports Phantom, Solflare, etc.)
  const { 
    isConnected: isWalletConnected, 
    connectWallet, 
    publicKey, 
    getProvider, 
    balance: walletBalance,
    walletName,
    isWalletReady 
  } = useSolanaWallet();
  
  // SOL to BRL conversion
  const [solPriceBrl, setSolPriceBrl] = useState<number | null>(null);
  
  // Fetch SOL price in BRL
  useEffect(() => {
    const fetchSolPrice = async () => {
      try {
        const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=brl');
        const data = await response.json();
        if (data.solana?.brl) {
          setSolPriceBrl(data.solana.brl);
        }
      } catch (error) {
        console.error('Error fetching SOL price:', error);
      }
    };
    
    fetchSolPrice();
    // Refresh every 60 seconds
    const interval = setInterval(fetchSolPrice, 60000);
    return () => clearInterval(interval);
  }, []);
  
  // Investment amount state
  const [investmentAmount, setInvestmentAmount] = useState<number>(100);
  const [investmentInput, setInvestmentInput] = useState<string>("100");
  
  // Gain and Stop Loss config
  const [gainPercent, setGainPercent] = useState<number>(20);
  const [gainInput, setGainInput] = useState<string>("20");
  const [stopLossPercent, setStopLossPercent] = useState<number>(10);
  const [stopLossInput, setStopLossInput] = useState<string>("10");
  
  // Slippage config (em %: 1% / 10% / 15%)
  const [slippagePercent, setSlippagePercent] = useState<number>(1);
  
  // Custom balance state
  const [customBalance, setCustomBalance] = useState<number>(463);
  const [customBalanceInput, setCustomBalanceInput] = useState<string>("463");
  const [balanceConfigOpen, setBalanceConfigOpen] = useState(false);
  
  const [configSaved, setConfigSaved] = useState(true);

  // Load saved config from localStorage
  useEffect(() => {
    const savedInvestment = localStorage.getItem("aurion_investment_amount");
    const savedGain = localStorage.getItem("aurion_gain_percent");
    const savedStopLoss = localStorage.getItem("aurion_stop_loss_percent");
    
    if (savedInvestment) {
      const amount = parseFloat(savedInvestment);
      if (!isNaN(amount) && amount > 0) {
        setInvestmentAmount(amount);
        setInvestmentInput(amount.toString());
      }
    }
    
    if (savedGain) {
      const gain = parseFloat(savedGain);
      if (!isNaN(gain) && gain > 0) {
        setGainPercent(gain);
        setGainInput(gain.toString());
      }
    }
    
    if (savedStopLoss) {
      const stopLoss = parseFloat(savedStopLoss);
      if (!isNaN(stopLoss) && stopLoss > 0) {
        setStopLossPercent(stopLoss);
        setStopLossInput(stopLoss.toString());
      }
    }
    
    const savedSlippage = localStorage.getItem("aurion_slippage_percent");
    if (savedSlippage) {
      const slippage = parseFloat(savedSlippage);
      if (slippage === 1 || slippage === 10 || slippage === 15) {
        setSlippagePercent(slippage);
      }
    }
    
    const savedBalance = localStorage.getItem("aurion_custom_balance");
    if (savedBalance) {
      const balance = parseFloat(savedBalance);
      if (!isNaN(balance) && balance >= 0) {
        setCustomBalance(balance);
        setCustomBalanceInput(balance.toString());
      }
    }
  }, []);

  const handleSaveConfig = () => {
    const amount = parseFloat(investmentInput);
    const gain = parseFloat(gainInput);
    const stopLoss = parseFloat(stopLossInput);
    
    if (isNaN(amount) || amount <= 0) {
      toast.error("Digite um valor de investimento válido maior que 0");
      return;
    }
    if (isNaN(gain) || gain <= 0) {
      toast.error("Digite um Gain válido maior que 0%");
      return;
    }
    if (isNaN(stopLoss) || stopLoss <= 0) {
      toast.error("Digite um Stop Loss válido maior que 0%");
      return;
    }
    
    setInvestmentAmount(amount);
    setGainPercent(gain);
    setStopLossPercent(stopLoss);
    
    localStorage.setItem("aurion_investment_amount", amount.toString());
    localStorage.setItem("aurion_gain_percent", gain.toString());
    localStorage.setItem("aurion_stop_loss_percent", stopLoss.toString());
    localStorage.setItem("aurion_slippage_percent", slippagePercent.toString());
    
    setConfigSaved(true);
    toast.success(`Configuração salva: $${amount.toFixed(0)} | Gain: ${gain}% | Stop: -${stopLoss}% | Slippage: ${slippagePercent}%`);
  };

  const handleSaveBalance = () => {
    const balance = parseFloat(customBalanceInput);
    if (isNaN(balance) || balance < 0) {
      toast.error("Digite um saldo válido (maior ou igual a 0)");
      return;
    }
    setCustomBalance(balance);
    localStorage.setItem("aurion_custom_balance", balance.toString());
    setBalanceConfigOpen(false);
    toast.success(`Saldo atualizado para R$ ${balance.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
  };

  const handleConfigChange = () => {
    setConfigSaved(false);
  };

  const {
    tokens,
    topTokens,
    isScanning,
    isLoadingTop,
    isAnalyzing,
    lastScanTime,
    error,
    simulatedTrades,
    dailyPerformance,
    rescan,
    refetchTopTokens,
    simulateEntry,
    exitTrade,
    clearTradeHistory,
  } = useAurionScanner(true, 30000); // Scan every 30 seconds

  // Helper to check if token has active trade
  const hasActiveTrade = (token: AurionToken) => {
    return simulatedTrades.some(t => t.token.id === token.id && t.status === "open");
  };

  // Helper to find all active trades for a token
  const getActiveTrades = (token: AurionToken) => {
    return simulatedTrades.filter(
      t => t.token.id === token.id && t.status === "open"
    );
  };

  // Sort function to prioritize tokens with active trades
  const sortByActiveTrade = (a: AurionToken, b: AurionToken) => {
    const aActive = hasActiveTrade(a);
    const bActive = hasActiveTrade(b);
    if (aActive && !bActive) return -1;
    if (!aActive && bActive) return 1;
    return 0;
  };

  // Tokens que passam nos filtros de segurança mas não atendem todos critérios TOP
  const excellentTokens = tokens?.main.filter(t => t.securityScore >= 80) || [];
  const confirmedTokens = [...excellentTokens.filter(t => t.aurionConfirmed)].sort(sortByActiveTrade);
  const pendingTokens = [...excellentTokens.filter(t => !t.aurionConfirmed)].sort(sortByActiveTrade);
  const radarTokens = [...(tokens?.radar || [])].sort(sortByActiveTrade);
  
  // Aurion Plus: Tokens Solana com Score > 65 E idade entre 10-40 minutos (janela ideal)
  // Filtro adicional: apenas tokens Solana (Base58, não 0x)
  const isSolanaAddress = (addr: string) => /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(addr);
  
  const plusTokens = useMemo(() => {
    return [...(tokens?.main || []), ...(tokens?.radar || [])]
      .filter(t => {
        // Apenas Solana
        if (!t.tokenAddress || !isSolanaAddress(t.tokenAddress)) return false;
        
        const ageMinutes = t.ageHours * 60;
        return t.securityScore > 65 && ageMinutes >= 10 && ageMinutes <= 40;
      })
      .sort((a, b) => b.securityScore - a.securityScore);
  }, [tokens?.main, tokens?.radar]);
  
  // Disparar análise Pump.fun para tokens Plus (fora do render)
  useEffect(() => {
    if (plusTokens.length === 0 || isPlusAnalyzing) return;
    
    // Analisar apenas tokens que ainda não estão no cache
    const tokensToAnalyze = plusTokens.filter(t => !plusAnalysisCache[t.tokenAddress]);
    
    if (tokensToAnalyze.length === 0) return;
    
    // Analisar em lotes pequenos para não sobrecarregar a IA
    const analyzeNextBatch = async () => {
      const batch = tokensToAnalyze.slice(0, 2); // 2 por vez (análise IA é mais pesada)
      for (const token of batch) {
        await analyzePumpFunToken({
          tokenMint: token.tokenAddress,
          deployerAddress: undefined, // Será detectado pela Helius se possível
          marketCap: token.marketCap,
          liquidity: token.liquidity,
          volume24h: token.volume24h,
          holders: token.holdersCount || 0,
          ageMinutes: token.ageHours * 60,
          tokenSymbol: token.symbol,
          tokenName: token.name,
        });
      }
    };
    
    analyzeNextBatch();
  }, [plusTokens.map(t => t.tokenAddress).join(',')]); // Só dispara quando lista de tokens muda

  // Calculate active operations stats
  const openTrades = simulatedTrades.filter(t => t.status === "open");
  const totalInvested = openTrades.reduce((sum, t) => sum + (t.investmentAmount || 100), 0);

  // Live prices for active trades
  const [livePrices, setLivePrices] = useState<Record<string, { price: number; pnlPercent: number; pnlUsd: number }>>({});

  // Fetch live prices for open trades
  useEffect(() => {
    if (openTrades.length === 0) return;

    const fetchPrices = async () => {
      const newPrices: Record<string, { price: number; pnlPercent: number; pnlUsd: number }> = {};
      
      await Promise.all(
        openTrades.map(async (trade) => {
          try {
            const response = await fetch(
              `https://api.dexscreener.com/latest/dex/pairs/${trade.token.chainId}/${trade.token.pairAddress}`
            );
            if (!response.ok) return;
            
            const data = await response.json();
            const pair = data.pair || data.pairs?.[0];
            if (!pair) return;
            
            const currentPrice = parseFloat(pair.priceUsd || "0");
            const pnlPercent = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100;
            const investment = trade.investmentAmount || 100;
            const pnlUsd = (pnlPercent / 100) * investment;
            
            newPrices[trade.id] = { price: currentPrice, pnlPercent, pnlUsd };
          } catch (err) {
            console.error(`Error fetching price for ${trade.token.symbol}:`, err);
          }
        })
      );
      
      setLivePrices(prev => ({ ...prev, ...newPrices }));
    };

    fetchPrices();
    const interval = setInterval(fetchPrices, 15000); // Update every 15 seconds
    
    return () => clearInterval(interval);
  }, [openTrades.length, openTrades.map(t => t.id).join(',')]);

  // Calculate total PnL
  const totalPnlUsd = Object.values(livePrices).reduce((sum, p) => sum + p.pnlUsd, 0);
  const totalPnlPercent = totalInvested > 0 ? (totalPnlUsd / totalInvested) * 100 : 0;

  const handleViewChart = (token: AurionToken) => {
    setSelectedToken(token);
    setChartModalOpen(true);
  };

  // Open trade confirmation modal instead of directly simulating
  const handleOpenTradeModal = (token: AurionToken) => {
    setPendingTradeToken(token);
    setTradeModalOpen(true);
  };

  // Open Aurion AI analysis drawer
  const handleOpenAurionAI = (token: AurionToken) => {
    setAiAnalysisToken(token);
    setAiDrawerOpen(true);
  };
  
  // Open Aurion Plus Sniper Chat (for Plus tab)
  const handleOpenPlusSniperChat = (token: AurionToken) => {
    setSniperChatToken(token);
    setSniperChatOpen(true);
  };

  // Open Aurion Radar Chat (for Radar tab)
  const handleOpenRadarChat = (token: AurionToken) => {
    setRadarChatToken(token);
    setRadarChatOpen(true);
  };

  // Open Aurion Top Chat (for Top tab)
  const handleOpenTopChat = (token: AurionToken) => {
    setTopChatToken(token);
    setTopChatOpen(true);
  };

  // Handle test trade (simulation)
  const handleConfirmTestTrade = () => {
    if (pendingTradeToken) {
      simulateEntry(pendingTradeToken, investmentAmount);
      setTradeModalOpen(false);
      setPendingTradeToken(null);
      toast.success(`Operação de TESTE iniciada para ${pendingTradeToken.symbol}`);
    }
  };

  // Handle confirmar entrada real do terminal DexScreener
  const handleConfirmRealEntry = useCallback((token: AurionToken, amount: number) => {
    // Cria a operação ativa
    simulateEntry(token, amount);
    // Fecha o modal de trade
    setTradeModalOpen(false);
    setPendingTradeToken(null);
    toast.success(`Operação iniciada para ${token.symbol} com $${amount.toFixed(2)}`);
  }, [simulateEntry]);

  // Handle abrir terminal para vender
  const handleOpenSellTerminal = useCallback((token: AurionToken) => {
    setSellTerminalToken(token);
    setSellTerminalOpen(true);
  }, []);

  // Function to fetch/validate token mint from DexScreener - ENHANCED VERSION
  const fetchTokenMint = useCallback(async (token: AurionToken): Promise<string | null> => {
    console.log("🔍 Validating token mint for:", token.symbol, {
      tokenAddress: token.tokenAddress,
      pairAddress: token.pairAddress,
      chainId: token.chainId
    });

    // First check if we already have a valid tokenAddress
    if (token.tokenAddress && isValidSolanaAddress(token.tokenAddress)) {
      console.log("✅ Using existing tokenAddress:", token.tokenAddress);
      return token.tokenAddress;
    }
    
    // Method 1: Try fetching by pair address
    console.log("🔄 Method 1: Fetching from pair endpoint...", token.pairAddress);
    
    try {
      const pairResponse = await fetch(
        `https://api.dexscreener.com/latest/dex/pairs/${token.chainId || 'solana'}/${token.pairAddress}`
      );
      
      if (pairResponse.ok) {
        const data = await pairResponse.json();
        const pair = data.pair || data.pairs?.[0];
        
        if (pair?.baseToken?.address && isValidSolanaAddress(pair.baseToken.address)) {
          console.log("✅ Got mint from pair endpoint:", pair.baseToken.address);
          return pair.baseToken.address;
        }
      }
    } catch (error) {
      console.warn("Method 1 failed:", error);
    }

    // Method 2: Try searching by token symbol/name
    console.log("🔄 Method 2: Searching by symbol...", token.symbol);
    
    try {
      const searchResponse = await fetch(
        `https://api.dexscreener.com/latest/dex/search?q=${encodeURIComponent(token.symbol)}`
      );
      
      if (searchResponse.ok) {
        const data = await searchResponse.json();
        
        // Find matching pair on Solana
        const matchingPair = data.pairs?.find((p: any) => 
          p.chainId === 'solana' && 
          (p.pairAddress === token.pairAddress || 
           p.baseToken?.symbol?.toLowerCase() === token.symbol?.toLowerCase())
        );
        
        if (matchingPair?.baseToken?.address && isValidSolanaAddress(matchingPair.baseToken.address)) {
          console.log("✅ Got mint from search:", matchingPair.baseToken.address);
          return matchingPair.baseToken.address;
        }
      }
    } catch (error) {
      console.warn("Method 2 failed:", error);
    }

    // Method 3: Try extracting from URL if available
    if (token.url) {
      console.log("🔄 Method 3: Extracting from URL...", token.url);
      
      // DexScreener URLs often contain the token address
      // e.g., https://dexscreener.com/solana/TokenAddress
      const urlMatch = token.url.match(/solana\/([A-Za-z0-9]{32,44})/);
      if (urlMatch && urlMatch[1] && isValidSolanaAddress(urlMatch[1])) {
        console.log("✅ Got mint from URL:", urlMatch[1]);
        return urlMatch[1];
      }
    }

    // Method 4: Last resort - try using pairAddress directly if it looks like a valid address
    if (token.pairAddress && isValidSolanaAddress(token.pairAddress)) {
      console.log("⚠️ Using pairAddress as fallback (may not work):", token.pairAddress);
      // Don't return this as it's likely a pair address, not a token address
    }
    
    console.error("❌ All methods failed to find token mint for:", token.symbol);
    return null;
  }, []);

  // Handle real trade via Jupiter (Solana)
  const handleConfirmRealTrade = async () => {
    if (!pendingTradeToken) {
      toast.error("Nenhum token selecionado");
      return;
    }

    if (!publicKey || !isWalletReady) {
      toast.error("Conecte a carteira e aguarde ela ficar pronta para assinar");
      return;
    }

    const provider = getProvider();
    if (!provider?.signTransaction) {
      toast.error("Carteira conectada, mas ainda não está pronta para assinar transações");
      return;
    }

    setIsExecutingTrade(true);
    
    try {
      // Get and validate token mint address
      toast.info("Validando endereço do token...");
      
      let tokenMintAddress = pendingTradeToken.tokenAddress;

      // Check if we need to fetch the mint address
      if (!tokenMintAddress || !isValidSolanaAddress(tokenMintAddress)) {
        console.log("⚠️ tokenAddress invalid or missing, fetching from DexScreener...");
        tokenMintAddress = await fetchTokenMint(pendingTradeToken) || "";
      }

      if (!tokenMintAddress) {
        console.error("Token mint not found - token data:", {
          id: pendingTradeToken.id,
          symbol: pendingTradeToken.symbol,
          tokenAddress: pendingTradeToken.tokenAddress,
          pairAddress: pendingTradeToken.pairAddress,
          chainId: pendingTradeToken.chainId,
          url: pendingTradeToken.url
        });
        toast.error(`Endereço do token ${pendingTradeToken.symbol} não encontrado. Token pode não estar listado corretamente.`);
        setIsExecutingTrade(false);
        return;
      }

      // Final validation
      if (!isValidSolanaAddress(tokenMintAddress)) {
        console.error("Invalid mint address:", tokenMintAddress);
        toast.error(`Mint inválido: ${tokenMintAddress?.slice(0, 10)}... Tente outro token.`);
        setIsExecutingTrade(false);
        return;
      }
      
      console.log("✅ Using token mint:", tokenMintAddress);

      // Converte $X -> SOL (preço atual) -> Lamports ANTES de enviar para a Jupiter
      const lamportsAmount = await calculateSolAmount(investmentAmount);

      if (!lamportsAmount) {
        toast.error("Não foi possível calcular o valor em SOL");
        setIsExecutingTrade(false);
        return;
      }

      toast.info(`Comprando ~$${investmentAmount} em ${pendingTradeToken.symbol}...`);

      // Convert slippage % to basis points (1% = 100 bps, 5% = 500 bps)
      const slippageBps = slippagePercent * 100;

      // Execute swap: SOL -> Token com slippage definido
      const result = await executeJupiterSwap(
        SOLANA_TOKENS.SOL, // inputMint deve ser SOL: So11111111111111111111111111111111111111112
        tokenMintAddress, // outputMint deve ser o mint address do contrato
        lamportsAmount,
        publicKey,
        provider as Parameters<typeof executeJupiterSwap>[4],
        slippageBps
      );
      
      if (result.success) {
        toast.success(`✅ Compra executada! TX: ${result.signature?.slice(0, 8)}...`);
        
        // Calculate entry price and target prices
        const entryPrice = pendingTradeToken.priceUsd;
        const takeProfitPrice = entryPrice * (1 + gainPercent / 100);
        const stopLossPrice = entryPrice * (1 - stopLossPercent / 100);
        
        // Calculate token amount received (approximation based on output)
        const tokenAmountReceived = result.outputAmount ? parseInt(result.outputAmount) : 0;
        
        console.log("Trade executed:", {
          entryPrice,
          takeProfitPrice,
          stopLossPrice,
          tokenAmountReceived,
          gainPercent,
          stopLossPercent
        });
        
        // Create Take Profit order (sell at gain target)
        if (tokenAmountReceived > 0) {
          toast.info(`🎯 Criando ordem Take Profit a $${takeProfitPrice.toFixed(8)} (+${gainPercent}%)...`);
          
          try {
            const tpResult = await createJupiterLimitOrder(
              tokenMintAddress,
              tokenAmountReceived,
              takeProfitPrice,
              publicKey,
              provider as Parameters<typeof createJupiterLimitOrder>[4],
              3 // maxRetries
            );
            
            if (tpResult.success) {
              toast.success(`✅ Take Profit criado! Venda automática em +${gainPercent}% ($${takeProfitPrice.toFixed(6)})`);
              console.log("Take Profit order created:", tpResult);
            } else {
              toast.error(`❌ Take Profit falhou: ${tpResult.error}`);
              toast.warning("⚠️ Crie a ordem de Take Profit manualmente!");
            }
          } catch (tpError) {
            console.error("Error creating take profit order:", tpError);
            toast.error("❌ Erro ao criar Take Profit - crie manualmente!");
          }
        } else {
          toast.warning("⚠️ Quantidade de tokens recebida não detectada - crie ordens manualmente");
        }
        
        // Show Stop Loss info for manual creation
        toast.info(`📊 Stop Loss: $${stopLossPrice.toFixed(6)} (-${stopLossPercent}%) - Criar manualmente`, {
          duration: 8000,
        });
        
        // Also record as simulated trade for tracking
        simulateEntry(pendingTradeToken, investmentAmount);
        
        setTradeModalOpen(false);
        setPendingTradeToken(null);
      } else {
        toast.error(result.error || "Erro ao executar swap");
      }
    } catch (error) {
      console.error("Error executing trade:", error);
      toast.error("Erro ao executar ordem");
    } finally {
      setIsExecutingTrade(false);
    }
  };

  // Wrapper for wallet connect to match modal prop type
  const handleConnectWallet = async (): Promise<boolean> => {
    try {
      await connectWallet();
      return true;
    } catch {
      return false;
    }
  };

  return (
    <div className="min-h-screen bg-background p-1 sm:p-2 md:p-4">
      <div className="max-w-7xl mx-auto space-y-2 sm:space-y-3">
        {/* Header */}
        <header className="gradient-header rounded-xl sm:rounded-2xl p-2 sm:p-3 md:p-4 premium-border relative overflow-visible">
          <div className="absolute inset-0 gradient-premium opacity-50 pointer-events-none"></div>
          
          <div className="relative flex items-center justify-between gap-2 sm:gap-3">
            {/* Logo + Title */}
            <div className="flex items-center gap-2 sm:gap-3">
              <button 
                onClick={() => navigate("/")}
                className="flex flex-col items-center gap-0.5 group flex-shrink-0"
              >
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-card/50 backdrop-blur-sm border-2 border-primary p-2 hover:scale-110 hover:border-primary/80 transition-all flex items-center justify-center shadow-glow">
                  <img src={aurionLogo} alt="AURION" className="w-full h-full object-contain drop-shadow-lg" />
                </div>
              </button>
              
              <div className="hidden sm:block">
                <h1 className="text-xl sm:text-2xl md:text-3xl font-black" style={{ 
                  color: '#C9943B',
                  textShadow: '0 2px 4px rgba(201, 148, 59, 0.3)',
                  letterSpacing: '0.05em'
                }}>
                  AURION
                </h1>
                {lastScanTime && (
                  <p className="text-xs text-muted-foreground">
                    Atualizado {formatDistanceToNow(lastScanTime, { addSuffix: true, locale: ptBR })}
                  </p>
                )}
              </div>
            </div>

            {/* Mobile Title */}
            <div className="sm:hidden absolute left-1/2 transform -translate-x-1/2">
              <h1 className="text-lg font-black" style={{ 
                color: '#C9943B',
                letterSpacing: '0.05em'
              }}>
                AURION
              </h1>
            </div>

            {/* Active Operations Balance - Prominent Display */}
            {openTrades.length > 0 && (
              <div className="hidden md:flex items-center gap-3 px-4 py-2 rounded-xl bg-card/80 backdrop-blur-sm border border-primary/30">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-sm text-muted-foreground">{openTrades.length} op. ativa{openTrades.length > 1 ? 's' : ''}</span>
                </div>
                <div className="h-4 w-px bg-border" />
                <div className="text-sm">
                  <span className="text-muted-foreground">Investido: </span>
                  <span className="font-bold text-primary">${totalInvested.toFixed(0)}</span>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              {/* Mobile: Active operations indicator */}
              {openTrades.length > 0 && (
                <div className="md:hidden flex items-center gap-1 px-2 py-1 rounded-lg bg-green-500/20 border border-green-500/30">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-xs font-bold text-green-400">{openTrades.length}</span>
                </div>
              )}
              
              <Button
                onClick={rescan} 
                disabled={isScanning || isAnalyzing}
                size="sm"
                className="gradient-button h-8 sm:h-9"
              >
                <RefreshCw className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
                <span className="hidden sm:inline ml-1">{isScanning ? 'Escaneando...' : 'Atualizar'}</span>
              </Button>
              
              <Button 
                variant="outline"
                size="sm"
                onClick={() => navigate("/")}
                className="h-8 sm:h-9"
              >
                <Home className="w-4 h-4" />
                <span className="hidden sm:inline ml-1">Início</span>
              </Button>
            </div>
          </div>

          {/* Wallet Connection Bar */}
          <div className="mt-2 pt-2 border-t border-primary/20 flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-muted-foreground">Carteira:</span>
              <SolanaWalletButton />
              {isWalletConnected && (
                <div className="flex items-center gap-2 px-2 py-1 rounded-md bg-gradient-to-r from-purple-500/15 to-blue-500/15 border border-purple-500/30">
                  <div className="w-4 h-4 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center shrink-0">
                    <span className="text-[8px] font-bold text-white">{walletName?.charAt(0) || 'S'}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {solPriceBrl ? (
                      <>
                        <span className="text-sm font-bold text-primary whitespace-nowrap">
                          R$ {customBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                        <span className="text-xs text-muted-foreground whitespace-nowrap">
                          ({(customBalance / solPriceBrl).toFixed(4)} SOL)
                        </span>
                      </>
                    ) : (
                      <span className="text-xs text-muted-foreground animate-pulse">Carregando...</span>
                    )}
                  </div>
                </div>
              )}
            </div>
            
            {/* Mobile: Active Operations Summary */}
            {openTrades.length > 0 && (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-xs text-muted-foreground">{openTrades.length} op. ativa{openTrades.length > 1 ? 's' : ''}</span>
                </div>
                <div className="text-xs">
                  <span className="text-muted-foreground">Total: </span>
                  <span className="font-bold text-primary">${totalInvested.toFixed(0)}</span>
                </div>
              </div>
            )}
          </div>

        </header>


        {/* Collapsible Investment Config */}
        <Collapsible open={configExpanded} onOpenChange={setConfigExpanded}>
          <CollapsibleContent>
            <Card className="glass-card p-3 sm:p-4">
              <div className="flex flex-col gap-4">
                {/* Investment + Gain + Stop Loss + Slippage row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {/* Investment */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-primary" />
                      <Label htmlFor="investment" className="text-sm font-medium">
                        Investimento (USD)
                      </Label>
                    </div>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">$</span>
                      <Input
                        id="investment"
                        type="number"
                        min="1"
                        step="1"
                        value={investmentInput}
                        onChange={(e) => { setInvestmentInput(e.target.value); handleConfigChange(); }}
                        onKeyDown={(e) => e.key === "Enter" && handleSaveConfig()}
                        className="pl-6 h-9"
                        placeholder="100"
                      />
                    </div>
                  </div>
                  
                  {/* Gain (Take Profit) */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-green-500" />
                      <Label htmlFor="gain" className="text-sm font-medium">
                        Gain (Take Profit %)
                      </Label>
                    </div>
                    <div className="relative">
                      <Input
                        id="gain"
                        type="number"
                        min="1"
                        step="1"
                        value={gainInput}
                        onChange={(e) => { setGainInput(e.target.value); handleConfigChange(); }}
                        onKeyDown={(e) => e.key === "Enter" && handleSaveConfig()}
                        className="pr-8 h-9"
                        placeholder="20"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-green-500 text-sm font-medium">%</span>
                    </div>
                  </div>
                  
                  {/* Stop Loss */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <X className="w-4 h-4 text-red-500" />
                      <Label htmlFor="stoploss" className="text-sm font-medium">
                        Stop Loss (%)
                      </Label>
                    </div>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-red-500 text-sm font-medium">-</span>
                      <Input
                        id="stoploss"
                        type="number"
                        min="1"
                        step="1"
                        value={stopLossInput}
                        onChange={(e) => { setStopLossInput(e.target.value); handleConfigChange(); }}
                        onKeyDown={(e) => e.key === "Enter" && handleSaveConfig()}
                        className="pl-6 pr-8 h-9"
                        placeholder="10"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-red-500 text-sm font-medium">%</span>
                    </div>
                  </div>
                  
                  {/* Slippage */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-yellow-500" />
                      <Label className="text-sm font-medium">
                        Slippage
                      </Label>
                    </div>

                    <Select
                      value={String(slippagePercent)}
                      onValueChange={(v) => {
                        setSlippagePercent(Number(v));
                        handleConfigChange();
                      }}
                    >
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1% (Padrão)</SelectItem>
                        <SelectItem value="10">10% (Alta volatilidade)</SelectItem>
                        <SelectItem value="15">15% (Lançamento extremo)</SelectItem>
                      </SelectContent>
                    </Select>

                    <p className="text-xs text-muted-foreground">
                      Tolerância de variação de preço ao cotar no Jupiter
                    </p>
                  </div>
                </div>
                
                {/* Save button */}
                <div className="flex justify-end">
                  <Button 
                    onClick={handleSaveConfig}
                    size="sm"
                    variant={configSaved ? "outline" : "default"}
                    className={`h-9 ${configSaved ? "border-green-500/50 text-green-500" : "gradient-button"}`}
                  >
                    {configSaved ? (
                      <>
                        <Check className="w-4 h-4 mr-1" />
                        Configurado
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4 mr-1" />
                        Salvar Configuração
                      </>
                    )}
                  </Button>
                </div>
                
                {/* Preview */}
                <div className="text-xs text-muted-foreground border-t border-border/50 pt-3 flex flex-wrap gap-4">
                  <span>
                    <span className="text-foreground font-medium">${investmentAmount.toFixed(0)}</span> investimento
                  </span>
                  <span>
                    Gain em <span className="text-green-500 font-medium">+{gainPercent}%</span>
                  </span>
                  <span>
                    Stop em <span className="text-red-500 font-medium">-{stopLossPercent}%</span>
                  </span>
                  <span>
                    Slippage: <span className="text-yellow-500 font-medium">{slippagePercent}%</span>
                  </span>
                  {isWalletConnected && (
                    <span className="text-primary">
                      ⚡ Ordens limite serão enviadas automaticamente à carteira conectada
                    </span>
                  )}
                </div>
              </div>
            </Card>
          </CollapsibleContent>
        </Collapsible>

        {/* Error Display */}
        {error && (
          <Card className="glass-card p-4 border-destructive/50 bg-destructive/10">
            <div className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="w-5 h-5" />
              <span className="font-medium">Erro no escaneamento:</span>
              <span>{error}</span>
            </div>
          </Card>
        )}

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-3 sm:space-y-4">
          <TabsList className="grid grid-cols-6 w-full max-w-2xl mx-auto h-auto p-1">
            <TabsTrigger value="active" className="flex items-center gap-0.5 sm:gap-2 text-[10px] sm:text-sm py-1.5 sm:py-2 px-1 sm:px-3">
              <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline sm:inline">Ativas</span>
              {openTrades.length > 0 && (
                <Badge variant="secondary" className="ml-0.5 sm:ml-1 bg-green-500 text-white text-[8px] sm:text-xs h-4 sm:h-5 px-1 sm:px-1.5">
                  {openTrades.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="aurion-plus" className="flex items-center gap-0.5 sm:gap-2 text-[10px] sm:text-sm py-1.5 sm:py-2 px-1 sm:px-3">
              <Crown className="w-3 h-3 sm:w-4 sm:h-4 text-yellow-400" />
              <span className="hidden xs:inline sm:inline">Plus</span>
              {plusTokens.length > 0 && (
                <Badge variant="secondary" className="ml-0.5 sm:ml-1 bg-yellow-500 text-black text-[8px] sm:text-xs h-4 sm:h-5 px-1 sm:px-1.5">
                  {plusTokens.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="opportunities" className="flex items-center gap-0.5 sm:gap-2 text-[10px] sm:text-sm py-1.5 sm:py-2 px-1 sm:px-3">
              <Star className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline sm:inline">Top</span>
              {topTokens.length > 0 && (
                <Badge variant="secondary" className="ml-0.5 sm:ml-1 bg-primary text-primary-foreground text-[8px] sm:text-xs h-4 sm:h-5 px-1 sm:px-1.5">
                  {topTokens.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="radar" className="flex items-center gap-0.5 sm:gap-2 text-[10px] sm:text-sm py-1.5 sm:py-2 px-1 sm:px-3">
              <Radar className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline sm:inline">Radar</span>
              {radarTokens.length > 0 && (
                <Badge variant="outline" className="ml-0.5 sm:ml-1 text-[8px] sm:text-xs h-4 sm:h-5 px-1 sm:px-1.5">
                  {radarTokens.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="simulator" className="flex items-center gap-0.5 sm:gap-2 text-[10px] sm:text-sm py-1.5 sm:py-2 px-1 sm:px-3">
              <History className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline sm:inline">Hist</span>
              {simulatedTrades.filter(t => t.status !== "open").length > 0 && (
                <Badge variant="outline" className="ml-0.5 sm:ml-1 text-[8px] sm:text-xs h-4 sm:h-5 px-1 sm:px-1.5">
                  {simulatedTrades.filter(t => t.status !== "open").length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="aurion-ai" className="flex items-center gap-0.5 sm:gap-2 text-[10px] sm:text-sm py-1.5 sm:py-2 px-1 sm:px-3">
              <Sparkles className="w-3 h-3 sm:w-4 sm:h-4 text-purple-400" />
              <span className="hidden xs:inline sm:inline">AI</span>
            </TabsTrigger>
          </TabsList>

          {/* Balance Config Panel - Inside Histórico tab area */}
          {activeTab === "simulator" && (
            <div className="flex items-center gap-2 mb-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setBalanceConfigOpen(!balanceConfigOpen)}
                className="h-7 w-7 p-0 text-muted-foreground hover:text-primary"
              >
                <Settings className="w-4 h-4" />
              </Button>
              
              {balanceConfigOpen && (
                <div className="flex items-center gap-2 flex-1">
                  <Input
                    type="number"
                    value={customBalanceInput}
                    onChange={(e) => setCustomBalanceInput(e.target.value)}
                    className="w-28 h-7 text-sm"
                    placeholder="0.00"
                    min="0"
                    step="0.01"
                  />
                  <Button
                    size="sm"
                    onClick={handleSaveBalance}
                    className="h-7 px-2 gap-1"
                  >
                    <Save className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setBalanceConfigOpen(false)}
                    className="h-7 w-7 p-0"
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* Active Operations Tab */}
          <TabsContent value="active" className="space-y-4">
            {openTrades.length > 0 ? (
              <AurionLiveOperationPanel
                trades={simulatedTrades}
                onExitTrade={exitTrade}
                onOpenSellTerminal={handleOpenSellTerminal}
                onViewChart={(token) => {
                  setSelectedToken(token);
                  setChartModalOpen(true);
                }}
              />
            ) : (
              <Card className="glass-card p-8 text-center">
                <div className="flex flex-col items-center gap-3">
                  <TrendingUp className="w-12 h-12 text-muted-foreground/30" />
                  <p className="text-muted-foreground">
                    Nenhuma operação ativa no momento.
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Vá para a aba "Top" ou "Radar" para iniciar uma operação.
                  </p>
                </div>
              </Card>
            )}
          </TabsContent>

          {/* Aurion Plus Tab - Score > 65, Bundle & Dev Analysis */}
          <TabsContent value="aurion-plus" className="space-y-4">
            <div className="flex flex-col gap-4 mb-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <Crown className="w-5 h-5 text-yellow-400" />
                  <h2 className="text-lg font-bold">Aurion Plus</h2>
                  <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                    Score &gt; 65
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      clearPlusCache();
                      rescan();
                      toast.success("Atualizando lista de moedas...");
                    }}
                    disabled={isScanning || isPlusAnalyzing}
                    className="h-8 gap-1.5 border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
                  >
                    <RefreshCw className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
                    <span className="hidden sm:inline">Atualizar</span>
                  </Button>
                  <Badge variant="outline" className="text-xs">
                    {plusTokens.length} token(s)
                  </Badge>
                </div>
              </div>

              {/* Barra de Pesquisa */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Pesquisar moeda por nome ou símbolo..."
                  value={plusSearchQuery}
                  onChange={(e) => setPlusSearchQuery(e.target.value)}
                  className="pl-9 pr-9 bg-card/50 border-yellow-500/30 focus:border-yellow-400"
                />
                {plusSearchQuery && (
                  <button
                    onClick={() => setPlusSearchQuery("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Legenda de Cores */}
              <div className="flex flex-wrap gap-3 text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                  <span className="text-muted-foreground">Promissora</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <span className="text-muted-foreground">Acompanhar</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-border" />
                  <span className="text-muted-foreground">Padrão</span>
                </div>
              </div>
            </div>

            {(() => {
              let filteredPlus = [...plusTokens];

              // Filtro de pesquisa
              if (plusSearchQuery.trim()) {
                const query = plusSearchQuery.toLowerCase().trim();
                filteredPlus = filteredPlus.filter(t =>
                  t.symbol?.toLowerCase().includes(query) ||
                  t.name?.toLowerCase().includes(query)
                );
              }

              // Apenas retornar do cache - NÃO chamar analyze durante render
              const getTokenAnalysis = (token: typeof plusTokens[0]): AurionPlusAnalysis | undefined => {
                return plusAnalysisCache[token.tokenAddress];
              };

              return filteredPlus.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-4">
                  {filteredPlus.map(token => (
                    <AurionPlusCard
                      key={token.id}
                      token={token}
                      analysis={getTokenAnalysis(token)}
                      onSimulateEntry={handleOpenTradeModal}
                      onViewChart={handleViewChart}
                      onAurionAI={handleOpenPlusSniperChat}
                    />
                  ))}
                </div>
              ) : (
                <Card className="glass-card p-8 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <Crown className="w-12 h-12 text-muted-foreground/30" />
                    <p className="text-muted-foreground">
                      {plusSearchQuery 
                        ? "Nenhum token encontrado com esse termo."
                        : "Nenhum token com Score > 85 encontrado no momento."}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Tokens precisam passar nos critérios de segurança Aurion.
                    </p>
                  </div>
                </Card>
              );
            })()}
          </TabsContent>

          {/* Top Tab - Moedas mais promovidas no DexScreener */}
          <TabsContent value="opportunities" className="space-y-3 sm:space-y-4">
            {/* TOP Section - Tokens mais promovidos */}
            <div className="space-y-2 sm:space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <Star className="w-4 h-4 sm:w-5 sm:h-5 text-primary fill-primary" />
                  <h2 className="text-sm sm:text-lg font-bold text-primary">TOP - Mais Promovidas</h2>
                  <Badge className="bg-primary/20 text-primary text-[10px] sm:text-xs">DexScreener Boost</Badge>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => refetchTopTokens()}
                  disabled={isLoadingTop}
                  className="h-7 sm:h-8 text-xs sm:text-sm"
                >
                  <RefreshCw className={`w-3 h-3 sm:w-4 sm:h-4 mr-1 ${isLoadingTop ? 'animate-spin' : ''}`} />
                  <span className="hidden sm:inline">Atualizar</span>
                </Button>
              </div>

              {/* Loading State */}
              {isLoadingTop && topTokens.length === 0 && (
                <Card className="glass-card p-8 text-center">
                  <div className="flex flex-col items-center gap-4">
                    <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                    <p className="text-muted-foreground">Carregando top tokens...</p>
                  </div>
                </Card>
              )}

              {/* Top Tokens Grid - Using AurionTokenCard like Radar */}
              {topTokens.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-4">
                  {topTokens.map(token => {
                    // Verificar se tem algum pilar de segurança OK
                    const hasSecurityPillar = !token.isMintable || !token.hasBlacklist || token.lpLocked;
                    // Verificar se tem TODOS os pilares OK para o selo completo
                    const hasAllSecurityPillars = !token.isMintable && !token.hasBlacklist && token.lpLocked;
                    
                    return (
                      <AurionTokenCard
                        key={token.id}
                        token={token}
                        onSimulateEntry={handleOpenTradeModal}
                        onViewChart={handleViewChart}
                        onAurionAI={handleOpenAurionAI}
                        onExitTrade={exitTrade}
                        activeTrades={getActiveTrades(token)}
                        showAurionCertificate={hasAllSecurityPillars}
                        showSecurityBadge={hasSecurityPillar}
                      />
                    );
                  })}
                </div>
              )}

              {/* Empty State */}
              {!isLoadingTop && topTokens.length === 0 && (
                <Card className="glass-card p-8 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <Star className="w-12 h-12 text-muted-foreground/30" />
                    <p className="text-muted-foreground font-medium">
                      Nenhum token top encontrado no momento.
                    </p>
                    <Button variant="outline" onClick={() => refetchTopTokens()}>
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Tentar novamente
                    </Button>
                  </div>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Radar Tab */}
          <TabsContent value="radar" className="space-y-3 sm:space-y-4">
            <div className="flex flex-col gap-2 sm:gap-4 mb-2 sm:mb-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <Radar className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-400" />
                  <h2 className="text-sm sm:text-lg font-bold">Radar de Próximas Gemas</h2>
                  <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-[10px] sm:text-xs">
                    30min - 4h
                  </Badge>
                </div>
              </div>

              {/* Barra de Pesquisa */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Pesquisar moeda..."
                  value={radarSearchQuery}
                  onChange={(e) => setRadarSearchQuery(e.target.value)}
                  className="pl-9 pr-9 h-9 sm:h-10 text-sm bg-card/50 border-cyan-500/30 focus:border-cyan-400"
                />
                {radarSearchQuery && (
                  <button
                    onClick={() => setRadarSearchQuery("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
              
              {/* Botão Aurion View - Filtro unificado */}
              <button
                onClick={() => setAurionViewFilter(!aurionViewFilter)}
                className={`w-full flex items-center justify-center gap-2 sm:gap-3 px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg border-2 transition-all text-xs sm:text-sm font-bold ${
                  aurionViewFilter 
                    ? 'bg-gradient-to-r from-cyan-500/30 to-primary/30 border-cyan-400 text-cyan-300 shadow-[0_0_20px_rgba(34,211,238,0.3)]' 
                    : 'bg-card/50 border-cyan-500/30 hover:border-cyan-400 text-muted-foreground hover:text-cyan-400'
                }`}
              >
                <Radar className={`w-4 h-4 sm:w-5 sm:h-5 ${aurionViewFilter ? 'text-cyan-400' : ''}`} />
                <span>Aurion View</span>
                {aurionViewFilter && <ShieldCheck className="w-3 h-3 sm:w-4 sm:h-4 text-green-400" />}
              </button>
            </div>

            {(() => {
              let filteredRadar = [...radarTokens];
              
              // Função para verificar se tem algum pilar de segurança OK (para selo dourado)
              const hasSecurityPillar = (t: AurionToken) => {
                return !t.isMintable || !t.hasBlacklist || t.lpLocked;
              };

              // Filtro de pesquisa por nome/símbolo
              if (radarSearchQuery.trim()) {
                const query = radarSearchQuery.toLowerCase().trim();
                filteredRadar = filteredRadar.filter(t => 
                  t.symbol?.toLowerCase().includes(query) ||
                  t.name?.toLowerCase().includes(query)
                );
              }
              
              // Aurion View: combina Excelente + Liq>$70k + Buyers>Sellers
              if (aurionViewFilter) {
                filteredRadar = filteredRadar.filter(t => {
                  // Excelente (score >= 80)
                  const isExcellent = t.securityScore >= 80;
                  // Liquidez > $70k
                  const hasLiquidity = t.liquidity > 70000;
                  // Compradores > Vendedores
                  const buyersWinning = (t.buys1h > t.sells1h) || (t.buys24h > t.sells24h);
                  
                  return isExcellent && hasLiquidity && buyersWinning;
                });
              }
              
              return filteredRadar.length > 0 ? (
                <>
                  {aurionViewFilter && (
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-[10px] sm:text-xs border-cyan-400 text-cyan-400">
                        {filteredRadar.length} token(s) • Aurion View
                      </Badge>
                    </div>
                  )}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-4">
                    {filteredRadar.map(token => (
                      <AurionTokenCard
                        key={token.id}
                        token={token}
                        onSimulateEntry={handleOpenTradeModal}
                        onViewChart={handleViewChart}
                        onAurionAI={handleOpenRadarChat}
                        onExitTrade={exitTrade}
                        activeTrades={getActiveTrades(token)}
                        showAurionCertificate={false}
                        showSecurityBadge={hasSecurityPillar(token)}
                      />
                    ))}
                  </div>
                </>
              ) : (
                <Card className="glass-card p-8 text-center">
                  <div className="flex flex-col items-center gap-3">
                    <Radar className="w-12 h-12 text-muted-foreground/30" />
                    <p className="text-muted-foreground">
                      {aurionViewFilter 
                        ? "Nenhum token atende aos critérios do Aurion View."
                        : "Nenhum token novo (30min-4h) passou nos filtros de segurança no momento."}
                    </p>
                    {aurionViewFilter && (
                      <p className="text-xs text-muted-foreground">
                        Tente desativar o filtro Aurion View para ver mais resultados.
                      </p>
                    )}
                  </div>
                </Card>
              );
            })()}
          </TabsContent>

          {/* Simulator Tab */}
          <TabsContent value="simulator">
            <AurionSimulatorPanel
              trades={simulatedTrades}
              performance={dailyPerformance}
              onExitTrade={exitTrade}
              onClearHistory={clearTradeHistory}
            />
          </TabsContent>

          {/* Aurion AI Chat Tab */}
          <TabsContent value="aurion-ai">
            <AurionAIChatPanel />
          </TabsContent>

        </Tabs>

        {/* Chart Modal */}
        <AurionChartModal
          token={selectedToken}
          isOpen={chartModalOpen}
          onClose={() => setChartModalOpen(false)}
        />

        {/* Trade Confirmation Modal */}
        <TradeConfirmationModal
          isOpen={tradeModalOpen}
          onClose={() => {
            setTradeModalOpen(false);
            setPendingTradeToken(null);
          }}
          token={pendingTradeToken}
          investmentAmount={investmentAmount}
          slippagePercent={slippagePercent}
          onConfirmTest={handleConfirmTestTrade}
          onConfirmReal={handleConfirmRealTrade}
          onConfirmEntry={handleConfirmRealEntry}
          isWalletConnected={isWalletConnected}
          onConnectWallet={handleConnectWallet}
          isExecuting={isExecutingTrade}
          activeTrades={simulatedTrades.filter(t => t.status === "open")}
        />

        {/* Sell Terminal - Abre DexScreener para vender */}
        {sellTerminalToken && (
          <AurionTradeTerminal
            token={sellTerminalToken}
            isOpen={sellTerminalOpen}
            onClose={() => {
              setSellTerminalOpen(false);
              setSellTerminalToken(null);
            }}
            activeTrades={simulatedTrades.filter(t => t.status === "open").map(t => ({
              id: t.id,
              token: t.token,
              entryPrice: t.entryPrice,
              investmentAmount: t.investmentAmount,
              status: t.status as "open" | "closed" | "stopped" | "manual_exit"
            }))}
            onOpenSellTerminal={handleOpenSellTerminal}
          />
        )}

        {/* Aurion AI Analysis Drawer */}
        <AurionAIAnalysisDrawer
          token={aiAnalysisToken}
          isOpen={aiDrawerOpen}
          onClose={() => {
            setAiDrawerOpen(false);
            setAiAnalysisToken(null);
          }}
          onBuy={handleOpenTradeModal}
        />
        
        {/* Aurion Plus Sniper Chat - Chat conversacional para aba Plus */}
        <AurionPlusSniperChat
          open={sniperChatOpen}
          onOpenChange={(open) => {
            setSniperChatOpen(open);
            if (!open) setSniperChatToken(null);
          }}
          token={sniperChatToken}
        />

        {/* Aurion Radar Chat - Chat conversacional para aba Radar */}
        <AurionRadarChat
          open={radarChatOpen}
          onOpenChange={(open) => {
            setRadarChatOpen(open);
            if (!open) setRadarChatToken(null);
          }}
          token={radarChatToken}
        />

        {/* Aurion Top Chat - Chat conversacional para aba Top */}
        <AurionTopChat
          open={topChatOpen}
          onOpenChange={(open) => {
            setTopChatOpen(open);
            if (!open) setTopChatToken(null);
          }}
          token={topChatToken}
        />
      </div>
    </div>
  );
};

export default AurionIntelligence;
