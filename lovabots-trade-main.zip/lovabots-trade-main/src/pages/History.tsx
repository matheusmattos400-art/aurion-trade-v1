import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BalanceEvolutionChart } from "@/components/BalanceEvolutionChart";
import { TradeHistory } from "@/components/TradeHistory";
import { ArrowLeft, TrendingUp, History as HistoryIcon, TestTube, Wallet } from "lucide-react";
import { useNavigate } from "react-router-dom";
import aurionLogo from "@/assets/aurion-triangle-logo.png";

const History = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"real" | "test">("real");

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-background/95">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/90 backdrop-blur-xl border-b border-border/30">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => navigate("/")}
              className="hover:bg-primary/10 hover:text-primary transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full" />
                <img 
                  src={aurionLogo} 
                  alt="Aurion" 
                  className="h-10 w-10 relative z-10"
                />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-primary via-primary to-primary/70 bg-clip-text text-transparent">
                  Histórico
                </h1>
                <p className="text-xs text-muted-foreground">Análise de performance</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Tabs - Real vs Test */}
      <div className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "real" | "test")} className="space-y-6">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 h-14 p-1.5 bg-card/50 backdrop-blur-sm border border-border/50">
            <TabsTrigger 
              value="real" 
              className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-lg transition-all h-full rounded-md"
            >
              <Wallet className="h-4 w-4" />
              <span className="font-semibold">Operações Reais</span>
            </TabsTrigger>
            <TabsTrigger 
              value="test" 
              className="flex items-center gap-2 data-[state=active]:bg-amber-500 data-[state=active]:text-white data-[state=active]:shadow-lg transition-all h-full rounded-md"
            >
              <TestTube className="h-4 w-4" />
              <span className="font-semibold">Operações Teste</span>
            </TabsTrigger>
          </TabsList>

          {/* Real Operations Content */}
          <TabsContent value="real" className="space-y-6 mt-6">
            {/* Balance Chart */}
            <Card className="overflow-hidden border-border/50 bg-card/80 backdrop-blur-sm">
              <div className="p-4 sm:p-6 border-b border-border/30 bg-gradient-to-r from-primary/5 to-transparent">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <TrendingUp className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-foreground">Evolução do Saldo Real</h2>
                    <p className="text-xs text-muted-foreground">Acompanhe seus ganhos reais ao longo do tempo</p>
                  </div>
                </div>
              </div>
              <div className="p-4 sm:p-6">
                <BalanceEvolutionChart mode="real" />
              </div>
            </Card>

            {/* Trade History */}
            <Card className="overflow-hidden border-border/50 bg-card/80 backdrop-blur-sm">
              <div className="p-4 sm:p-6 border-b border-border/30 bg-gradient-to-r from-primary/5 to-transparent">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <HistoryIcon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-foreground">Histórico de Operações Reais</h2>
                    <p className="text-xs text-muted-foreground">Todas as suas operações com dinheiro real</p>
                  </div>
                </div>
              </div>
              <div className="p-4 sm:p-6">
                <TradeHistory mode="real" />
              </div>
            </Card>
          </TabsContent>

          {/* Test Operations Content */}
          <TabsContent value="test" className="space-y-6 mt-6">
            {/* Balance Chart */}
            <Card className="overflow-hidden border-amber-500/20 bg-card/80 backdrop-blur-sm">
              <div className="p-4 sm:p-6 border-b border-amber-500/20 bg-gradient-to-r from-amber-500/10 to-transparent">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-amber-500/10">
                    <TrendingUp className="h-5 w-5 text-amber-500" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-foreground">Evolução do Saldo Teste</h2>
                    <p className="text-xs text-muted-foreground">Acompanhe seus ganhos simulados</p>
                  </div>
                </div>
              </div>
              <div className="p-4 sm:p-6">
                <BalanceEvolutionChart mode="test" />
              </div>
            </Card>

            {/* Trade History */}
            <Card className="overflow-hidden border-amber-500/20 bg-card/80 backdrop-blur-sm">
              <div className="p-4 sm:p-6 border-b border-amber-500/20 bg-gradient-to-r from-amber-500/10 to-transparent">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-amber-500/10">
                    <HistoryIcon className="h-5 w-5 text-amber-500" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-foreground">Histórico de Operações Teste</h2>
                    <p className="text-xs text-muted-foreground">Todas as suas operações simuladas</p>
                  </div>
                </div>
              </div>
              <div className="p-4 sm:p-6">
                <TradeHistory mode="test" />
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default History;