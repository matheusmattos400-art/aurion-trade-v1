import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.38.4'

const RETENTION_DAYS = 30

Deno.serve(async (req) => {
  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    console.log(`🧹 Iniciando limpeza de histórico (mantendo ${RETENTION_DAYS} dias)...`)

    // Calcular data limite (30 dias atrás)
    const retentionDate = new Date()
    retentionDate.setDate(retentionDate.getDate() - RETENTION_DAYS)
    const retentionDateISO = retentionDate.toISOString()

    console.log(`📅 Deletando registros anteriores a: ${retentionDateISO}`)

    // Buscar usuários que têm trades antigos para consolidar
    const { data: oldTrades, error: oldTradesError } = await supabaseClient
      .from('trade_history')
      .select('user_id, profit')
      .lt('ended_at', retentionDateISO)

    if (oldTradesError) throw oldTradesError

    if (!oldTrades || oldTrades.length === 0) {
      console.log('✅ Nenhum registro antigo para limpar')
      return new Response(
        JSON.stringify({
          success: true,
          message: 'Nenhum registro antigo para limpar',
          recordsDeleted: 0,
        }),
        {
          headers: { 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    }

    // Agrupar lucros por usuário
    const userProfits: Record<string, number> = {}
    for (const trade of oldTrades) {
      if (!userProfits[trade.user_id]) {
        userProfits[trade.user_id] = 0
      }
      userProfits[trade.user_id] += Number(trade.profit)
    }

    console.log(`📊 Processando ${Object.keys(userProfits).length} usuários com ${oldTrades.length} trades antigos`)

    // Atualizar totais e deletar trades antigos por usuário
    for (const [userId, historyProfit] of Object.entries(userProfits)) {
      // Buscar total atual
      const { data: profitData } = await supabaseClient
        .from('profit_totals')
        .select('total_profit')
        .eq('user_id', userId)
        .maybeSingle()

      const currentTotal = profitData?.total_profit || 0
      const newTotal = Number(currentTotal) + historyProfit

      // Atualizar total acumulado
      const { error: updateError } = await supabaseClient
        .from('profit_totals')
        .upsert({
          user_id: userId,
          total_profit: newTotal,
          last_reset_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

      if (updateError) {
        console.error(`Erro ao atualizar total do usuário ${userId}:`, updateError)
        continue
      }

      // Deletar APENAS trades antigos do usuário
      const { error: deleteError } = await supabaseClient
        .from('trade_history')
        .delete()
        .eq('user_id', userId)
        .lt('ended_at', retentionDateISO)

      if (deleteError) {
        console.error(`Erro ao deletar histórico antigo do usuário ${userId}:`, deleteError)
        continue
      }

      console.log(`✅ Usuário ${userId}: trades antigos consolidados, total: $${newTotal.toFixed(2)}`)
    }

    console.log('🎉 Limpeza concluída com sucesso!')

    return new Response(
      JSON.stringify({
        success: true,
        message: `Histórico antigo limpo (>${RETENTION_DAYS} dias)`,
        usersProcessed: Object.keys(userProfits).length,
        recordsDeleted: oldTrades.length,
      }),
      {
        headers: { 'Content-Type': 'application/json' },
        status: 200,
      }
    )
  } catch (error) {
    console.error('❌ Erro na limpeza:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    return new Response(
      JSON.stringify({
        success: false,
        error: errorMessage,
      }),
      {
        headers: { 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})
