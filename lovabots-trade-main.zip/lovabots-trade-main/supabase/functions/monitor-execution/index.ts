import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-monitor-key',
};

// Controle de concorrência
let isMonitorRunning = false;
let lastExecutionTime = 0;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('🔔 Monitor sinal recebido');

    // Validar chave de autenticação
    const monitorKey = req.headers.get('x-monitor-key');
    const expectedKey = Deno.env.get('MONITOR_API_KEY');
    
    if (!monitorKey || monitorKey !== expectedKey) {
      console.error('❌ Chave de autenticação inválida');
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }), 
        { status: 401, headers: corsHeaders }
      );
    }

    // Controle de concorrência - evitar execuções simultâneas
    if (isMonitorRunning) {
      console.log('⏸️ Monitor já está em execução, ignorando sinal');
      return new Response(
        JSON.stringify({ status: 'skipped', message: 'Monitor already running' }), 
        { status: 200, headers: corsHeaders }
      );
    }

    // Throttle - mínimo 2 segundos entre execuções
    const now = Date.now();
    if (now - lastExecutionTime < 2000) {
      console.log('⏸️ Throttle ativo, aguardando intervalo');
      return new Response(
        JSON.stringify({ status: 'throttled', message: 'Too many requests' }), 
        { status: 429, headers: corsHeaders }
      );
    }

    // Marcar como em execução
    isMonitorRunning = true;
    lastExecutionTime = now;

    // Iniciar processamento em background (não aguardar conclusão)
    executeMonitorLogic().catch((err) => {
      console.error('❌ Erro fatal no monitor em background:', err);
      isMonitorRunning = false;
    });

    // Responder imediatamente
    return new Response(
      JSON.stringify({ status: 'processing', message: 'Monitor execution started' }), 
      { status: 202, headers: corsHeaders }
    );

  } catch (error) {
    isMonitorRunning = false;
    console.error('❌ Erro no monitor:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }), 
      { status: 500, headers: corsHeaders }
    );
  }
});

async function executeMonitorLogic() {
  try {
    console.log('🚀 Iniciando lógica do monitor');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Buscar operações ativas REAIS (não teste) com auto_close_enabled
    const { data: operations, error: opsError } = await supabase
      .from('active_operations')
      .select('*')
      .eq('auto_close_enabled', true)
      .eq('status', 'active')
      .eq('is_test', false);


    if (opsError) {
      console.error('❌ Erro ao buscar operações:', opsError);
      return;
    }

    if (!operations || operations.length === 0) {
      console.log('✅ Nenhuma operação com auto-close ativo');
      isMonitorRunning = false;
      return;
    }

    console.log(`📊 ${operations.length} operação(ões) com auto-close ativo`);

    // Para cada operação, verificar se deve fechar
    for (const operation of operations) {
      try {
        await processOperation(operation, supabase);
      } catch (error) {
        console.error(`❌ Erro ao processar operação ${operation.id}:`, error);
      }
    }

    console.log('✅ Monitor finalizado com sucesso');
  } catch (error) {
    console.error('❌ Erro fatal no monitor:', error);
  } finally {
    isMonitorRunning = false;
  }
}

async function processOperation(operation: any, supabase: any) {
  console.log(`🔍 Processando operação ${operation.id}`);

  // Buscar posições da Binance via edge function
  const { data: positionsResponse, error: posError } = await supabase.functions.invoke('binance-trading', {
    body: {
      action: 'get_positions',
      symbols: [operation.long_symbol, operation.short_symbol]
    }
  });

  if (posError || !positionsResponse?.success || !positionsResponse?.data?.positions) {
    console.error(`❌ Erro ao buscar posições:`, posError || 'Resposta inválida');
    console.error(`📊 Resposta recebida:`, JSON.stringify(positionsResponse, null, 2));
    return;
  }

  const positions = positionsResponse.data.positions;
  console.log(`📈 Posições encontradas:`, positions.length);

  // Se não houver nenhuma posição na Binance, marcar operação como encerrada localmente
  if (!positions || positions.length === 0) {
    console.log(`⚠️ Nenhuma posição aberta na Binance para operação ${operation.id}. Marcando como encerrada.`);
    await supabase
      .from('active_operations')
      .update({
        status: 'closed',
        auto_close_enabled: false,
        updated_at: new Date().toISOString(),
      })
      .eq('id', operation.id);
    return;
  }

  // Filtrar posições relevantes
  const longPosition = positions.find((p: any) => 
    p.symbol === operation.long_symbol && parseFloat(p.positionAmt) > 0
  );
  const shortPosition = positions.find((p: any) => 
    p.symbol === operation.short_symbol && parseFloat(p.positionAmt) < 0
  );

  if (!longPosition || !shortPosition) {
    console.log(`⚠️ Posições não encontradas para operação ${operation.id}`);
    return;
  }

  // Calcular PnL total
  const longPnL = parseFloat(longPosition.unRealizedProfit || '0');
  const shortPnL = parseFloat(shortPosition.unRealizedProfit || '0');
  const totalPnL = longPnL + shortPnL;

  console.log(`💰 PnL Total: ${totalPnL.toFixed(2)} USDT (Long: ${longPnL.toFixed(2)}, Short: ${shortPnL.toFixed(2)})`);

  // Verificar se atingiu o target
  const profitTarget = operation.profit_target || 0;
  
  if (totalPnL >= profitTarget && profitTarget > 0) {
    console.log(`🎯 Target atingido! Fechando posições IMEDIATAMENTE...`);
    
    // ⚡ PRIORIDADE MÁXIMA: Fechar AMBAS posições em PARALELO imediatamente!
    console.log('⚡ Enviando ordens de fechamento em paralelo...');
    
    const closeStartTime = Date.now();
    
    const [closeLongResult, closeShortResult] = await Promise.all([
      supabase.functions.invoke('binance-trading', {
        body: {
          action: 'close_position',
          symbol: operation.long_symbol,
        }
      }),
      supabase.functions.invoke('binance-trading', {
        body: {
          action: 'close_position',
          symbol: operation.short_symbol,
        }
      })
    ]);

    const closeTime = Date.now() - closeStartTime;
    console.log(`⚡ Posições fechadas em ${closeTime}ms`);

    if (closeLongResult.error || !closeLongResult.data?.success) {
      console.error(`❌ Erro ao fechar posição LONG:`, closeLongResult.error || closeLongResult.data?.error);
    } else {
      console.log(`✅ Posição LONG fechada`);
    }

    if (closeShortResult.error || !closeShortResult.data?.success) {
      console.error(`❌ Erro ao fechar posição SHORT:`, closeShortResult.error || closeShortResult.data?.error);
    } else {
      console.log(`✅ Posição SHORT fechada`);
    }

    // ⏳ Tarefas secundárias em background (não bloquear)
    let realProfit = totalPnL;

    // Calcular lucro real em background
    (async () => {
      try {
        // Aguardar um pouco para saldo atualizar
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const { data: accountAfter } = await supabase.functions.invoke('binance-trading', {
          body: { action: 'get_account' }
        });

        if (accountAfter?.success) {
          // Usar PnL como referência pois não temos o saldo antes
          console.log('💰 Saldo após fechamento:', accountAfter.data.totalWalletBalance, 'USDT');
        }
      } catch (error) {
        console.error('❌ Erro ao verificar saldo:', error);
      }
    })();

    // Calcular duração
    const startedAt = new Date(operation.started_at);
    const endedAt = new Date();
    const durationSeconds = Math.floor((endedAt.getTime() - startedAt.getTime()) / 1000);

    // Registrar no trade_history (não bloquear para isso)
    supabase
      .from('trade_history')
      .insert({
        user_id: operation.user_id,
        long_symbol: operation.long_symbol,
        short_symbol: operation.short_symbol,
        investment_amount: operation.investment_amount,
        leverage: operation.leverage,
        leverage_long: operation.leverage_long,
        leverage_short: operation.leverage_short,
        profit: realProfit,
        started_at: operation.started_at,
        ended_at: endedAt.toISOString(),
        duration_seconds: durationSeconds,
        is_test: operation.is_test || false
      })
      .then(({ error }: { error: any }) => {
        if (error) console.error(`❌ Erro ao registrar trade_history:`, error);
        else console.log(`✅ Trade registrado no histórico`);
      });

    // Remover operação ativa (não bloquear para isso)
    supabase
      .from('active_operations')
      .delete()
      .eq('id', operation.id)
      .then(({ error }: { error: any }) => {
        if (error) console.error(`❌ Erro ao remover operação ativa:`, error);
        else console.log(`✅ Operação removida da tabela active_operations`);
      });

    console.log(`🎉 Operação ${operation.id} fechada! Lucro estimado: ${realProfit.toFixed(2)} USDT (tempo: ${closeTime}ms)`);
  } else {
    console.log(`📊 Target não atingido. PnL atual: ${totalPnL.toFixed(2)}, Target: ${profitTarget.toFixed(2)}`);
    
    // Atualizar PnL atual na operação
    await supabase
      .from('active_operations')
      .update({ 
        current_pnl: totalPnL,
        updated_at: new Date().toISOString()
      })
      .eq('id', operation.id);
  }
}
