import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { orderId } = await req.json();

    // Configuração PagBank Sandbox
    const PAGBANK_TOKEN = "ed5dd77b-5a64-4a20-8387-ae61dfc8f3b3a0a5a079427192c3976ccd1edff90319ea9c-74b2-4e41-bda9-789b9ed19bd7";
    const PAGBANK_API_URL = `https://sandbox.api.pagseguro.com/orders/${orderId}`;

    // Consultar status no PagBank
    const pagBankResponse = await fetch(PAGBANK_API_URL, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${PAGBANK_TOKEN}`,
        "Content-Type": "application/json",
      },
    });

    if (!pagBankResponse.ok) {
      const errorText = await pagBankResponse.text();
      console.error("Erro ao consultar PagBank:", errorText);
      throw new Error(`Erro ao consultar pagamento: ${errorText}`);
    }

    const pagBankData = await pagBankResponse.json();
    const charge = pagBankData.charges?.[0];
    const status = charge?.status || "PENDING";

    console.log("Status do pagamento:", status);

    // Se estiver pago, processar créditos
    if (status === "PAID") {
      const supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
      );

      // Buscar transação
      const { data: transaction, error: transactionError } = await supabaseClient
        .from("credit_transactions")
        .select("*")
        .eq("order_id", orderId)
        .eq("status", "pending")
        .maybeSingle();

      if (transactionError) {
        console.error("Erro ao buscar transação:", transactionError);
        throw transactionError;
      }

      if (!transaction) {
        console.log("Transação não encontrada ou já processada");
        return new Response(
          JSON.stringify({ status, message: "Transação já processada" }),
          {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 200,
          }
        );
      }

      // Atualizar status da transação
      await supabaseClient
        .from("credit_transactions")
        .update({ status: "paid" })
        .eq("id", transaction.id);

      // Atualizar créditos do usuário
      const { data: userCredit, error: creditError } = await supabaseClient
        .from("user_credits")
        .select("*")
        .eq("user_id", transaction.user_id)
        .maybeSingle();

      if (creditError) {
        console.error("Erro ao buscar créditos:", creditError);
        throw creditError;
      }

      const newCredits = (userCredit?.credits || 0) + transaction.credits;

      if (userCredit) {
        await supabaseClient
          .from("user_credits")
          .update({ credits: newCredits })
          .eq("user_id", transaction.user_id);
      } else {
        await supabaseClient
          .from("user_credits")
          .insert({
            user_id: transaction.user_id,
            credits: transaction.credits,
          });
      }

      console.log(`✅ Créditos adicionados: ${transaction.credits} para usuário ${transaction.user_id}`);
    }

    return new Response(
      JSON.stringify({ status }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Erro na função:", error);
    const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      }
    );
  }
});
