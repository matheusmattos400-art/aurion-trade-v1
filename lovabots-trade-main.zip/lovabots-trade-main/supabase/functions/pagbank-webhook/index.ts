import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const webhookData = await req.json();
    console.log("Webhook recebido:", JSON.stringify(webhookData, null, 2));

    // Extrair informações do webhook
    const charge = webhookData.charges?.[0];
    const status = charge?.status;
    const orderId = webhookData.id;

    console.log(`Status: ${status}, Order ID: ${orderId}`);

    // Processar apenas pagamentos confirmados
    if (status === "PAID") {
      const supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
      );

      // Buscar transação
      const { data: transaction, error: transactionError } = await supabaseClient
        .from("credit_transactions")
        .select("*")
        .eq("order_id", orderId)
        .eq("status", "pending")
        .maybeSingle();

      if (transactionError) {
        console.error("Erro ao buscar transação:", transactionError);
        throw transactionError;
      }

      if (!transaction) {
        console.log("Transação não encontrada ou já processada");
        return new Response(
          JSON.stringify({ message: "Transação já processada" }),
          {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 200,
          }
        );
      }

      // Atualizar status da transação
      await supabaseClient
        .from("credit_transactions")
        .update({ status: "paid" })
        .eq("id", transaction.id);

      // Atualizar créditos do usuário
      const { data: userCredit } = await supabaseClient
        .from("user_credits")
        .select("*")
        .eq("user_id", transaction.user_id)
        .maybeSingle();

      const newCredits = (userCredit?.credits || 0) + transaction.credits;

      if (userCredit) {
        await supabaseClient
          .from("user_credits")
          .update({ credits: newCredits })
          .eq("user_id", transaction.user_id);
      } else {
        await supabaseClient
          .from("user_credits")
          .insert({
            user_id: transaction.user_id,
            credits: transaction.credits,
          });
      }

      console.log(`✅ Webhook processado: ${transaction.credits} créditos adicionados para ${transaction.user_id}`);
    }

    return new Response(
      JSON.stringify({ message: "Webhook processado com sucesso" }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Erro no webhook:", error);
    const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      }
    );
  }
});
