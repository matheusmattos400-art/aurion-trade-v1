import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Esta função APENAS coleta dados brutos da Helius e entrega para a Aurion AI decidir
// NÃO FAZ ANÁLISE - apenas coleta dados

async function heliusRpcCall(method: string, params: any[]): Promise<any> {
  const HELIUS_API_KEY = Deno.env.get("HELIUS_API_KEY");
  if (!HELIUS_API_KEY) {
    throw new Error("HELIUS_API_KEY not configured");
  }

  const response = await fetch(`https://mainnet.helius-rpc.com/?api-key=${HELIUS_API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method,
      params,
    }),
  });

  if (!response.ok) {
    throw new Error(`Helius RPC error: ${response.status}`);
  }

  const data = await response.json();
  if (data.error) {
    throw new Error(`RPC error: ${data.error.message}`);
  }

  return data.result;
}

// Buscar transações de um token usando getSignaturesForAddress (CORRETO para Pump.fun tokens)
async function getTokenTransactions(tokenMint: string): Promise<any[]> {
  try {
    console.log(`[DataCollector] Fetching signatures for ${tokenMint}`);
    
    // Buscar assinaturas relacionadas ao token
    const signatures = await heliusRpcCall("getSignaturesForAddress", [
      tokenMint,
      { limit: 100 }
    ]);

    if (!signatures || signatures.length === 0) {
      console.log(`[DataCollector] No signatures found for ${tokenMint}`);
      return [];
    }

    console.log(`[DataCollector] Found ${signatures.length} signatures`);

    // Pegar as transações mais antigas (do lançamento) - últimos 30
    const oldestSignatures = signatures.slice(-30);
    
    const transactions: any[] = [];
    
    // Buscar transações em paralelo (mais rápido)
    const txPromises = oldestSignatures.map(async (sig: any) => {
      try {
        const tx = await heliusRpcCall("getTransaction", [
          sig.signature,
          { encoding: "jsonParsed", maxSupportedTransactionVersion: 0 }
        ]);
        if (tx) {
          return { 
            signature: sig.signature,
            slot: sig.slot, 
            blockTime: sig.blockTime,
            transaction: tx.transaction,
            meta: tx.meta
          };
        }
        return null;
      } catch (e) {
        console.error(`[DataCollector] Error fetching tx ${sig.signature}:`, e);
        return null;
      }
    });

    const results = await Promise.all(txPromises);
    return results.filter(tx => tx !== null);
  } catch (error) {
    console.error("[DataCollector] Error fetching token transactions:", error);
    return [];
  }
}

// Buscar token holders usando getTokenLargestAccounts
async function getTokenHolders(tokenMint: string): Promise<any[]> {
  try {
    console.log(`[DataCollector] Fetching holders for ${tokenMint}`);
    
    const largestAccounts = await heliusRpcCall("getTokenLargestAccounts", [tokenMint]);
    
    if (!largestAccounts?.value) {
      return [];
    }

    console.log(`[DataCollector] Found ${largestAccounts.value.length} largest accounts`);

    return largestAccounts.value.map((account: any) => ({
      address: account.address,
      amount: account.amount,
      uiAmount: account.uiAmount,
      decimals: account.decimals,
    }));
  } catch (error) {
    console.error("[DataCollector] Error fetching token holders:", error);
    return [];
  }
}

// Buscar histórico de transações de uma carteira (para DNA do Dev)
async function getWalletHistory(walletAddress: string): Promise<any[]> {
  try {
    if (!walletAddress) return [];
    
    console.log(`[DataCollector] Fetching wallet history for ${walletAddress}`);
    
    const signatures = await heliusRpcCall("getSignaturesForAddress", [
      walletAddress,
      { limit: 50 }
    ]);

    if (!signatures || signatures.length === 0) {
      return [];
    }

    console.log(`[DataCollector] Found ${signatures.length} wallet transactions`);

    // Buscar primeiras 20 transações para análise
    const txPromises = signatures.slice(0, 20).map(async (sig: any) => {
      try {
        const tx = await heliusRpcCall("getTransaction", [
          sig.signature,
          { encoding: "jsonParsed", maxSupportedTransactionVersion: 0 }
        ]);
        if (tx) {
          return {
            signature: sig.signature,
            slot: sig.slot,
            blockTime: sig.blockTime,
            instructions: tx.transaction?.message?.instructions || [],
            preBalances: tx.meta?.preBalances || [],
            postBalances: tx.meta?.postBalances || [],
            err: tx.meta?.err,
          };
        }
        return null;
      } catch {
        return null;
      }
    });

    const results = await Promise.all(txPromises);
    return results.filter(tx => tx !== null);
  } catch (error) {
    console.error("[DataCollector] Error fetching wallet history:", error);
    return [];
  }
}

// Extrair carteiras do Bloco 0 (primeiros slots após criação)
// IMPORTANTE: aqui a gente só EXTRAI dados brutos; não decide se é bom/ruim.
const KNOWN_PROGRAM_IDS = new Set<string>([
  "11111111111111111111111111111111", // System Program
  "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA", // SPL Token Program
  "ComputeBudget111111111111111111111111111111",
  "SysvarRent111111111111111111111111111111111",
  "So11111111111111111111111111111111111111112", // Wrapped SOL mint (frequente nos swaps)
]);

function extractSignerWalletsFromAccountKeys(accountKeys: any[]): string[] {
  const wallets: string[] = [];

  for (const k of accountKeys || []) {
    if (typeof k === "string") continue;

    const pubkey = k?.pubkey;
    const signer = !!k?.signer;

    if (!pubkey || !signer) continue;
    wallets.push(pubkey);
  }

  return wallets;
}

function inferDeployerAddressFromCreationTx(transactions: any[], tokenMint: string): string | null {
  if (!transactions?.length) return null;

  // Selecionar transação mais antiga (criação / primeiros minutos)
  const oldestTx = transactions.reduce((acc, tx) => (tx.slot < acc.slot ? tx : acc), transactions[0]);
  const accountKeys = oldestTx?.transaction?.message?.accountKeys || [];
  const signerWallets = extractSignerWalletsFromAccountKeys(accountKeys);

  // Heurística mínima: 1º signer que não é programa nem o mint
  for (const w of signerWallets) {
    if (w === tokenMint) continue;
    if (KNOWN_PROGRAM_IDS.has(w)) continue;
    return w;
  }

  return null;
}

function extractBlock0Wallets(transactions: any[], tokenMint: string): any {
  if (!transactions?.length) {
    return {
      creationSlot: null,
      creationTime: null,
      block0Wallets: [],
      block0TransactionCount: 0,
      totalTransactions: 0,
    };
  }

  // Encontrar o slot de criação (mais antigo)
  const creationSlot = Math.min(...transactions.map((tx) => tx.slot));

  // Filtrar transações nos primeiros 3 slots (Block 0)
  const block0Transactions = transactions.filter((tx) => tx.slot <= creationSlot + 2);

  const wallets = new Set<string>();

  for (const tx of block0Transactions) {
    const accountKeys = tx?.transaction?.message?.accountKeys || [];

    // Preferir apenas signers (wallets reais) para evitar poluir com programas
    const signerWallets = extractSignerWalletsFromAccountKeys(accountKeys);
    for (const w of signerWallets) {
      if (w === tokenMint) continue;
      if (KNOWN_PROGRAM_IDS.has(w)) continue;
      wallets.add(w);
    }
  }

  return {
    creationSlot,
    creationTime: block0Transactions[0]?.blockTime
      ? new Date(block0Transactions[0].blockTime * 1000).toISOString()
      : null,
    block0Wallets: Array.from(wallets),
    block0TransactionCount: block0Transactions.length,
    totalTransactions: transactions.length,
  };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      tokenMint, 
      deployerAddress,
      includeHolders = true,
      includeDevHistory = true,
    } = await req.json();

    if (!tokenMint) {
      return new Response(
        JSON.stringify({ error: "tokenMint is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validar se é um endereço Solana válido (Base58, 32-44 chars, não começa com 0x)
    const isSolanaAddress = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(tokenMint);
    
    if (!isSolanaAddress) {
      console.log(`[DataCollector] SKIP - Not a Solana address: ${tokenMint}`);
      return new Response(
        JSON.stringify({
          tokenMint,
          collectedAt: new Date().toISOString(),
          block0: { creationSlot: null, creationTime: null, wallets: [], transactionCount: 0, totalTransactionsAnalyzed: 0 },
          holders: { count: 0, topAccounts: [] },
          devWallet: null,
          _meta: { 
            heliusCallsSuccessful: false, 
            skipped: true, 
            reason: "Not a Solana address (EVM/other chain detected)",
            totalTokenTransactions: 0,
            holdersQueried: false,
            devHistoryQueried: false,
          },
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[DataCollector] START - Collecting raw data for ${tokenMint}`);
    console.log(`[DataCollector] deployerAddress: ${deployerAddress || 'not provided'}`);

    // Coleta paralela dos dados brutos (token txs + holders)
    const [tokenTransactions, tokenHolders] = await Promise.all([
      getTokenTransactions(tokenMint),
      includeHolders ? getTokenHolders(tokenMint) : Promise.resolve([]),
    ]);

    // Extrair dados do Bloco 0
    const block0Data = extractBlock0Wallets(tokenTransactions, tokenMint);

    // Inferir Dev/Deployer automaticamente quando não foi fornecido
    const effectiveDeployerAddress = deployerAddress || (includeDevHistory
      ? inferDeployerAddressFromCreationTx(tokenTransactions, tokenMint)
      : null);

    const devHistory = includeDevHistory && effectiveDeployerAddress
      ? await getWalletHistory(effectiveDeployerAddress)
      : [];

    // Montar resposta com APENAS dados brutos - SEM ANÁLISE
    const rawData = {
      tokenMint,
      collectedAt: new Date().toISOString(),
      
      // Dados do Bloco 0 (para Bundle Detection)
      block0: {
        creationSlot: block0Data.creationSlot,
        creationTime: block0Data.creationTime,
        wallets: block0Data.block0Wallets,
        transactionCount: block0Data.block0TransactionCount,
        totalTransactionsAnalyzed: block0Data.totalTransactions,
      },
      
      // Top holders atuais
      holders: {
        count: tokenHolders.length,
        topAccounts: tokenHolders.slice(0, 20).map(h => ({
          address: h.address,
          balance: h.uiAmount,
        })),
      },
      
      // Histórico do Dev (para DNA analysis)
      devWallet: effectiveDeployerAddress ? {
        address: effectiveDeployerAddress,
        inferred: !deployerAddress,
        transactionCount: devHistory.length,
        transactions: devHistory.map((tx) => ({
          signature: tx.signature,
          blockTime: tx.blockTime,
          balanceChangeLamports:
            tx.postBalances[0] && tx.preBalances[0] ? tx.postBalances[0] - tx.preBalances[0] : 0,
          instructionCount: tx.instructions?.length || 0,
          hasError: !!tx.err,
        })),
      } : null,

      // Méta-dados para debug
      _meta: {
        heliusCallsSuccessful: true,
        totalTokenTransactions: tokenTransactions.length,
        holdersQueried: includeHolders,
        devHistoryQueried: includeDevHistory && !!effectiveDeployerAddress,
        deployerProvided: !!deployerAddress,
        deployerInferred: !deployerAddress && !!effectiveDeployerAddress,
      },
    };

    console.log(`[DataCollector] COMPLETE - Block0 wallets: ${block0Data.block0Wallets.length}, Holders: ${tokenHolders.length}, Dev txs: ${devHistory.length}`);

    return new Response(
      JSON.stringify(rawData),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("[DataCollector] ERROR:", error);
    
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        tokenMint: null,
        collectedAt: new Date().toISOString(),
        block0: null,
        holders: null,
        devWallet: null,
        _meta: { heliusCallsSuccessful: false },
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
