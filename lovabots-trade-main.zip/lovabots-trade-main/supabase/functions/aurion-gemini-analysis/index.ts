import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface DexScreenerPair {
  chainId: string;
  pairAddress: string;
  baseToken: {
    address: string;
    name: string;
    symbol: string;
  };
  priceUsd: string;
  priceChange: {
    m5?: number;
    h1?: number;
    h6?: number;
    h24?: number;
  };
  liquidity?: {
    usd?: number;
  };
  volume?: {
    m5?: number;
    h1?: number;
    h24?: number;
  };
  txns?: {
    m5?: { buys: number; sells: number };
    h1?: { buys: number; sells: number };
    h24?: { buys: number; sells: number };
  };
  pairCreatedAt?: number;
  info?: {
    imageUrl?: string;
    websites?: { url: string }[];
    socials?: { type: string; url: string }[];
  };
}

interface SocialAnalysis {
  hasTwitter: boolean;
  twitterUrl: string | null;
  hasWebsite: boolean;
  websiteUrl: string | null;
  hasTelegram: boolean;
  telegramUrl: string | null;
  hasDiscord: boolean;
  discordUrl: string | null;
  socialScore: number; // 0-100
  socialRisk: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  socialRiskReason: string;
  totalSocials: number;
}

interface RawSocialData {
  hasTwitter: boolean;
  twitterUrl: string | null;
  hasWebsite: boolean;
  websiteUrl: string | null;
  hasTelegram: boolean;
  telegramUrl: string | null;
  hasDiscord: boolean;
  discordUrl: string | null;
  totalSocials: number;
}

interface LiveTokenData {
  symbol: string;
  name: string;
  priceUsd: number;
  priceChange5m: number;
  priceChange1h: number;
  priceChange24h: number;
  liquidity: number;
  volume24h: number;
  volume5m: number;
  volume1h: number;
  buys5m: number;
  sells5m: number;
  buys1h: number;
  sells1h: number;
  buys24h: number;
  sells24h: number;
  ageHours: number;
  pairAddress: string;
  chainId: string;
  imageUrl?: string;
  tokenAddress?: string;
  // Raw social data - AI will evaluate
  rawSocialData?: RawSocialData;
  // AI-evaluated social analysis (added after AI processing)
  socialAnalysis?: SocialAnalysis;
}

interface ContractAnalysis {
  isHoneypot: boolean;
  honeypotReason: string;
  hasMintAuthority: boolean;
  hasFreezeAuthority: boolean;
  isRenounced: boolean;
  topHoldersPercent: number;
  creatorHoldingPercent: number;
  riskLevel: "SAFE" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  riskReasons: string[];
  rugCheckScore: number;
  dataSource: "RUGCHECK" | "UNAVAILABLE";
}

interface ForensicAnalysis {
  suspiciousVolume: boolean;
  suspiciousVolumeReason: string;
  distributionDetected: boolean;
  distributionReason: string;
  top10Selling: boolean;
  top10SellingReason: string;
  creatorRisk: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  creatorRiskReason: string;
  dangerDistribution: boolean;
  dataSource: "LIVE_DEXSCREENER" | "CACHED";
  fetchedAt: string;
  contractAnalysis?: ContractAnalysis;
}

interface AnalysisResult {
  symbol: string;
  verdict: string;
  score: number;
  tradeProfile: string;
  buyReason: string;
  analysis: string;
  forensicAnalysis: ForensicAnalysis;
}

// Fetch LIVE data from DexScreener API
async function fetchLiveTokenData(pairAddress: string, chainId: string = "solana"): Promise<LiveTokenData | null> {
  try {
    console.log(`🔄 Fetching LIVE data from DexScreener for ${pairAddress}...`);
    
    const response = await fetch(
      `https://api.dexscreener.com/latest/dex/pairs/${chainId}/${pairAddress}`,
      { 
        headers: { "Accept": "application/json" },
        signal: AbortSignal.timeout(10000) // 10 second timeout
      }
    );

    if (!response.ok) {
      console.error(`DexScreener API error: ${response.status}`);
      return null;
    }

    const data = await response.json();
    const pair: DexScreenerPair = data.pair || data.pairs?.[0];
    
    if (!pair) {
      console.error("No pair data found in DexScreener response");
      return null;
    }

    const now = Date.now();
    const createdAt = pair.pairCreatedAt || now;
    const ageHours = (now - createdAt) / (1000 * 60 * 60);

    // Parse social data from DexScreener - ONLY extract raw data, AI will evaluate
    const socials = pair.info?.socials || [];
    const websites = pair.info?.websites || [];
    
    const twitterSocial = socials.find((s: any) => s.type === "twitter" || s.url?.includes("twitter.com") || s.url?.includes("x.com"));
    const telegramSocial = socials.find((s: any) => s.type === "telegram" || s.url?.includes("t.me") || s.url?.includes("telegram"));
    const discordSocial = socials.find((s: any) => s.type === "discord" || s.url?.includes("discord"));
    const websiteInfo = websites[0];

    const hasTwitter = !!twitterSocial;
    const hasWebsite = !!websiteInfo;
    const hasTelegram = !!telegramSocial;
    const hasDiscord = !!discordSocial;
    
    const totalSocials = [hasTwitter, hasWebsite, hasTelegram, hasDiscord].filter(Boolean).length;
    
    // Raw social data - AI will evaluate score and risk
    const rawSocialData = {
      hasTwitter,
      twitterUrl: twitterSocial?.url || null,
      hasWebsite,
      websiteUrl: websiteInfo?.url || null,
      hasTelegram,
      telegramUrl: telegramSocial?.url || null,
      hasDiscord,
      discordUrl: discordSocial?.url || null,
      totalSocials,
    };

    console.log(`📱 Social data extracted: ${totalSocials} socials found | Twitter: ${hasTwitter} | Website: ${hasWebsite} | Telegram: ${hasTelegram} | Discord: ${hasDiscord}`);

    const liveData: LiveTokenData = {
      symbol: pair.baseToken?.symbol || "UNKNOWN",
      name: pair.baseToken?.name || "Unknown Token",
      priceUsd: parseFloat(pair.priceUsd || "0"),
      priceChange5m: pair.priceChange?.m5 || 0,
      priceChange1h: pair.priceChange?.h1 || 0,
      priceChange24h: pair.priceChange?.h24 || 0,
      liquidity: pair.liquidity?.usd || 0,
      volume24h: pair.volume?.h24 || 0,
      volume5m: pair.volume?.m5 || 0,
      volume1h: pair.volume?.h1 || 0,
      buys5m: pair.txns?.m5?.buys || 0,
      sells5m: pair.txns?.m5?.sells || 0,
      buys1h: pair.txns?.h1?.buys || 0,
      sells1h: pair.txns?.h1?.sells || 0,
      buys24h: pair.txns?.h24?.buys || 0,
      sells24h: pair.txns?.h24?.sells || 0,
      ageHours,
      pairAddress: pair.pairAddress,
      chainId: pair.chainId,
      imageUrl: pair.info?.imageUrl,
      tokenAddress: pair.baseToken?.address,
      rawSocialData,
    };

    console.log(`✅ LIVE data fetched: ${liveData.symbol} | Price: $${liveData.priceUsd} | Liq: $${liveData.liquidity} | TokenAddr: ${liveData.tokenAddress}`);
    return liveData;
  } catch (error) {
    console.error("Error fetching live DexScreener data:", error);
    return null;
  }
}

// Fetch contract analysis from RugCheck API
async function fetchContractAnalysis(tokenAddress: string): Promise<ContractAnalysis | null> {
  try {
    console.log(`🔍 Fetching contract analysis from RugCheck for ${tokenAddress}...`);
    
    const response = await fetch(
      `https://api.rugcheck.xyz/v1/tokens/${tokenAddress}/report`,
      { 
        headers: { "Accept": "application/json" },
        signal: AbortSignal.timeout(8000)
      }
    );

    if (!response.ok) {
      console.error(`RugCheck API error: ${response.status}`);
      return null;
    }

    const data = await response.json();
    
    // Parse RugCheck response
    const risks = data.risks || [];
    const riskReasons: string[] = [];
    
    // Check for specific risks
    const hasMintAuthority = risks.some((r: any) => 
      r.name?.toLowerCase().includes("mint") && r.level !== "none"
    );
    const hasFreezeAuthority = risks.some((r: any) => 
      r.name?.toLowerCase().includes("freeze") && r.level !== "none"
    );
    const isHoneypot = risks.some((r: any) => 
      r.name?.toLowerCase().includes("honeypot") || 
      r.name?.toLowerCase().includes("cannot sell")
    );
    
    // Count risk levels
    let hasCritical = false;
    let hasWarning = false;
    let hasInfo = false;
    
    risks.forEach((r: any) => {
      if (r.level === "danger" || r.level === "critical") {
        riskReasons.push(`🔴 ${r.name}: ${r.description || 'Critical risk detected'}`);
        hasCritical = true;
      } else if (r.level === "warn" || r.level === "warning") {
        riskReasons.push(`🟠 ${r.name}: ${r.description || 'Warning detected'}`);
        hasWarning = true;
      } else if (r.level === "info") {
        riskReasons.push(`🟡 ${r.name}`);
        hasInfo = true;
      }
    });

    // Calculate top holders concentration
    const topHolders = data.topHolders || [];
    const topHoldersPercent = topHolders.slice(0, 10).reduce((sum: number, h: any) => 
      sum + (h.pct || h.percentage || 0), 0
    );
    
    // Creator holding
    const creatorHolding = topHolders.find((h: any) => h.isCreator || h.owner === data.creator);
    const creatorHoldingPercent = creatorHolding?.pct || creatorHolding?.percentage || 0;

    // Check if ownership is renounced
    const isRenounced = !hasMintAuthority && !hasFreezeAuthority;

    // RugCheck score (0-100, higher is safer)
    const rugCheckScore = data.score || (100 - (risks.length * 15));

    // Flag high risk holders
    const highHolderRisk = topHoldersPercent > 50 || creatorHoldingPercent > 10;
    const mediumHolderRisk = topHoldersPercent > 30;
    
    if (topHoldersPercent > 50) {
      riskReasons.push(`🔴 Top 10 holders control ${topHoldersPercent.toFixed(1)}% of supply`);
    } else if (topHoldersPercent > 30) {
      riskReasons.push(`🟠 Top 10 holders control ${topHoldersPercent.toFixed(1)}% of supply`);
    }

    if (creatorHoldingPercent > 10) {
      riskReasons.push(`🔴 Creator still holds ${creatorHoldingPercent.toFixed(1)}%`);
    }

    // Determine final risk level
    let riskLevel: "SAFE" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
    if (hasCritical || isHoneypot) {
      riskLevel = "CRITICAL";
    } else if (highHolderRisk || hasMintAuthority || hasFreezeAuthority) {
      riskLevel = "HIGH";
    } else if (hasWarning || mediumHolderRisk) {
      riskLevel = "MEDIUM";
    } else if (hasInfo) {
      riskLevel = "LOW";
    } else {
      riskLevel = "SAFE";
    }

    const contractAnalysis: ContractAnalysis = {
      isHoneypot,
      honeypotReason: isHoneypot ? "Token flagged as potential honeypot" : "No honeypot detected",
      hasMintAuthority,
      hasFreezeAuthority,
      isRenounced,
      topHoldersPercent,
      creatorHoldingPercent,
      riskLevel,
      riskReasons,
      rugCheckScore: Math.max(0, Math.min(100, rugCheckScore)),
      dataSource: "RUGCHECK"
    };

    console.log(`✅ Contract analysis complete: Risk=${riskLevel}, Score=${rugCheckScore}, Honeypot=${isHoneypot}`);
    return contractAnalysis;
  } catch (error) {
    console.error("Error fetching RugCheck data:", error);
    return null;
  }
}
async function fetchUserStrategyContext(
  userId: string,
  conversationId?: string,
): Promise<{
  context: string;
  conversationIdUsed: string | null;
  messageCount: number;
  lastUserMessageAt: string | null;
}> {
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseKey) {
      console.log("Supabase credentials not available for strategy fetch");
      return { context: "", conversationIdUsed: null, messageCount: 0, lastUserMessageAt: null };
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    let conversationIdUsed: string | null = null;

    // 1) If client provided a conversationId, validate it belongs to the user
    if (conversationId) {
      const { data: conv, error } = await supabase
        .from("aurion_ai_conversations")
        .select("id")
        .eq("id", conversationId)
        .eq("user_id", userId)
        .maybeSingle();

      if (!error && conv?.id) {
        conversationIdUsed = conv.id;
      } else {
        console.log("⚠️ Provided conversationId is invalid or not owned by user; falling back.");
      }
    }

    // 2) Fallback to the conversation that has the most recent message (more reliable than updated_at)
    if (!conversationIdUsed) {
      const { data: lastMsg, error } = await supabase
        .from("aurion_ai_messages")
        .select("conversation_id, created_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (!error && lastMsg?.conversation_id) {
        conversationIdUsed = lastMsg.conversation_id;
      }
    }

    // 3) Last resort: most recently updated conversation
    if (!conversationIdUsed) {
      const { data: conversations, error: convError } = await supabase
        .from("aurion_ai_conversations")
        .select("id")
        .eq("user_id", userId)
        .order("updated_at", { ascending: false })
        .limit(1);

      if (convError || !conversations || conversations.length === 0) {
        console.log("No conversations found for user");
        return { context: "", conversationIdUsed: null, messageCount: 0, lastUserMessageAt: null };
      }

      conversationIdUsed = conversations[0].id;
    }

    // Load messages for selected conversation
    const { data: messages, error: msgError } = await supabase
      .from("aurion_ai_messages")
      .select("role, content, created_at")
      .eq("conversation_id", conversationIdUsed)
      .order("created_at", { ascending: true })
      .limit(200);

    if (msgError || !messages || messages.length === 0) {
      console.log("No messages found in conversation");
      return { context: "", conversationIdUsed, messageCount: 0, lastUserMessageAt: null };
    }

    const lastUserMessageAt = [...messages]
      .reverse()
      .find((m) => m.role === "user")?.created_at || null;

    const strategyContext = messages
      .map((m) => `${m.role === "user" ? "Usuário" : "Aurion"}: ${m.content}`)
      .join("\n");

    console.log(
      `✅ Strategy context loaded: ${messages.length} messages from chat | conversationId=${conversationIdUsed}`,
    );

    return {
      context: strategyContext,
      conversationIdUsed,
      messageCount: messages.length,
      lastUserMessageAt,
    };
  } catch (error) {
    console.error("Error fetching strategy context:", error);
    return { context: "", conversationIdUsed: null, messageCount: 0, lastUserMessageAt: null };
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { token, userId, conversationId } = await req.json() as { 
      token: { pairAddress: string; chainId?: string; symbol?: string };
      userId?: string;
      conversationId?: string;
    };
    
    if (!token?.pairAddress) {
      return new Response(
        JSON.stringify({ error: "pairAddress é obrigatório para buscar dados ao vivo" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY");
    
    if (!GEMINI_API_KEY) {
      console.error("GEMINI_API_KEY not found in environment");
      return new Response(
        JSON.stringify({ error: "API key do Gemini não configurada" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // ========== STEP 1: FETCH LIVE DATA FROM DEXSCREENER ==========
    const liveData = await fetchLiveTokenData(token.pairAddress, token.chainId || "solana");
    
    if (!liveData) {
      return new Response(
        JSON.stringify({ 
          error: "Não foi possível obter dados ao vivo da DexScreener. Tente novamente.",
          retryable: true 
        }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // ========== STEP 2: FETCH STRATEGY CONTEXT FROM CHAT ==========
    let strategyContext = "";
    let strategyMeta: { conversationIdUsed: string | null; messageCount: number; lastUserMessageAt: string | null } | null = null;
    if (userId) {
      const s = await fetchUserStrategyContext(userId, conversationId);
      strategyContext = s.context;
      strategyMeta = {
        conversationIdUsed: s.conversationIdUsed,
        messageCount: s.messageCount,
        lastUserMessageAt: s.lastUserMessageAt,
      };
    }

    // ========== STEP 2.5: FETCH CONTRACT ANALYSIS FROM RUGCHECK ==========
    let contractAnalysis: ContractAnalysis | null = null;
    if (liveData.tokenAddress) {
      contractAnalysis = await fetchContractAnalysis(liveData.tokenAddress);
    }

    // ========== STEP 3: FORENSIC ANALYSIS WITH LIVE DATA ==========
    const volumeToLiquidityRatio = liveData.volume24h / (liveData.liquidity || 1);
    const volume5mToLiqRatio = liveData.volume5m / (liveData.liquidity || 1);
    
    // 1. SUSPICIOUS VOLUME DETECTION
    const suspiciousVolume = volume5mToLiqRatio > 0.5 || 
                              (volumeToLiquidityRatio > 10 && Math.abs(liveData.priceChange1h) < 2);
    const suspiciousVolumeReason = suspiciousVolume 
      ? volume5mToLiqRatio > 0.5 
        ? `Volume 5min (${(volume5mToLiqRatio * 100).toFixed(0)}% da liquidez) indica manipulação`
        : `Volume 24h ${volumeToLiquidityRatio.toFixed(1)}x maior que liquidez com preço estável = Wash Trading`
      : "Padrão normal de volume";

    // 2. DISTRIBUTION DETECTION
    const sellRatio5m = liveData.sells5m / (liveData.buys5m || 1);
    const sellRatio1h = liveData.sells1h / (liveData.buys1h || 1);
    const distributionDetected = sellRatio5m > 2 || (sellRatio1h > 1.5 && liveData.priceChange1h < -10);
    const distributionReason = distributionDetected
      ? sellRatio5m > 2
        ? `🚨 Vendas 5min: ${liveData.sells5m} vs Compras: ${liveData.buys5m} (Ratio ${sellRatio5m.toFixed(1)}x)`
        : `Dump em progresso: ${sellRatio1h.toFixed(1)}x mais vendas que compras em 1h`
      : "Equilíbrio compra/venda";

    // 3. TOP 10 (estimate based on sell pressure OR contract data)
    const top10FromContract = contractAnalysis?.topHoldersPercent ? contractAnalysis.topHoldersPercent > 40 : false;
    const top10Selling = (sellRatio1h > 1.5 && liveData.volume1h > liveData.liquidity * 0.3) || top10FromContract;
    const top10SellingReason = top10FromContract && contractAnalysis
      ? `⚠️ Top 10 holders controlam ${contractAnalysis.topHoldersPercent.toFixed(1)}% do supply`
      : top10Selling
        ? `⚠️ Alta pressão vendedora detectada (${sellRatio1h.toFixed(1)}x mais vendas)`
        : "Pressão vendedora normal";

    // 4. CREATOR RISK (from contract or estimate from age and volume pattern)
    let creatorRisk: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" = "LOW";
    let creatorRiskReason = "";
    
    // Use contract analysis if available
    if (contractAnalysis) {
      if (contractAnalysis.isHoneypot || contractAnalysis.riskLevel === "CRITICAL") {
        creatorRisk = "CRITICAL";
        creatorRiskReason = contractAnalysis.isHoneypot 
          ? `🔴 HONEYPOT DETECTADO - NÃO PODE VENDER`
          : `🔴 Contrato de ALTO RISCO: ${contractAnalysis.riskReasons[0] || 'Múltiplos problemas'}`;
      } else if (contractAnalysis.hasMintAuthority || contractAnalysis.hasFreezeAuthority || contractAnalysis.riskLevel === "HIGH") {
        creatorRisk = "HIGH";
        creatorRiskReason = contractAnalysis.hasMintAuthority
          ? `🟠 MINT AUTHORITY ATIVO - Dev pode criar mais tokens`
          : contractAnalysis.hasFreezeAuthority
            ? `🟠 FREEZE AUTHORITY ATIVO - Dev pode congelar wallets`
            : `🟠 Contrato com riscos: ${contractAnalysis.riskReasons.slice(0, 2).join(', ')}`;
      } else if (contractAnalysis.riskLevel === "MEDIUM") {
        creatorRisk = "MEDIUM";
        creatorRiskReason = `🟡 Monitorar contrato: ${contractAnalysis.riskReasons[0] || 'Alguns alertas'}`;
      } else if (contractAnalysis.isRenounced) {
        creatorRisk = "LOW";
        creatorRiskReason = `✅ Ownership renunciada - Contrato seguro (Score: ${contractAnalysis.rugCheckScore})`;
      } else {
        creatorRisk = "LOW";
        creatorRiskReason = `✅ Contrato OK (RugCheck Score: ${contractAnalysis.rugCheckScore})`;
      }
    } else if (liveData.ageHours < 1 && sellRatio5m > 3) {
      creatorRisk = "CRITICAL";
      creatorRiskReason = `🔴 Token muito novo (${(liveData.ageHours * 60).toFixed(0)}min) com vendas massivas`;
    } else if (liveData.ageHours < 6 && sellRatio1h > 2) {
      creatorRisk = "HIGH";
      creatorRiskReason = `🟠 Token jovem com pressão vendedora alta`;
    } else if (liveData.ageHours < 24 && sellRatio1h > 1.3) {
      creatorRisk = "MEDIUM";
      creatorRiskReason = `🟡 Monitorar - Token recente com vendas acima da média`;
    } else {
      creatorRisk = "LOW";
      creatorRiskReason = `✅ Padrão de vendas normal para idade do token`;
    }

    // ========== SECURITY LOCK: DANGER DISTRIBUTION ==========
    const contractDanger = contractAnalysis?.isHoneypot || contractAnalysis?.riskLevel === "CRITICAL";
    const dangerDistribution = liveData.liquidity < 5000 || liveData.priceChange5m < -15 || contractDanger;

    // Pre-calculated forensic data as REFERENCE for the AI (not final values)
    const forensicReference = {
      suspiciousVolume,
      suspiciousVolumeReason,
      distributionDetected,
      distributionReason,
      top10Selling,
      top10SellingReason,
      creatorRisk,
      creatorRiskReason,
      dangerDistribution,
      dataSource: "LIVE_DEXSCREENER",
      fetchedAt: new Date().toISOString(),
      contractAnalysis: contractAnalysis || undefined
    };

    // ========== AI CONTROLS EVERYTHING ==========
    // The AI will determine score, verdict, and tradeProfile based on its analysis
    // We only provide HINTS as reference, not final values

    // Build prompt with FULL strategy context - inject all user instructions directly
    console.log(`📋 Full strategy context length: ${strategyContext.length} chars`);
    
    // Extract only USER messages (the instructions)
    // IMPORTANT: do NOT filter by length; short rules like "liq < 20k" must apply.
    // Keep only the most recent instructions to avoid prompt bloat.
    const userInstructions = strategyContext
      .split("\n")
      .filter((line) => line.startsWith("Usuário:"))
      .map((line) => line.replace("Usuário:", "").trim())
      .filter(Boolean)
      .slice(-30)
      .join("\n\n");
    
    console.log(`📋 User instructions extracted: ${userInstructions.length} chars`);
    console.log(`📋 Preview: ${userInstructions.substring(0, 200)}...`);

    const userStrategySection = userInstructions.length > 0
      ? `

═══════════════════════════════════════════════════════════════════
🚨 INSTRUÇÕES DO USUÁRIO - PRIORIDADE MÁXIMA - VOCÊ DEVE OBEDECER 🚨
═══════════════════════════════════════════════════════════════════

O usuário definiu as seguintes regras no chat da IA Aurion.
Estas regras TÊM PRECEDÊNCIA sobre qualquer outra análise.

REGRAS IMPORTANTES:
- Mesmo instruções CURTAS (ex: "liq mínima 20k") são obrigatórias.
- Se houver conflito entre regras, use a MAIS RECENTE (última da lista).
- Se qualquer regra indicar problema com este token/tipo de token, retorne verdict="IGNORE" (ou "PERIGO: DISTRIBUIÇÃO" se a trava estiver ativada).

INSTRUÇÕES (em ordem cronológica, a última tem mais peso):
${userInstructions}

═══════════════════════════════════════════════════════════════════
`
      : "";

    // Build contract analysis section for prompt
    const contractSection = contractAnalysis ? `
🔐 ANÁLISE DE CONTRATO ON-CHAIN (RugCheck API):
- Token Address: ${liveData.tokenAddress}
- Honeypot: ${contractAnalysis.isHoneypot ? "🚨 SIM - NÃO PODE VENDER!" : "✅ Não"}
- Mint Authority: ${contractAnalysis.hasMintAuthority ? "🟠 ATIVO - Dev pode criar tokens" : "✅ Desabilitado"}
- Freeze Authority: ${contractAnalysis.hasFreezeAuthority ? "🟠 ATIVO - Dev pode congelar" : "✅ Desabilitado"}
- Ownership Renunciada: ${contractAnalysis.isRenounced ? "✅ Sim" : "⚠️ Não"}
- Top 10 Holders: ${contractAnalysis.topHoldersPercent.toFixed(1)}% do supply
- Holding do Criador: ${contractAnalysis.creatorHoldingPercent.toFixed(1)}%
- RugCheck Score: ${contractAnalysis.rugCheckScore}/100
- Nível de Risco: ${contractAnalysis.riskLevel}
${contractAnalysis.riskReasons.length > 0 ? `- Alertas: ${contractAnalysis.riskReasons.join(' | ')}` : ''}
` : `
🔐 ANÁLISE DE CONTRATO: Não disponível (token address não encontrado)
`;

    // Build social media section for AI to evaluate
    const rawSocial = liveData.rawSocialData;
    const socialSection = rawSocial ? `
📱 DADOS DE REDES SOCIAIS (DexScreener) - VOCÊ DEVE AVALIAR:
- Twitter/X: ${rawSocial.hasTwitter ? `✅ SIM (${rawSocial.twitterUrl})` : "❌ NÃO ENCONTRADO"}
- Website Oficial: ${rawSocial.hasWebsite ? `✅ SIM (${rawSocial.websiteUrl})` : "❌ NÃO ENCONTRADO"}
- Telegram: ${rawSocial.hasTelegram ? `✅ SIM (${rawSocial.telegramUrl})` : "❌ NÃO ENCONTRADO"}
- Discord: ${rawSocial.hasDiscord ? `✅ SIM (${rawSocial.discordUrl})` : "❌ NÃO ENCONTRADO"}
- Total de Redes: ${rawSocial.totalSocials}/4

VOCÊ DEVE AVALIAR E RETORNAR socialAnalysis com:
- socialScore (0-100): Sua avaliação da presença social
- socialRisk (LOW/MEDIUM/HIGH/CRITICAL): Seu julgamento do risco
- socialRiskReason: Sua explicação detalhada
- Os URLs e flags hasTwitter/hasWebsite/etc devem ser copiados dos dados acima
` : `
📱 DADOS DE REDES SOCIAIS: Não disponíveis
`;

    const systemPrompt = `Você é a IA Aurion, analista forense especializado em detectar GOLPES e RUGPULLS na rede Solana.

SUA MISSÃO: Proteger o usuário de perder dinheiro. Na dúvida, seja CONSERVADOR.
${userStrategySection}

🔴 DADOS EM TEMPO REAL - DexScreener API (${new Date().toISOString()})
${contractSection}
${socialSection}

⛔ TRAVA DE SEGURANÇA: ${dangerDistribution ? "ATIVADA - RETORNE OBRIGATORIAMENTE verdict='PERIGO: DISTRIBUIÇÃO' e score=0" : "Não ativada"}

📊 DADOS BRUTOS PARA SUA ANÁLISE (você deve interpretar):
- Preço atual: $${liveData.priceUsd.toFixed(8)}
- Variação 5min: ${liveData.priceChange5m.toFixed(2)}%
- Variação 1h: ${liveData.priceChange1h.toFixed(2)}%
- Variação 24h: ${liveData.priceChange24h.toFixed(2)}%
- Liquidez: $${liveData.liquidity.toLocaleString()}
- Volume 5min: $${liveData.volume5m.toLocaleString()}
- Volume 1h: $${liveData.volume1h.toLocaleString()}
- Volume 24h: $${liveData.volume24h.toLocaleString()}
- Vol/Liq Ratio: ${volumeToLiquidityRatio.toFixed(2)}x
- Compras 5min: ${liveData.buys5m} | Vendas 5min: ${liveData.sells5m}
- Compras 1h: ${liveData.buys1h} | Vendas 1h: ${liveData.sells1h}
- Idade do token: ${(liveData.ageHours * 60).toFixed(0)} minutos

VOCÊ DEVE ANALISAR E RETORNAR EM JSON:

{
  "verdict": "PERIGO: DISTRIBUIÇÃO" | "IGNORE" | "NEUTRO" | "ALTA CONVICÇÃO" | "OPORTUNIDADE IMEDIATA",
  "score": 0-100,
  "tradeProfile": "⛔ EVITAR" | "Aguardar" | "Entrada Cautelosa" | "Entrada Imediata",
  "buyReason": "Explicação técnica baseada nos dados AO VIVO",
  "analysis": "Análise forense detalhada. MENCIONE se aplicou alguma instrução do usuário.",
  
  "forensicAnalysis": {
    "suspiciousVolume": true/false,
    "suspiciousVolumeReason": "Sua análise do volume em relação à liquidez",
    
    "distributionDetected": true/false,
    "distributionReason": "Sua análise de compras vs vendas",
    
    "top10Selling": true/false,
    "top10SellingReason": "Sua análise da pressão vendedora",
    
    "creatorRisk": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
    "creatorRiskReason": "Sua análise do risco do criador/contrato"
  },
  
  "socialAnalysis": {
    "hasTwitter": ${rawSocial?.hasTwitter || false},
    "twitterUrl": ${rawSocial?.twitterUrl ? `"${rawSocial.twitterUrl}"` : "null"},
    "hasWebsite": ${rawSocial?.hasWebsite || false},
    "websiteUrl": ${rawSocial?.websiteUrl ? `"${rawSocial.websiteUrl}"` : "null"},
    "hasTelegram": ${rawSocial?.hasTelegram || false},
    "telegramUrl": ${rawSocial?.telegramUrl ? `"${rawSocial.telegramUrl}"` : "null"},
    "hasDiscord": ${rawSocial?.hasDiscord || false},
    "discordUrl": ${rawSocial?.discordUrl ? `"${rawSocial.discordUrl}"` : "null"},
    "totalSocials": ${rawSocial?.totalSocials || 0},
    "socialScore": 0-100 (SUA AVALIAÇÃO),
    "socialRisk": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" (SEU JULGAMENTO),
    "socialRiskReason": "Sua explicação do risco social baseada nos links encontrados"
  }
}

REGRAS PARA SUA ANÁLISE FORENSE:
1. VOLUME SUSPEITO: Volume 5min > 30% da liquidez OU Volume 24h > 15x liquidez com preço estável = SUSPEITO
2. DISTRIBUIÇÃO: Vendas > 2x compras em 5min = DUMP/DISTRIBUIÇÃO
3. TOP 10 SELLING: Pressão vendedora alta = Vendas > 1.5x compras em 1h com volume alto
4. CREATOR RISK: Baseie-se nos dados on-chain (Mint, Freeze, Holders %) + idade + padrão de vendas

REGRAS PARA SUA ANÁLISE DE REDES SOCIAIS:
1. NENHUMA rede social = CRITICAL (projeto fantasma, alto risco de rug)
2. Apenas 1 rede (sem Twitter) = HIGH (baixa credibilidade)
3. Apenas Twitter = MEDIUM (monitorar outras redes)
4. 2+ redes = LOW (presença básica aceitável)
5. 4 redes com links válidos = LOW com score alto (projeto completo)
6. Avalie a QUALIDADE dos links (ex: twitter.com/legit_project vs twitter.com/xyz123randombot)

SE HONEYPOT ou liquidez < $5000 ou queda > 15% em 5min = score 0, verdict PERIGO

Retorne APENAS o JSON, sem explicações adicionais.`;

    console.log(`🤖 Calling Gemini with LIVE data for: ${liveData.symbol}`);

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: systemPrompt }] }],
          generationConfig: { temperature: 0.2, maxOutputTokens: 2048 },
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Gemini API error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Limite da API Gemini atingido. Aguarde.", isQuotaError: true, retryAfter: 45 }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      return new Response(
        JSON.stringify({ error: "Erro na API do Gemini" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    const analysisText = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    
    let result: AnalysisResult;
    let aiSocialAnalysis: SocialAnalysis | null = null;
    
    try {
      const jsonMatch = analysisText.match(/```(?:json)?\s*([\s\S]*?)```/) || [null, analysisText];
      const jsonStr = jsonMatch[1]?.trim() || analysisText.trim();
      const parsed = JSON.parse(jsonStr);
      
      // ========== AI CONTROLS EVERYTHING ==========
      // All values come from the AI response with fallback to reference data
      const aiForensic = parsed.forensicAnalysis || {};
      const finalForensicAnalysis: ForensicAnalysis = {
        suspiciousVolume: typeof aiForensic.suspiciousVolume === "boolean" ? aiForensic.suspiciousVolume : forensicReference.suspiciousVolume,
        suspiciousVolumeReason: aiForensic.suspiciousVolumeReason || forensicReference.suspiciousVolumeReason,
        distributionDetected: typeof aiForensic.distributionDetected === "boolean" ? aiForensic.distributionDetected : forensicReference.distributionDetected,
        distributionReason: aiForensic.distributionReason || forensicReference.distributionReason,
        top10Selling: typeof aiForensic.top10Selling === "boolean" ? aiForensic.top10Selling : forensicReference.top10Selling,
        top10SellingReason: aiForensic.top10SellingReason || forensicReference.top10SellingReason,
        creatorRisk: ["LOW", "MEDIUM", "HIGH", "CRITICAL"].includes(aiForensic.creatorRisk) ? aiForensic.creatorRisk : forensicReference.creatorRisk,
        creatorRiskReason: aiForensic.creatorRiskReason || forensicReference.creatorRiskReason,
        dangerDistribution: typeof aiForensic.dangerDistribution === "boolean" ? aiForensic.dangerDistribution : forensicReference.dangerDistribution,
        dataSource: "LIVE_DEXSCREENER",
        fetchedAt: new Date().toISOString(),
        contractAnalysis: contractAnalysis || undefined,
      };
      
      // ========== AI EVALUATES SOCIAL ANALYSIS ==========
      const aiSocial = parsed.socialAnalysis || {};
      const rawSocial = liveData.rawSocialData;
      
      if (rawSocial || aiSocial.socialScore !== undefined) {
        aiSocialAnalysis = {
          hasTwitter: typeof aiSocial.hasTwitter === "boolean" ? aiSocial.hasTwitter : (rawSocial?.hasTwitter || false),
          twitterUrl: aiSocial.twitterUrl || rawSocial?.twitterUrl || null,
          hasWebsite: typeof aiSocial.hasWebsite === "boolean" ? aiSocial.hasWebsite : (rawSocial?.hasWebsite || false),
          websiteUrl: aiSocial.websiteUrl || rawSocial?.websiteUrl || null,
          hasTelegram: typeof aiSocial.hasTelegram === "boolean" ? aiSocial.hasTelegram : (rawSocial?.hasTelegram || false),
          telegramUrl: aiSocial.telegramUrl || rawSocial?.telegramUrl || null,
          hasDiscord: typeof aiSocial.hasDiscord === "boolean" ? aiSocial.hasDiscord : (rawSocial?.hasDiscord || false),
          discordUrl: aiSocial.discordUrl || rawSocial?.discordUrl || null,
          totalSocials: typeof aiSocial.totalSocials === "number" ? aiSocial.totalSocials : (rawSocial?.totalSocials || 0),
          socialScore: typeof aiSocial.socialScore === "number" ? Math.min(100, Math.max(0, aiSocial.socialScore)) : 0,
          socialRisk: ["LOW", "MEDIUM", "HIGH", "CRITICAL"].includes(aiSocial.socialRisk) ? aiSocial.socialRisk : "CRITICAL",
          socialRiskReason: aiSocial.socialRiskReason || "Análise de redes sociais não disponível",
        };
        
        console.log(`📱 AI Social Analysis: Score=${aiSocialAnalysis.socialScore} | Risk=${aiSocialAnalysis.socialRisk}`);
      }
      
      // AI provides score and verdict - only minimal fallback
      const aiScore = typeof parsed.score === "number" ? Math.min(100, Math.max(0, parsed.score)) : 50;
      const aiVerdict = parsed.verdict || "NEUTRO";
      const aiTradeProfile = parsed.tradeProfile || "Análise Pendente";
      
      result = {
        symbol: liveData.symbol,
        verdict: aiVerdict,
        score: aiScore,
        tradeProfile: aiTradeProfile,
        buyReason: parsed.buyReason || "",
        analysis: parsed.analysis || analysisText.substring(0, 200),
        forensicAnalysis: finalForensicAnalysis,
      };
    } catch {
      // Fallback when AI response cannot be parsed
      result = {
        symbol: liveData.symbol,
        verdict: "NEUTRO",
        score: 50,
        tradeProfile: "Análise Manual",
        buyReason: `Dados ao vivo: Vol/Liq ${volumeToLiquidityRatio.toFixed(2)}x`,
        analysis: analysisText.substring(0, 300) || "Erro ao processar resposta da IA",
        forensicAnalysis: forensicReference as ForensicAnalysis,
      };
    }
    
    // Attach AI-evaluated social analysis to liveData for UI
    if (aiSocialAnalysis) {
      liveData.socialAnalysis = aiSocialAnalysis;
    }

    console.log(`✅ Analysis complete: ${result.symbol} | Verdict: ${result.verdict} | Score: ${result.score}`);

    return new Response(
      JSON.stringify({ 
        result,
        liveData, // Return live data for UI
        preCalculated: {
          volumeToLiquidityRatio,
          isGoldenRatio: volumeToLiquidityRatio > 3 && volumeToLiquidityRatio < 10,
          isEliteLiquidity: liveData.liquidity > 40000 && liveData.volume24h > 100000,
          isProjectElite: liveData.liquidity > 100000,
          isPotentialCTO: false,
          isWashTrading: forensicReference.suspiciousVolume,
          dangerDistribution: forensicReference.dangerDistribution,
          forensicAnalysis: forensicReference
        },
        meta: {
          strategy: strategyMeta,
        },
        timestamp: new Date().toISOString(),
        dataSource: "LIVE_DEXSCREENER"
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error in aurion-gemini-analysis:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Erro desconhecido" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
