const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Function to resolve hostname to IPv4
async function resolveIPv4(hostname: string): Promise<string | null> {
  try {
    const result = await Deno.resolveDns(hostname, "A")
    return result.length > 0 ? result[0] : null
  } catch (error) {
    console.error('Error resolving DNS:', error)
    return null
  }
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {

    // Get database URL from environment
    const databaseUrl = Deno.env.get('SUPABASE_DB_URL')
    
    if (!databaseUrl) {
      return new Response(
        JSON.stringify({ error: 'DATABASE_URL não encontrado' }),
        { status: 500, headers: { 'Content-Type': 'application/json' } }
      )
    }

    // Parse the URL to show components
    let parsedInfo: any = {}
    let ipv4Address: string | null = null
    
    try {
      const url = new URL(databaseUrl)
      
      // Resolve hostname to IPv4
      ipv4Address = await resolveIPv4(url.hostname)
      
      parsedInfo = {
        host: url.hostname,
        port: url.port,
        database: url.pathname.replace('/', ''),
        username: url.username,
        // Don't show full password, just indicate it exists
        hasPassword: !!url.password,
        ipv4: ipv4Address
      }
    } catch (e) {
      console.error('Error parsing URL:', e)
    }

    // Create IPv4-forced connection string if IPv4 was resolved
    let ipv4ConnectionString = null
    if (ipv4Address && parsedInfo.port && parsedInfo.username && parsedInfo.database) {
      try {
        const url = new URL(databaseUrl)
        ipv4ConnectionString = `postgres://${url.username}:${url.password}@${ipv4Address}:${parsedInfo.port}/${parsedInfo.database}?sslmode=prefer`
      } catch (e) {
        console.error('Error creating IPv4 connection string:', e)
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        database_url: databaseUrl,
        ipv4_connection_url: ipv4ConnectionString,
        components: parsedInfo,
        instructions: {
          pt: 'Copie o DATABASE_URL abaixo e cole no arquivo .env.monitor do seu VPS. Se enfrentar problemas IPv6, use o ipv4_connection_url.',
          en: 'Copy the DATABASE_URL below and paste it into your VPS .env.monitor file. If facing IPv6 issues, use ipv4_connection_url.'
        }
      }),
      { 
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )

  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: String(error) }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
