import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { amount, credits, userEmail, taxId } = await req.json();

    // Configuração PagBank - Usando token do ambiente
    const PAGBANK_TOKEN = Deno.env.get('PAGBANK_TOKEN');
    
    if (!PAGBANK_TOKEN) {
      throw new Error("Token do PagBank não configurado");
    }
    
    // URL de produção do PagBank
    const PAGBANK_API_URL = "https://api.pagseguro.com/orders";
    
    console.log("Iniciando criação de pagamento PIX...");

    // Obter usuário autenticado
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const { data: { user } } = await supabaseClient.auth.getUser();
    if (!user) {
      throw new Error("Usuário não autenticado");
    }

    // Criar referência única
    const timestamp = Date.now();
    const referenceId = `AURION_CREDITO_${user.id.substring(0, 8)}_${timestamp}`;

    // Criar pedido no PagBank
    const pagBankResponse = await fetch(PAGBANK_API_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${PAGBANK_TOKEN}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        reference_id: referenceId,
        customer: {
          name: user.email?.split('@')[0] || "Cliente Aurion",
          email: userEmail || user.email,
          tax_id: taxId || "12345678909", // CPF para sandbox
        },
        items: [
          {
            name: `Pacote de ${credits} Créditos Aurion`,
            quantity: 1,
            unit_amount: Math.round(amount * 100), // Valor em centavos
          },
        ],
        qr_codes: [
          {
            amount: {
              value: Math.round(amount * 100),
            },
          },
        ],
      }),
    });

    if (!pagBankResponse.ok) {
      const errorText = await pagBankResponse.text();
      console.error("Erro PagBank:", errorText);
      throw new Error(`Erro ao criar pagamento: ${errorText}`);
    }

    const pagBankData = await pagBankResponse.json();
    console.log("Pedido criado:", pagBankData);

    // Salvar transação no banco
    const { error: insertError } = await supabaseClient
      .from("credit_transactions")
      .insert({
        user_id: user.id,
        credits: credits,
        amount_paid: amount,
        payment_method: "PIX",
        status: "pending",
        order_id: pagBankData.id,
        reference_id: referenceId,
      });

    if (insertError) {
      console.error("Erro ao salvar transação:", insertError);
      throw insertError;
    }

    // Extrair QR Code e código Pix
    const qrCode = pagBankData.qr_codes?.[0];
    const qrCodeUrl = qrCode?.links?.find((link: any) => link.rel === "QRCODE.PNG")?.href || "";
    const pixCode = qrCode?.text || "";

    return new Response(
      JSON.stringify({
        orderId: pagBankData.id,
        referenceId: referenceId,
        qrCodeUrl: qrCodeUrl,
        pixCode: pixCode,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Erro na função:", error);
    const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      }
    );
  }
});
