import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

type BalanceResponse = {
  balanceLamports?: number;
  balanceSol?: number;
  rpc?: string;
  error?: string;
  details?: unknown;
};

const RPC_ENDPOINTS = [
  "https://rpc.ankr.com/solana",
  "https://api.mainnet-beta.solana.com",
  "https://solana.publicnode.com",
];

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "method_not_allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const publicKey = String(body?.publicKey || "").trim();

    // Basic validation (base58 pubkey length is typically 32-44 chars)
    if (!publicKey || publicKey.length < 32 || publicKey.length > 44) {
      return new Response(JSON.stringify({ error: "invalid_public_key" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    for (const rpc of RPC_ENDPOINTS) {
      try {
        const rpcRes = await fetch(rpc, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            jsonrpc: "2.0",
            id: 1,
            method: "getBalance",
            params: [publicKey],
          }),
        });

        const data = await rpcRes.json().catch(() => null);

        if (!rpcRes.ok) {
          continue;
        }

        const lamports = data?.result?.value;
        if (typeof lamports === "number") {
          const resp: BalanceResponse = {
            balanceLamports: lamports,
            balanceSol: lamports / 1e9,
            rpc,
          };

          return new Response(JSON.stringify(resp), {
            status: 200,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        // JSON-RPC error payload
        if (data?.error) {
          continue;
        }
      } catch {
        // try next rpc
        continue;
      }
    }

    const failResp: BalanceResponse = { error: "balance_fetch_failed" };
    return new Response(JSON.stringify(failResp), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    const errResp: BalanceResponse = {
      error: "unexpected_error",
      details: message,
    };

    return new Response(JSON.stringify(errResp), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
