const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface NewsItem {
  id: string;
  title: string;
  body: string;
  url: string;
  imageUrl: string;
  source: string;
  publishedAt: string;
  categories: string;
}

async function translateTexts(texts: string[]): Promise<string[]> {
  const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');
  
  if (!GEMINI_API_KEY || texts.length === 0) {
    console.log('No GEMINI_API_KEY or empty texts, skipping translation');
    return texts;
  }

  try {
    console.log('Calling Gemini for translation...');
    
    const prompt = `Traduza os seguintes textos do inglês para português brasileiro. Retorne APENAS as traduções, uma por linha, na mesma ordem. Sem numeração, sem explicações.

${texts.join('\n---\n')}`;

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [
            { 
              role: 'user', 
              parts: [{ text: 'Você é um tradutor. Traduza textos de inglês para português brasileiro. Retorne apenas as traduções separadas por ---' }]
            },
            {
              role: 'model',
              parts: [{ text: 'Entendido. Vou traduzir os textos para português brasileiro.' }]
            },
            { role: 'user', parts: [{ text: prompt }] }
          ],
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 1024,
          },
        }),
      }
    );

    if (!response.ok) {
      console.error('Translation API error:', response.status, await response.text());
      return texts;
    }

    const data = await response.json();
    const translatedContent = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    
    console.log('Translation response received, parsing...');
    
    // Parse translations separated by ---
    const translations = translatedContent.split('---').map((t: string) => t.trim()).filter((t: string) => t.length > 0);
    
    console.log(`Parsed ${translations.length} translations from ${texts.length} texts`);
    
    // Return translations if we got the right amount, otherwise return originals
    if (translations.length >= texts.length) {
      return translations.slice(0, texts.length);
    }
    
    // Try line-by-line parsing as fallback
    const lineTranslations = translatedContent.split('\n').map((t: string) => t.trim()).filter((t: string) => t.length > 0);
    if (lineTranslations.length >= texts.length) {
      return lineTranslations.slice(0, texts.length);
    }
    
    return texts;
  } catch (error) {
    console.error('Translation error:', error);
    return texts;
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Parse request body for translate option
    let shouldTranslate = false;
    try {
      const body = await req.json();
      shouldTranslate = body?.translate === true;
    } catch {
      // No body or invalid JSON, use defaults
    }
    
    console.log(`Fetching crypto news... (translate: ${shouldTranslate})`);
    
    // Usando CryptoCompare News API
    const response = await fetch(
      'https://min-api.cryptocompare.com/data/v2/news/?lang=EN&sortOrder=latest&excludeCategories=Sponsored',
      {
        headers: {
          'Accept': 'application/json',
        },
      }
    );

    if (!response.ok) {
      throw new Error(`CryptoCompare API error: ${response.status}`);
    }

    const data = await response.json();
    
    // Verificar se Data existe e é um array
    let newsArray: any[] = [];
    
    if (Array.isArray(data?.Data)) {
      newsArray = data.Data;
    } else if (Array.isArray(data)) {
      newsArray = data;
    } else if (data?.Data && typeof data.Data === 'object') {
      newsArray = Object.values(data.Data);
    }
    
    console.log(`Found ${newsArray.length} news items in response`);
    
    // Pegar as 12 notícias mais recentes
    const rawNewsItems = newsArray.slice(0, 12);
    
    let newsItems: NewsItem[];
    
    if (shouldTranslate) {
      // Translate titles
      const titlesToTranslate = rawNewsItems.map((item: any) => item.title || '');
      const translatedTitles = await translateTexts(titlesToTranslate);
      
      newsItems = rawNewsItems.map((item: any, index: number) => ({
        id: item.id?.toString() || Math.random().toString(),
        title: translatedTitles[index] || item.title || '',
        body: (item.body?.substring(0, 200) || '') + '...',
        url: item.url || '',
        imageUrl: item.imageurl || '',
        source: item.source_info?.name || item.source || 'Unknown',
        publishedAt: item.published_on 
          ? new Date(item.published_on * 1000).toISOString()
          : new Date().toISOString(),
        categories: item.categories || '',
      }));
      
      console.log(`Returning ${newsItems.length} translated news items`);
    } else {
      newsItems = rawNewsItems.map((item: any) => ({
        id: item.id?.toString() || Math.random().toString(),
        title: item.title || '',
        body: (item.body?.substring(0, 200) || '') + '...',
        url: item.url || '',
        imageUrl: item.imageurl || '',
        source: item.source_info?.name || item.source || 'Unknown',
        publishedAt: item.published_on 
          ? new Date(item.published_on * 1000).toISOString()
          : new Date().toISOString(),
        categories: item.categories || '',
      }));
      
      console.log(`Returning ${newsItems.length} news items (no translation)`);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        data: newsItems,
        translated: shouldTranslate,
        fetchedAt: new Date().toISOString(),
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error fetching news:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch news',
        data: [],
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
