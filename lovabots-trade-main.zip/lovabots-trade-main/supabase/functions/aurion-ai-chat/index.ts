import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface TextContent {
  type: "text";
  text: string;
}

interface ImageContent {
  type: "image_url";
  image_url: { url: string };
}

type MessageContent = string | (TextContent | ImageContent)[];

interface Message {
  role: "user" | "assistant" | "system";
  content: MessageContent;
}

const SYSTEM_PROMPT = `Você é o Aurion AI, um assistente especializado em trading de criptomoedas na rede Solana. Você foi treinado para analisar tokens, identificar oportunidades de trading e ajudar traders a tomar decisões informadas.

SUAS COMPETÊNCIAS:
1. Análise técnica de tokens (RSI, ADX, Chandelier Exit, Volume, Liquidez)
2. Avaliação de segurança de contratos (Mint, Freeze, LP Lock)
3. Identificação de padrões de mercado (Golden Ratio, Wash Trading, Community Takeover)
4. Estratégias de entrada e saída (Stop Loss, Take Profit)
5. Gestão de risco e posicionamento
6. Análise de gráficos e imagens de trading

COMO VOCÊ DEVE RESPONDER:
- Seja técnico, direto e objetivo
- Use dados e métricas para fundamentar suas análises
- Alerte sobre riscos potenciais
- Sugira níveis de entrada, stop loss e take profit quando relevante
- Mantenha um tom profissional mas acessível

QUANDO RECEBER IMAGENS:
- Analise gráficos de preço identificando padrões técnicos
- Identifique suportes, resistências, tendências
- Aponte indicadores visíveis (médias móveis, RSI, MACD, etc.)
- Forneça insights acionáveis baseados na imagem

VOCÊ PODE:
- Receber instruções sobre estratégias de trading
- Ajustar parâmetros de análise conforme solicitado
- Memorizar preferências do usuário durante a conversa
- Responder sobre mercado cripto em geral
- Analisar imagens de gráficos, trades e screenshots

LEMBRE-SE:
- Todas as análises são para fins educacionais
- Não garanta resultados
- Recomende sempre gestão de risco

DETECÇÃO DE INSTRUÇÕES/COMANDOS:
Quando o usuário enviar uma mensagem que pareça ser uma INSTRUÇÃO, REGRA ou COMANDO para você seguir nas análises futuras (ex: "sempre considere X", "nunca recomende Y", "priorize Z", "use tal estratégia", "a partir de agora faça X"), você DEVE:
1. Responder normalmente confirmando que entendeu a instrução
2. Incluir EXATAMENTE esta tag no FINAL da sua resposta: [INSTRUCTION_DETECTED]

Exemplos de mensagens que são instruções:
- "Sempre priorize tokens com liquidez acima de 50k"
- "Nunca recomende tokens com menos de 100 holders"
- "Use stop loss de 5% em todas as análises"
- "A partir de agora, considere tokens CTO como prioridade"
- "Quero que você analise com foco em volume"

NÃO adicione a tag para perguntas normais ou pedidos de análise pontuais.`;

// Helper to convert base64 data URL to Gemini format
function parseImageContent(content: MessageContent): any[] {
  if (typeof content === "string") {
    return [{ text: content }];
  }

  const parts: any[] = [];
  
  for (const item of content) {
    if (item.type === "text") {
      parts.push({ text: item.text });
    } else if (item.type === "image_url") {
      const url = item.image_url.url;
      
      // Check if it's a base64 data URL
      if (url.startsWith("data:")) {
        const matches = url.match(/^data:([^;]+);base64,(.+)$/);
        if (matches) {
          const mimeType = matches[1];
          const base64Data = matches[2];
          parts.push({
            inline_data: {
              mime_type: mimeType,
              data: base64Data
            }
          });
        }
      } else {
        // For external URLs, we'd need to fetch them first
        // For now, just mention the image was provided
        parts.push({ text: "[Imagem externa fornecida]" });
      }
    }
  }
  
  return parts;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, conversationHistory } = await req.json() as { 
      messages: Message[]; 
      conversationHistory?: Message[];
    };
    
    if (!messages || messages.length === 0) {
      return new Response(
        JSON.stringify({ error: "Nenhuma mensagem fornecida" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY");
    
    if (!GEMINI_API_KEY) {
      console.error("GEMINI_API_KEY not found in environment");
      return new Response(
        JSON.stringify({ error: "API key do Gemini não configurada" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Build conversation context
    const allMessages = [
      { role: "user", parts: [{ text: SYSTEM_PROMPT }] },
      { role: "model", parts: [{ text: "Entendido. Estou pronto para ajudar com análises de trading, estratégias na rede Solana e análise de gráficos. Envie imagens de gráficos ou faça suas perguntas!" }] },
    ];

    // Add conversation history (text only for history)
    if (conversationHistory && conversationHistory.length > 0) {
      for (const msg of conversationHistory) {
        const role = msg.role === "assistant" ? "model" : "user";
        const content = typeof msg.content === "string" ? msg.content : "[Mensagem com mídia]";
        allMessages.push({
          role,
          parts: [{ text: content }]
        });
      }
    }

    // Add current messages (with image support)
    for (const msg of messages) {
      const role = msg.role === "assistant" ? "model" : "user";
      const parts = parseImageContent(msg.content);
      allMessages.push({ role, parts });
    }

    console.log("Sending to Gemini with", allMessages.length, "messages");
    
    // Check if we have images (use vision model)
    const hasImages = messages.some(msg => {
      if (typeof msg.content === "string") return false;
      return msg.content.some(item => item.type === "image_url");
    });

    // Use gemini-2.0-flash for both text and vision
    const modelName = "gemini-2.0-flash";

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: allMessages,
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048,
          },
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Gemini API error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ 
            error: "Limite da API atingido. Aguarde alguns segundos.",
            isQuotaError: true,
            retryAfter: 30
          }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      return new Response(
        JSON.stringify({ error: "Erro na API do Gemini", details: errorText }),
        { status: response.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    const responseText = data.candidates?.[0]?.content?.parts?.[0]?.text || "Desculpe, não consegui gerar uma resposta.";

    // Check if the AI detected an instruction in the user's message
    const isInstruction = responseText.includes("[INSTRUCTION_DETECTED]");
    const cleanResponse = responseText.replace("[INSTRUCTION_DETECTED]", "").trim();

    return new Response(
      JSON.stringify({ 
        response: cleanResponse,
        timestamp: new Date().toISOString(),
        isInstruction
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error in aurion-ai-chat:", error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : "Erro desconhecido",
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
