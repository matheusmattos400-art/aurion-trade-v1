import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-user-public-key",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// Jupiter API endpoints
const JUPITER_QUOTE_API = "https://quote-api.jup.ag/v6/quote";
const JUPITER_SWAP_API = "https://quote-api.jup.ag/v6/swap";

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, params } = await req.json();
    const userPublicKey = req.headers.get("x-user-public-key") || "";

    console.log(`[Jupiter Proxy] Action: ${action}, User: ${userPublicKey}`);

    if (action === "quote") {
      const { inputMint, outputMint, amount, slippageBps } = params;

      console.log("[Jupiter Proxy] Quote request:", { inputMint, outputMint, amount, slippageBps });

      const queryParams = new URLSearchParams({
        inputMint,
        outputMint,
        amount: amount.toString(),
        slippageBps: (slippageBps || 100).toString(),
        onlyDirectRoutes: "false",
        restrictIntermediateTokens: "false",
      });

      const response = await fetch(`${JUPITER_QUOTE_API}?${queryParams.toString()}`, {
        headers: {
          "Accept": "application/json",
        },
      });

      const data = await response.json();

      if (!response.ok) {
        console.error("[Jupiter Proxy] Quote error:", data);
        // IMPORTANT: always return 200 so the client can read the exact Jupiter error payload
        return new Response(
          JSON.stringify({ error: data.error || "Quote failed", details: data, status: response.status }),
          {
            status: 200,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }

      console.log("[Jupiter Proxy] Quote success:", { outAmount: data.outAmount });

      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "swap") {
      const { quoteResponse, userPublicKey: swapUserKey } = params;

      console.log("[Jupiter Proxy] Swap request for user:", swapUserKey);

      const response = await fetch(JUPITER_SWAP_API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          quoteResponse,
          userPublicKey: swapUserKey,
          wrapAndUnwrapSol: true,
          dynamicComputeUnitLimit: true,
          // Fixed priority fee: 0.001 SOL (1,000,000 lamports)
          prioritizationFeeLamports: 1000000,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        console.error("[Jupiter Proxy] Swap error:", data);
        // IMPORTANT: always return 200 so the client can read the exact Jupiter error payload
        return new Response(
          JSON.stringify({ error: data.error || "Swap failed", details: data, status: response.status }),
          {
            status: 200,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }

      console.log("[Jupiter Proxy] Swap transaction prepared");

      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "solPrice") {
      // Try CoinGecko first
      try {
        const cgResponse = await fetch(
          "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd"
        );
        if (cgResponse.ok) {
          const data = await cgResponse.json();
          if (data.solana?.usd) {
            console.log("[Jupiter Proxy] SOL price from CoinGecko:", data.solana.usd);
            return new Response(JSON.stringify({ price: data.solana.usd, source: "coingecko" }), {
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            });
          }
        }
      } catch (e) {
        console.warn("[Jupiter Proxy] CoinGecko failed:", e);
      }

      // Fallback: Jupiter quote for 1 SOL -> USDC
      const SOL_MINT = "So11111111111111111111111111111111111111112";
      const USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
      const ONE_SOL = "1000000000";

      const queryParams = new URLSearchParams({
        inputMint: SOL_MINT,
        outputMint: USDC_MINT,
        amount: ONE_SOL,
        slippageBps: "50",
      });

      const jupResponse = await fetch(`${JUPITER_QUOTE_API}?${queryParams.toString()}`);
      if (jupResponse.ok) {
        const quote = await jupResponse.json();
        const price = parseInt(quote.outAmount) / 1_000_000;
        console.log("[Jupiter Proxy] SOL price from Jupiter:", price);
        return new Response(JSON.stringify({ price, source: "jupiter" }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({ error: "Could not fetch SOL price" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("[Jupiter Proxy] Error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
