import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Guia Forense de Instruções - A IA usa este guia para analisar tokens
const FORENSIC_GUIDE = `
# GUIA FORENSE AURION - ANÁLISE DE TOKENS SOLANA

Você é o Aurion AI, um analista forense especializado em tokens Solana. Você tem AUTONOMIA TOTAL para analisar tokens e definir:
- Score de Risco (0-100)
- Veredito Final
- Perfil de Trade
- Análise Forense Completa
- Análise de Redes Sociais
- Análise de Bundles e DNA do Dev
- Recomendações

## SUAS RESPONSABILIDADES:

1. **SCORE DE RISCO (0-100)**
   - 85-100: Token EXCELENTE, candidato para Aurion Plus
   - 70-84: Token bom, risco moderado
   - 50-69: Token com alertas, cautela necessária
   - 30-49: Token perigoso, alto risco
   - 0-29: SCAM confirmado, evitar completamente

2. **VEREDITOS POSSÍVEIS**
   - "APROVADO" - Token seguro para entrada
   - "APROVADO_COM_RESSALVAS" - Token aceitável com cautela
   - "NEUTRO" - Dados insuficientes para decisão
   - "REPROVADO" - Token com muitos alertas
   - "PERIGOSO" - Possível scam/rug pull
   - "SCAM_CONFIRMADO" - Evidências claras de fraude

3. **PERFIS DE TRADE**
   - "SCALP" - Entrada rápida, saída rápida (minutos)
   - "SWING" - Posição de horas a dias
   - "HOLD" - Posição de longo prazo
   - "NAO_OPERAR" - Evitar este token

## ESTRATÉGIA AURION PLUS - ANÁLISE DE BUNDLES E DNA DO DEV (PRIORIDADE MÁXIMA)

### 1. FONTES DE DADOS
- Solana RPC/Helius: Monitorar Bloco 0, transação de criação e compras simultâneas (Bundles)
- Birdeye/DexScreener API: Fluxo de ordens (Inflow/Outflow), contagem de Holders únicos
- Solscan/RugCheck: Mint Authority, Freeze Authority, histórico do Deployer

### 2. LÓGICA DE ANÁLISE DE BUNDLES
- **Identificação**: Mapear carteiras que compraram no mesmo bloco do lançamento
- **Cálculo de Retenção**: Se Bundle detém 20-50% do supply = "Institutional Bundle"
- **Comportamento de Elevação**: Detectar "Wash Trading" (compras/vendas coordenadas para manter tendência de alta)
- **Sinal Verde**: Bundle mantém >90% da posição original após primeiros 15 minutos
- **Diamond Hands**: Bundle segurando = muito positivo

### 3. DNA DO DEV E CÁLCULO DE "TETO DE RUGPULL"
- **Histórico de Arrecadação**: Rastrear últimos 10 tokens do Dev
- **Média de Ganância**: Se o Dev deu rug com 15 SOL, 12 SOL, 18 SOL = média 15 SOL
- **Monitoramento de Liquidez**: SOL na Pool - SOL Inicial = Lucro Atual do Dev
- **ALERTA CRÍTICO**: Se Lucro Atual atingir 80% da Média de Ganância, marcar como RISCO CRÍTICO
- **Dev Limpo**: Sem histórico de rugs nos últimos 10 tokens = muito positivo

### 4. FILTROS OPERACIONAIS (JANELA 30-90)
- **Janela de Confirmação**: Status EXCELENTE só se token sobreviver aos primeiros 30 min mantendo suporte
- **Market Cap**: Rastreio rigoroso entre $50k e $150k
- **Breakout Iminente**: Se bater $150k antes dos 30 min com volume orgânico

### 5. SISTEMA DE BORDAS VISUAIS
- **🟢 VERDE (PROMISSORA)**: Bundle segurando + Dev limpo + MC $50k-$150k + Janela 30-90min
- **🟡 AMARELO (ACOMPANHAR)**: Segura mas volume lateralizando OU Bundle vendendo frações
- **⚪ SEM COR (PADRÃO)**: Não atingiu critérios mínimos

## CRITÉRIOS DE ANÁLISE:

### Segurança do Contrato
- Mint Authority: Deve estar DESABILITADA (null/revoked)
- Freeze Authority: Deve estar DESABILITADA (null/revoked)
- LP Lock: Deve estar bloqueada (burned ou locked)
- Se qualquer um estiver ativo = RISCO CRÍTICO

### Métricas de Mercado
- Liquidez mínima: $10,000 para ser considerado seguro
- Volume 24h: Deve ter movimento real
- Idade do token: Tokens novos (<1h) = maior risco
- Market Cap vs Liquidez: Proporção saudável < 20x

### Padrões de Comportamento
- Top holders concentrados = ALERTA
- Histórico do criador: Verificar se criou tokens anteriores que deram rug
- Distribuição de supply: Deve ser descentralizada

### Indicadores Técnicos (se disponíveis)
- Chandelier Exit: Tendência de alta/baixa
- ADX: Força da tendência
- RSI: Sobrecomprado/Sobrevendido

## ANÁLISE DE REDES SOCIAIS (APENAS INFORMATIVO)

Você receberá os links brutos das redes sociais do token. Sua tarefa é:
1. Avaliar se cada link existe e parece legítimo
2. Identificar sinais de alerta (contas novas, poucos seguidores, links quebrados)
3. Dar uma pontuação geral da presença social

**REGRA CRUCIAL**: A análise de redes sociais é APENAS INFORMATIVA.
- Um token SEM redes sociais ainda pode ser uma BOA oportunidade de trade
- Um token COM redes sociais excelentes ainda pode ser um SCAM
- As redes sociais NÃO DEVEM ser fator de exclusão do token

## FORMATO DE RESPOSTA:

Você DEVE responder APENAS com um JSON válido, sem markdown, sem explicações antes ou depois:

{
  "score": <número 0-100>,
  "verdict": "<APROVADO|APROVADO_COM_RESSALVAS|NEUTRO|REPROVADO|PERIGOSO|SCAM_CONFIRMADO>",
  "tradeProfile": "<SCALP|SWING|HOLD|NAO_OPERAR>",
  "confidence": <número 0-100>,
  "summary": "<resumo executivo em 2-3 frases>",
  "aurionPlusStatus": "<PROMISING|WATCH|NEUTRAL>",
  "bundleAnalysis": {
    "bundleRetention": <% de retenção do Bundle 0-100>,
    "bundleHolding": <true/false - Diamond Hands>,
    "bundleSelling": <true/false - vendendo frações>,
    "washTrading": <true/false - comportamento de elevação artificial>,
    "detail": "<explicação da análise do Bundle>"
  },
  "devDNA": {
    "devPnlEstimated": <lucro atual do Dev em SOL>,
    "devGreedAverage": <média de ganância histórica em SOL>,
    "devClean": <true/false - histórico limpo>,
    "devRugRisk": "<LOW|MEDIUM|HIGH|CRITICAL>",
    "rugPullThreshold": <% do teto de rug atingido 0-100>,
    "detail": "<explicação do DNA do Dev>"
  },
  "windowAnalysis": {
    "ageMinutes": <idade em minutos>,
    "inWindow": <true/false - dentro de 30-90min>,
    "mcInRange": <true/false - MC entre $50k-$150k>,
    "breakoutImminent": <true/false - rompimento iminente>,
    "detail": "<explicação da janela operacional>"
  },
  "forensicAnalysis": {
    "mintAuthority": {
      "status": "<SAFE|WARNING|DANGER>",
      "detail": "<explicação>"
    },
    "freezeAuthority": {
      "status": "<SAFE|WARNING|DANGER>",
      "detail": "<explicação>"
    },
    "lpStatus": {
      "status": "<SAFE|WARNING|DANGER>",
      "detail": "<explicação>"
    },
    "creatorHistory": {
      "status": "<SAFE|WARNING|DANGER>",
      "detail": "<explicação>"
    },
    "liquidityAnalysis": {
      "status": "<SAFE|WARNING|DANGER>",
      "detail": "<explicação>"
    },
    "holderDistribution": {
      "status": "<SAFE|WARNING|DANGER>",
      "detail": "<explicação>"
    }
  },
  "socialAnalysis": {
    "socialScore": <número 0-100>,
    "socialRisk": "<LOW|MEDIUM|HIGH|CRITICAL>",
    "socialRiskReason": "<explicação do risco social>",
    "isInformativeOnly": true,
    "items": [
      {
        "network": "twitter",
        "status": "<VERIFIED|WARNING|NOT_FOUND>",
        "trust": "<HIGH|MEDIUM|LOW>",
        "url": "<url ou null>",
        "details": "<o que você observou sobre este link>"
      }
    ]
  },
  "technicalAnalysis": {
    "trend": "<BULLISH|BEARISH|NEUTRAL>",
    "strength": "<STRONG|MODERATE|WEAK>",
    "entryZone": "<GOOD|NEUTRAL|BAD>",
    "detail": "<análise técnica>"
  },
  "tradePlan": {
    "entry": "<preço ou zona de entrada sugerida>",
    "stopLoss": "<nível de stop sugerido>",
    "takeProfit1": "<primeiro alvo>",
    "takeProfit2": "<segundo alvo>",
    "timeframe": "<tempo estimado da operação>",
    "riskReward": "<proporção risco/retorno>"
  },
  "warnings": ["<lista de alertas importantes>"],
  "positives": ["<lista de pontos positivos>"],
  "finalRecommendation": "<recomendação final detalhada>"
}
`;

interface TokenData {
  symbol: string;
  name: string;
  address: string;
  chainId: string;
  pairAddress: string;
  price: number;
  priceChange24h: number;
  volume24h: number;
  liquidity: number;
  marketCap: number;
  fdv: number;
  pairCreatedAt?: number;
  // Dados de segurança se disponíveis
  securityScore?: number;
  mintAuthority?: string | null;
  freezeAuthority?: string | null;
  lpLocked?: boolean;
  // Indicadores técnicos se disponíveis
  chandelierExit?: { trend: string; price: number };
  adx?: { value: number; plusDI: number; minusDI: number };
  rsi?: number;
  // Dados adicionais
  topHolders?: Array<{ address: string; percentage: number }>;
  creatorAddress?: string;
  website?: string;
  twitter?: string;
}

async function fetchLiveTokenData(pairAddress: string, chainId: string): Promise<any> {
  try {
    const response = await fetch(`https://api.dexscreener.com/latest/dex/pairs/${chainId}/${pairAddress}`);
    if (!response.ok) return null;
    const data = await response.json();
    const pair = data.pair || null;
    
    if (!pair) return null;
    
    // Extract raw social data - NÃO calcular, apenas passar para a IA
    const socials = pair.info?.socials || [];
    const websites = pair.info?.websites || [];
    
    const twitterSocial = socials.find((s: any) => s.type === "twitter" || s.url?.includes("twitter.com") || s.url?.includes("x.com"));
    const telegramSocial = socials.find((s: any) => s.type === "telegram" || s.url?.includes("t.me") || s.url?.includes("telegram"));
    const discordSocial = socials.find((s: any) => s.type === "discord" || s.url?.includes("discord"));
    const websiteInfo = websites[0];

    // Apenas passar os links RAW para a IA avaliar
    pair.rawSocialData = {
      twitter: twitterSocial?.url || null,
      website: websiteInfo?.url || null,
      telegram: telegramSocial?.url || null,
      discord: discordSocial?.url || null,
    };
    
    console.log(`📱 Raw social data extracted: Twitter=${!!twitterSocial?.url} | Website=${!!websiteInfo?.url} | Telegram=${!!telegramSocial?.url} | Discord=${!!discordSocial?.url}`);
    
    return pair;
  } catch (error) {
    console.error("Error fetching live token data:", error);
    return null;
  }
}

async function fetchRugCheckData(tokenAddress: string): Promise<any> {
  try {
    const response = await fetch(`https://api.rugcheck.xyz/v1/tokens/${tokenAddress}/report/summary`);
    if (!response.ok) return null;
    return await response.json();
  } catch (error) {
    console.error("Error fetching RugCheck data:", error);
    return null;
  }
}

// Buscar contexto de estratégia do usuário das conversas do chat
// O CHAT É O CÉREBRO DA IA - todas as mensagens do usuário são usadas como contexto
async function fetchUserStrategyContext(userId: string, conversationId?: string): Promise<{
  hasInstructions: boolean;
  instructions: string;
  recentMessages: Array<{ role: string; content: string }>;
}> {
  console.log(`[fetchUserStrategyContext] START - userId: ${userId}, conversationId: ${conversationId}`);
  
  if (!userId) {
    console.log("[fetchUserStrategyContext] No userId provided, returning empty");
    return { hasInstructions: false, instructions: "", recentMessages: [] };
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      console.error("[fetchUserStrategyContext] CRITICAL: Supabase credentials not available!");
      return { hasInstructions: false, instructions: "", recentMessages: [] };
    }

    const authHeaders = {
      "apikey": SUPABASE_SERVICE_ROLE_KEY,
      "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
      "Content-Type": "application/json",
    };

    // Buscar a conversa ativa ou a mais recente
    let targetConversationId = conversationId;

    if (!targetConversationId) {
      console.log(`[fetchUserStrategyContext] No conversationId, fetching most recent for userId: ${userId}`);
      const convResponse = await fetch(
        `${SUPABASE_URL}/rest/v1/aurion_ai_conversations?user_id=eq.${userId}&order=updated_at.desc&limit=1`,
        { headers: authHeaders }
      );

      if (convResponse.ok) {
        const conversations = await convResponse.json();
        console.log(`[fetchUserStrategyContext] Found ${conversations.length} conversations`);
        if (conversations.length > 0) {
          targetConversationId = conversations[0].id;
          console.log(`[fetchUserStrategyContext] Using conversation: ${targetConversationId}`);
        }
      } else {
        console.error(`[fetchUserStrategyContext] Failed to fetch conversations: ${convResponse.status}`);
      }
    }

    if (!targetConversationId) {
      console.log("[fetchUserStrategyContext] No conversation found, returning empty");
      return { hasInstructions: false, instructions: "", recentMessages: [] };
    }

    // BUSCAR TODAS AS MENSAGENS DO CHAT - ISSO É O CÉREBRO DA IA
    console.log(`[fetchUserStrategyContext] Fetching ALL messages for conversation: ${targetConversationId}`);

    const messagesResponse = await fetch(
      `${SUPABASE_URL}/rest/v1/aurion_ai_messages?conversation_id=eq.${targetConversationId}&order=created_at.asc&limit=200`,
      { headers: authHeaders }
    );

    if (!messagesResponse.ok) {
      console.error(`[fetchUserStrategyContext] Failed to fetch messages: ${messagesResponse.status}`);
      return { hasInstructions: false, instructions: "", recentMessages: [] };
    }

    const messages = await messagesResponse.json();
    console.log(`[fetchUserStrategyContext] SUCCESS: Fetched ${messages.length} messages from chat`);

    if (messages.length === 0) {
      console.log("[fetchUserStrategyContext] No messages found in conversation");
      return { hasInstructions: false, instructions: "", recentMessages: [] };
    }

    // Extrair todas as mensagens do usuário - essas são as COORDENADAS/INSTRUÇÕES
    const userMessages = messages
      .filter((m: any) => m.role === "user")
      .map((m: any) => {
        if (typeof m.content === "string") {
          return m.content;
        } else if (Array.isArray(m.content)) {
          return m.content
            .filter((part: any) => part.type === "text")
            .map((part: any) => part.text)
            .join(" ");
        }
        return "";
      })
      .filter((msg: string) => msg.length > 0);

    console.log(`[fetchUserStrategyContext] Extracted ${userMessages.length} user messages as instructions`);

    // Montar contexto completo: todas as mensagens do usuário são o "cérebro"
    let instructionsText = "";
    
    if (userMessages.length > 0) {
      instructionsText = `
## 🧠 CÉREBRO DO AURION AI - INSTRUÇÕES DO USUÁRIO (PRIORIDADE MÁXIMA ABSOLUTA)

O usuário conversou com você no chat Aurion AI e definiu as seguintes diretrizes, regras e padrões de operação.
Você DEVE seguir TODAS essas instruções OBRIGATORIAMENTE ao analisar qualquer token:

${userMessages.map((instr: string, i: number) => `### Instrução ${i + 1}:
"${instr}"
`).join("\n")}

---

## REGRAS DE OURO - VOCÊ DEVE OBEDECER:

1. **PRIORIDADE MÁXIMA**: As instruções acima têm precedência TOTAL sobre o Guia Forense padrão.
2. **FOCO DO USUÁRIO**: O usuário definiu em qual mercado/tipo de tokens focar - siga exatamente.
3. **CRITÉRIOS PERSONALIZADOS**: Se o usuário mencionou liquidez mínima, volume, score, etc. - use ESSES valores.
4. **ESTILO DE ANÁLISE**: Se o usuário pediu análises mais agressivas ou conservadoras - ajuste seu comportamento.
5. **PROIBIÇÕES**: Se o usuário disse para NUNCA recomendar algo - você NÃO pode recomendar.
6. **APRENDIZADO**: Trate essas mensagens como seu treinamento - o usuário está te ensinando seu estilo.
7. **CONFLITOS**: Em caso de conflito entre instruções, a MAIS RECENTE (última) prevalece.

O usuário te alimentou com ${userMessages.length} mensagens de treinamento. Use esse conhecimento!
`;
    }

    // Contexto das últimas mensagens para continuidade da conversa
    const recentMessages = messages.slice(-30).map((m: any) => ({
      role: m.role,
      content: typeof m.content === "string" ? m.content : JSON.stringify(m.content),
    }));

    console.log(`[fetchUserStrategyContext] COMPLETE - hasInstructions: true, userMessages: ${userMessages.length}`);

    return {
      hasInstructions: userMessages.length > 0,
      instructions: instructionsText,
      recentMessages,
    };

  } catch (error) {
    console.error("[fetchUserStrategyContext] EXCEPTION:", error);
    return { hasInstructions: false, instructions: "", recentMessages: [] };
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { token, userId, conversationId } = await req.json();
    
    console.log(`[aurion-full-analysis] Received request - userId: ${userId}, conversationId: ${conversationId}`);
    
    if (!token) {
      return new Response(
        JSON.stringify({ error: "Token data is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Use GEMINI_API_KEY directly instead of Lovable AI Gateway
    const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY");
    if (!GEMINI_API_KEY) {
      return new Response(
        JSON.stringify({ error: "GEMINI_API_KEY not configured. Please set it in your environment variables." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Buscar dados ao vivo do token
    let liveData = null;
    if (token.pairAddress && token.chainId) {
      liveData = await fetchLiveTokenData(token.pairAddress, token.chainId);
    }

    // Buscar dados de segurança do RugCheck
    let rugCheckData = null;
    if (token.address) {
      rugCheckData = await fetchRugCheckData(token.address);
    }

    // Preparar contexto completo para a IA
    const tokenContext = {
      basicInfo: {
        symbol: token.symbol,
        name: token.name,
        address: token.address,
        chainId: token.chainId,
        pairAddress: token.pairAddress,
      },
      marketData: {
        price: liveData?.priceUsd || token.price,
        priceChange24h: liveData?.priceChange?.h24 || token.priceChange24h,
        volume24h: liveData?.volume?.h24 || token.volume24h,
        liquidity: liveData?.liquidity?.usd || token.liquidity,
        marketCap: liveData?.marketCap || token.marketCap,
        fdv: liveData?.fdv || token.fdv,
        pairCreatedAt: liveData?.pairCreatedAt || token.pairCreatedAt,
      },
      securityData: {
        rugCheckScore: rugCheckData?.score,
        risks: rugCheckData?.risks || [],
        mintAuthority: token.mintAuthority,
        freezeAuthority: token.freezeAuthority,
        lpLocked: token.lpLocked,
      },
      technicalIndicators: {
        chandelierExit: token.chandelierExit,
        adx: token.adx,
        rsi: token.rsi,
      },
      additionalInfo: {
        topHolders: token.topHolders,
        creatorAddress: token.creatorAddress,
        website: token.website,
        twitter: token.twitter,
      }
    };

    // Calcular idade do token
    let tokenAge = "Desconhecido";
    if (tokenContext.marketData.pairCreatedAt) {
      const ageMs = Date.now() - tokenContext.marketData.pairCreatedAt;
      const hours = Math.floor(ageMs / (1000 * 60 * 60));
      const days = Math.floor(hours / 24);
      if (days > 0) {
        tokenAge = `${days} dia(s)`;
      } else if (hours > 0) {
        tokenAge = `${hours} hora(s)`;
      } else {
        tokenAge = `${Math.floor(ageMs / (1000 * 60))} minuto(s)`;
      }
    }

    // Buscar contexto de estratégia do usuário do chat
    const strategyContext = await fetchUserStrategyContext(userId, conversationId);
    
    console.log(`User strategy context: hasInstructions=${strategyContext.hasInstructions}`);

    // Extrair dados brutos da Helius se disponíveis (Aurion Plus analysis)
    const heliusRawData = token.heliusRawData || null;
    const pumpFunContext = token.pumpFunContext || null;
    const isAurionPlusAnalysis = pumpFunContext?.isAurionPlusAnalysis || false;

    // Construir seção de dados brutos da Helius para a IA analisar
    let heliusDataSection = "";
    if (heliusRawData) {
      heliusDataSection = `

## 🔬 DADOS BRUTOS DA HELIUS (BLOCO 0 E DNA DO DEV) - ANALISE COM CUIDADO

**IMPORTANTE**: Estes são dados BRUTOS coletados diretamente da blockchain Solana via Helius RPC.
Você deve ANALISAR estes dados para determinar:
1. Se houve Bundle no lançamento (compras coordenadas no Bloco 0)
2. Se o Bundle está segurando ou vendendo
3. O histórico do Dev (DNA do Dev) e risco de rug pull
4. A janela operacional (30-90 minutos é ideal)

### Dados do Bloco 0 (Lançamento do Token):
- Slot de Criação: ${heliusRawData.block0?.creationSlot || "Não disponível"}
- Data/Hora de Criação: ${heliusRawData.block0?.creationTime || "Não disponível"}
- Carteiras no Bloco 0: ${heliusRawData.block0?.wallets?.length || 0}
- Lista de Carteiras: ${JSON.stringify(heliusRawData.block0?.wallets?.slice(0, 10) || [])}
- Transações no Bloco 0: ${heliusRawData.block0?.transactionCount || 0}

### Top Holders Atuais:
- Total de Holders: ${heliusRawData.holders?.count || 0}
- Top 10 Holders: ${JSON.stringify(heliusRawData.holders?.topAccounts?.slice(0, 10) || [])}

### Histórico do Dev (DNA):
${heliusRawData.devWallet ? `
- Endereço do Dev: ${heliusRawData.devWallet.address}
- Total de Transações: ${heliusRawData.devWallet.transactionCount}
- Transações Recentes: ${JSON.stringify(heliusRawData.devWallet.transactions?.slice(0, 10) || [])}
` : "- Dev wallet não identificada"}

### Contexto Pump.fun:
- Idade do Token: ${pumpFunContext?.ageMinutes || 0} minutos
- Contagem de Holders: ${pumpFunContext?.holdersCount || 0}
- É Análise Aurion Plus: ${isAurionPlusAnalysis ? "SIM - Aplique critérios rigorosos" : "NÃO"}
`;
    }

    const userPrompt = `
${strategyContext.instructions}

Analise este token Solana com base no Guia Forense Aurion:

## DADOS DO TOKEN:

**Informações Básicas:**
- Símbolo: ${tokenContext.basicInfo.symbol}
- Nome: ${tokenContext.basicInfo.name}
- Endereço: ${tokenContext.basicInfo.address}
- Chain: ${tokenContext.basicInfo.chainId}
- Idade: ${tokenAge}

**Dados de Mercado:**
- Preço: $${tokenContext.marketData.price}
- Variação 24h: ${tokenContext.marketData.priceChange24h}%
- Volume 24h: $${tokenContext.marketData.volume24h}
- Liquidez: $${tokenContext.marketData.liquidity}
- Market Cap: $${tokenContext.marketData.marketCap}
- FDV: $${tokenContext.marketData.fdv}

**Dados de Segurança (RugCheck):**
- Score RugCheck: ${tokenContext.securityData.rugCheckScore || "Não disponível"}
- Riscos identificados: ${JSON.stringify(tokenContext.securityData.risks)}
- Mint Authority: ${tokenContext.securityData.mintAuthority === null ? "REVOGADA (SEGURO)" : tokenContext.securityData.mintAuthority || "Desconhecido"}
- Freeze Authority: ${tokenContext.securityData.freezeAuthority === null ? "REVOGADA (SEGURO)" : tokenContext.securityData.freezeAuthority || "Desconhecido"}
- LP Bloqueada: ${tokenContext.securityData.lpLocked ? "SIM" : "NÃO ou Desconhecido"}
${heliusDataSection}
**Indicadores Técnicos:**
- Chandelier Exit: ${tokenContext.technicalIndicators.chandelierExit ? JSON.stringify(tokenContext.technicalIndicators.chandelierExit) : "Não disponível"}
- ADX: ${tokenContext.technicalIndicators.adx ? JSON.stringify(tokenContext.technicalIndicators.adx) : "Não disponível"}
- RSI: ${tokenContext.technicalIndicators.rsi || "Não disponível"}

**Informações Adicionais:**
- Website: ${tokenContext.additionalInfo.website || "Não informado"}
- Twitter: ${tokenContext.additionalInfo.twitter || "Não informado"}

**LINKS DE REDES SOCIAIS (AVALIE A CONFIABILIDADE - APENAS INFORMATIVO):**
- Twitter: ${liveData?.rawSocialData?.twitter || "NÃO FORNECIDO"}
- Website: ${liveData?.rawSocialData?.website || "NÃO FORNECIDO"}
- Telegram: ${liveData?.rawSocialData?.telegram || "NÃO FORNECIDO"}
- Discord: ${liveData?.rawSocialData?.discord || "NÃO FORNECIDO"}

${isAurionPlusAnalysis ? `
## 🎯 ANÁLISE AURION PLUS - APLIQUE A ESTRATÉGIA COMPLETA

Esta é uma análise AURION PLUS. Você DEVE:
1. Analisar os dados do Bloco 0 para detectar Bundles
2. Calcular retenção do Bundle (quantas carteiras ainda seguram)
3. Analisar DNA do Dev (histórico de transações)
4. Determinar o status: PROMISING (verde), WATCH (amarelo) ou NEUTRAL

**Critérios para PROMISING (borda verde):**
- Bundle segurando >70% da posição original
- Dev com histórico limpo (sem rugs anteriores)
- Market Cap entre $50k-$150k
- Idade entre 30-90 minutos
- Sem wash trading detectado

**Critérios para WATCH (borda amarela):**
- Bundle vendendo frações mas ainda presente
- Volume lateralizando
- Dev com 1-2 tokens anteriores (sem rugs)
- Fora da janela ideal mas seguro

**NEUTRAL (sem borda especial):**
- Não atende aos critérios acima
` : ""}

IMPORTANTE: Avalie os links sociais e determine se parecem legítimos. Essa análise é APENAS INFORMATIVA e NÃO deve excluir o token de oportunidades de trade.

Com base em TODOS esses dados, no Guia Forense Aurion, e nas INSTRUÇÕES DO USUÁRIO (se houver), forneça sua análise completa no formato JSON especificado.
Você tem AUTONOMIA TOTAL para definir o Score, Veredito e todas as recomendações baseado nos dados brutos, MAS DEVE respeitar as instruções específicas do usuário.
`;

    // Call Gemini API directly instead of Lovable AI Gateway
    const geminiMessages = [
      { role: "user", parts: [{ text: FORENSIC_GUIDE }] },
      { role: "model", parts: [{ text: "Entendido. Vou analisar tokens seguindo o Guia Forense Aurion e responder apenas com JSON válido." }] },
      { role: "user", parts: [{ text: userPrompt }] }
    ];

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: geminiMessages,
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 2000,
          },
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Gemini API error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      return new Response(
        JSON.stringify({ error: "AI analysis failed", details: errorText }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const aiResponse = await response.json();
    const aiContent = aiResponse.candidates?.[0]?.content?.parts?.[0]?.text || "";

    // Extrair JSON da resposta
    let analysisResult;
    try {
      // Tentar extrair JSON diretamente ou de dentro de blocos de código
      let jsonStr = aiContent;
      const jsonMatch = aiContent.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (jsonMatch) {
        jsonStr = jsonMatch[1].trim();
      }
      // Limpar possíveis caracteres extras
      jsonStr = jsonStr.replace(/^[^{]*/, '').replace(/[^}]*$/, '');
      analysisResult = JSON.parse(jsonStr);
    } catch (parseError) {
      console.error("Failed to parse AI response:", parseError);
      console.log("Raw AI content:", aiContent);
      
      // Fallback: criar resposta padrão se parsing falhar
      analysisResult = {
        score: 50,
        verdict: "NEUTRO",
        tradeProfile: "NAO_OPERAR",
        confidence: 30,
        summary: "Não foi possível completar a análise automaticamente. Por favor, revise os dados manualmente.",
        forensicAnalysis: {
          mintAuthority: { status: "WARNING", detail: "Análise incompleta" },
          freezeAuthority: { status: "WARNING", detail: "Análise incompleta" },
          lpStatus: { status: "WARNING", detail: "Análise incompleta" },
          creatorHistory: { status: "WARNING", detail: "Análise incompleta" },
          liquidityAnalysis: { status: "WARNING", detail: "Análise incompleta" },
          holderDistribution: { status: "WARNING", detail: "Análise incompleta" },
          socialAnalysis: liveData?.socialAnalysis || null,
        },
        technicalAnalysis: {
          trend: "NEUTRAL",
          strength: "WEAK",
          entryZone: "NEUTRAL",
          detail: "Dados insuficientes para análise técnica",
        },
        tradePlan: null,
        warnings: ["Análise automática falhou - revise manualmente"],
        positives: [],
        finalRecommendation: "Dados insuficientes para uma recomendação segura.",
        rawAiResponse: aiContent,
      };
    }

    // A socialAnalysis agora vem diretamente da IA no analysisResult
    // Garantir que está marcada como informativa
    if (analysisResult.socialAnalysis) {
      analysisResult.socialAnalysis.isInformativeOnly = true;
    }
    
    const finalResult = {
      ...analysisResult,
      analyzedAt: new Date().toISOString(),
      tokenInfo: {
        symbol: tokenContext.basicInfo.symbol,
        name: tokenContext.basicInfo.name,
        address: tokenContext.basicInfo.address,
        price: tokenContext.marketData.price,
        liquidity: tokenContext.marketData.liquidity,
        volume24h: tokenContext.marketData.volume24h,
        priceChange24h: tokenContext.marketData.priceChange24h,
        age: tokenAge,
      },
      dataSource: {
        dexscreener: !!liveData,
        rugcheck: !!rugCheckData,
        userInstructions: strategyContext.hasInstructions,
      }
    };

    return new Response(
      JSON.stringify(finalResult),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error in aurion-full-analysis:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
