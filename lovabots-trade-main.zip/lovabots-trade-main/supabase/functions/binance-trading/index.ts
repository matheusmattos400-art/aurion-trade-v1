import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

interface BinanceCredentials {
  api_key: string;
  api_secret: string;
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// 🔐 Gera assinatura HMAC para autenticar na Binance
async function createSignature(queryString: string, secret: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(queryString);
  const keyData = encoder.encode(secret);

  const cryptoKey = await crypto.subtle.importKey("raw", keyData, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);

  const signature = await crypto.subtle.sign("HMAC", cryptoKey, data);
  return Array.from(new Uint8Array(signature))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

// 🔍 Obter informações de precisão de um símbolo
async function getSymbolPrecision(symbol: string): Promise<number> {
  try {
    const response = await fetch(`https://fapi.binance.com/fapi/v1/exchangeInfo`);
    const data = await response.json();
    const symbolInfo = data.symbols.find((s: any) => s.symbol === symbol);
    
    if (!symbolInfo) {
      console.warn(`⚠️ Símbolo ${symbol} não encontrado, usando precisão padrão 3`);
      return 3;
    }
    
    // Buscar precisão da quantidade nos filtros LOT_SIZE
    const lotSizeFilter = symbolInfo.filters.find((f: any) => f.filterType === 'LOT_SIZE');
    if (lotSizeFilter) {
      const stepSize = parseFloat(lotSizeFilter.stepSize);
      const precision = Math.abs(Math.log10(stepSize));
      console.log(`📏 Precisão para ${symbol}: ${precision} decimais (stepSize: ${stepSize})`);
      return Math.floor(precision);
    }
    
    console.warn(`⚠️ Filtro LOT_SIZE não encontrado para ${symbol}, usando precisão padrão 3`);
    return 3;
  } catch (error) {
    console.error(`❌ Erro ao buscar precisão para ${symbol}:`, error);
    return 3; // Fallback
  }
}

// 🔢 Arredondar quantidade para a precisão correta
function roundToPrecision(value: number, precision: number): string {
  return value.toFixed(precision);
}

// 📡 Função para chamar a Binance Futures API
// - Se PROXY_URL estiver configurado, roteia via proxy com IP fixo (recomendado)
// - Caso contrário, tenta conexão direta (pode falhar se sua API key estiver com restrição de IP)
async function binanceRequest(
  endpoint: string,
  method: string,
  credentials: BinanceCredentials,
  params: Record<string, string> = {},
) {
  const timestamp = Date.now().toString();
  const queryParams = {
    ...params,
    timestamp,
    recvWindow: "60000",
  };
  const queryString = new URLSearchParams(queryParams).toString();
  const signature = await createSignature(queryString, credentials.api_secret);
  const finalQuery = `${queryString}&signature=${signature}`;

  const rawProxyUrl = Deno.env.get("PROXY_URL");

  // ⚠️ Edge Runtime (Deno fetch) não suporta socks5:// diretamente.
  // Se estiver em socks5://, ignoramos silenciosamente e tentamos conexão direta.
  // Para IP fixo, use um proxy HTTP→SOCKS5 e aponte PROXY_URL para http(s)://<ip>:3000
  let proxyUrl: string | null = null;
  if (rawProxyUrl) {
    if (rawProxyUrl.startsWith("http://") || rawProxyUrl.startsWith("https://")) {
      proxyUrl = rawProxyUrl;
    } else if (rawProxyUrl.startsWith("socks5://")) {
      console.warn("⚠️ PROXY_URL está em socks5:// (não suportado por Deno). Tentando conexão direta...");
      // Continua sem proxy - não lança erro
    }
  }
  
  const baseUrl = "https://fapi.binance.com";
  const directUrl = `${baseUrl}${endpoint}?${finalQuery}`;

  console.log("🔍 Request details:", {
    endpoint,
    method,
    usingProxy: !!proxyUrl,
    proxySkipped: rawProxyUrl && !proxyUrl ? "socks5 not supported" : null,
    queryLength: finalQuery.length,
    apiKeyPrefix: credentials.api_key.substring(0, 8) + "...",
  });

  // Helper to parse JSON safely
  const parseJsonSafe = async (resp: Response) => {
    const text = await resp.text();
    try {
      return { ok: true, json: JSON.parse(text), raw: text };
    } catch {
      return { ok: false, json: null as any, raw: text };
    }
  };

  try {
    // ✅ Prefer proxy if configured
    const response = proxyUrl
      ? await fetch(proxyUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Target-Endpoint": endpoint,
            "X-Target-Method": method,
            "X-Target-Query": finalQuery,
            "X-API-Key": credentials.api_key,
          },
          // O proxy HTTP encaminha tudo via querystring assinada; body não é necessário
          body: "",
        })
      : await fetch(directUrl, {
          method,
          headers: {
            "X-MBX-APIKEY": credentials.api_key,
            "Content-Type": "application/json",
          },
        });

    const parsed = await parseJsonSafe(response);
    const data = parsed.ok ? parsed.json : { msg: parsed.raw };

    if (!response.ok) {
      const msg = String((data as any)?.msg || `Erro HTTP ${response.status}`);
      const code = (data as any)?.code;

      console.error("❌ Erro da Binance API:", {
        status: response.status,
        code,
        msg,
        endpoint,
        usingProxy: !!proxyUrl,
        bodyPreview: parsed.raw?.substring?.(0, 300),
      });

      // -2015: Invalid API-key, IP, or permissions for action
      if (code === -2015 || msg.includes("Invalid API-key") || msg.includes("permissions")) {
        throw new Error(`BINANCE_AUTH_ERROR: ${msg}`);
      }

      throw new Error(msg);
    }

    console.log("✅ Requisição concluída com sucesso!", { usingProxy: !!proxyUrl });
    return data;
  } catch (error) {
    console.error("❌ Erro na requisição:", {
      error: error instanceof Error ? error.message : "Erro desconhecido",
      stack: error instanceof Error ? error.stack : undefined,
    });
    throw error;
  }
}

serve(async (req) => {
  // Permite requisições OPTIONS (CORS)
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // 🛑 BINANCE PAUSADO - Retornar erro amigável sem tentar chamar a API
  // Para reativar, remova este bloco e ajuste a API Key para "Unrestricted" na Binance
  const BINANCE_PAUSED = true;
  if (BINANCE_PAUSED) {
    const pausedMessage = "Binance temporariamente pausada. Configure sua API Key como 'Unrestricted' (sem restrição de IP) na Binance ou use proxy HTTP com IP fixo.";
    console.log("⏸️ Binance PAUSADA - retornando erro amigável");
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: pausedMessage,
        paused: true,
        details: {
          message: pausedMessage,
          howToFix: [
            "1. Acesse sua conta Binance → API Management",
            "2. Encontre sua API Key e clique em 'Edit restrictions'",
            "3. Em 'IP access restrictions', selecione 'Unrestricted'",
            "4. Salve as alterações",
            "5. Aguarde alguns minutos para a mudança propagar"
          ]
        }
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 503 }
    );
  }

  try {
    const { action, symbol, side, leverage, quantity, symbols, listenKey, orderId, price } = await req.json();
    console.log('🧪 Ação recebida:', action);

    const VALID_ACTIONS = ["set_leverage", "create_order", "create_limit_order", "close_position", "close_position_limit", "get_position", "get_account", "get_prices", "get_funding_rates", "get_positions", "create_listen_key", "keepalive_listen_key", "check_order_status", "cancel_order"];
    if (!VALID_ACTIONS.includes(action)) {
      throw new Error(`Ação inválida: ${action}`);
    }

    const apiKey = Deno.env.get("BINANCE_API_KEY");
    const apiSecret = Deno.env.get("BINANCE_API_SECRET");

    console.log('🔑 Verificando credenciais...');
    console.log('API Key presente:', !!apiKey);
    console.log('API Secret presente:', !!apiSecret);
    console.log('API Key length:', apiKey?.length || 0);
    console.log('API Secret length:', apiSecret?.length || 0);
    console.log('API Key primeiros 8 chars:', apiKey?.substring(0, 8));

    if (!apiKey || !apiSecret) {
      throw new Error("Credenciais Binance não configuradas no Cloud.");
    }

    // Validação de formato
    if (apiKey.length < 20 || apiSecret.length < 20) {
      throw new Error('Formato das credenciais inválido. Verifique se copiou as chaves completas.');
    }

    const credentials: BinanceCredentials = {
      api_key: apiKey,
      api_secret: apiSecret,
    };

    let result;

    switch (action) {
      case "set_leverage":
        console.log('🔧 Configurando alavancagem:', { symbol, leverage });
        result = await binanceRequest("/fapi/v1/leverage", "POST", credentials, {
          symbol,
          leverage: leverage.toString(),
        });
        console.log('✅ Alavancagem configurada:', result);
        break;

      case "create_order": {
        console.log('📝 Criando ordem:', { symbol, side, quantity });
        
        // Buscar preço atual para validar valor nocional
        const tickerResponse = await fetch(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${symbol}`);
        if (!tickerResponse.ok) {
          throw new Error(`Erro ao buscar preço do símbolo ${symbol}`);
        }
        const tickerData = await tickerResponse.json();
        const currentPrice = parseFloat(tickerData.price);
        
        // Obter precisão do símbolo e arredondar quantidade
        const precision = await getSymbolPrecision(symbol);
        const roundedQuantity = roundToPrecision(parseFloat(quantity), precision);
        
        // Calcular valor nocional
        const notionalValue = parseFloat(roundedQuantity) * currentPrice;
        const MIN_NOTIONAL = 100;
        
        console.log('🔢 Validação da ordem:', {
          symbol,
          original: quantity,
          rounded: roundedQuantity,
          precision,
          currentPrice,
          notionalValue,
          minRequired: MIN_NOTIONAL,
          isValid: notionalValue >= MIN_NOTIONAL
        });
        
        // Validar valor nocional mínimo
        if (notionalValue < MIN_NOTIONAL) {
          const minQuantityRequired = (MIN_NOTIONAL / currentPrice).toFixed(precision);
          throw new Error(
            `Valor nocional muito baixo (${notionalValue.toFixed(2)} USDT). ` +
            `Mínimo exigido: ${MIN_NOTIONAL} USDT. ` +
            `Quantidade mínima para ${symbol}: ${minQuantityRequired}`
          );
        }
        
        result = await binanceRequest("/fapi/v1/order", "POST", credentials, {
          symbol,
          side: side.toUpperCase(),
          type: "MARKET",
          quantity: roundedQuantity,
        });
        console.log('✅ Ordem criada:', result);
        break;
      }

      // 🎯 NOVA AÇÃO: Criar ordem LIMIT no preço de entrada (break-even)
      case "create_limit_order": {
        console.log('🎯 Criando ordem LIMIT:', { symbol, side, price, quantity });

        if (!symbol || !side || price === undefined || quantity === undefined) {
          throw new Error("Parâmetros obrigatórios: symbol, side, price, quantity");
        }

        const sideUpper = String(side).toUpperCase();
        if (sideUpper !== "BUY" && sideUpper !== "SELL") {
          throw new Error(`Side inválido: ${side}`);
        }

        // Normalizar inputs (aceitar vírgula)
        const priceNum = typeof price === "string"
          ? Number(price.replace(/\s+/g, "").replace(/,/g, "."))
          : Number(price);
        const qtyNum = typeof quantity === "string"
          ? Number(quantity.replace(/\s+/g, "").replace(/,/g, "."))
          : Number(quantity);

        if (!Number.isFinite(priceNum) || priceNum <= 0) {
          throw new Error("Preço inválido");
        }

        if (!Number.isFinite(qtyNum) || qtyNum <= 0) {
          throw new Error("Quantidade inválida");
        }

        // Proteção: impedir ordem LIMIT que executaria imediatamente (vira 'a mercado')
        // (BUY com preço >= mark) ou (SELL com preço <= mark)
        const premiumResp = await fetch(`https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${symbol}`);
        if (!premiumResp.ok) {
          throw new Error(`Falha ao buscar markPrice (${premiumResp.status})`);
        }
        const premiumData = await premiumResp.json();
        const markPrice = Number(premiumData?.markPrice);
        if (!Number.isFinite(markPrice) || markPrice <= 0) {
          throw new Error("Não foi possível validar o preço atual (markPrice)");
        }

        // Obter precisão do símbolo
        const quantityPrecision = await getSymbolPrecision(symbol);
        const roundedQuantity = roundToPrecision(qtyNum, quantityPrecision);

        // Obter precisão de preço do símbolo
        const exchangeInfoResponse = await fetch(`https://fapi.binance.com/fapi/v1/exchangeInfo`);
        const exchangeInfo = await exchangeInfoResponse.json();
        const symbolInfo = exchangeInfo.symbols.find((s: any) => s.symbol === symbol);
        const priceFilter = symbolInfo?.filters?.find((f: any) => f.filterType === 'PRICE_FILTER');
        const tickSize = parseFloat(priceFilter?.tickSize || '0.01');
        const pricePrecision = Math.abs(Math.log10(tickSize));

        // Arredondar preço para a precisão correta
        const roundedPrice = (Math.round(priceNum / tickSize) * tickSize).toFixed(Math.floor(pricePrecision));
        const roundedPriceNum = Number(roundedPrice);

        const wouldFillImmediately = sideUpper === "SELL"
          ? roundedPriceNum <= markPrice
          : roundedPriceNum >= markPrice;

        console.log('🛡️ Validação anti-mercado:', {
          symbol,
          side: sideUpper,
          markPrice,
          requestedPrice: priceNum,
          roundedPrice,
          wouldFillImmediately,
        });

        if (wouldFillImmediately) {
          throw new Error(
            `Preço limite (${roundedPrice}) cruza o preço atual (${markPrice}). Ajuste o preço para não executar imediatamente.`
          );
        }

        console.log('📊 Ordem LIMIT detalhes:', {
          symbol,
          side: sideUpper,
          quantity: roundedQuantity,
          price: roundedPrice,
          type: 'LIMIT',
          timeInForce: 'GTC',
          reduceOnly: true,
        });

        result = await binanceRequest("/fapi/v1/order", "POST", credentials, {
          symbol,
          side: sideUpper,
          type: "LIMIT",
          quantity: roundedQuantity,
          price: roundedPrice,
          timeInForce: "GTC", // Good Till Cancelled - ordem fica ativa até ser executada ou cancelada
          reduceOnly: "true", // Garante que só fecha posições existentes
        });

        // Garantia extra: se por algum motivo vier diferente de LIMIT, falhar
        if (result?.type && String(result.type).toUpperCase() !== "LIMIT") {
          console.error('❌ Tipo de ordem inesperado:', result?.type);
          throw new Error('Ordem retornou tipo inesperado. Operação cancelada por segurança.');
        }

        console.log('✅ Ordem LIMIT criada:', result);
        break;
      }

      case "close_position": {
        const positions = await binanceRequest("/fapi/v2/positionRisk", "GET", credentials);
        const position = positions.find((p: any) => p.symbol === symbol);

        if (!position || parseFloat(position.positionAmt) === 0) {
          console.log('⚠️ Nenhuma posição encontrada para fechar:', { symbol, positionAmt: position?.positionAmt });
          throw new Error("Nenhuma posição aberta encontrada para esse símbolo.");
        }

        const closeSide = parseFloat(position.positionAmt) > 0 ? "SELL" : "BUY";
        const positionAmt = Math.abs(parseFloat(position.positionAmt));
        
        // Obter precisão do símbolo e arredondar quantidade
        const precision = await getSymbolPrecision(symbol);
        const roundedQuantity = roundToPrecision(positionAmt, precision);
        
        console.log('🔢 Fechando posição com quantidade ajustada:', {
          symbol,
          side: closeSide,
          original: positionAmt,
          rounded: roundedQuantity,
          precision,
          reduceOnly: true
        });

        result = await binanceRequest("/fapi/v1/order", "POST", credentials, {
          symbol,
          side: closeSide,
          type: "MARKET",
          quantity: roundedQuantity,
          reduceOnly: "true", // 🎯 CRÍTICO: Garante que só fecha posições existentes
        });
        break;
      }
      
      // 📊 NOVA AÇÃO: Fechar posição com ordem LIMIT (apregoar)
      case "close_position_limit": {
        console.log('📊 Criando ordem LIMIT para fechar posição:', symbol);
        
        const positions = await binanceRequest("/fapi/v2/positionRisk", "GET", credentials);
        const position = positions.find((p: any) => p.symbol === symbol);

        if (!position || parseFloat(position.positionAmt) === 0) {
          console.log('⚠️ Nenhuma posição encontrada para fechar:', { symbol, positionAmt: position?.positionAmt });
          throw new Error("Nenhuma posição aberta encontrada para esse símbolo.");
        }

        const positionAmt = parseFloat(position.positionAmt);
        const closeSide = positionAmt > 0 ? "SELL" : "BUY";
        const absPositionAmt = Math.abs(positionAmt);
        const entryPrice = parseFloat(position.entryPrice);
        const markPrice = parseFloat(position.markPrice);
        
        // Obter precisão do símbolo
        const precision = await getSymbolPrecision(symbol);
        const roundedQuantity = roundToPrecision(absPositionAmt, precision);
        
        // Obter precisão de preço do símbolo
        const exchangeInfoResponse = await fetch(`https://fapi.binance.com/fapi/v1/exchangeInfo`);
        const exchangeInfo = await exchangeInfoResponse.json();
        const symbolInfo = exchangeInfo.symbols.find((s: any) => s.symbol === symbol);
        const priceFilter = symbolInfo?.filters?.find((f: any) => f.filterType === 'PRICE_FILTER');
        const tickSize = parseFloat(priceFilter?.tickSize || '0.01');
        const pricePrecision = Math.abs(Math.log10(tickSize));
        
        // Calcular preço de fechamento otimizado
        // Para LONG (venda): preço ligeiramente acima do mark price
        // Para SHORT (compra): preço ligeiramente abaixo do mark price
        let limitPrice: number;
        
        if (closeSide === "SELL") {
          // Vendendo LONG: preço = mark price + 0.01% (apregoar logo acima)
          limitPrice = markPrice * 1.0001;
        } else {
          // Comprando SHORT: preço = mark price - 0.01% (apregoar logo abaixo)
          limitPrice = markPrice * 0.9999;
        }
        
        // Arredondar para a precisão correta
        const roundedPrice = (Math.round(limitPrice / tickSize) * tickSize).toFixed(Math.floor(pricePrecision));
        
        console.log('📊 Ordem LIMIT para fechar:', {
          symbol,
          side: closeSide,
          quantity: roundedQuantity,
          price: roundedPrice,
          markPrice,
          entryPrice,
          pricePrecision: Math.floor(pricePrecision),
        });

        result = await binanceRequest("/fapi/v1/order", "POST", credentials, {
          symbol,
          side: closeSide,
          type: "LIMIT",
          quantity: roundedQuantity,
          price: roundedPrice,
          timeInForce: "GTC", // Good Till Cancelled
          reduceOnly: "true",
        });
        
        console.log('✅ Ordem LIMIT criada:', result);
        break;
      }
      
      // 📊 Verificar status de uma ordem
      case "check_order_status": {
        console.log('🔍 Verificando status da ordem:', { symbol, orderId });
        
        result = await binanceRequest("/fapi/v1/order", "GET", credentials, {
          symbol,
          orderId: orderId.toString(),
        });
        
        console.log('📊 Status da ordem:', result);
        break;
      }
      
      // ❌ Cancelar uma ordem
      case "cancel_order": {
        console.log('❌ Cancelando ordem:', { symbol, orderId });
        
        result = await binanceRequest("/fapi/v1/order", "DELETE", credentials, {
          symbol,
          orderId: orderId.toString(),
        });
        
        console.log('✅ Ordem cancelada:', result);
        break;
      }

      case "get_position":
        const positions = await binanceRequest("/fapi/v2/positionRisk", "GET", credentials);
        result = positions.find((p: any) => p.symbol === symbol) || null;
        break;

      case "get_account":
        result = await binanceRequest("/fapi/v2/account", "GET", credentials);
        break;

      case "get_positions": {
        console.log('📊 Buscando posições ativas da Binance...');
        const accountData = await binanceRequest("/fapi/v2/account", "GET", credentials);
        
        // Filtra apenas posições com quantidade diferente de zero
        const activePositions = accountData.positions?.filter((pos: any) => 
          parseFloat(pos.positionAmt) !== 0
        ) || [];
        
        console.log('✅ Posições ativas encontradas:', activePositions.length);
        result = {
          positions: activePositions,
          totalUnrealizedProfit: accountData.totalUnrealizedProfit
        };
        break;
      }

      case "get_prices": {
        console.log('📊 Buscando preços públicos diretamente da Binance');

        if (!symbols || symbols.length === 0) {
          throw new Error('Símbolos são obrigatórios para get_prices');
        }

        // 1) Buscar dados de 24h SOMENTE para os símbolos solicitados
        const tickers24h = await Promise.all(
          symbols.map(async (sym: string) => {
            const resp = await fetch(`https://fapi.binance.com/fapi/v1/ticker/24hr?symbol=${sym}`);
            const text = await resp.text();

            console.log('📥 Resposta de preços 24h:', {
              symbol: sym,
              status: resp.status,
              bodyPreview: text.substring(0, 150),
            });

            if (!resp.ok) {
              throw new Error(`Erro ao buscar preços 24h para ${sym}: ${resp.status}`);
            }

            try {
              return JSON.parse(text);
            } catch (e) {
              console.error(`❌ Erro ao fazer parse do JSON de preços 24h (${sym}):`, e);
              throw new Error(`Resposta inválida de preços 24h (${sym}): ${text.substring(0, 150)}`);
            }
          })
        );

        console.log('🔍 Buscando dados de 1h para símbolos:', symbols);

        // 2) Para cada símbolo solicitado, buscar apenas klines de 1h
        const enrichedData = await Promise.all(
          tickers24h.map(async (item: any) => {
            try {
              const klines1hResponse = await fetch(
                `https://fapi.binance.com/fapi/v1/klines?symbol=${item.symbol}&interval=1h&limit=2`
              );

              let priceChangePercent1h = 0;
              let volume1h = 0;

              if (klines1hResponse.ok) {
                const klines1h = await klines1hResponse.json();

                if (klines1h.length >= 2) {
                  const [prevCandle, currentCandle] = klines1h;
                  const prevClose = parseFloat(prevCandle[4]);
                  const currentClose = parseFloat(currentCandle[4]);
                  volume1h = parseFloat(currentCandle[7]);

                  if (prevClose > 0) {
                    priceChangePercent1h = ((currentClose - prevClose) / prevClose) * 100;
                  }
                }
              }

              return {
                ...item,
                // Mantém dados EXATOS da Binance sem conversões desnecessárias
                priceChangePercent: Number(item.priceChangePercent || 0),
                priceChangePercent1h: Number(priceChangePercent1h.toFixed(6)), // Limitar para evitar precisão excessiva
                volume1h: Number(volume1h),
              };
            } catch (e) {
              console.error(`Erro ao buscar klines para ${item.symbol}:`, e);

              // Se falhar, retornar com valores padrão mantendo dados exatos da Binance
              return {
                ...item,
                priceChangePercent: Number(item.priceChangePercent || 0),
                priceChangePercent1h: 0,
                volume1h: 0,
              };
            }
          })
        );

        result = enrichedData;
        break;
      }
      
      case "get_funding_rates": {
        // Buscar funding rates diretamente da Binance
        console.log('💰 Buscando funding rates para símbolos:', symbols);
        
        const fundingRates = await Promise.all(
          symbols.map(async (symbol: string) => {
            try {
              // Buscar dados de premium index (contém funding rate atual e próximo funding time)
              const premiumResponse = await fetch(`https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${symbol}`);
              
              if (!premiumResponse.ok) {
                console.error(`Erro ao buscar premium index para ${symbol}:`, premiumResponse.status);
                return null;
              }
              
              const premiumData = await premiumResponse.json();
              
              // Buscar último funding rate que foi efetivamente aplicado
              const fundingHistoryResponse = await fetch(`https://fapi.binance.com/fapi/v1/fundingRate?symbol=${symbol}&limit=1`);
              
              let lastFundingRate = parseFloat(premiumData.lastFundingRate || 0);
              
              if (fundingHistoryResponse.ok) {
                const fundingHistory = await fundingHistoryResponse.json();
                if (fundingHistory.length > 0) {
                  lastFundingRate = parseFloat(fundingHistory[0].fundingRate);
                }
              }
              
              return {
                symbol,
                fundingRate: parseFloat(premiumData.lastFundingRate || 0), // Taxa atual/próxima
                fundingTime: parseInt(premiumData.nextFundingTime || 0), // Próximo funding em ms
                lastFundingRate, // Última taxa que foi aplicada
              };
            } catch (e) {
              console.error(`Erro ao buscar funding rate para ${symbol}:`, e);
              return null;
            }
          })
        );
        
        result = fundingRates.filter(r => r !== null);
        console.log('✅ Funding rates encontrados:', result);
        break;
      }
      
      case "create_listen_key": {
        console.log('🔑 Criando listenKey para User Data Stream');
        result = await binanceRequest("/fapi/v1/listenKey", "POST", credentials);
        console.log('✅ ListenKey criado:', result?.listenKey?.substring(0, 10) + '...');
        break;
      }
      
      case "keepalive_listen_key": {
        console.log('🔄 Renovando listenKey:', listenKey?.substring(0, 10) + '...');
        result = await binanceRequest("/fapi/v1/listenKey", "PUT", credentials);
        console.log('✅ ListenKey renovado');
        break;
      }
    }

    return new Response(JSON.stringify({ success: true, data: result }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    console.error("❌ Erro na função Binance:", error);
    console.error("Error stack:", error instanceof Error ? error.stack : 'No stack trace');
    
    const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";
    const errorDetails = {
      message: errorMessage,
      type: error instanceof Error ? error.constructor.name : typeof error,
      stack: error instanceof Error ? error.stack : undefined,
    };

    console.log('📤 Retornando erro:', errorDetails);

    const isAuthError =
      errorMessage.includes("BINANCE_AUTH_ERROR") ||
      errorMessage.includes("Invalid API-key") ||
      errorMessage.includes("permissions");

    const isProxyConfigError = errorMessage.includes("PROXY_CONFIG_ERROR");

    return new Response(
      JSON.stringify({
        success: false,
        error: isAuthError
          ? "BINANCE_AUTH_ERROR: API key bloqueada por IP/permissões. Ajuste a restrição de IP na Binance (Unrestricted) ou use proxy com IP fixo."
          : isProxyConfigError
            ? "PROXY_CONFIG_ERROR: PROXY_URL está configurado como socks5:// e foi ignorado. Configure PROXY_URL como http(s)://<SEU_VPS>:3000 (proxy HTTP→SOCKS5) para ter IP fixo."
            : errorMessage,
        details: errorDetails,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: isAuthError ? 403 : 400,
      },
    );
  }
});
