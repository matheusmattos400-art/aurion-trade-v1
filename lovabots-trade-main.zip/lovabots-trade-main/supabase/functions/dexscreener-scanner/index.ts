import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TokenData {
  chainId: string;
  pairAddress: string;
  baseToken: {
    address: string;
    name: string;
    symbol: string;
  };
  quoteToken: {
    address: string;
    symbol: string;
  };
  priceNative: string;
  priceUsd: string;
  txns: {
    h24: { buys: number; sells: number };
    h6: { buys: number; sells: number };
    h1: { buys: number; sells: number };
    m5: { buys: number; sells: number };
  };
  volume: {
    h24: number;
    h6: number;
    h1: number;
    m5: number;
  };
  priceChange: {
    h24: number;
    h6: number;
    h1: number;
    m5: number;
  };
  liquidity?: {
    usd?: number;
    base?: number;
    quote?: number;
  } | null;
  fdv: number;
  marketCap: number;
  pairCreatedAt: number;
  info?: {
    imageUrl?: string;
    websites?: Array<{ url: string }>;
    socials?: Array<{ type: string; url: string }>;
  };
  dexId: string;
  url: string;
  boostAmount?: number;
}

interface GoPlusSecurityData {
  is_honeypot?: string;
  is_open_source?: string;
  is_proxy?: string;
  is_mintable?: string;
  can_take_back_ownership?: string;
  owner_change_balance?: string;
  hidden_owner?: string;
  selfdestruct?: string;
  external_call?: string;
  is_blacklisted?: string;
  is_whitelisted?: string;
  is_anti_whale?: string;
  anti_whale_modifiable?: string;
  trading_cooldown?: string;
  transfer_pausable?: string;
  cannot_buy?: string;
  cannot_sell_all?: string;
  slippage_modifiable?: string;
  personal_slippage_modifiable?: string;
  lp_holders?: Array<{
    address: string;
    is_locked: number;
    percent: number;
  }>;
  trust_list?: string;
  holder_count?: string;
}

// RugCheck API response interface for Solana
interface RugCheckData {
  mint: string;
  tokenMeta?: {
    name: string;
    symbol: string;
  };
  rugged?: boolean;
  risks?: Array<{
    name: string;
    level: string;
    score: number;
    description: string;
  }>;
  score?: number;
  // Token program info
  token?: {
    mintAuthority: string | null;
    freezeAuthority: string | null;
    supply: number;
    decimals: number;
  };
  // Markets/LP info
  markets?: Array<{
    lp?: {
      lpLocked: number;
      lpLockedPct: number;
      lpBurned: number;
      lpBurnedPct: number;
    };
  }>;
}

// Fetch tokens from DexScreener - multiple sources for more coverage
async function fetchDexScreenerTokens(chain: string = "solana"): Promise<TokenData[]> {
  const allTokens: TokenData[] = [];
  
  try {
    // Source 1: Latest boosts
    const boostResponse = await fetch(`https://api.dexscreener.com/token-boosts/latest/v1`, {
      headers: { 'Accept': 'application/json' }
    });
    
    if (boostResponse.ok) {
      const boostData = await boostResponse.json();
      if (Array.isArray(boostData)) {
        // Fetch pair data for boosted tokens
        for (const boost of boostData.slice(0, 30)) {
          try {
            if (boost.tokenAddress) {
              const pairRes = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${boost.tokenAddress}`);
              if (pairRes.ok) {
                const pairData = await pairRes.json();
                if (pairData.pairs?.length > 0) {
                  allTokens.push(...pairData.pairs.slice(0, 3));
                }
              }
            }
          } catch { continue; }
        }
      }
    }
  } catch (error) {
    console.error("Error fetching boost tokens:", error);
  }
  
  try {
    // Source 2: Direct chain pairs (most recent)
    const chainResponse = await fetch(`https://api.dexscreener.com/latest/dex/pairs/${chain}`, {
      headers: { 'Accept': 'application/json' }
    });
    
    if (chainResponse.ok) {
      const chainData = await chainResponse.json();
      if (chainData.pairs) {
        allTokens.push(...chainData.pairs.slice(0, 50));
      }
    }
  } catch (error) {
    console.error("Error fetching chain pairs:", error);
  }
  
  try {
    // Source 3: Search for trending terms
    const searchTerms = ['ai', 'trump', 'pepe', 'doge', 'meme', 'sol'];
    const randomTerm = searchTerms[Math.floor(Math.random() * searchTerms.length)];
    const searchResponse = await fetch(`https://api.dexscreener.com/latest/dex/search?q=${randomTerm}`, {
      headers: { 'Accept': 'application/json' }
    });
    
    if (searchResponse.ok) {
      const searchData = await searchResponse.json();
      if (searchData.pairs) {
        allTokens.push(...searchData.pairs.filter((p: any) => p.chainId === chain).slice(0, 30));
      }
    }
  } catch (error) {
    console.error("Error fetching search tokens:", error);
  }
  
  console.log(`📥 Fetched ${allTokens.length} tokens from DexScreener sources`);
  return allTokens;
}

// Fetch trending tokens
async function fetchTrendingTokens(): Promise<TokenData[]> {
  try {
    const response = await fetch(`https://api.dexscreener.com/token-profiles/latest/v1`, {
      headers: { 'Accept': 'application/json' }
    });

    if (!response.ok) return [];
    
    const profiles = await response.json();
    if (!Array.isArray(profiles)) return [];

    // Para cada token, buscar dados do par
    const tokens: TokenData[] = [];
    for (const profile of profiles.slice(0, 50)) {
      try {
        const pairResponse = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${profile.tokenAddress}`);
        if (pairResponse.ok) {
          const pairData = await pairResponse.json();
          if (pairData.pairs && pairData.pairs.length > 0) {
            tokens.push(pairData.pairs[0]);
          }
        }
      } catch {
        continue;
      }
    }

    return tokens;
  } catch (error) {
    console.error("Error fetching trending tokens:", error);
    return [];
  }
}

// Fetch TOP boosted tokens from DexScreener
async function fetchTopBoostedTokens(): Promise<TokenData[]> {
  try {
    console.log("🚀 Fetching top boosted tokens...");
    const response = await fetch(`https://api.dexscreener.com/token-boosts/top/v1`, {
      headers: { 'Accept': 'application/json' }
    });

    if (!response.ok) {
      console.error("Error fetching top boosts:", response.status);
      return [];
    }
    
    const boosts = await response.json();
    if (!Array.isArray(boosts)) return [];

    console.log(`📊 Found ${boosts.length} top boosted tokens`);

    // Para cada token, buscar dados do par (limitado a solana)
    const tokens: TokenData[] = [];
    for (const boost of boosts.slice(0, 30)) {
      try {
        if (boost.chainId !== "solana") continue;
        
        const pairResponse = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${boost.tokenAddress}`);
        if (pairResponse.ok) {
          const pairData = await pairResponse.json();
          if (pairData.pairs && pairData.pairs.length > 0) {
            // Add boost info to token
            const token = pairData.pairs[0];
            token.boostAmount = boost.totalAmount || boost.amount || 0;
            tokens.push(token);
          }
        }
      } catch {
        continue;
      }
    }

    console.log(`✅ Processed ${tokens.length} top boosted tokens`);
    return tokens;
  } catch (error) {
    console.error("Error fetching top boosted tokens:", error);
    return [];
  }
}

// Simple in-memory cache for RugCheck results (within same request)
const rugCheckCache = new Map<string, RugCheckData | null>();

// Rate limiter helper
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Check token security with RugCheck API (for Solana) - with caching and rate limiting
async function checkRugCheckSecurity(tokenAddress: string, delayMs: number = 0): Promise<RugCheckData | null> {
  // Check cache first
  if (rugCheckCache.has(tokenAddress)) {
    return rugCheckCache.get(tokenAddress) || null;
  }
  
  try {
    // Add delay to respect rate limits
    if (delayMs > 0) {
      await delay(delayMs);
    }
    
    const response = await fetch(
      `https://api.rugcheck.xyz/v1/tokens/${tokenAddress}/report/summary`,
      {
        headers: { 'Accept': 'application/json' }
      }
    );

    if (response.status === 429) {
      // Rate limited - cache as null and return
      console.log(`RugCheck rate limited for ${tokenAddress}`);
      rugCheckCache.set(tokenAddress, null);
      return null;
    }
    
    if (!response.ok) {
      console.log(`RugCheck API returned ${response.status} for ${tokenAddress}`);
      rugCheckCache.set(tokenAddress, null);
      return null;
    }

    const data = await response.json();
    rugCheckCache.set(tokenAddress, data);
    return data;
  } catch (error) {
    console.error(`Error checking RugCheck for ${tokenAddress}:`, error);
    rugCheckCache.set(tokenAddress, null);
    return null;
  }
}

// Check token security with GoPlus (fallback for non-Solana)
async function checkTokenSecurity(chainId: string, tokenAddress: string): Promise<GoPlusSecurityData | null> {
  try {
    // Map DexScreener chainId to GoPlus chainId
    const chainMap: Record<string, string> = {
      'ethereum': '1',
      'bsc': '56',
      'polygon': '137',
      'arbitrum': '42161',
      'base': '8453',
      'avalanche': '43114',
    };

    const goPlusChainId = chainMap[chainId.toLowerCase()] || chainId;
    
    // Skip GoPlus for Solana - use RugCheck instead
    if (chainId.toLowerCase() === 'solana') {
      return null;
    }
    
    const response = await fetch(
      `https://api.gopluslabs.io/api/v1/token_security/${goPlusChainId}?contract_addresses=${tokenAddress}`,
      {
        headers: { 'Accept': 'application/json' }
      }
    );

    if (!response.ok) return null;

    const data = await response.json();
    return data.result?.[tokenAddress.toLowerCase()] || null;
  } catch (error) {
    console.error(`Error checking security for ${tokenAddress}:`, error);
    return null;
  }
}

// Extract security info from RugCheck data
function extractRugCheckSecurity(rugCheck: RugCheckData | null): {
  isMintable: boolean;
  hasFreeze: boolean;
  lpLocked: boolean;
  lpLockedPct: number;
  isRugged: boolean;
  riskScore: number;
} {
  if (!rugCheck) {
    return {
      isMintable: false, // Unknown = assume safe
      hasFreeze: false,
      lpLocked: false,
      lpLockedPct: 0,
      isRugged: false,
      riskScore: 0
    };
  }

  // Check mint authority - if null, it's revoked (safe)
  const isMintable = rugCheck.token?.mintAuthority !== null && rugCheck.token?.mintAuthority !== undefined;
  
  // Check freeze authority - if null, it's disabled (safe)
  const hasFreeze = rugCheck.token?.freezeAuthority !== null && rugCheck.token?.freezeAuthority !== undefined;
  
  // Check LP locked/burned
  const market = rugCheck.markets?.[0];
  const lpLockedPct = market?.lp?.lpLockedPct ?? 0;
  const lpBurnedPct = market?.lp?.lpBurnedPct ?? 0;
  const lpLocked = (lpLockedPct + lpBurnedPct) >= 50; // Consider locked if 50%+ is locked or burned

  return {
    isMintable,
    hasFreeze,
    lpLocked,
    lpLockedPct: lpLockedPct + lpBurnedPct,
    isRugged: rugCheck.rugged === true,
    riskScore: rugCheck.score ?? 0
  };
}

// Calculate DEXT-like score based on available data - MAIS PERMISSIVO
function calculateSecurityScore(security: GoPlusSecurityData | null, token: TokenData): number {
  // Helper para obter liquidez USD (fallback para 0)
  const liquidityUsd = token.liquidity?.usd ?? 0;

  // Se não há dados de segurança, calcular score baseado apenas no token
  if (!security) {
    let score = 70; // Score base MAIOR para tokens sem verificação
    
    // Liquidez (bônus pequenos)
    if (liquidityUsd >= 50000) score += 15;
    else if (liquidityUsd >= 20000) score += 10;
    else if (liquidityUsd >= 5000) score += 5;
    
    // Volume
    if ((token.volume?.h24 ?? 0) >= 50000) score += 10;
    else if ((token.volume?.h24 ?? 0) >= 10000) score += 5;
    
    // Social presence bonus
    if (token.info?.websites?.length) score += 3;
    if (token.info?.socials?.length) score += 3;
    
    return Math.max(30, Math.min(100, score));
  }

  let score = 100;

  // Critical issues (deduções moderadas)
  if (security.is_honeypot === "1") score -= 80; // Crítico
  if (security.cannot_sell_all === "1") score -= 60; // Crítico
  if (security.is_mintable === "1") score -= 8; // Menor penalidade
  if (security.is_blacklisted === "1") score -= 5; // Menor penalidade
  if (security.hidden_owner === "1") score -= 5;

  // Minor issues (penalidades pequenas)
  if (security.is_open_source !== "1") score -= 3;
  if (security.transfer_pausable === "1") score -= 3;
  if (security.trading_cooldown === "1") score -= 2;
  if (security.slippage_modifiable === "1") score -= 2;

  // Positive factors (bônus)
  if (security.trust_list === "1") score += 15;

  // Liquidez - menos punitivo
  if (liquidityUsd < 1000) score -= 10;
  else if (liquidityUsd >= 30000) score += 5;

  // LP locked bonus
  const lockedLp = security.lp_holders?.some(lp => lp.is_locked === 1);
  if (lockedLp) score += 10;

  // Social presence bonus
  if (token.info?.websites?.length) score += 3;
  if (token.info?.socials?.length) score += 3;

  return Math.max(0, Math.min(100, score));
}

// Check if token passes filter - MUITO PERMISSIVO (só bloqueia honeypots confirmados)
function passesSecurityFilter(security: GoPlusSecurityData | null, score: number): { passes: boolean; reasons: string[] } {
  const reasons: string[] = [];

  // Se não há dados de segurança, SEMPRE permite
  if (!security) {
    if (score < 40) {
      reasons.push("⚠️ Liquidez/Volume baixo");
    }
    // Permite mesmo sem verificação de segurança (comum em Solana)
    return { passes: score >= 30, reasons };
  }

  // ÚNICO BLOQUEIO: honeypot confirmado OU impossível vender
  if (security.is_honeypot === "1") {
    reasons.push("🚫 Honeypot detectado");
    return { passes: false, reasons };
  }

  if (security.cannot_sell_all === "1") {
    reasons.push("🚫 Não é possível vender");
    return { passes: false, reasons };
  }

  // Avisos (NÃO bloqueiam, apenas informam)
  if (security.is_mintable === "1") {
    reasons.push("⚠️ Função de mint ativa");
  }

  if (security.is_blacklisted === "1") {
    reasons.push("⚠️ Função de blacklist");
  }

  if (security.hidden_owner === "1") {
    reasons.push("⚠️ Owner oculto");
  }

  if (security.transfer_pausable === "1") {
    reasons.push("⚠️ Transferência pausável");
  }

  if (score < 50) {
    reasons.push(`⚠️ Score: ${score}`);
  }

  // PASSA se não é honeypot e pode vender (score mínimo muito baixo)
  return { passes: score >= 25, reasons };
}

// Calculate token age in hours
function getTokenAgeHours(pairCreatedAt: number): number {
  const now = Date.now();
  const ageMs = now - pairCreatedAt;
  return ageMs / (1000 * 60 * 60);
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { chain = "solana", action = "scan", pairAddress, chainId } = await req.json().catch(() => ({}));

    console.log(`🔍 DexScreener Scanner - Action: ${action}, Chain: ${chain}`);

    // Get price for a specific pair
    if (action === "getPrice" && pairAddress) {
      try {
        const pairChain = chainId || "solana";
        const response = await fetch(
          `https://api.dexscreener.com/latest/dex/pairs/${pairChain}/${pairAddress}`,
          { headers: { 'Accept': 'application/json' } }
        );
        
        if (!response.ok) {
          return new Response(
            JSON.stringify({ success: false, error: "Pair not found" }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        
        const data = await response.json();
        const pair = data.pair || data.pairs?.[0];
        
        if (!pair) {
          return new Response(
            JSON.stringify({ success: false, error: "Price not available" }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        
        return new Response(
          JSON.stringify({ 
            success: true, 
            price: pair.priceUsd,
            priceNative: pair.priceNative,
            priceChange24h: pair.priceChange?.h24
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      } catch (error) {
        console.error("Error fetching price:", error);
        return new Response(
          JSON.stringify({ success: false, error: "Failed to fetch price" }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // New action: Get top boosted tokens with full data like radar
    if (action === "top") {
      const topTokens = await fetchTopBoostedTokens();
      
      // Process top tokens with security checks (same as scan)
      const processedTop = [];
      
      for (const token of topTokens.slice(0, 20)) {
        try {
          const ageHours = getTokenAgeHours(token.pairCreatedAt || Date.now());
          const tokenAddress = token.baseToken?.address || "";
          const isSolana = token.chainId?.toLowerCase() === 'solana';
          
          // Use RugCheck for Solana, GoPlus for others
          let isMintable = false;
          let hasBlacklist = false;
          let lpLocked = false;
          let securityScore = 70;
          let isHoneypot = false;
          let isVerified = false;
          let reasons: string[] = [];
          let passes = true;

          if (isSolana && tokenAddress) {
            // Use RugCheck API for Solana
            const rugCheck = await checkRugCheckSecurity(tokenAddress);
            const rugSecurity = extractRugCheckSecurity(rugCheck);
            
            isMintable = rugSecurity.isMintable;
            hasBlacklist = rugSecurity.hasFreeze;
            lpLocked = rugSecurity.lpLocked;
            isHoneypot = rugSecurity.isRugged;
            
            // Calculate score based on RugCheck
            securityScore = 100;
            if (rugSecurity.isRugged) { securityScore -= 80; passes = false; reasons.push("🚫 Token rugged"); }
            if (rugSecurity.isMintable) { securityScore -= 10; reasons.push("⚠️ Mint ativo"); }
            if (rugSecurity.hasFreeze) { securityScore -= 10; reasons.push("⚠️ Freeze ativo"); }
            if (!rugSecurity.lpLocked) { securityScore -= 5; reasons.push("⚠️ LP não travada"); }
            else { securityScore += 10; }
            
            // Liquidity bonus
            const liq = token.liquidity?.usd ?? 0;
            if (liq >= 50000) securityScore += 10;
            else if (liq >= 20000) securityScore += 5;
            
            securityScore = Math.max(0, Math.min(100, securityScore));
          } else {
            // Use GoPlus for non-Solana
            const security = await checkTokenSecurity(token.chainId, tokenAddress);
            securityScore = calculateSecurityScore(security, token);
            const filterResult = passesSecurityFilter(security, securityScore);
            passes = filterResult.passes;
            reasons = filterResult.reasons;
            isVerified = security?.is_open_source === "1";
            isHoneypot = security?.is_honeypot === "1";
            isMintable = security?.is_mintable === "1";
            hasBlacklist = security?.is_blacklisted === "1";
            lpLocked = security?.lp_holders?.some(lp => lp.is_locked === 1) || false;
          }

          processedTop.push({
            // Basic info
            id: token.pairAddress,
            chainId: token.chainId,
            pairAddress: token.pairAddress,
            tokenAddress: token.baseToken?.address,
            name: token.baseToken?.name || "Unknown",
            symbol: token.baseToken?.symbol || "???",
            dexId: token.dexId,
            url: token.url,
            imageUrl: token.info?.imageUrl,

            // Price data
            priceUsd: parseFloat(token.priceUsd || "0"),
            priceChange5m: token.priceChange?.m5 || 0,
            priceChange1h: token.priceChange?.h1 || 0,
            priceChange6h: token.priceChange?.h6 || 0,
            priceChange24h: token.priceChange?.h24 || 0,

            // Volume & Liquidity
            volume24h: token.volume?.h24 || 0,
            volume1h: token.volume?.h1 || 0,
            liquidity: token.liquidity?.usd || 0,
            marketCap: token.marketCap || token.fdv || 0,

            // Transactions
            buys24h: token.txns?.h24?.buys || 0,
            sells24h: token.txns?.h24?.sells || 0,
            buys1h: token.txns?.h1?.buys || 0,
            sells1h: token.txns?.h1?.sells || 0,

            // Age & Category
            ageHours,
            category: "top",
            createdAt: token.pairCreatedAt,
            boostAmount: token.boostAmount || 0,

            // Security
            securityScore,
            passesSecurityFilter: passes,
            securityReasons: reasons,
            isVerified,
            isHoneypot,
            isMintable,
            hasBlacklist,
            lpLocked,

            // Social
            hasWebsite: (token.info?.websites?.length || 0) > 0,
            hasSocials: (token.info?.socials?.length || 0) > 0,
            websites: token.info?.websites || [],
            socials: token.info?.socials || [],

            // Technical analysis placeholder
            technicalStatus: "pending",
            chandelierSignal: null,
            adxSignal: null,
            rsiSignal: null,
            aurionConfirmed: false,
          });
        } catch (error) {
          console.error(`Error processing top token:`, error);
        }
      }

      return new Response(
        JSON.stringify({
          success: true,
          data: processedTop,
          timestamp: Date.now(),
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === "scan") {
      // Fetch tokens from multiple sources
      const [boostTokens, trendingTokens] = await Promise.all([
        fetchDexScreenerTokens(chain),
        fetchTrendingTokens()
      ]);

      // Combine and deduplicate
      const allTokens = [...boostTokens, ...trendingTokens];
      const uniqueTokens = allTokens.filter((token, index, self) =>
        index === self.findIndex(t => t.pairAddress === token.pairAddress)
      );

      console.log(`📊 Found ${uniqueTokens.length} unique tokens`);

      // Process tokens with security checks
      const processedTokens = [];
      const batchSize = 10;

      for (let i = 0; i < Math.min(uniqueTokens.length, 100); i += batchSize) {
        const batch = uniqueTokens.slice(i, i + batchSize);
        
          const results = await Promise.all(
          batch.map(async (token) => {
            try {
              const ageHours = getTokenAgeHours(token.pairCreatedAt || Date.now());
              const tokenAddress = token.baseToken?.address || "";
              const isSolana = token.chainId?.toLowerCase() === 'solana';
              
              // Use RugCheck for Solana, GoPlus for others
              let isMintable = false;
              let hasBlacklist = false;
              let lpLocked = false;
              let securityScore = 70;
              let isHoneypot = false;
              let isVerified = false;
              let reasons: string[] = [];
              let passes = true;

              if (isSolana && tokenAddress) {
                // Use RugCheck API for Solana
                const rugCheck = await checkRugCheckSecurity(tokenAddress);
                const rugSecurity = extractRugCheckSecurity(rugCheck);
                
                isMintable = rugSecurity.isMintable;
                hasBlacklist = rugSecurity.hasFreeze;
                lpLocked = rugSecurity.lpLocked;
                isHoneypot = rugSecurity.isRugged;
                
                // Calculate score based on RugCheck
                securityScore = 100;
                if (rugSecurity.isRugged) { securityScore -= 80; passes = false; reasons.push("🚫 Token rugged"); }
                if (rugSecurity.isMintable) { securityScore -= 10; reasons.push("⚠️ Mint ativo"); }
                if (rugSecurity.hasFreeze) { securityScore -= 10; reasons.push("⚠️ Freeze ativo"); }
                if (!rugSecurity.lpLocked) { securityScore -= 5; reasons.push("⚠️ LP não travada"); }
                else { securityScore += 10; }
                
                // Liquidity bonus
                const liq = token.liquidity?.usd ?? 0;
                if (liq >= 50000) securityScore += 10;
                else if (liq >= 20000) securityScore += 5;
                
                securityScore = Math.max(0, Math.min(100, securityScore));
              } else {
                // Use GoPlus for non-Solana
                const security = await checkTokenSecurity(token.chainId, tokenAddress);
                securityScore = calculateSecurityScore(security, token);
                const filterResult = passesSecurityFilter(security, securityScore);
                passes = filterResult.passes;
                reasons = filterResult.reasons;
                isVerified = security?.is_open_source === "1";
                isHoneypot = security?.is_honeypot === "1";
                isMintable = security?.is_mintable === "1";
                hasBlacklist = security?.is_blacklisted === "1";
                lpLocked = security?.lp_holders?.some(lp => lp.is_locked === 1) || false;
              }

              return {
                // Basic info
                id: token.pairAddress,
                chainId: token.chainId,
                pairAddress: token.pairAddress,
                tokenAddress: token.baseToken?.address,
                name: token.baseToken?.name || "Unknown",
                symbol: token.baseToken?.symbol || "???",
                dexId: token.dexId,
                url: token.url,
                imageUrl: token.info?.imageUrl,

                // Price data
                priceUsd: parseFloat(token.priceUsd || "0"),
                priceChange5m: token.priceChange?.m5 || 0,
                priceChange1h: token.priceChange?.h1 || 0,
                priceChange6h: token.priceChange?.h6 || 0,
                priceChange24h: token.priceChange?.h24 || 0,

                // Volume & Liquidity
                volume24h: token.volume?.h24 || 0,
                volume1h: token.volume?.h1 || 0,
                liquidity: token.liquidity?.usd || 0,
                marketCap: token.marketCap || token.fdv || 0,

                // Transactions
                buys24h: token.txns?.h24?.buys || 0,
                sells24h: token.txns?.h24?.sells || 0,
                buys1h: token.txns?.h1?.buys || 0,
                sells1h: token.txns?.h1?.sells || 0,

                // Age & Category - radar agora inclui até 12 horas
                ageHours,
                category: ageHours <= 12 ? "radar" : "main",
                createdAt: token.pairCreatedAt,

                // Security
                securityScore,
                passesSecurityFilter: passes,
                securityReasons: reasons,
                isVerified,
                isHoneypot,
                isMintable,
                hasBlacklist,
                lpLocked,

                // Social
                hasWebsite: (token.info?.websites?.length || 0) > 0,
                hasSocials: (token.info?.socials?.length || 0) > 0,
                websites: token.info?.websites || [],
                socials: token.info?.socials || [],

                // For technical analysis (placeholder - will be done client-side)
                technicalStatus: "pending",
                chandelierSignal: null,
                adxSignal: null,
                rsiSignal: null,
                aurionConfirmed: false,
              };
            } catch (error) {
              console.error(`Error processing token:`, error);
              return null;
            }
          })
        );

      processedTokens.push(...results.filter((r): r is NonNullable<typeof r> => r !== null));
      
      // Small delay between batches
      if (i + batchSize < uniqueTokens.length) {
        await new Promise(resolve => setTimeout(resolve, 200));
      }
    }

    // Sort by age (older = safer) and then by security score
    const mainTokens = processedTokens
      .filter(t => t.category === "main" && t.passesSecurityFilter)
      .sort((a, b) => {
        // Prioriza moedas mais antigas (maior ageHours)
        if (b.ageHours !== a.ageHours) {
          return b.ageHours - a.ageHours;
        }
        // Em caso de empate, usa o security score
        return b.securityScore - a.securityScore;
      });

    const radarTokens = processedTokens
      .filter(t => t.category === "radar" && t.passesSecurityFilter)
      .sort((a, b) => a.ageHours - b.ageHours);

      const rejectedTokens = processedTokens
        .filter(t => !t.passesSecurityFilter)
        .slice(0, 20);

      console.log(`✅ Processed: ${mainTokens.length} main, ${radarTokens.length} radar, ${rejectedTokens.length} rejected`);

      return new Response(
        JSON.stringify({
          success: true,
          data: {
            main: mainTokens,
            radar: radarTokens,
            rejected: rejectedTokens,
            totalScanned: uniqueTokens.length,
            timestamp: Date.now(),
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: false, error: "Invalid action" }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Error in DexScreener scanner:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
