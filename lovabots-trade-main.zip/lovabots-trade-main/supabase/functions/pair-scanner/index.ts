import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const ALL_CRYPTO_PAIRS = [
  "BNBUSDT", "SOLUSDT", "ADAUSDT", "DOGEUSDT", "XRPUSDT", 
  "DOTUSDT", "AVAXUSDT", "LINKUSDT", "ATOMUSDT",
  "LTCUSDT", "ETCUSDT", "NEARUSDT", "FTMUSDT", "SANDUSDT",
  "UNIUSDT", "AAVEUSDT", "ICPUSDT", "FILUSDT", "APTUSDT"
];

interface TradingSignal {
  id: string;
  longSymbol: string;
  shortSymbol: string;
  strategy: "micro_distortion" | "partial_reversal" | "trend_follow";
  zScore: number;
  correlation: number;
  correlation5d: number;   // 5 dias (120h)
  correlation25d: number;  // 25 dias (600h)
  correlation2m: number;   // 2 meses (1440h)
  momentumAge: number;
  currentMomentum: number;
  avgBullish: number;
  avgBearish: number;
  liquidityRatio: number;
  message: string;
  timestamp: string;
  status: "ready" | "pending";
  pendingReason?: string;
}

// Fetch data directly from Binance public API (no auth needed for klines)
async function fetchBinanceData(endpoint: string): Promise<any> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000);
  
  try {
    const response = await fetch(`https://fapi.binance.com${endpoint}`, {
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

// Fetch all klines for a symbol in one call
async function fetchKlinesForSymbol(symbol: string): Promise<{
  klines1h: number[][];
  klines30m: number[][];
  currentPrice: number;
} | null> {
  try {
    // Buscar 1500 horas (~62 dias / 2 meses) para correlação de longo prazo
    // Binance permite até 1500 candles por request
    const [klines1h, klines30m, ticker] = await Promise.all([
      fetchBinanceData(`/fapi/v1/klines?symbol=${symbol}&interval=1h&limit=1500`),
      fetchBinanceData(`/fapi/v1/klines?symbol=${symbol}&interval=30m&limit=48`),
      fetchBinanceData(`/fapi/v1/ticker/price?symbol=${symbol}`),
    ]);
    
    if (!Array.isArray(klines1h) || klines1h.length < 120) {
      console.error(`❌ Dados insuficientes para ${symbol}: apenas ${klines1h?.length || 0} candles`);
      return null;
    }
    
    return {
      klines1h,
      klines30m,
      currentPrice: parseFloat(ticker.price),
    };
  } catch (error) {
    console.error(`❌ Erro ao buscar dados de ${symbol}:`, error);
    return null;
  }
}

// Calculate Pearson correlation using PRICES (not returns) - more stable
function calculateCorrelation(prices1: number[], prices2: number[]): number {
  if (prices1.length !== prices2.length || prices1.length < 10) return 0;
  
  // Usar correlação de PREÇOS normalizados (não retornos)
  // Isso é muito mais estável e reflete melhor a correlação real dos ativos
  const mean1 = prices1.reduce((a, b) => a + b, 0) / prices1.length;
  const mean2 = prices2.reduce((a, b) => a + b, 0) / prices2.length;
  
  // Normalizar preços (dividir pela média para ter escala comparável)
  const norm1 = prices1.map(p => p / mean1);
  const norm2 = prices2.map(p => p / mean2);
  
  const normMean1 = norm1.reduce((a, b) => a + b, 0) / norm1.length;
  const normMean2 = norm2.reduce((a, b) => a + b, 0) / norm2.length;
  
  let num = 0, den1 = 0, den2 = 0;
  for (let i = 0; i < norm1.length; i++) {
    const diff1 = norm1[i] - normMean1;
    const diff2 = norm2[i] - normMean2;
    num += diff1 * diff2;
    den1 += diff1 * diff1;
    den2 += diff2 * diff2;
  }
  
  const denominator = Math.sqrt(den1 * den2);
  if (denominator === 0) return 0;
  
  const result = num / denominator;
  return isNaN(result) ? 0 : result;
}

// Analyze pair using cached data
function analyzePairFromData(
  symbol1: string,
  symbol2: string,
  data1: { klines1h: number[][]; klines30m: number[][]; currentPrice: number },
  data2: { klines1h: number[][]; klines30m: number[][]; currentPrice: number }
): TradingSignal | null {
  try {
    // Extract prices - EXCLUIR O CANDLE ATUAL (último) pois ainda não fechou
    // Isso evita ruído do candle em andamento na correlação
    const prices1_1h_all: number[] = data1.klines1h.map((k) => parseFloat(String(k[4])));
    const prices2_1h_all: number[] = data2.klines1h.map((k) => parseFloat(String(k[4])));
    
    // Remover o último candle (ainda não fechado) para correlação
    const prices1_1h = prices1_1h_all.slice(0, -1);
    const prices2_1h = prices2_1h_all.slice(0, -1);
    
    // Garantir que temos dados suficientes (5 dias = 120 horas)
    const minLength = Math.min(prices1_1h.length, prices2_1h.length);
    if (minLength < 120) {
      console.log(`⚠️ Dados insuficientes para ${symbol1}/${symbol2}: ${minLength} candles`);
      return null;
    }
    
    // Calculate correlations for 3 periods: 5 dias (120h), 25 dias (600h), 2 meses (1440h)
    // IMPORTANTE: Usar apenas candles FECHADOS para correlação estável
    const correlation5d = calculateCorrelation(prices1_1h.slice(-120), prices2_1h.slice(-120));    // 5 dias
    const correlation25d = calculateCorrelation(
      prices1_1h.slice(-Math.min(600, minLength)), 
      prices2_1h.slice(-Math.min(600, minLength))
    ); // 25 dias
    const correlation2m = calculateCorrelation(
      prices1_1h.slice(-Math.min(1440, minLength)), 
      prices2_1h.slice(-Math.min(1440, minLength))
    );  // 2 meses
    
    const correlations = [correlation5d, correlation25d, correlation2m];
    
    // Validate: All 3 periods must be > 80% AND at least 1 >= 90%
    const allAbove80 = correlations.every(c => c > 0.80);
    const atLeastOne90 = correlations.some(c => c >= 0.90);
    
    if (!allAbove80 || !atLeastOne90) {
      return null;
    }
    
    // Use the average correlation for display
    const correlation = correlations.reduce((a, b) => a + b, 0) / correlations.length;
    
    // Filter only closed candles
    const now = Date.now();
    const closedKlines1_30m = data1.klines30m.filter((k) => k[6] < now);
    const closedKlines2_30m = data2.klines30m.filter((k) => k[6] < now);
    
    // Check current candle age - discard if >= 25 minutes into the candle
    const lastKline = data1.klines30m[data1.klines30m.length - 1];
    const candleOpenTime = lastKline[0] as number;
    const candleAgeMinutes = (now - candleOpenTime) / (1000 * 60);
    
    // If candle is >= 25 minutes old, discard - wait for new candle at 30min
    if (candleAgeMinutes >= 25) {
      return null;
    }
    
    const prices1_30m: number[] = closedKlines1_30m.map((k) => parseFloat(String(k[4])));
    const prices2_30m: number[] = closedKlines2_30m.map((k) => parseFloat(String(k[4])));
    const volumes1_1h: number[] = data1.klines1h.map((k) => parseFloat(String(k[7])));
    const volumes2_1h: number[] = data2.klines1h.map((k) => parseFloat(String(k[7])));

    if (prices1_30m.length < 2 || prices2_30m.length < 2) {
      return null;
    }

    // Calculate Z-Score
    const ratios: number[] = prices1_30m.map((p1, i) => (p1 / prices2_30m[i] - 1) * 100);
    const currentDifference = ratios[ratios.length - 1];
    const avgDifference = ratios.reduce((a, b) => a + b, 0) / ratios.length;
    const variance = ratios.reduce((sum, val) => sum + Math.pow(val - avgDifference, 2), 0) / ratios.length;
    const stdDev = Math.sqrt(variance);
    const zScore = stdDev > 0 ? (currentDifference - avgDifference) / stdDev : 0;
    const absZScore = Math.abs(zScore);

    // Calculate momentum with real-time price
    const lastRatio = prices1_30m[prices1_30m.length - 1] / prices2_30m[prices2_30m.length - 1];
    const currentRatio = data1.currentPrice / data2.currentPrice;
    const currentMomentum = ((currentRatio - lastRatio) / lastRatio) * 100;

    // Calculate momentum averages
    const momentumChanges: number[] = ratios.slice(1).map((r, i) => {
      const prev = ratios[i];
      return prev !== 0 ? ((r - prev) / Math.abs(prev)) * 100 : 0;
    });
    const bullishChanges = momentumChanges.filter(m => m > 0);
    const bearishChanges = momentumChanges.filter(m => m < 0);
    const avgBullish = bullishChanges.length > 0 ? bullishChanges.reduce((a, b) => a + b, 0) / bullishChanges.length : 0;
    const avgBearish = bearishChanges.length > 0 ? bearishChanges.reduce((a, b) => a + b, 0) / bearishChanges.length : 0;

    // Candle age in minutes for display
    const momentumAgeMinutes = Math.floor(candleAgeMinutes);

    // Calculate liquidity
    const avgVolume1 = volumes1_1h.reduce((a, b) => a + b, 0) / volumes1_1h.length;
    const avgVolume2 = volumes2_1h.reduce((a, b) => a + b, 0) / volumes2_1h.length;
    const liquidityRatio = Math.min(avgVolume1, avgVolume2) / Math.max(avgVolume1, avgVolume2);

    // FILTRO DE MOMENTUM: só mostrar se momentum atual for significativo
    // O momentum precisa ser maior que a média histórica na direção correspondente
    const absMomentum = Math.abs(currentMomentum);
    const thresholdMomentum = currentMomentum > 0 ? avgBullish : Math.abs(avgBearish);
    
    // Se não houver momentum significativo (acima da média), não mostrar o sinal
    if (absMomentum < thresholdMomentum || absMomentum < 0.05) {
      return null;
    }

    // Status is always ready if we got here
    const status: "ready" | "pending" = "ready";
    const pendingReason: string | undefined = undefined;

    // Z-Score is only informational
    let zScoreInfo = "";
    if (absZScore >= 2.0) {
      zScoreInfo = "Excelente";
    } else if (absZScore >= 1.5) {
      zScoreInfo = "Bom";
    } else if (absZScore >= 1.0) {
      zScoreInfo = "Moderado";
    } else {
      zScoreInfo = "Baixo";
    }

    // Strategy based on correlation + momentum (Z-Score only informational)
    const strategy: "micro_distortion" | "partial_reversal" | "trend_follow" = "micro_distortion";
    const message = `Z-Score: ${zScoreInfo} (${zScore.toFixed(2)})`;

    // Estratégia baseada no MOMENTUM do ratio symbol1/symbol2 (operacional de reversão à média)
    // currentMomentum é a variação % do ratio symbol1/symbol2 entre o último candle fechado e o preço atual.
    //
    // REGRAS DO OPERACIONAL:
    // - currentMomentum MUITO POSITIVO  → symbol1 disparou vs symbol2 (ratio subiu forte)
    //   → symbol1 está CARO, symbol2 está BARATO
    //   → Operação: VENDER (SHORT) symbol1 e COMPRAR (LONG) symbol2
    // - currentMomentum MUITO NEGATIVO → symbol1 afundou vs symbol2 (ratio caiu forte)
    //   → symbol1 está BARATO, symbol2 está CARO
    //   → Operação: COMPRAR (LONG) symbol1 e VENDER (SHORT) symbol2
    //
    // Assim garantimos que, quando o momentum volta em direção à média, o PnL tende a AUMENTAR.
    const longSymbol = currentMomentum > 0 ? symbol2 : symbol1;
    const shortSymbol = currentMomentum > 0 ? symbol1 : symbol2;

    return {
      id: `${longSymbol}-${shortSymbol}-${Date.now()}`,
      longSymbol,
      shortSymbol,
      strategy,
      zScore,
      correlation,
      correlation5d,
      correlation25d,
      correlation2m,
      momentumAge: momentumAgeMinutes,
      currentMomentum,
      avgBullish,
      avgBearish,
      liquidityRatio,
      message,
      timestamp: new Date().toISOString(),
      status,
      pendingReason,
    };
  } catch (error) {
    console.error(`❌ Erro ao analisar par ${symbol1}/${symbol2}:`, error);
    return null;
  }
}

// Scan all pairs
async function scanAllPairs(): Promise<TradingSignal[]> {
  const signals: TradingSignal[] = [];
  const pairs = ALL_CRYPTO_PAIRS;

  console.log("🔍 Iniciando escaneamento de", pairs.length, "moedas...");
  console.log("📊 Buscando dados de todos os símbolos em paralelo...");

  // Fetch all data in parallel (3 requests per symbol = 60 total requests)
  const dataPromises = pairs.map(symbol => fetchKlinesForSymbol(symbol));
  const allData = await Promise.all(dataPromises);
  
  // Create a map of symbol -> data
  const dataMap: Map<string, { klines1h: number[][]; klines30m: number[][]; currentPrice: number }> = new Map();
  
  for (let i = 0; i < pairs.length; i++) {
    if (allData[i]) {
      dataMap.set(pairs[i], allData[i]!);
    }
  }
  
  console.log(`✅ Dados obtidos para ${dataMap.size}/${pairs.length} símbolos`);

  // Create all pair combinations and analyze
  for (let i = 0; i < pairs.length; i++) {
    for (let j = i + 1; j < pairs.length; j++) {
      const symbol1 = pairs[i];
      const symbol2 = pairs[j];
      const data1 = dataMap.get(symbol1);
      const data2 = dataMap.get(symbol2);
      
      if (data1 && data2) {
        const result = analyzePairFromData(symbol1, symbol2, data1, data2);
        if (result) {
          signals.push(result);
        }
      }
    }
  }

  // Sort by average correlation (highest first)
  // Primary: average correlation, Secondary: minimum correlation consistency
  signals.sort((a, b) => {
    // Compare average correlation first
    if (b.correlation !== a.correlation) {
      return b.correlation - a.correlation;
    }
    // If equal, compare minimum correlation (consistency)
    const minCorrA = Math.min(a.correlation5d, a.correlation25d, a.correlation2m);
    const minCorrB = Math.min(b.correlation5d, b.correlation25d, b.correlation2m);
    return minCorrB - minCorrA;
  });

  console.log("✅ Escaneamento concluído!", signals.length, "sinais encontrados");
  
  return signals;
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("🚀 Pair Scanner iniciado");
    
    const signals = await scanAllPairs();
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        signals,
        scannedAt: new Date().toISOString(),
        totalPairs: ALL_CRYPTO_PAIRS.length,
        totalCombinations: (ALL_CRYPTO_PAIRS.length * (ALL_CRYPTO_PAIRS.length - 1)) / 2
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    );
  } catch (error) {
    console.error("❌ Erro no pair scanner:", error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : "Unknown error" 
      }),
      { 
        status: 500,
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    );
  }
});
