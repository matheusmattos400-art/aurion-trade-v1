-- Ativar realtime para active_operations
ALTER PUBLICATION supabase_realtime ADD TABLE public.active_operations;