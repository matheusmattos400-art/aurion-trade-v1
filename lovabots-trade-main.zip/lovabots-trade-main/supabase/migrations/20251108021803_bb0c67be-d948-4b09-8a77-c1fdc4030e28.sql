-- Enable pgcrypto extension for encryption
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Replace encryption function to use pgcrypto instead of pgsodium
CREATE OR REPLACE FUNCTION public.encrypt_credential(credential text, key_id uuid)
RETURNS bytea
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Use pgcrypto for encryption with AES
  RETURN pgp_sym_encrypt(credential, key_id::text);
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'Encryption error: %', SQLERRM;
  RAISE EXCEPTION 'Falha na criptografia: %', SQLERRM;
END;
$function$;

-- Replace decryption function to use pgcrypto
CREATE OR REPLACE FUNCTION public.decrypt_credential(encrypted_data bytea, key_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN pgp_sym_decrypt(encrypted_data, key_id::text);
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'Decryption error: %', SQLERRM;
  RAISE EXCEPTION 'Falha na descriptografia: %', SQLERRM;
END;
$function$;