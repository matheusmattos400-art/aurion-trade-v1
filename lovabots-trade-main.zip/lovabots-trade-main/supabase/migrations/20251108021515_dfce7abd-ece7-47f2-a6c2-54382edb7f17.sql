-- Simplify encryption to use a fixed approach
CREATE OR REPLACE FUNCTION public.encrypt_credential(credential text, key_id uuid)
RETURNS bytea
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  encrypted BYTEA;
BEGIN
  -- Use pgsodium to encrypt with the provided key_id
  encrypted := pgsodium.crypto_aead_det_encrypt(
    convert_to(credential, 'utf8'),
    convert_to('additional_data', 'utf8'),
    key_id::UUID,
    NULL
  );
  RETURN encrypted;
EXCEPTION WHEN OTHERS THEN
  -- Log the actual error for debugging
  RAISE LOG 'Encryption error: %', SQLERRM;
  RAISE EXCEPTION 'Falha na criptografia: %', SQLERRM;
END;
$function$;

-- Update decrypt function with better error handling
CREATE OR REPLACE FUNCTION public.decrypt_credential(encrypted_data bytea, key_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  decrypted BYTEA;
BEGIN
  decrypted := pgsodium.crypto_aead_det_decrypt(
    encrypted_data,
    convert_to('additional_data', 'utf8'),
    key_id::UUID,
    NULL
  );
  RETURN convert_from(decrypted, 'utf8');
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'Decryption error: %', SQLERRM;
  RAISE EXCEPTION 'Falha na descriptografia: %', SQLERRM;
END;
$function$;