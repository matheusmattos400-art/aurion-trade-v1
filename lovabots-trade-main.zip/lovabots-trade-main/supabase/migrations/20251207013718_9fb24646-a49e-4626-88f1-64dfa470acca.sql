-- Tabela para armazenar momentum histórico (nunca recalculado)
CREATE TABLE public.momentum_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  long_symbol TEXT NOT NULL,
  short_symbol TEXT NOT NULL,
  timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
  momentum NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, long_symbol, short_symbol, timestamp)
);

-- Enable RLS
ALTER TABLE public.momentum_history ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view their own momentum history" 
ON public.momentum_history 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own momentum history" 
ON public.momentum_history 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own momentum history" 
ON public.momentum_history 
FOR DELETE 
USING (auth.uid() = user_id);

-- Adicionar coluna entry_momentum na tabela active_operations
ALTER TABLE public.active_operations 
ADD COLUMN entry_momentum NUMERIC DEFAULT NULL;