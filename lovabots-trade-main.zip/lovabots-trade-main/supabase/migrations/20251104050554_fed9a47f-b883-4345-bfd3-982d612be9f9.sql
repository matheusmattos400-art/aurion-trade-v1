-- Adicionar campos para preços de entrada na tabela active_operations
ALTER TABLE public.active_operations 
ADD COLUMN entry_price_long numeric,
ADD COLUMN entry_price_short numeric;