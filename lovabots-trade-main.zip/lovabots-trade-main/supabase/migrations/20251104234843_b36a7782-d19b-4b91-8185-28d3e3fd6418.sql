-- Criar tabela para armazenar totais acumulados de lucro
CREATE TABLE IF NOT EXISTS public.profit_totals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  total_profit NUMERIC NOT NULL DEFAULT 0,
  last_reset_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.profit_totals ENABLE ROW LEVEL SECURITY;

-- Criar políticas de segurança
CREATE POLICY "Users can view their own profit totals"
ON public.profit_totals
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profit totals"
ON public.profit_totals
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profit totals"
ON public.profit_totals
FOR UPDATE
USING (auth.uid() = user_id);

-- Criar trigger para atualizar updated_at
CREATE TRIGGER update_profit_totals_updated_at
BEFORE UPDATE ON public.profit_totals
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();