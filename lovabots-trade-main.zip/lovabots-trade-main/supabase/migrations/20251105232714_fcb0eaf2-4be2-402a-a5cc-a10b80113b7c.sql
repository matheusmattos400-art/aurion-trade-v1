-- Adicionar política DELETE para permitir que usuários apaguem seu próprio histórico
CREATE POLICY "Users can delete their own trade history"
ON public.trade_history
FOR DELETE
USING (auth.uid() = user_id);