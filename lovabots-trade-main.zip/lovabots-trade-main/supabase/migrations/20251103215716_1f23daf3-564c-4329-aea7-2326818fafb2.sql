-- Table for storing Binance API credentials (encrypted)
CREATE TABLE public.binance_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  api_key TEXT NOT NULL,
  api_secret TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.binance_credentials ENABLE ROW LEVEL SECURITY;

-- RLS Policies for credentials
CREATE POLICY "Users can view their own credentials"
  ON public.binance_credentials FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own credentials"
  ON public.binance_credentials FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own credentials"
  ON public.binance_credentials FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own credentials"
  ON public.binance_credentials FOR DELETE
  USING (auth.uid() = user_id);

-- Table for trade history
CREATE TABLE public.trade_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  long_symbol TEXT NOT NULL,
  short_symbol TEXT NOT NULL,
  leverage INTEGER NOT NULL,
  investment_amount DECIMAL(20, 8) NOT NULL,
  profit DECIMAL(20, 8) NOT NULL,
  duration_seconds INTEGER NOT NULL,
  started_at TIMESTAMP WITH TIME ZONE NOT NULL,
  ended_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.trade_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies for trade history
CREATE POLICY "Users can view their own trade history"
  ON public.trade_history FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own trades"
  ON public.trade_history FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Table for active operations
CREATE TABLE public.active_operations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  long_symbol TEXT NOT NULL,
  short_symbol TEXT NOT NULL,
  leverage INTEGER NOT NULL,
  investment_amount DECIMAL(20, 8) NOT NULL,
  long_order_id TEXT,
  short_order_id TEXT,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'monitoring', 'closing', 'closed')),
  current_pnl DECIMAL(20, 8) DEFAULT 0,
  started_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.active_operations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for active operations
CREATE POLICY "Users can view their own operations"
  ON public.active_operations FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own operations"
  ON public.active_operations FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own operations"
  ON public.active_operations FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own operations"
  ON public.active_operations FOR DELETE
  USING (auth.uid() = user_id);

-- Trigger for updating updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_binance_credentials_updated_at
  BEFORE UPDATE ON public.binance_credentials
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_active_operations_updated_at
  BEFORE UPDATE ON public.active_operations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();