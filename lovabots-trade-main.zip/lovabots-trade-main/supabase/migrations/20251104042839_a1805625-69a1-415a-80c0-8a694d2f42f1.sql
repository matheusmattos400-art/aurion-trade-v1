-- Adicionar colunas para armazenar os profit targets na tabela active_operations
ALTER TABLE active_operations 
ADD COLUMN IF NOT EXISTS profit_target_1 numeric DEFAULT 10,
ADD COLUMN IF NOT EXISTS profit_target_2 numeric DEFAULT 7,
ADD COLUMN IF NOT EXISTS profit_target_3 numeric DEFAULT 5,
ADD COLUMN IF NOT EXISTS profit_target_4 numeric DEFAULT 3;