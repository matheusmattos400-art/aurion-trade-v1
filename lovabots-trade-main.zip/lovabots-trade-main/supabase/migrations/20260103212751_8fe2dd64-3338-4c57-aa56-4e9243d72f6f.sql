-- Create table for Aurion simulated trades
CREATE TABLE public.aurion_simulated_trades (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  trade_id TEXT NOT NULL,
  token_data JSONB NOT NULL,
  entry_price NUMERIC NOT NULL,
  entry_time BIGINT NOT NULL,
  exit_price NUMERIC,
  exit_time BIGINT,
  pnl_percent NUMERIC,
  pnl_usd NUMERIC,
  status TEXT NOT NULL DEFAULT 'open',
  chandelier_exit_price NUMERIC,
  investment_amount NUMERIC DEFAULT 100,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, trade_id)
);

-- Enable Row Level Security
ALTER TABLE public.aurion_simulated_trades ENABLE ROW LEVEL SECURITY;

-- Create policies for user access
CREATE POLICY "Users can view their own trades" 
ON public.aurion_simulated_trades 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own trades" 
ON public.aurion_simulated_trades 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own trades" 
ON public.aurion_simulated_trades 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own trades" 
ON public.aurion_simulated_trades 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_aurion_trades_updated_at
BEFORE UPDATE ON public.aurion_simulated_trades
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();