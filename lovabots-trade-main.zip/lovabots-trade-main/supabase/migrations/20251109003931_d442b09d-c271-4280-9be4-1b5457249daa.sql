-- Remove encryption functions
DROP FUNCTION IF EXISTS public.encrypt_credential(text, uuid);
DROP FUNCTION IF EXISTS public.decrypt_credential(bytea, uuid);

-- Drop encrypted_credentials table
DROP TABLE IF EXISTS public.encrypted_credentials;