-- Adicionar campo para identificar o modo de negociação (B3 ou Crypto)
ALTER TABLE public.active_operations 
ADD COLUMN trading_mode text NOT NULL DEFAULT 'crypto';

-- Adicionar constraint para validar valores
ALTER TABLE public.active_operations 
ADD CONSTRAINT active_operations_trading_mode_check 
CHECK (trading_mode IN ('crypto', 'b3'));