-- Adicionar campos para rastrear o estado de cada posição individualmente
ALTER TABLE public.active_operations 
ADD COLUMN IF NOT EXISTS long_closed boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS short_closed boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS long_close_pnl numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS short_close_pnl numeric DEFAULT 0;