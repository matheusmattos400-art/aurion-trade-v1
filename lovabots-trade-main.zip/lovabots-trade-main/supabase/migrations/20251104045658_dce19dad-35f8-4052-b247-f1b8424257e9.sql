-- Enable pgsodium extension for encryption
CREATE EXTENSION IF NOT EXISTS pgsodium;

-- Create encrypted_credentials table to store API keys securely
CREATE TABLE IF NOT EXISTS public.encrypted_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  api_key_encrypted BYTEA NOT NULL,
  api_secret_encrypted BYTEA NOT NULL,
  key_id UUID NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE public.encrypted_credentials ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Users can view their own encrypted credentials"
  ON public.encrypted_credentials
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own encrypted credentials"
  ON public.encrypted_credentials
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own encrypted credentials"
  ON public.encrypted_credentials
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own encrypted credentials"
  ON public.encrypted_credentials
  FOR DELETE
  USING (auth.uid() = user_id);

-- Create function to encrypt data
CREATE OR REPLACE FUNCTION public.encrypt_credential(credential TEXT, key_id UUID)
RETURNS BYTEA
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  encrypted BYTEA;
BEGIN
  -- Use pgsodium to encrypt the credential
  encrypted := pgsodium.crypto_aead_det_encrypt(
    convert_to(credential, 'utf8'),
    convert_to('', 'utf8'),
    key_id::UUID,
    NULL
  );
  RETURN encrypted;
END;
$$;

-- Create function to decrypt data (only callable by authenticated users for their own data)
CREATE OR REPLACE FUNCTION public.decrypt_credential(encrypted_data BYTEA, key_id UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  decrypted BYTEA;
BEGIN
  -- Use pgsodium to decrypt the credential
  decrypted := pgsodium.crypto_aead_det_decrypt(
    encrypted_data,
    convert_to('', 'utf8'),
    key_id::UUID,
    NULL
  );
  RETURN convert_from(decrypted, 'utf8');
END;
$$;

-- Migrate existing data from binance_credentials to encrypted_credentials
DO $$
DECLARE
  rec RECORD;
  new_key_id UUID;
BEGIN
  FOR rec IN SELECT * FROM public.binance_credentials LOOP
    -- Generate a new key for each user
    new_key_id := gen_random_uuid();
    
    -- Insert encrypted credentials
    INSERT INTO public.encrypted_credentials (
      user_id,
      api_key_encrypted,
      api_secret_encrypted,
      key_id,
      created_at,
      updated_at
    ) VALUES (
      rec.user_id,
      public.encrypt_credential(rec.api_key, new_key_id),
      public.encrypt_credential(rec.api_secret, new_key_id),
      new_key_id,
      rec.created_at,
      rec.updated_at
    )
    ON CONFLICT (user_id) DO NOTHING;
  END LOOP;
END $$;

-- Add trigger for updated_at
CREATE TRIGGER update_encrypted_credentials_updated_at
  BEFORE UPDATE ON public.encrypted_credentials
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Drop old table (commenting out for safety - uncomment after verifying migration)
-- DROP TABLE IF EXISTS public.binance_credentials;