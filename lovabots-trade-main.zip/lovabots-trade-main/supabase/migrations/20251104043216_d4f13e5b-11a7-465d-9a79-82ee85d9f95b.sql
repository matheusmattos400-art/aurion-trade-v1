-- Remover colunas de profit targets múltiplos e adicionar um único alvo
ALTER TABLE active_operations 
DROP COLUMN IF EXISTS profit_target_1,
DROP COLUMN IF EXISTS profit_target_2,
DROP COLUMN IF EXISTS profit_target_3,
DROP COLUMN IF EXISTS profit_target_4,
ADD COLUMN IF NOT EXISTS profit_target numeric DEFAULT 10,
ADD COLUMN IF NOT EXISTS auto_close_enabled boolean DEFAULT true;