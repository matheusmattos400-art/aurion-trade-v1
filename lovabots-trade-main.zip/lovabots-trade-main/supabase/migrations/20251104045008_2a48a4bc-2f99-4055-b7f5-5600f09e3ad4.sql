-- Adicionar campo para marcar operações de teste
ALTER TABLE active_operations 
ADD COLUMN is_test boolean DEFAULT false;

-- Adicionar campo no histórico também
ALTER TABLE trade_history 
ADD COLUMN is_test boolean DEFAULT false;