-- Enable realtime for trade_history table
ALTER PUBLICATION supabase_realtime ADD TABLE public.trade_history;