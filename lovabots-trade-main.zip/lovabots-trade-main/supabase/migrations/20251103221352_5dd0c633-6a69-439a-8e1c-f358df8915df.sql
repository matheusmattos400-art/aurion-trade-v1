-- Add individual leverage columns to active_operations
ALTER TABLE public.active_operations 
ADD COLUMN leverage_long integer,
ADD COLUMN leverage_short integer;

-- Copy existing leverage values to both columns for existing records
UPDATE public.active_operations 
SET leverage_long = leverage, leverage_short = leverage
WHERE leverage_long IS NULL OR leverage_short IS NULL;

-- Make the new columns NOT NULL after copying data
ALTER TABLE public.active_operations 
ALTER COLUMN leverage_long SET NOT NULL,
ALTER COLUMN leverage_short SET NOT NULL;

-- Add individual leverage columns to trade_history
ALTER TABLE public.trade_history
ADD COLUMN leverage_long integer,
ADD COLUMN leverage_short integer;

-- Copy existing leverage values to both columns for existing records
UPDATE public.trade_history
SET leverage_long = leverage, leverage_short = leverage
WHERE leverage_long IS NULL OR leverage_short IS NULL;

-- Make the new columns NOT NULL after copying data
ALTER TABLE public.trade_history
ALTER COLUMN leverage_long SET NOT NULL,
ALTER COLUMN leverage_short SET NOT NULL;