-- Add columns to store custom limit order information
ALTER TABLE public.active_operations 
ADD COLUMN IF NOT EXISTS custom_order_id text,
ADD COLUMN IF NOT EXISTS custom_order_price numeric,
ADD COLUMN IF NOT EXISTS custom_order_created boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS limit_order_id text,
ADD COLUMN IF NOT EXISTS limit_order_created boolean DEFAULT false;