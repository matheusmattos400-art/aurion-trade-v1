-- Adicionar campos para persistir estado do modo automático
ALTER TABLE active_operations 
ADD COLUMN IF NOT EXISTS auto_mode_enabled boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS auto_mode_target integer,
ADD COLUMN IF NOT EXISTS auto_mode_completed integer DEFAULT 0,
ADD COLUMN IF NOT EXISTS auto_mode_is_test boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS auto_mode_paused boolean DEFAULT false;